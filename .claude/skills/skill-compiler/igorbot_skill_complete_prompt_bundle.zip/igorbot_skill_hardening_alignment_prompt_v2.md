# IgorBot Skill Hardening Alignment Prompt — Revised

```yaml
followup_prompt:
  id: igorbot_skill_hardening_alignment_prompt_v2
  role: senior_skill_alignment_and_hardening_agent

  objective: >
    Execute a recursive multi-pass alignment, completeness, correctness, and
    hardening review of the IgorBot Skill design package. Output the complete
    deployment-ready hardened version with all required Skill files, user guide,
    AWS Secrets Manager setup commands, approval checkpoints, validation steps,
    troubleshooting guidance, ongoing Skill compliance process, Skill versioning
    update process, manifest, changelog, and downloadable zip output contract.

  target:
    skill_name: igorbot-operator
    repository: https://github.com/cryptoxdog/igorbot
    aws_secret_prefix: openclaw-igorbot/
    final_skill_package_name: skill.zip
    design_pack_zip_name: igorbot_operator_skill_design_pack.zip

  hard_rules:
    - do_not_execute_repo_changes
    - do_not_create_real_secrets
    - do_not_print_secret_values
    - do_not_invent_secret_values
    - do_not_leave_placeholders_except_REPLACE_ME_inside_safe_AWS_examples
    - all_secret_names_must_start_with_openclaw_igorbot/
    - every_required_secret_must_have_AWS_create_secret_command
    - every_agent_pause_point_must_be_documented
    - every_reference_file_must_be_linked_from_SKILL_md
    - SKILL_md_must_remain_control_plane_only
    - long_detail_goes_to_references
    - deterministic_validation_scripts_only
    - ongoing_compliance_frequency_must_be_user_selected
    - ongoing_compliance_must_report_only_by_default
    - skill_updates_must_include_changelog_and_validation
    - final_output_must_define_downloadable_zip_contents
    - zero_stubs
    - zero_TODOs
    - zero_unlinked_files

  recursive_passes:
    pass_1_scope_alignment:
      verify:
        - user_requested_compile_not_execution
        - target_is_skill_design_package
        - repo_is_cryptoxdog_igorbot
        - aws_secret_prefix_is_openclaw_igorbot/
        - final_output_is_downloadable_zip
    pass_2_file_completeness:
      verify:
        - all_required_skill_files_exist
        - each_file_has_complete_content
        - each_file_has_clear_purpose
        - no_duplicate_reference_files
        - no_unlinked_reference_files
    pass_3_credential_hardening:
      verify:
        - every_credential_has_secret_name
        - every_secret_name_uses_openclaw_igorbot_prefix
        - every_credential_has_purpose
        - every_credential_has_JSON_schema
        - every_credential_has_AWS_CLI_command
        - every_credential_has_validation_method
        - no_secret_values_present
    pass_4_user_guide_hardening:
      verify:
        - full_secret_creation_commands
        - credential_JSON_payload_shapes
        - user_decision_points
        - deployment_steps
        - validation_steps
        - ongoing_compliance_setup
        - skill_versioning_and_updates
        - rollback_steps
    pass_5_agent_pause_points:
      verify:
        - each_pause_has_trigger
        - each_pause_has_required_user_input
        - each_pause_has_allowed_responses
        - each_pause_has_consequence_if_skipped
    pass_6_ongoing_compliance_alignment:
      verify:
        - compliance_schedule_is_user_selected
        - no_hardcoded_frequency
        - cron_or_schedule_reports_only_by_default
        - compliance_does_not_modify_repo
        - compliance_does_not_rotate_secrets
        - compliance_does_not_deploy
        - compliance_does_not_send_live_messages
        - compliance_escalates_required_actions_to_user
    pass_7_versioning_alignment:
      verify:
        - CHANGELOG.md_exists
        - versioning_process_exists
        - semantic_versioning_rules_defined
        - update_triggers_defined
        - credential_schema_change_review_required
        - package_final_skill_as_skill_zip
        - previous_working_version_preserved_until_new_version_validates
    pass_8_validation_and_scripts:
      verify:
        - validate_secret_names_py_present
        - check_required_env_py_present
        - render_credential_report_py_present
        - scripts_never_print_secret_values
    pass_9_skill_packaging_alignment:
      verify:
        - SKILL_md_frontmatter_has_only_name_and_description
        - skill_name_is_lowercase_hyphenated
        - agents_openai_yaml_exists
        - all_files_fit_under_25MB
        - package_name_is_skill.zip
        - manifest_matches_file_tree
    pass_10_final_correctness:
      verify:
        - no_old_credential_prefixes
        - no_secret_values
        - no_TODO
        - no_placeholder_except_REPLACE_ME_inside_safe_AWS_examples
        - no_claims_of_execution
        - no_repo_changes
        - all_unknowns_labeled
        - complete_downloadable_zip_contract_present

  final_output_required:
    - complete_hardened_compiled_prompt
    - complete_file_tree
    - complete_required_file_contents
    - AWS_secret_creation_commands
    - user_approval_checkpoint_table
    - ongoing_skill_compliance_process
    - skill_versioning_update_process
    - validation_commands
    - packaging_instructions
    - downloadable_zip_output_contract
    - final_DoD
    - convergence_block

  convergence_block:
    required: true
    fields:
      convergence_status: converged | partial | blocked
      recursive_passes_run: 10
      same_output_after_multiple_passes: true_or_false
      completeness_status: pass | partial | fail
      correctness_status: pass | partial | fail
      credential_naming_status: pass | partial | fail
      ongoing_compliance_status: pass | partial | fail
      versioning_status: pass | partial | fail
      zero_stub_status: pass | partial | fail
      downloadable_zip_status: pass | partial | fail
      remaining_unknowns: []
```
