# IgorBot Skill Complete Prompt Bundle

Generated: 2026-06-01 20:09:54

## Contents

1. `igorbot_skill_builder_compiled_prompt_v2_hardened.md`
2. `igorbot_skill_hardening_alignment_prompt_v2.md`
3. `igorbot_skill_pack_leverage_audit_followup_prompt.md`
4. `igorbot_skill_pack_final_artifact_builder_followup_prompt.md`

## Purpose

Complete prompt bundle for designing, hardening, leverage-auditing, and finally generating the IgorBot Operator Skill package.

## Credential Naming Rule

```text
openclaw-igorbot/CREDENTIAL_NAME
```

## Usage Order

1. Run the builder prompt.
2. Run the hardening alignment prompt.
3. Run the leverage audit prompt.
4. Run the final artifact builder prompt.
