# IgorBot Skill Pack Leverage Audit Follow-Up Prompt

```yaml
followup_prompt_1:
  id: igorbot_skill_pack_leverage_audit_v1
  role: senior_skill_leverage_auditor

  objective: >
    Audit the revised IgorBot Skill prompt pack for compounding leverage.
    Identify which parts improve future actions, reduce future user work,
    strengthen reusable assets, and prevent recurring operational drag.

  instructions:
    - read the full revised prompt pack
    - score each major component using the leverage kernel
    - identify weak or one-time-only sections
    - recommend only changes that increase reusable value
    - do not add complexity unless it improves future execution
    - preserve compiler-only scope
    - preserve openclaw-igorbot credential naming

  leverage_scoring_basis:
    scale:
      0: no leverage
      1: one-time local benefit
      2: repeatable personal benefit
      3: reusable across multiple situations
      4: accelerates a class of future actions
      5: compounding multiplier across domains
    approve_minimum: 3.5
    prioritize_minimum: 4.0

  required_output:
    - leverage_score_by_section
    - highest_leverage_components
    - low_leverage_components_to_cut_or_merge
    - missing_reusable_assets
    - recurring_drag_risks
    - top_5_improvements
    - revised_file_plan_if_needed
    - convergence_block
```
