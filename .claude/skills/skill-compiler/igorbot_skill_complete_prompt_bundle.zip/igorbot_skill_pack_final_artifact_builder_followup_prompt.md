# IgorBot Skill Pack Final Artifact Builder Follow-Up Prompt

```yaml
followup_prompt_2:
  id: igorbot_skill_pack_final_artifact_builder_v1
  role: skill_pack_artifact_builder

  objective: >
    Using the hardened IgorBot Skill prompt pack and leverage audit, generate the
    final deployment-ready Skill design package as downloadable files. Include
    all Skill files, references, scripts, manifest, changelog, user guide, AWS
    credential commands, approval points, compliance guidance, and versioning
    process.

  instructions:
    - build the complete igorbot-operator Skill folder
    - keep SKILL.md compact
    - move long guidance into references/
    - include all AWS Secrets Manager commands
    - include user-selected ongoing compliance schedule guidance
    - include versioning and update process
    - include validation scripts
    - include manifest and README
    - package design pack as igorbot_operator_skill_design_pack.zip
    - package deployable Skill as skill.zip only if explicitly requested

  required_output:
    - downloadable_zip_link
    - file_tree
    - credential_command_summary
    - approval_checkpoint_summary
    - validation_commands
    - unresolved_unknowns
    - convergence_block
```
