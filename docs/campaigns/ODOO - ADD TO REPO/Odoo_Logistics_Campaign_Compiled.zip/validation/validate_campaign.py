#!/usr/bin/env python3
"""Read-only, deterministic validation of the compiled logistics candidate pack.

This validates structure, references, domain boundary and package bytes, not Odoo execution.
"""
from __future__ import annotations
import argparse,csv,copy,hashlib,json,re,sys,zipfile
from pathlib import Path

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def uniq(xs,k,errors):
 vals=[x[k] for x in xs]
 if len(vals)!=len(set(vals)):errors.append('duplicate '+k)
 return set(vals)
def check_content(C,R,OWN,S,origF,origH,origC,loc):
 e=[]
 try:
  import jsonschema
  jsonschema.validate(instance=C,schema=read(loc/'validation/campaign.schema.json'))
 except ImportError:e.append('SCHEMA_UNVERIFIED: jsonschema unavailable')
 except Exception as exc:e.append('schema invalid: '+str(exc)[:160])
 rr=C.get('requirements',[]);rids=uniq(rr,'requirement_id',e);hids=uniq(rr,'harvest_id',e)
 ids=uniq(R,'rule_id',e);ownids=uniq(OWN,'brs_id',e)
 policyids=uniq(C.get('policies',[]),'policy_id',e)
 nodes=C.get('nodes',[]);nids=uniq(nodes,'node_id',e)
 acc=C.get('acceptance',[]);aids=uniq(acc,'acceptance_id',e)
 fids=uniq(C.get('findings',[]),'finding_id',e)
 slices=C.get('slices',[]);sids=uniq(slices,'slice_id',e)
 srcids={s['source_id'] for s in S}
 origids={r['harvest_id'] for r in origH}
 if hids!=origids:e.append('harvest coverage differs from original (missing/extra H rows)')
 if fids!={f['finding_id'] for f in origF}:e.append('finding identities differ from original')
 if {c['conflict_id'] for c in C.get('conflicts',[])}!={c['conflict_id'] for c in origC}:e.append('donor conflict identities differ from original')
 if policyids!=ids:e.append('policy IDs not exactly rule IDs')
 if {x['rule_id'] for x in R}!={x['policy_id'] for x in C['policies']}:e.append('policy/rule mismatch')
 origby={h['harvest_id']:h for h in origH}
 rulesby={r['rule_id']:r for r in R}
 owner_by={r['brs_id']:r for r in OWN}
 reqby={r['requirement_id']:r for r in rr}
 for r in rr:
  h=origby.get(r['harvest_id']);rid=r['requirement_id']
  if not h:continue
  if h['selected_contract']!=r.get('assertion'):e.append(rid+' source meaning changed')
  if h['title']!=r.get('title'):e.append(rid+' source title changed')
  if set(h['donor_evidence']+h['target_evidence'])!=set(r['source_refs']):e.append(rid+' source refs changed')
  if not r.get('source_refs') or not set(r['source_refs']) <= srcids:e.append(rid+' source reference unresolved')
  if not r.get('acceptance_ids') or not set(r['acceptance_ids']) <= aids:e.append(rid+' acceptance unresolved')
  if r['slice_id'] not in sids:e.append(rid+' slice missing')
  if r.get('authoritative_business_concern') not in (None,*ownids):e.append(rid+' unknown BRS owner')
  if r.get('status')=='IMPLEMENTED' or r.get('operator_acceptance')=='REPOSITORY_ADMITTED':e.append(rid+' false admission or execution')
 for r in R:
  name=r['rule_id'];rid=r['requirement_id']
  if rid not in rids or r['family_id'] not in ownids:e.append(name+' owner or requirement unresolved')
  if not r.get('evidence_ids') or not set(r['evidence_ids'])<=srcids:e.append(name+' evidence unresolved')
  if not r.get('tests') or not set(r['tests'])<=aids:e.append(name+' cases unresolved')
  if r['normative_source_statement']!=reqby[rid]['assertion']:e.append(name+' duplicate normative definition changed')
  if r['admission'] not in ('EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN','CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW','PENDING_EXPLICIT_POLICY_APPROVAL'):e.append(name+' ungrounded admission')
  if r['disposition']!='REJECT' and re.search(r'\b(?:n8n|supabase|openclaw)\b',r['normative_source_statement'],re.I):e.append(name+' unrelated runtime in active candidate business rule')
 for owner in OWN:
  if set(owner['rules'])!={r['rule_id'] for r in R if r['family_id']==owner['brs_id']}:e.append(owner['brs_id']+' rule ownership mismatch')
  if owner['registration']!='NOT_REGISTERED':e.append(owner['brs_id']+' false rule registration')
 for p in C['policies']:
  v=rulesby.get(p['policy_id']);
  if v is None or v['family_id']!=p['family_owner'] or v['requirement_id']!=p['source_requirement']:e.append('policy pointer mismatch '+p['policy_id'])
 for a in acc:
  aid=a['acceptance_id']
  if not a['requirement_ids'] or not set(a['requirement_ids'])<=rids:e.append(aid+' requirement orphan')
  if not a['work_package_ids'] or not set(a['work_package_ids'])<=nids:e.append(aid+' WP orphan')
  if not set(a.get('rule_ids',[]))<=ids:e.append(aid+' rule orphan')
  if not a.get('source_refs') or not set(a['source_refs'])<=srcids:e.append(aid+' source orphan')
  if not a.get('expected_observation'):e.append(aid+' empty exit')
  if a['execution_result'] not in ('NOT_RUN','PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION'):e.append(aid+' invented runtime pass')
 for n in nodes:
  nid=n['node_id'];deps=n['dependencies']
  if not set(deps)<=nids:e.append(nid+' unknown dependency')
  if nid in deps:e.append(nid+' depends on itself')
  if not n['requirement_ids'] or not set(n['requirement_ids'])<=rids:e.append(nid+' requirement orphan')
  if not n['acceptance_ids'] or not set(n['acceptance_ids'])<=aids:e.append(nid+' acceptance orphan')
  if not n.get('observed_exit_criterion'):e.append(nid+' no exit criterion')
  if n['stage_id'] not in sids:e.append(nid+' no stage')
  if n['implementation_authority'] not in ('READ_ONLY_PREFLIGHT','NOT_GRANTED'):e.append(nid+' unapproved mutation authority')
 edgetuples={(x['from'],x['to']) for x in C['edges']}
 depedges={(d,n['node_id']) for n in nodes for d in n['dependencies']}
 if edgetuples!=depedges:e.append('edges disagree with node dependencies')
 if len(edgetuples)!=len(C['edges']):e.append('duplicate graph edges')
 topo={n['node_id']:set(n['dependencies']) for n in nodes}
 ordered=[]
 while topo:
  avail=sorted(k for k,v in topo.items() if not v)
  if not avail:e.append('dependency graph has cycle');break
  for v in avail:ordered.append(v);topo.pop(v)
  for deps in topo.values():deps.difference_update(avail)
 for stage in slices:
  if set(stage['node_ids'])!={n['node_id'] for n in nodes if n['stage_id']==stage['slice_id']}:e.append(stage['slice_id']+' stage node projection mismatch')
 for f in C['findings']:
  fid=f['finding_id']
  if not set(f['requirement_ids'])<=rids or not f['requirement_ids']:e.append(fid+' requirements unresolved')
  if not set(f['acceptance_ids'])<=aids or not f['acceptance_ids']:e.append(fid+' cases unresolved')
  if not set(f['work_packages'])<=nids or not f['work_packages']:e.append(fid+' package unresolved')
  if f['implementation_status']!='OPEN_NOT_EXECUTED' or f.get('closing_evidence') is not None:e.append(fid+' falsely closed')
 for d in C['decisions']:
  if d.get('approved_option') is not None or d.get('status')!='PENDING_OWNER_DECISION':e.append(d['decision_id']+' invented owner approval')
 for un in C['unknowns']:
  if un.get('status')!='UNKNOWN':e.append(un['unknown_id']+' unknown suppressed')
 # Strict known-nonlogistics leakage guard across every generated semantic slot.
 # The exact foreign-domain exclusion set cannot be established until its separate reference archive arrives.
 unrelated=re.compile(r'(?i)\b(?:passport renewal|tax return filing|criminal defense|court hearing|divorce agreement|voter registration|stock market trading|medical patient|applicant interview|supabase tax ledger|semgrep sdk release)\b')
 slots=[]
 for x in C['requirements']:slots.extend([('requirement '+x['requirement_id'],x['title']),('requirement contract '+x['requirement_id'],x['assertion'])])
 for x in R:slots.extend([('rule '+x['rule_id'],x['title']),('rule contract '+x['rule_id'],x['normative_source_statement'])])
 for x in C['nodes']:slots.extend([('work package '+x['node_id'],x['title']),('work package exit '+x['node_id'],x['observed_exit_criterion'])])
 for x in C['acceptance']:slots.extend([('acceptance '+x['acceptance_id'],x['title']),('given '+x['acceptance_id'],x['given']),('when '+x['acceptance_id'],x['when']),('expected '+x['acceptance_id'],x['expected_observation'])])
 for x in C['decisions']:slots.extend([('decision '+x['decision_id'],x['decision']),('recommendation '+x['decision_id'],x['recommendation'])])
 for x in C['field_mapping']:slots.append(('field role '+x['id'],x['semantic_role']))
 for x in C['slices']:slots.extend([('stage '+x['slice_id'],x['name']),('stage objective '+x['slice_id'],x['objective'])])
 for context,value in slots:
  if unrelated.search(str(value)):e.append('nonlogistics lexical contamination: '+context)
 for x in C['nodes']:
  if any(re.search(r'(?i)(?:^|/)(?:supabase|n8n|openclaw)(?:/|$)',str(path)) for path in x['paths_cited_as_potential_change_targets']):
   e.append('unapproved external execution target: '+x['node_id'])
 if C['authorization'].get('target_mutation')!='NOT_AUTHORIZED':e.append('unapproved target mutation')
 if C['authorization'].get('live_emails')!='NOT_AUTHORIZED':e.append('unapproved external send')
 if C['provenance']['structural_reference'].get('status')!='NOT_SUPPLIED':e.append('missing structural exemplar falsely represented as present')
 if C['provenance']['structural_reference'].get('fidelity')!='UNKNOWN':e.append('false exact exemplar fidelity')
 if C['coverage']['target_runtime_test_status']!='NOT_RUN':e.append('false Odoo runtime acceptance')
 if C['business_rules_binding']['registration_status']!='NOT_REGISTERED_IN_TARGET':e.append('false repo BRS admission')
 if C['provenance']['target']['immutable_revision']!='4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e':e.append('unbound target SHA')
 if len(C['requirements'])!=C['coverage']['harvest_requirements']:e.append('reported requirements count mismatch')
 if len(acc)!=C['coverage']['all_acceptance_cases']:e.append('reported acceptance count mismatch')
 if len(C['findings'])!=C['coverage']['tracked_findings']:e.append('reported findings count mismatch')
 if len(R)!=C['coverage']['candidate_business_rules']:e.append('reported business-rule count mismatch')
 return e,ordered

def validate(root,hashes=True):
 root=Path(root)
 names=['README.md','CAMPAIGN_SPEC.md','ROADMAP.md','LOGISTICS_COVERAGE.md','ACCEPTANCE.md','SOURCES_DECISIONS_AND_GAPS.md','EXECUTION_HANDOFF.md','campaign.json','REGISTRATION_MANIFEST.json','SHA256SUMS.json','FIELD_ROUTING_AND_CONFORMANCE.md','CAMPAIGN_GRAPH.mmd','business_rules/rules.json','business_rules/OWNER_INDEX.json','field_routing.json','validation/campaign.schema.json','validation/STRUCTURAL_FIDELITY.json']
 errors=[]
 for n in names:
  if not (root/n).is_file():errors.append('missing artifact '+n)
 if not hashes:
  errors=[e for e in errors if e!='missing artifact SHA256SUMS.json']
 if errors:return errors,{}
 C=read(root/'campaign.json');R=read(root/'business_rules/rules.json');OWN=read(root/'business_rules/OWNER_INDEX.json');S=read(root/'source_inputs/source_registry_original.json');F=read(root/'source_inputs/findings_original.json')['findings'];H=read(root/'source_inputs/harvest_original.json')['rows'];CON=read(root/'source_inputs/conflicts_original.json')['conflicts'];
 err,order=check_content(C,R,OWN,S,F,H,CON,root);errors+=err
 B=read(root/'source_inputs/SOURCE_BOUNDARY.json')
 if B!=C['provenance']:errors.append('source boundary view diverges from campaign provenance')
 reg=read(root/'REGISTRATION_MANIFEST.json')
 if reg['campaign_id']!=C['campaign_id'] or reg['status']!='CANDIDATE_NOT_REGISTERED':errors.append('registration manifest invalid or wrongly admitted')
 if reg['target']['source_revision']!=C['provenance']['target']['immutable_revision']:errors.append('registration SHA mismatch')
 if set(reg['business_rule_families'])!={o['brs_id'] for o in OWN}:errors.append('registration owner mismatch')
 dref=read(root/'validation/STRUCTURAL_FIDELITY.json')
 if dref['reference_archive_found'] or dref['exact_exemplar_fidelity']!='UNKNOWN':errors.append('unavailable reference portrayed as verified')
 path_refs=read(root/'field_routing.json')
 if path_refs['verified_target_fields']!=C['field_mapping']:errors.append('field routing projection diverges')
 for field in C['field_mapping']:
  if field['technical_identity']:
   if 'blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/' not in field['url'] or not field['source_path']:errors.append(field['id']+' non-bound source coordinate')
  else:
   if field['change_status']!='PROPOSED_GAP_NOT_ADMITTED' or not field['decision_required']:errors.append(field['id']+' invented technical model')
 for f in S:
  if f.get('evidence_class')=='LOCAL_RAW_BYTES' and f.get('evidence_path'):
   pp=root/'source_inputs/local_donor'/Path(f['evidence_path']).name
   if not pp.is_file() or sha(pp)!=f['raw_byte_sha256']:errors.append(f['source_id']+' local donor integrity failure')
 # Human projections must show all owned identifiers. Regenerate from machine catalogs, not manually maintaining duplicates.
 for o in OWN:
  pp=root/'business_rules'/f"{o['brs_id']}.md"
  if not pp.is_file():errors.append(o['brs_id']+' spec missing');continue
  body=pp.read_text()
  for rid in o['rules']:
   if body.count('### '+rid+':')!=1:errors.append(rid+' BRS human view mismatch')
 road=(root/'ROADMAP.md').read_text();cover=(root/'LOGISTICS_COVERAGE.md').read_text();acs=(root/'ACCEPTANCE.md').read_text();graph=(root/'CAMPAIGN_GRAPH.mmd').read_text()
 for n in C['nodes']:
  if road.count('| `'+n['node_id']+'` |')!=1:errors.append(n['node_id']+' roadmap projection mismatch')
  if graph.count('  '+n['node_id']+'["')!=1:errors.append(n['node_id']+' graph node projection mismatch')
 for ed in C['edges']:
  if graph.count('  '+ed['from']+' --> '+ed['to'])!=1:errors.append(str(ed)+' graph edge view mismatch')
 for a in C['acceptance']:
  if acs.count('### '+a['acceptance_id']+' -')!=1:errors.append(a['acceptance_id']+' acceptance human view mismatch')
 for r in C['requirements']:
  if cover.count('| '+r['harvest_id']+' | `'+r['requirement_id']+'` ')!=1:errors.append(r['requirement_id']+' coverage human view mismatch')
 with (root/'SOURCE_TO_REQUIREMENT_TRACEABILITY.csv').open(newline='',encoding='utf-8') as fd:tr=list(csv.DictReader(fd))
 if {r['requirement_id'] for r in tr}!={r['requirement_id'] for r in C['requirements']} or len(tr)!=len(C['requirements']):errors.append('requirement ledger CSV diverges')
 with (root/'FINDINGS_CLOSURE.csv').open(newline='',encoding='utf-8') as fd:fr=list(csv.DictReader(fd))
 if {r['finding_id'] for r in fr}!={r['finding_id'] for r in C['findings']} or len(fr)!=len(C['findings']):errors.append('findings ledger CSV diverges')
 with (root/'business_rules/BUSINESS_RULE_TRACEABILITY.csv').open(newline='',encoding='utf-8') as fd:br=list(csv.DictReader(fd))
 if {r['rule_id'] for r in br}!={r['rule_id'] for r in R} or len(br)!=len(R):errors.append('rules ledger CSV diverges')
 # Known-reference contamination negative controls: no active external alternative state or authority.
 active=(root/'CAMPAIGN_SPEC.md').read_text()
 for term in ['custom Supabase state store is required','use an n8n webhook for dispatch','automatically award cheapest','ignore operator rate approval','treat OCR as verified delivery']:
  if term in active:errors.append('forbidden active architecture: '+term)
 if hashes:
  manifest=read(root/'SHA256SUMS.json')
  keys=set(manifest.get('files',{}))
  actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'}
  if keys!=actual:errors.append('checksum inventory missing or extra files')
  for p,v in manifest['files'].items():
   if not re.fullmatch(r'[0-9a-f]{64}',v):errors.append('bad digest shape '+p)
   elif (root/p).is_file() and sha(root/p)!=v:errors.append('checksum mismatch '+p)
  if manifest.get('algorithm')!='sha256' or manifest.get('campaign_id')!=C['campaign_id']:errors.append('checksum manifest owner mismatch')
 return errors,{'requirements':len(C['requirements']),'rules':len(R),'brs':len(OWN),'source_records':len(S),'nodes':len(C['nodes']),'edges':len(C['edges']),'acceptance_cases':len(C['acceptance']),'original_acceptance_cases':sum(bool(a.get('source_case_id')) for a in C['acceptance']),'findings':len(C['findings']),'conflicts':len(C['conflicts']),'unknowns':len(C['unknowns']),'topological_order':order,'runtime_tests':'NOT_RUN','structural_reference':'NOT_SUPPLIED'}

def selftest(root):
 root=Path(root);C=read(root/'campaign.json');R=read(root/'business_rules/rules.json');OWN=read(root/'business_rules/OWNER_INDEX.json');S=read(root/'source_inputs/source_registry_original.json');F=read(root/'source_inputs/findings_original.json')['findings'];H=read(root/'source_inputs/harvest_original.json')['rows'];CON=read(root/'source_inputs/conflicts_original.json')['conflicts']
 def expect(label,fn):
  cc=copy.deepcopy(C);rr=copy.deepcopy(R);oo=copy.deepcopy(OWN);fn(cc,rr,oo)
  e,_=check_content(cc,rr,oo,S,F,H,CON,root)
  return {'case':label,'result':'EXPECTED_FAILURE_OBSERVED' if e else 'FALSE_GREEN','detected_errors':e[:3]}
 tests=[
 expect('orphan source',lambda c,r,o:c['requirements'][0]['source_refs'].append('E-NOT-FOUND')),
 expect('missing acceptance',lambda c,r,o:c['requirements'][0]['acceptance_ids'].append('AC-VOID')),
 expect('graph cycle',lambda c,r,o:(c['nodes'][0]['dependencies'].append(c['nodes'][-1]['node_id']),c['edges'].append({'from':c['nodes'][-1]['node_id'],'to':c['nodes'][0]['node_id'],'type':'FINISH_TO_START'}))),
 expect('duplicate business rule owner',lambda c,r,o:r[1].update({'rule_id':r[0]['rule_id']})),
 expect('policy pointer swaps rule',lambda c,r,o:c['policies'][0].update({'family_owner':'BRS-07'})),
 expect('claim runtime pass with no evidence',lambda c,r,o:c['acceptance'][0].update({'execution_result':'PASS'})),
 expect('suppress material unknown',lambda c,r,o:c['unknowns'][0].update({'status':'RESOLVED'})),
 expect('invented repository admission',lambda c,r,o:o[0].update({'registration':'REGISTERED'})),
 expect('source meaning mutated',lambda c,r,o:c['requirements'][0].update({'assertion':'send early regardless of readiness'})),
 expect('false structural-reference match',lambda c,r,o:c['provenance']['structural_reference'].update({'fidelity':'PASS'})),
 expect('unauthorized live dispatch',lambda c,r,o:c['authorization'].update({'live_emails':'AUTHORIZED'})),
 expect('fake finding closure',lambda c,r,o:c['findings'][0].update({'implementation_status':'FIXED'})),
 expect('foreign domain in acceptance test',lambda c,r,o:c['acceptance'][0].update({'expected_observation':'Complete passport renewal'})),
 ]
 return tests

if __name__=='__main__':
 pa=argparse.ArgumentParser();pa.add_argument('root',nargs='?',default='.',help='unpacked campaign directory');pa.add_argument('--skip-checksums',action='store_true');pa.add_argument('--self-test',action='store_true');pa.add_argument('--json',action='store_true');args=pa.parse_args()
 errors,stats=validate(args.root,hashes=not args.skip_checksums)
 tests=selftest(args.root) if args.self_test else []
 if any(x['result']!='EXPECTED_FAILURE_OBSERVED' for x in tests):errors.append('known-bad calibration FALSE GREEN')
 out={'status':'PASS' if not errors else 'FAIL','scope':'LOCAL_ARTIFACT_COMPILATION_ONLY','counts':stats,'errors':errors,'known_bad_tests':tests,'operational_test_result':'NOT_RUN','exact_exemplar_fidelity':'UNKNOWN'}
 print(json.dumps(out,indent=2) if args.json else f"{out['status']}: {stats}; errors={errors}; calibration={len(tests)}")
 sys.exit(0 if not errors else 1)
