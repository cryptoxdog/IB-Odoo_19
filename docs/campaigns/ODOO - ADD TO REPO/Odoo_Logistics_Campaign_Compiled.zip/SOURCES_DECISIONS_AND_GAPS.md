# Sources, Operator Decisions, Conflicts and Unknowns

## Evidence hierarchy and status

- **Direct current operator scope:** 2026-10-20 task + preceding logistics-first, no-new-platform, no-n8n instructions. Direct authority over this compilation's desired outcome, not a repository write grant.
- **Existing target authority at `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`:** `INVARIANTS.md` / `AGENTS.md`, accepted exact-filename ADRs, current implementation and tests. Read-only source inspection; code presence does not prove active module installation.
- **Logistics harvest input:** 2026-10-19 pack with 68 harvest rows, 25 finding rows, 16 conflicts and 90 acceptance cases; original artifacts are preserved byte-for-byte in `source_inputs/`.
- **Donors:** 10 identified families, mixed evidence classes (locally available raw snippets and Dropbox connector text); lack of an independent byte rehash must not become an exact digest claim.
- **Structural exemplar:** **NOT PROVIDED**. The user-provided enumeration of required artifact classes is the only available structural specification. No source-domain lexical exclusion dictionary can be honestly extracted from an unseen exemplar.

## Source inventory

| ID | Provenance root / identified family | Source class |
|---|---|---|
| `D01` | Uploaded Linda v1 package / embedded v5 and Odoo prototypes | historical logistics donor (actual field/byte coverage in source registry) |
| `D02` | Linda v6 Odoo | historical logistics donor (actual field/byte coverage in source registry) |
| `D03` | Linda v4 Odoo dispatch variant | historical logistics donor (actual field/byte coverage in source registry) |
| `D04` | Linda FastAPI v7.9.8 / v7.9.9 | historical logistics donor (actual field/byte coverage in source registry) |
| `D05` | Linda v7.9.1 five modules plus checkpoint ZIP | historical logistics donor (actual field/byte coverage in source registry) |
| `D06` | Standalone logistics DevKit, non-n8n material | historical logistics donor (actual field/byte coverage in source registry) |
| `D07` | Canonical Logistics v1.3.1 | historical logistics donor (actual field/byte coverage in source registry) |
| `D08` | Earlier plasticos_logistics Odoo19 snapshot | historical logistics donor (actual field/byte coverage in source registry) |
| `D09` | Linda freight intelligence dev pack v2.1 | historical logistics donor (actual field/byte coverage in source registry) |
| `D10` | Linda v5 outer document/workflow narratives | historical logistics donor (actual field/byte coverage in source registry) |

## Exact source trace

The complete `E*` donor and `T*` repository sources retain source paths, excerpt text, source classification and original inspection notes in `source_inputs/source_registry_original.json`. The original archive is identified by SHA-256 in `source_inputs/SOURCE_BOUNDARY.json`. **Only `LOCAL_RAW_BYTES` sources are byte-verified; connector text carries an observation identity, not an independent original-file checksum.**

## Current target-local law

| Concern | Frozen source | Local binding |
|---|---|---|
| INVARIANTS.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/INVARIANTS.md | Odoo 19 compatibility, no circular addon deps, no duplicate source truths, security and cron doctrine |
| AGENTS.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/AGENTS.md | Module and test discipline, version bump obligation, per-owner permission review and current published corrections |
| ARCHITECTURE.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/ARCHITECTURE.md | Single Odoo transaction/load/document/logistics architecture |
| docs/adr/ADR-008-odoo-action-methods.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/docs/adr/ADR-008-odoo-action-methods.md | Native Odoo action form conventions |
| docs/adr/ADR-018-human-brokerage-checkpoints.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/docs/adr/ADR-018-human-brokerage-checkpoints.md | Human broker/commercial gates, not automatic authorization |
| docs/adr/ADR-019-documentation-convergence-supersession.md | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/docs/adr/ADR-019-documentation-convergence-supersession.md | Which accepted ADR supersedes stale narrative in related intelligence scope |

## Explicit operator constraints

- **OP-001** (DIRECT_OPERATOR_SCOPE): Logistics exclusively; the structural exemplar supplies format only.
- **OP-002** (DIRECT_OPERATOR_DECISION): Existing plasticos_logistics is the starting implementation; do not replace it.
- **OP-003** (DIRECT_OPERATOR_DECISION): All available logistics donors may contribute missing behavior, but no separate orchestration runtime.
- **OP-004** (DIRECT_OPERATOR_CONSTRAINT): Retain precise evidence, unknowns, business ownership and no unapproved policy.
- **OP-005** (DIRECT_OPERATOR_SCOPE): Compile and validate a campaign ZIP; no repository edit, publication, deployment or operational dispatch authorized.
- **OP-006** (DIRECT_OPERATOR_SCOPE): No reference-domain business content, vocabulary, examples or policy may migrate.

## Decisions requiring approved binding

| ID | Decision | Proposed safe route | Status |
|---|---|---|---|
| A01 | Minimal request identity and secure confirmation interface | Recommend one load-confirmation entity owned by plasticos_logistics, using native Mail and authenticated partner-specific actions. | PENDING |
| A02 | Evidence-only service authority | Recommend narrow operation permissions for routine facts, never blanket carrier/rate award. | PENDING |
| A03 | Current reminder timing and facility clock | Honor Monday-morning status intent; choose one approved hour/zone and reconcile daily readiness cadence. Preserve approved live thresholds until changed. | PENDING |
| A04 | Document verification and required receipt evidence | Preserve signed/current BOL requirements and receiver evidence; authenticated file attestation is not automatically a signature verifier. | PENDING |
| A05 | Post-confirmation recovery and amendment | Recommend versioned cancellation/reconfirmation of affected future commitments; preserve physical milestones. | PENDING |
| A06 | Existing data and document adoption | Classify old values as verified, asserted, contradictory or unassociated; activate only explicit eligible cohort. | PENDING |
| A07 | Necessary integration mutation scope | Propose exact affected logistics, automation, transaction, document, facility and security paths, plus focused tests/migrations. | PENDING |
| A08 | Isolated runtime and live pilot | Use production-equivalent Odoo19/Enterprise disposable database with blocked operational recipients and controlled mail sink. | PENDING |

## Historical contradictions and supersessions

| Conflict | Earlier conflicting interpretation | Current candidate resolution | Operator signoff |
|---|---|---|---|
| C01 | FCFS means immediate dispatch/skip readiness | FCFS removes only appointment requirement. Direct cargo readiness remains mandatory. | Not inferred |
| C02 | Sales ready replaces shipper ready | Sales release starts the process; shipper named/timestamped readiness is still required per load. | Not inferred |
| C03 | Pickup-first booking everywhere | When delivery appointment is required, accepted destination slot constrains final pickup commitment. | Not inferred |
| C04 | Weighted readiness threshold | All mandatory dispatch prerequisites must hold; no score can omit rate/carrier/ready requirements. | Not inferred |
| C05 | First/next-best/cheapest carrier automatically wins | Preserve operator carrier/rate decision and manual RFQ; failed capacity is an exception, not automatic reassignment. | Not inferred |
| C06 | Any keyword, sender, subject or anonymous token proves acceptance | Authenticate intended party and current typed request; preserve free text as evidence only. | Not inferred |
| C07 | SMTP returned/no exception means received or fulfilled | Queue, transport acceptance, recipient acknowledgment and fulfillment are independent events. | Not inferred |
| C08 | Mark stock picking done at pickup | Pickup is not delivered stock. Use correct native move/route validation only on supported receipt/delivery facts. | Not inferred |
| C09 | Content hash or low-OCR archive unlocks financial close | Hash proves bytes, not signatures/receiver truth; required docs and existing financial close gates remain. | Not inferred |
| C10 | Install all historical timers and quiet hours | One approved policy per logical touch; no stacked reminders. Exact hour and changed thresholds remain explicit approvals. | Not inferred |
| C11 | Content-hash-only dedup and cache expiry imply exactly-once | Stable operation identity plus payload drift check, durable revision and transaction locking; uncertain SMTP effects require reconciliation. | Not inferred |
| C12 | Corporate partner/default field is facility confirmation | Actual origin/destination each supplies requirements; legacy defaults are assertions, not verified FCFS. | Not inferred |
| C13 | Required account numbers, fees, weights and carrier history may use defaults | No invented operational or commercial facts. Consume current approved inputs; missing stays unknown. | Not inferred |
| C14 | Legacy file version number supersedes current implementation | Current target source/policy and explicit mission control. September AI/Gate components are excluded by this deterministic mission. | Not inferred |
| C15 | Store copies per party folder or use Supabase archive SSOT | One existing Odoo attachment identity, versioned evidence and role-filtered views; no second archive system. | Not inferred |
| C16 | Buyer/Supplier threads or blanket Sales CC are harmless | No buyer-supplier cross-disclosure, no Sales CC on buyer SO, no archival CC; guard followers and quoted content too. | Not inferred |

## Unresolved source/implementation gaps

| Unknown | Affected matter | Block owner / resolution |
|---|---|---|
| U01 | Deployed modules, registry and revision | WP00 / Rebind authoritative evidence |
| U02 | Live mail routing, delivery, bounces and identity | WP02 / Rebind authoritative evidence |
| U03 | Approved evidence-only automation authority | WP02 / Rebind authoritative evidence |
| U04 | Existing operational data and open-load adoption | WP10 / Rebind authoritative evidence |
| U05 | Exact timer, document and recovery policy | WP00 / Rebind authoritative evidence |
| U06 | Remote byte completeness and historical copy equality | WP00 / Rebind authoritative evidence |
| U07 | Residual remote source coverage | WP00 / Rebind authoritative evidence |
| U08 | Actual runtime, concurrency and replay outcomes | WP11 / Rebind authoritative evidence |
| U09 | Independent review and L9 authority certification | WP11 / Rebind authoritative evidence |
| U10 | Current executable commands and publication invocation | WP00 / Rebind authoritative evidence |
| U-REF | Separate non-logistics structural reference archive | WP00 / Supply exact exemplar in separate future compilation; no invented reference-domain exclusion set. |
| U-BRS | Repo-registered numbered BRS rule family | WP00 / Confirm repo-local governance owner accepts or already has an alternative business-rule registry. |
| U-PUB | Publication handoff | WP11 / Rebind explicit latest Odoo publication policy and obtain remote mutation grant before PR. |
| U-PROOF | Odoo runtime and native mailbox behavior | WP00 / Run controlled disposable-database registry and Mail integration tests. |

No proposed decision, inherited default, historical donor header, prior pack receipt or self-test is accepted as a new Odoo business policy by mere inclusion.
