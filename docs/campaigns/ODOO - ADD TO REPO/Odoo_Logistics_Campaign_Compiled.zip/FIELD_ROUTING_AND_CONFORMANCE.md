# Field Routing and Conformance

This is a **field evidence mapping**, not an instruction to add 43 fields or retrofit legacy values. Existing identities were read at the exact frozen `Staging` SHA. Proposed gaps have no technical name or schema authority; preserve Unknown until a minimal sufficiency test and target owner acceptance.

## Source-confirmed fields

| Route | Existing technical identity | Source | Role / gap |
|---|---|---|---|
| FM-01 | `plasticos.load.name` | [plasticos_logistics/models/load.py:40](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L40) | load identity (EXISTING) |
| FM-02 | `plasticos.load.sale_order_id` | [plasticos_logistics/models/load.py:43](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L43) | sales order link (EXISTING) |
| FM-03 | `plasticos.load.company_id` | [plasticos_logistics/models/load.py:44](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L44) | stored SO-related company; missing SO can yield no company (EXISTING_GAP) |
| FM-04 | `plasticos.load.transaction_id` | [plasticos_logistics/models/load.py:132](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L132) | computed reverse transaction link (EXISTING) |
| FM-05 | `plasticos.transaction.load_id` | [plasticos_logistics/models/transaction_inherit.py:10](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/transaction_inherit.py#L10) | unique transaction-side load reference (EXISTING) |
| FM-06 | `plasticos.transaction.purchase_order_ids` | [plasticos_transaction/models/transaction.py:44](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_transaction/models/transaction.py#L44) | purchase order associations (EXISTING) |
| FM-07 | `plasticos.load.ready_confirmed_by` | [plasticos_logistics/models/load.py:114](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L114) | name of ready confirmer; provenance absent (EXISTING_GAP) |
| FM-08 | `plasticos.load.ready_confirmed_at` | [plasticos_logistics/models/load.py:115](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L115) | ready timestamp; verified reply linkage absent (EXISTING_GAP) |
| FM-09 | `plasticos.load.pickup_datetime` | [plasticos_logistics/models/load.py:117](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L117) | scheduled pickup date (not actual movement) (EXISTING) |
| FM-10 | `plasticos.load.delivery_datetime` | [plasticos_logistics/models/load.py:118](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L118) | scheduled delivery date (not actual receipt) (EXISTING) |
| FM-11 | `plasticos.load.delivery_term` | [plasticos_logistics/models/load.py:143](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L143) | one delivery term field; pickup-side appointment proof unresolved (EXISTING_GAP) |
| FM-12 | `res.partner.default_delivery_term` | [plasticos_facility_profile/models/res_partner_delivery_term.py:9](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_facility_profile/models/res_partner_delivery_term.py#L9) | default appointment but not positive confirmation of dock rule (EXISTING_GAP) |
| FM-13 | `plasticos.load.carrier_id` | [plasticos_logistics/models/load.py:47](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L47) | carrier reference; booking evidence separate (EXISTING) |
| FM-14 | `plasticos.load.rate_amount` | [plasticos_logistics/models/load.py:48](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L48) | booked rate value (EXISTING) |
| FM-15 | `plasticos.load.rate_confirmed_at` | [plasticos_logistics/models/load.py:49](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L49) | rate confirmation time (EXISTING) |
| FM-16 | `plasticos.load.rate_currency_id` | [plasticos_logistics/models/load.py:51](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L51) | rate currency (EXISTING) |
| FM-17 | `plasticos.load.freight_context_fingerprint` | [plasticos_logistics/models/load.py:69](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L69) | freight context fingerprint (EXISTING) |
| FM-18 | `plasticos.load.sal_decision` | [plasticos_logistics/models/load.py:78](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L78) | SAL decision with retained outcomes (EXISTING) |
| FM-19 | `plasticos.freight.quote.request.load_id` | [plasticos_logistics/models/freight_quote.py:50](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/freight_quote.py#L50) | immutable request contextual load binding (EXISTING) |
| FM-20 | `plasticos.freight.quote.request.recipient_ids` | [plasticos_logistics/models/freight_quote.py:82](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/freight_quote.py#L82) | carrier recipient evidence (EXISTING) |
| FM-21 | `plasticos.load.dispatch_sent` | [plasticos_logistics/models/load.py:165](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L165) | notification timestamp; competing send path risk (EXISTING_GAP) |
| FM-22 | `plasticos.load.dispatch_acknowledged` | [plasticos_logistics/models/load.py:170](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L170) | ack time; attributable proof gap (EXISTING_GAP) |
| FM-23 | `plasticos.load.dispatched_at` | [plasticos_logistics/models/load.py:125](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L125) | state transition time (EXISTING) |
| FM-24 | `plasticos.load.delivered_at` | [plasticos_logistics/models/load.py:126](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L126) | state transition time absent receiver proof (EXISTING_GAP) |
| FM-25 | `plasticos.load.pickup_partner_id` | [plasticos_logistics/models/load.py:188](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L188) | shipper physical location (EXISTING) |
| FM-26 | `plasticos.load.delivery_partner_id` | [plasticos_logistics/models/load.py:206](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L206) | receiver physical location (EXISTING) |
| FM-27 | `plasticos.load.bol_pickup_attached` | [plasticos_logistics/models/load.py:120](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L120) | boolean attachment projection, not verification (EXISTING_GAP) |
| FM-28 | `plasticos.load.bol_delivery_attached` | [plasticos_logistics/models/load.py:121](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py#L121) | boolean attachment projection, not verification (EXISTING_GAP) |
| FM-29 | `plasticos.document.attachment_id` | [plasticos_documents/models/document.py:18](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/document.py#L18) | document content reference (EXISTING) |
| FM-30 | `plasticos.document.verified` | [plasticos_documents/models/document.py:21](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/document.py#L21) | document verification status (EXISTING) |
| FM-31 | `plasticos.document.load_id` | [plasticos_documents/models/document.py:68](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/document.py#L68) | legacy document load association (EXISTING) |
| FM-32 | `documents.document.doc_type` | [plasticos_documents_native/models/document_native.py:60](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents_native/models/document_native.py#L60) | native Enterprise document classification (EXISTING) |
| FM-33 | `documents.document.verified` | [plasticos_documents_native/models/document_native.py:82](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents_native/models/document_native.py#L82) | native document verification status (EXISTING) |
| FM-34 | `plasticos.transaction.freight_actual` | [plasticos_transaction/models/transaction.py:167](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_transaction/models/transaction.py#L167) | financial actual, distinct from booked rate (EXISTING) |
| FM-35 | `plasticos.transaction.actual_delivery_date` | [plasticos_transaction/models/transaction.py:146](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_transaction/models/transaction.py#L146) | downstream actual delivery date (EXISTING_GAP) |
| FM-36 | `plasticos.dispatch.state` | [plasticos_logistics/models/dispatch.py:15](https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/dispatch.py#L15) | parallel legacy dispatch state that must not govern load (EXISTING_GAP) |

## Actual data-contract gaps, NOT preapproved new fields

| Gap | Missing/verifiably incomplete behavior | Concern owner | Minimum proof before representation |
|---|---|---|---|
| FG-01 | Load-specific confirmation request/response identity | BRS-02 | Representation not admitted; prove existing Mail plus load fields cannot express all identities before adding record |
| FG-02 | Pickup-side FCFS/APPT explicit certainty and accepted slot | BRS-03 | Existing facility default is not accepted time or explicit unknown |
| FG-03 | Destination accepted appointment commitment | BRS-03 | Proposed, accepted, amended and cancelled must be distinguished |
| FG-04 | Carrier booking acceptance and capacity evidence | BRS-04 | Rate confirmation is not carrier coverage |
| FG-05 | Checkpoint source time and independent event provenance | BRS-06 | Scheduled date/state stamp is not physical evidence |
| FG-06 | Role-scoped current document pack verification | BRS-07 | Attachment flag and native/legacy mirror may diverge |
| FG-07 | Outbox/send-attempt durable identity | BRS-05 | Native mail.mail features/limits require proof before new persistence |

## Historical donor to current owner correspondence (proposed)

| Route | Donor expression | Current target owner/field | Disposition |
|---|---|---|---|
| LM-01 | `v6 purchase.order.x_ready_for_pickup` | `plasticos.load.ready_confirmed_at and ready_confirmed_by` | NEEDS_VERIFIED_PER_LOAD_EVIDENCE |
| LM-02 | `v6 sale.order.x_appointment_confirmed` | `plasticos.load.delivery_datetime` | NOT_EQUIVALENT_ACCEPTED_SLOT_MISSING |
| LM-03 | `v6 stock.picking.x_actual_pickup` | `plasticos.load.state / transition proof` | NEEDS_CHECKPOINT_SOURCE |
| LM-04 | `v6 stock.picking.x_pod_received` | `documents.document verified + plasticos.document verified` | NOT_EQUIVALENT_DOC_VERIFICATION |
| LM-05 | `v6 carrier dispatch state` | `plasticos.load.action_dispatch` | GUARDED_ACTION_ONLY |
| LM-06 | `v6 automated carrier selection` | `existing SAL/manual-only RFQ and operator quote selection` | REJECT_AUTO_AWARD |
| LM-07 | `v6 sm.tx` | `plasticos.transaction` | REJECT_PARALLEL_TRANSACTION_SPINE |

## Cross-owner contract obligations

1. `plasticos_logistics` owns load actions and evidence acceptance, not legacy `stock.picking` server actions.
2. `plasticos_facility_profile` owns general facility facts; load owns per-movement verified scheduling facts.
3. `plasticos_automation` may invoke guarded actions and set activities but does not declare its own shipment state or ignore stopped reminders.
4. `plasticos_documents_native` is native document ownership. Existing `plasticos_documents` mirror/compliance must preserve attached bytes, verification and link currentness; avoid duplicate physical storage.
5. `plasticos_transaction` owns downstream transaction/financial closure; logistics close never auto-satisfies it.
6. Existing `plasticos_security_base` company ACL/rules apply; schema/record rule changes need independent operator review.
7. Missing `res.partner.default_delivery_term` explicit uncertainty is not proof of FCFS or accepted appointment, even with a configured default.

## Conformance gates

- Existing field path/import/manifest proven in current source, installed Odoo registry and disposable upgrade.
- Legacy `x_` fields **not** imported as current technical identifiers. Current Odoo 19 invariants forbid casually transplanting legacy naming and APIs.
- Every proposed new model/field must carry a demonstrated existing-representation insufficiency, source-supported obligation, migration-safe definition, single domain owner and negative cases.
- Company and source transaction identity are verified before reading/writing any reply, load or document, not only in a UI view domain.
- No duplicate business meaning across load, picking, transaction and document owner.
