# Logistics Implementation Roadmap

**Status:** Proposed bounded rollout; no code mutation authorized.  
**Branch:** `Staging` at frozen source SHA `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e` for *compilation only*. Rebind before implementation.

## Critical path and valid parallelism

`WP00 -> WP01 -> WP02 -> WP03 -> WP04 -> WP05 -> WP06 -> WP07 -> WP09 -> WP10 -> WP11`  
`WP02 -> WP08 -> WP09` is an independent document-owner branch once the response identity contract is fixed. WP08's source audit can start in parallel with WP01/WP02, but it cannot claim final document synchronization until integration with the accepted evidence contract.

No stage is automatically merged or deployed upon another's completion. Parallel branches touching `plasticos_logistics/models/load.py` or `plasticos_automation/data/workflow_automations.xml` require one integration owner and compatible interface freeze.

## Work-package ledger

| ID | Stage | Implementation slice | Dependencies | Acceptance obligation | Evidence state |
|---|---|---|---|---|---|
| `WP00` | `P00` | Revision and permission preflight | none | Read-only census, active-rule/runtime inventory, approval decisions and exact authorized paths. | NOT_STARTED |
| `WP01` | `P01` | Canonical safety, entry and association | WP00 | Canonical command closes all public/automatic send and state bypass seams, with no premature stock/transaction completion. | NOT_STARTED |
| `WP02` | `P02` | Party-scoped request evidence and native transport | WP01 | One minimal fixed-purpose confirmation record plus native authenticated action/message correlation; no external processor. | NOT_STARTED |
| `WP03` | `P02` | Closed-loop shipper readiness | WP02 | Direct shipper READY for one exact load, named/time-bound evidence, counters and reminders stop correctly; approvals remain. | NOT_STARTED |
| `WP04` | `P03` | Two-ended appointment coordination | WP03 | Destination-required appointment accepted before final pickup commitment; FCFS/unknown handled independently per facility. | NOT_STARTED |
| `WP05` | `P04` | Current carrier booking and recovery | WP04 | Preserve SAL/manual RFQ/ranking; bind explicit accepted carrier capacity/equipment/windows; no unauthorized rebooking. | NOT_STARTED |
| `WP06` | `P05` | Guarded packet and receipt-to-release | WP05 | One audience-safe current packet in Scheduled, true transport status, valid packet receipt then Dispatched. | NOT_STARTED |
| `WP07` | `P05` | Verified checkpoints and one scheduler | WP06 | Due checkpoint requests, cancellation, concurrency, fair catch-up and actionable exceptions cover active transit, not just dispatch ACK. | NOT_STARTED |
| `WP08` | `P06` | Current document evidence seam | WP02 | Exact current native attachment/legacy mirror and guarded verification; correct party/load/version and required document criteria. | NOT_STARTED |
| `WP09` | `P06` | Verified delivery and downstream reconciliation | WP07, WP08 | Receiver-backed delivery, native stock validation, load closure and facts-only financial handoff; disputes stay open. | NOT_STARTED |
| `WP10` | `P07` | Upgrade and controlled data adoption | WP09 | Preserve assertions, current IDs and prior business history; initialize only reviewed cohorts; disable specific conflicting rules. | NOT_STARTED |
| `WP11` | `P07` | Isolated acceptance and pilot release decision | WP10 | Execute all relevant cases with source/run/DB/mail evidence; no fake PASS. Pilot needs separate live-send and deployment grant. | NOT_STARTED |

## Incremental release gates

**Gate P00: identity and authority.** Local governing rules, module versions, current branch, exact involved paths, Mail/cron/provider configuration and disposable testing facilities documented; no logic or data changes.

**Gate P01: no unguarded external effect.** With a stock picking assigned but carrier booking missing, zero external messages and zero `dispatch_sent`; company and multi-transaction identities cannot resolve to an arbitrary first match.

**Gate P02: first useful automatic capability.** A supplier answers exactly one current, authenticated request; one load progresses and only after the right shipper evidence. Duplicate/replay/ambiguous email does not progress; outstanding reminders stop. A failing message may create one justified exception, not a false transition.

**Gate P03: committed dock constraints.** For each end, FCFS must be actually established or the required accepted slot must exist. Facility-specific availability and destination-first scheduling cannot be bypassed by a proposed slot or a default.

**Gate P04: carrier capacity.** A valid selected rate does not mean an available truck. Carrier decline, stale equipment or revised appointment requires re-resolution under current commercial policy, not an invisible substitution.

**Gate P05: guarded dispatch and tracking.** Current three-paper packet sent with double-blind audience; sent, acknowledged, released and picked up are distinct, evidence-backed and retry safe. One scheduler owns due evaluations.

**Gate P06: actual delivery.** Receiver proof, current document verification and native-to-legacy consistency are demonstrated. Transaction close does not bypass accounting obligations.

**Gate P07: adoption.** Fresh install, upgrade from bounded source state, data reconciliation and rollback operate in a disposable production-equivalent environment; only then an independently authorized live canary decision.

## Stop conditions

Any of: unknown company/load, source SHA drift, unverified actor or receiver, unaudited alternative send path, missing freight operator approval, missing independent physical event, business-rule conflict, cross-company leakage, unresolved native-doc mirror disagreement, auto-acceptance of an arbitrary mailbox response, unapproved schema/cron/security change, old data reclassified as verified, no isolated Odoo environment, or an executor seeking new scope without exact owner approval. Block only the affected branch when independent work remains lawful.

## Preservation / upgrade obligations

Every affected addon manifest must follow current `AGENTS.md` version-bump requirements. Preserve module DAG, Odoo 19 API compatibility, fresh install and scoped `-u` migration proof. Existing freight SAL, quotes, approvals, packet reports and transaction/accounting controls remain regression targets. No old archive is installed or replayed as an addon.
