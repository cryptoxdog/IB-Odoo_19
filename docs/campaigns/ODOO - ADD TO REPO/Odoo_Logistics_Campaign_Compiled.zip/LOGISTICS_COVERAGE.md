# Logistics Coverage and Traceability

All 68 prior harvest decisions remain present. None has been discarded because it is already implemented, rejected, deferred, or apparently difficult. Each is either a candidate operating requirement, a current capability-preservation obligation, a prohibition, or a deferred out-of-scope note. No source-derived finding disappears.

## Lifecycle coverage

| Stage | Concerns | Business owner | Relevant sources and tests | Runtime status |
|---|---|---|---|---|
| P01 | Transaction, movement identity and company boundary | `BRS-01` | 3 candidate rules / 7 linked case IDs | NOT_RUN |
| P02, P03 | Supplier readiness and verified responses | `BRS-02` | 12 candidate rules / 28 linked case IDs | NOT_RUN |
| P03 | Facility terms and appointments | `BRS-03` | 7 candidate rules / 16 linked case IDs | NOT_RUN |
| P04 | Freight policy and carrier booking | `BRS-04` | 7 candidate rules / 15 linked case IDs | NOT_RUN |
| P01, P05 | Dispatch, messages and confidentiality | `BRS-05` | 8 candidate rules / 18 linked case IDs | NOT_RUN |
| P05 | Physical checkpoints and follow-ups | `BRS-06` | 9 candidate rules / 18 linked case IDs | NOT_RUN |
| P06, P07 | Delivery, documents and operational closeout | `BRS-07` | 12 candidate rules / 20 linked case IDs | NOT_RUN |

## Obligation accounting

- Requirement-to-source and requirement-to-case: machine links in `campaign.json`, both nonempty for each material source decision.
- Accepted business rules: **none newly admitted** by this pack. Seven numbered BRS concern specifications are **candidates** with one owner each; no competing rule family is added to the target.
- Findings: all 25 retained open, mapped to source, requirement, implementation slice, acceptance, and planned closing evidence. Zero findings claimed fixed.
- Existing freight: preserving source-defined functioning rate/quote controls is a required non-regression boundary, not a promise to refactor them.
- Source conflicts: all 16 retained with current proposed disposition and operator-signoff unknown.
- Negative-case posture: stale response, cross-company leak, duplicate sending, rate bypass, default appointment assumption and false pickup/delivery must be demonstrably rejected.

## Full harvested rule/decision coverage

| Harvest ID | Requirement | Candidate owner | Disposition | Test count | Work package |
|---|---|---|---|---:|---|
| H001 | `LR-001` Sales release starts logistics; supplier READY remains separate | BRS-01 | NATIVE_REIMPLEMENTATION | 3 | WP01 |
| H002 | `LR-002` Exact transaction/load/PO/SO association | BRS-01 | MERGE_WITH_HARDENING | 3 | WP01 |
| H003 | `LR-003` Company ownership cannot be unknown for automation | BRS-01 | MERGE_WITH_HARDENING | 2 | WP01 |
| H004 | `LR-004` Direct shipper READY for every load | BRS-02 | NATIVE_REIMPLEMENTATION | 3 | WP02 |
| H005 | `LR-005` Ready date versus proposed date | BRS-02 | MERGE_WITH_HARDENING | 2 | WP02 |
| H006 | `LR-006` Explicit negative and corrected responses | BRS-02 | NATIVE_REIMPLEMENTATION | 3 | WP02 |
| H007 | `LR-007` Monday shipper status request | BRS-02 | CONFIGURE_AFTER_APPROVAL | 2 | WP02 |
| H008 | `LR-008` Required cargo/equipment facts | BRS-02 | MERGE_WITH_HARDENING | 3 | WP04 |
| H009 | `LR-009` Native Odoo Mail, not a mailbox microservice | BRS-02 | NATIVE_REIMPLEMENTATION | 3 | WP02 |
| H010 | `LR-010` Typed request evidence with minimal new persistence | BRS-02 | NATIVE_REIMPLEMENTATION | 4 | WP02 |
| H011 | `LR-011` Authenticated structured confirmation | BRS-02 | NATIVE_REIMPLEMENTATION | 5 | WP02 |
| H012 | `LR-012` Separate transport, proposed observation and accepted fact | BRS-02 | NATIVE_REIMPLEMENTATION | 4 | WP02 |
| H013 | `LR-013` Stable business identity independent of payload hash | BRS-02 | MERGE_WITH_HARDENING | 3 | WP02 |
| H014 | `LR-014` Stale, forwarded and contradictory replies | BRS-02 | NATIVE_REIMPLEMENTATION | 4 | WP02 |
| H015 | `LR-015` Evidence-only service capability | BRS-02 | NATIVE_REIMPLEMENTATION | 3 | WP02 |
| H016 | `LR-016` Per-facility unknown-safe dock rules | BRS-03 | MERGE_WITH_HARDENING | 3 | WP04 |
| H017 | `LR-017` Delivery slot constrains pickup scheduling | BRS-03 | NATIVE_REIMPLEMENTATION | 3 | WP04 |
| H018 | `LR-018` Proposal/request/acceptance/cancellation distinction | BRS-03 | NATIVE_REIMPLEMENTATION | 3 | WP04 |
| H019 | `LR-019` FCFS removes only appointment gate | BRS-03 | MERGE_WITH_HARDENING | 3 | WP04 |
| H020 | `LR-020` Facility time zones, hours and lead time | BRS-03 | NATIVE_REIMPLEMENTATION | 3 | WP04 |
| H021 | `LR-021` No invented dock-capacity subsystem | BRS-03 | MERGE_WITH_HARDENING | 2 | WP04 |
| H022 | `LR-022` Amendment invalidates dependencies | BRS-03 | NATIVE_REIMPLEMENTATION | 4 | WP04 |
| H023 | `LR-023` SAL and canonical executed history | BRS-04 | PRESERVE_EXISTING | 3 | WP05 |
| H024 | `LR-024` Estimate/recommendation/award/actual remain distinct | BRS-04 | PRESERVE_EXISTING | 5 | WP05 |
| H025 | `LR-025` Manual-only RFQ after SAL miss | BRS-04 | PRESERVE_EXISTING | 2 | WP05 |
| H026 | `LR-026` Immutable market response and recipient evidence | BRS-04 | PRESERVE_EXISTING | 3 | WP05 |
| H027 | `LR-027` Carrier commitment beyond approved rate | BRS-04 | NATIVE_REIMPLEMENTATION | 3 | WP05 |
| H028 | `LR-028` Unavailable carrier routes commercial exception | BRS-04 | MERGE_WITH_HARDENING | 3 | WP05 |
| H029 | `LR-029` One guarded dispatch authority | BRS-05 | MERGE_WITH_HARDENING | 3 | WP01 |
| H030 | `LR-030` Three documents, current version, then acknowledgment | BRS-05 | MERGE_WITH_HARDENING | 3 | WP06 |
| H031 | `LR-031` Party-specific document and message audiences | BRS-05 | MERGE_WITH_HARDENING | 2 | WP06 |
| H032 | `LR-032` No Sales CC on buyer SO; no archival CC | BRS-05 | MERGE_WITH_HARDENING | 2 | WP06 |
| H033 | `LR-033` No secret leakage through shared notes or chatter | BRS-05 | MERGE_WITH_HARDENING | 3 | WP06 |
| H034 | `LR-034` Durable queue and truthful send status | BRS-05 | MERGE_WITH_HARDENING | 3 | WP06 |
| H035 | `LR-035` Uncertain SMTP outcome is not safely retryable by default | BRS-05 | NATIVE_REIMPLEMENTATION | 3 | WP06 |
| H036 | `LR-036` Currency, time zone and actual fields rendered correctly | BRS-05 | MERGE_WITH_HARDENING | 3 | WP06 |
| H037 | `LR-037` One state-dependent milestone clock | BRS-06 | MERGE_WITH_HARDENING | 4 | WP06 |
| H038 | `LR-038` Race-safe due evaluation and catch-up | BRS-06 | MERGE_WITH_HARDENING | 4 | WP06 |
| H039 | `LR-039` Resolve conflicting historical timer policies | BRS-06 | CONFIGURE_AFTER_APPROVAL | 3 | WP06 |
| H040 | `LR-040` Actionable, deduplicated human exceptions | BRS-06 | MERGE_WITH_HARDENING | 3 | WP06 |
| H041 | `LR-041` Checkpoint vocabulary without new load states | BRS-06 | NATIVE_REIMPLEMENTATION | 3 | WP06 |
| H042 | `LR-042` Pickup proof does not finish delivery picking | BRS-06 | NATIVE_REIMPLEMENTATION | 2 | WP06 |
| H043 | `LR-043` Out-of-order and stale event handling | BRS-06 | NATIVE_REIMPLEMENTATION | 3 | WP06 |
| H044 | `LR-044` No response after pickup is a monitored exception | BRS-06 | NATIVE_REIMPLEMENTATION | 3 | WP06 |
| H045 | `LR-045` Receiver evidence and destination validation | BRS-07 | NATIVE_REIMPLEMENTATION | 3 | WP08 |
| H046 | `LR-046` Store once, preserve original and role views | BRS-07 | MERGE_WITH_HARDENING | 3 | WP08 |
| H047 | `LR-047` Deterministic association before classification | BRS-07 | NATIVE_REIMPLEMENTATION | 3 | WP08 |
| H048 | `LR-048` Current verified BOL/POD, not checkboxes | BRS-07 | MERGE_WITH_HARDENING | 4 | WP08 |
| H049 | `LR-049` Native-to-legacy proof synchronization | BRS-07 | MERGE_WITH_HARDENING | 3 | WP08 |
| H050 | `LR-050` Hash and supersession as integrity, not authority | BRS-07 | MERGE_WITH_HARDENING | 3 | WP08 |
| H051 | `LR-051` Party-specific missing-document deadlines | BRS-07 | CONFIGURE_AFTER_APPROVAL | 2 | WP08 |
| H052 | `LR-052` Quantities, discrepancies and original unit evidence | BRS-07 | MERGE_WITH_HARDENING | 2 | WP08 |
| H053 | `LR-053` Verified downstream synchronization | BRS-07 | MERGE_WITH_HARDENING | 3 | WP08 |
| H054 | `LR-054` Financial close is a separate gate | BRS-07 | PRESERVE_EXISTING | 2 | WP08 |
| H055 | `LR-055` Truthful operational metrics | BRS-07 | MERGE_WITH_HARDENING | 2 | WP08 |
| H056 | `LR-056` Legacy assertions are not confirmed events | BRS-07 | NATIVE_REIMPLEMENTATION | 3 | WP10 |
| H057 | `LR-057` Fresh install and upgrade safety | scope/verification | MERGE_WITH_HARDENING | 3 | WP10 |
| H058 | `LR-058` Rollback retains business history | scope/verification | NATIVE_REIMPLEMENTATION | 3 | WP10 |
| H059 | `LR-059` Replace fake green with real workflow proof | scope/verification | MERGE_WITH_HARDENING | 4 | WP10 |
| H060 | `LR-060` No second logistics platform/state store | scope/verification | REJECT | 2 | WP00 |
| H061 | `LR-061` No n8n donor/runtime integration | scope/verification | REJECT | 2 | WP00 |
| H062 | `LR-062` No AI/OCR business authority | scope/verification | REJECT | 3 | WP00 |
| H063 | `LR-063` No weighted dispatch safety or fabricated facts | scope/verification | REJECT | 3 | WP00 |
| H064 | `LR-064` No historical penalties or fixed dollar formulas | scope/verification | REJECT | 3 | WP00 |
| H065 | `LR-065` Supplier onboarding and preapproved party intent | scope/verification | DEFER_OUT_OF_SCOPE | 3 | WP00 |
| H066 | `LR-066` Accounting, CRM, buyer ranking and broad QC platform | scope/verification | DEFER_OUT_OF_SCOPE | 3 | WP00 |
| H067 | `LR-067` Retain useful working freight; do not repeat predecessor campaign | BRS-04 | PRESERVE_EXISTING | 3 | WP05 |
| H068 | `LR-068` Minimal operator-facing exception and next action | BRS-06 | MERGE_WITH_HARDENING | 3 | WP06 |

Original source and extracted evidence are available under `source_inputs/`. The CSV `SOURCE_TO_REQUIREMENT_TRACEABILITY.csv` is the deterministic export.
