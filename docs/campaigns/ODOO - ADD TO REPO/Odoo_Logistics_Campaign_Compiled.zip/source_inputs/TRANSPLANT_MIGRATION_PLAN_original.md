# Transplant and Migration Plan

**Bottom Line:** keep the current Odoo load/freight execution spine and add the smallest missing confirmation, coordination and evidence links. No entire donor addon or service is a valid transplant.

## 1. Scope and authority

This is a proposed implementation design. It grants no repository, database, mailbox, deployment or publication mutation. Existing primary scope is logistics; identified root causes in automation, transaction, facility, documents, native-document mirror, security and tests must be explicitly admitted into a later implementation scope. A downstream workaround in logistics is not a substitute for correcting those owners.

Current explicit intent outranks historical donor defaults. Target-local current freight policy remains binding. Old documents marked Locked or Production Ready do not become new authority by being harvested. The global semantic-foundation harvest edition is not retargeted or used to admit global law.

## 2. Keep / replace / add

**Keep:** `plasticos.load`, `plasticos.dispatch` identities, existing state map, exact transaction relations, carrier/partner master, SAL/context/rate/quote/estimate/actuals owners, Mail queue/thread APIs, QWeb reports, `ir.cron`, activities, document verification models and transaction financial guards.

**Correct in place:** unsafe assigned-picking dispatch, ambiguous order-to-load searches, uncontrolled acknowledgment/BOL assertions, direct packet send semantics, misleading date/currency display, duplicate reminder flows, private-transition milestone prerequisites, stale tests and exact document mirror propagation.

**Add only where irreducible:** request/response identity and current acceptance evidence, then missing typed milestone actions in the existing load owner. Do not add another shipment state machine, carrier registry, scheduling service or broad configurable workflow framework.

### A minimal new representation is justified, not free

Recommended candidate: one load-owned confirmation/request record, provisionally called `plasticos.load.confirmation`. The technical name is **proposed, not observed or admitted**. Existing `mail.message` remains the transport/evidence document; this record supplies the business meaning that a message lacks.

The current obligations it must express are: company/load/transaction binding; one purpose and party/facility; immutable requested facts/version; a stable logical request key independent of payload hash; issued/due/expiry instants; current/superseded/cancelled identity; native outbound/inbound message and attachment references; a typed response outcome with authenticated actor, physical-event time and received-at time; and the accepted commitment reference.

These are semantic obligations, not permission to copy an expansive JSON payload into one field or to add all fields blindly. Reuse inherited/native fields first. Purpose is a small fixed set for the current lifecycle, not a generic plugin catalog. The request outcome is not a second load status. Multiple responses stay in native messages and attributed successor evidence; an accepted response is never silently overwritten.

**Irreducibility witness:** one supplier with two simultaneous loads, two competing dock proposals, a superseding date, an old forwarded reply and a current carrier booking cannot be represented safely by `supplier_ready`, `appointment_requested`, `dispatch_acknowledged` and chatter text alone. Reusing `plasticos.freight.quote.recipient` for cargo readiness would change its freight meaning. A narrow confirmation record closes this obligation without a parallel system. [H002, H010-H014, H018]

**New-file budget:** at most one justified model owner for this representation, its required ACL/rule/data wiring, and only a thin native authenticated submission endpoint if existing extension points do not suffice. Tests and migrations required by the delta earn their files. Exact filenames/version increments are chosen only after inspecting current repository owners. No new runtime/platform/configuration framework.

## 3. Native Mail and authentication contract

Use existing Odoo Mail routing, queue, message and attachment identities. Odoo19 documentation establishes native Odoo.sh reply/alias capability; it does not prove this database/domain is configured. A custom mailbox/domain must be verified in the isolated environment. [O01]

The safe default is an authenticated Odoo counterparty session, an explicitly permitted current party-to-request relationship, a scoped unexpired single-use request challenge, and an intentional POST. The challenge prevents replay/cross-request use; it is not sole identity. Email scanners/GET requests cannot accept. A portal-facing record exposes only the relevant party's allowed projection, not the full confidential load.

The implementation must independently establish the exact available native authentication/portal mechanism before creating a new endpoint. Do not build a new identity platform. An unverified reply or a counterparty unable to provide the approved structured confirmation stays an exception. A mere From address, quoted message, subject ID or bearer link is insufficient. No anonymous quote-token design is resurrected. [H009-H015]

A deterministic response identifies **what** was accepted: cargo availability, a specific appointment, the commercial terms and capacity of a booking, receipt of a particular document packet, or a physical checkpoint. `confirmed=true` without a current typed object is ambiguous. Counterproposals and rejections are first-class outcomes. Raw conversational text never invokes a consequential action.

### Request and event admission, in order

1. Resolve authenticated actor and allowed company/party without disclosing other records.
2. Resolve exact request and load/transaction/facility. Reject order-only ambiguity.
3. Validate active request revision, expiry, accepted proposed facts and current context.
4. Acquire the existing load/operation transaction serialization boundary and re-read.
5. Resolve stable business-operation identity; exact replay is no-op, payload drift is a conflict.
6. Persist evidence and controlled request outcome, then invoke the canonical milestone command.
7. Reconcile only affected projections/reminders and preserve the complete prior evidence trail.

Unsolicited messages remain native message evidence until uniquely associated and authorized. They do not create loads or grant commercial permission.

## 4. State mapping: no new load enum required

| Business milestone | Existing load representation | Required evidence / effect |
|---|---|---|
| Eligible transaction | Draft, then awaiting_ready through a governed entry action | Authorized commercial release, exact movement and company |
| Cargo available | ready_confirmed | Direct shipper READY for this load, named actor/time, current availability |
| Freight approved | rate_confirmed | Existing operator/SAL/manual quote command and current freight context |
| Slots being coordinated | Confirmation records, not a new load state | Independent origin/destination proposals and acceptances or verified FCFS |
| Truck committed | scheduled | Accepted current carrier capacity/equipment/windows; required slots and freight valid |
| Packet sent | Scheduled plus native mail evidence | Three current correct documents to carrier, no premature release |
| Carrier packet receipt / release | dispatched | Authenticated receipt of exact packet revision, all prerequisites still current |
| Pickup / in transit | picked_up plus checkpoint evidence | Physical pickup evidence, actual event time; later progress/delay checkpoints |
| Delivery | delivered | Correct receiver/destination evidence and required delivery verification |
| Logistics complete | closed | Required current verified BOL/POD/documents and no unresolved close blocker |
| Exception | Existing exception/activity mechanisms | Block the relevant action without manufacturing a backward physical transition |

`_transition` remains the single load transition mechanism. Its caller cannot avoid milestone proof merely because the transition order is valid. Conversely, receipt of a future event is stored, not discarded or used to invent missing predecessors.

The v1.3.1 carrier receipt requirement creates an intentional distinction between **sending instructions** and **releasing dispatch**. Sending the packet is permitted at Scheduled only after booking/readiness/appointments. `action_dispatch` requires packet receipt; packet send must not require Dispatched. [H029-H030, V41]

## 5. Scheduling and carrier commitments

Resolve each actual facility's FCFS/appointment rule and current operating facts. Missing or seeded defaults are not external confirmation. When delivery needs a dock appointment, get an accepted destination slot before finalizing supplier pickup. Coordinate feasibility using real carrier capability, travel-duration evidence and loading windows; do not turn Haversine features into an invented ETA. [H016-H022]

Do not implement a global dock availability calendar or assume every overlapping load at a facility conflicts. Enforce exclusive slot/resource identity only when that resource is actually known; otherwise obtain facility acceptance. Slot proposals can be gathered early, but commitments are current and explicit.

Retain existing SAL, exact context checks, operator award and manual-only RFQ. SAL answers which current approved carrier/rate may be reused; it does not prove the carrier has a truck for today's slot. A booking confirmation binds that carrier, approved rate/currency, equipment and exact pickup/delivery windows. Free-text conditions or equipment substitution require an exception/approved amendment. [H023-H028]

For failed capacity or post-confirmation changes, use a narrow approved recovery action, not first/next-cheapest carrier selection. Preserve original rate/quote/booking evidence, invalidate only affected future commitments, and require renewed acceptance. A physical pickup already completed cannot be undone by resetting the load to Draft.

## 6. Exactly one send obligation, not fictional exactly-once SMTP

The native queue and business operation record should commit together. A unique logical operation plus transaction lock prevents duplicate enqueue from UI, cron, import hooks and replay. A payload fingerprint separately catches drift. Editing a template must not mint a second initial packet for the same operation. [H013, H034-H035]

External SMTP acceptance and Odoo database commit are not one atomic transaction. A timeout/crash after provider acceptance can leave the send outcome unknown. Preserve native/provider message identity, reconcile it, and hold irreversible rebooking/re-dispatch rather than blindly creating another external action. This pack does not promise exactly-once delivery where the transport cannot demonstrate it.

Preserve original-send time; separate subsequent attempts and reminders. Queued is not sent, sent is not received, received is not booking acceptance, and packet receipt is not pickup. Render the accepted currency and correct local windows. Test the actual current Odoo template engine/report rendering; do not assume historical Jinja-like template source renders correctly.

### Double-blind release guard

Apply role-specific content and recipient checks before queueing and at resend/composer submission. Check To/CC/BCC, attachment identity, generated report audience, reply references and follower notification paths. Do not put both external parties on a shared confidential load thread. Supplier/buyer output must not consume unrestricted shared notes, internal transaction folder names or arbitrary uploaded attachments. Carrier gets necessary execution locations, not supplier/buyer commercial pricing documents. [H031-H033]

Literal retained rules: carrier DO/combined packet only to carrier; no buyer/supplier CC on trucker communication; no Sales CC on buyer SO communication; archive through Odoo, not an email CC. A later business override needs explicit user approval, not a template default.

## 7. One scheduler and one actionable exception surface

Reuse the current logistics scheduler/escalation owner and Mail queue. Consolidate the overlapping PO, picking and load flows through a per-obligation owner and approved activation migration. Do not add independent cron clocks because each donor had one. [H037-H040]

Each active obligation has a next required fact and approved due time. Evaluate `due <= now`, not exact clock equality. Re-read acceptance/cancellation under transaction lock before enqueue. Use bounded, fair progress so old blocked records cannot starve later loads. Stop acknowledgment reminders on valid receipt, but continue pickup/delivery monitoring. Treat quiet-hour deferral separately from urgent internal owner activities.

Weekly shipper status and daily overdue-request chase serve different purposes. The Monday-morning intent is retained, but the exact hour/time zone and interaction with current daily reminders need a single policy decision. Donor 2h/4h/09:00/13:00/07:00/08:00 defaults are not all installed. [A03]

Every exception uses existing activities with load, blocked milestone, cause, last verified fact, evidence references, responsible owner and permitted next action. Deduplicate by unresolved obligation/revision, not a fragile substring/date-only chatter search. Resolving one issue must not erase another or mark disputed delivery complete.

## 8. Documents and verified downstream handoff

Native `documents.document`, `ir.attachment`, the existing `plasticos.document` mirror and compliance service remain the owners. Keep files once, expose party views through tags and safe references, and retain original bytes. Exact request authentication/correlation precedes business assignment. Do not use sender-domain or first PO/SO match to associate an attachment. [H046-H047]

Strengthen load closure in the existing **documents-to-load extension** (`plasticos_documents/models/load_docs_bridge.py`) so logistics does not add a circular dependency on its downstream document addon. Required verified/current/nonexpired/non-superseded files must match exact load/company/party and purpose. Merely generating the three outbound reports is not signed completion evidence. [H048]

The freshly inspected native mirror update copies verification flags only. Prove another current owner propagates changed attachment/tag/business linkage or repair the existing mirror helper. Link and proof must remain coherent across native and legacy surfaces. Avoid a second synchronization engine. [F-025, H049]

Hashes bind bytes and versions. A signed BOL/receiver attestation is verified only through an approved deterministic mechanism or a real authorized reviewer. OCR confidence, matching filenames and valid hashes cannot create signer authority. Ambiguous documents are archived and reviewed while required missing facts still block closure. This explicitly rejects the donor's blanket unsigned/low-confidence automatic close policy. [H050]

When delivery is verified, reconcile exact load, transaction and native stock movement. Use native stock validation with correct route/quantities, not raw `state=done`; a return or incoming receipt cannot masquerade as outbound buyer delivery. Then publish logistics completion facts. Existing posted-invoice, manager, compliance and margin constraints retain financial close authority. [H053-H054]

## 9. Transplant map: old fields and methods are evidence, not target schema

| Donor element | Existing destination / selected treatment | Migration prohibition |
|---|---|---|
| `sm.tx`, donor `tx_id` | Existing `plasticos.transaction` and proven load/order allocation | Do not install a second transaction model or map by first order match |
| `x_ready_for_pickup`, donor confirmation time | Current readiness projection plus source-bound per-load evidence | Never mark all loads on a PO ready from one Boolean |
| `x_appt_requested` | Existing request indicator / proposed confirmation record | Never migrate to accepted slot |
| `x_appointment_confirmed`, datetime | Candidate commitment only with source/party/zone/version proof | A legacy Boolean is an assertion, not acceptance |
| `x_broker_id` / donor auto-carrier method | Existing approved carrier master and freight command | No first-carrier/automatic substitute award |
| `x_receipt_confirmation` | Current packet-revision receipt evidence | A true flag cannot stop reminders until validated/adopted |
| `x_broker_notified_on` | Historical send assertion pending native message reconciliation | Do not create a new send merely because provider evidence is absent |
| tracking/estimated/actual fields | Existing load/transaction dates plus attributed checkpoints | No GPS, guessed ETA or stock done on pickup |
| POD/BOL/CST flags | Existing exact attachments/tags/verification | No flags-to-signed-doc backfill |
| generic `update_odoo_status` cascade | Existing named business actions and exact bridges | No arbitrary model/status API or raw picking state writes |
| donor hash ACK | Exact current file/version integrity plus existing verification | Hash is not identity, acceptance or financial authority |
| Supabase/Redis/archive tables | Existing Odoo persistence/queue/documents | No parallel stores or mirrored live gating authority |
| static party lists/vendor-form policy | Existing upstream partner/commercial owner | No new CSV carrier/party registry or unrelated procurement rewrite |

## 10. Deployment and data migration sequence

**Read-only preflight:** establish deployed module versions, model/field registry, mail routes, active crons/base automations and their XML IDs, user/group grants, pending native mail, current dispatch usage, document links, open load cardinality and production routes. Do not fetch secret values into reports. Compare to the pinned source; new head changes invalidate only affected evidence, not all prior work.

**Schema and code migration:** use repository-owned migration/version conventions, with current commands verified first. Add only nullable/inactive upgrade-safe structures that do not reinterpret historical values. Existing published identities stay; obsolete donor modules are not installed. A fresh install and an upgrade clone are both required.

**Cohort classification:** verified evidence; legacy assertion; contradiction; unassociated. Do not silently label an old accepted slot, delivery flag or sent timestamp as authenticated proof. Bind source IDs and status reasons, retain existing business history, and obtain explicit owner adoption before enabling automatic transitions for existing loads.

**Writer cutover:** inventory and disable only the proven conflicting automation XML IDs for an approved cohort. Reconcile queued/sent messages before starting new obligations. A kill switch prevents new coordination without erasing past sends/acceptances. No blanket `active=True` on install, no double poller or dual-write interval.

**Isolated proof:** controlled mail sink and egress guards; production-equivalent Odoo19/Enterprise addons/roles/routes; realistic synthetic loads plus safely neutralized clone data. Do not use a live business recipient during tests. Repeat events and scheduler ticks against the same identities; do not re-run unrelated external-data imports to simulate replay.

**Controlled pilot:** explicit operator approval for real mailbox/domain changes, live sends and cohort activation. Track actual routine manual interventions, overdue checkpoints, identity conflicts, queue failures and false-progress attempts. Do not invent a target percentage of autonomy.

**Rollback:** stop new outbound coordination; leave immutable evidence and physical/financial history; cancel only uncommitted scheduled work; resolve uncertain external effects before retry. Code/schema rollback must not break existing document or quote records. Roll forward with a repair when a destructive downgrade would lose evidence.

## 11. Dependency-bound work packages
| Package | Stage | Depends on | Outcome | Scope status |
| --- | --- | --- | --- | --- |
| WP00 Revision and permission preflight | P00 | none | Read-only census, active-rule/runtime inventory, approval decisions and exact authorized paths. | READ_ONLY |
| WP01 Canonical safety, entry and association | P01 | WP00 | Canonical command closes all public/automatic send and state bypass seams, with no premature stock/transaction completion. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP02 Party-scoped request evidence and native transport | P02 | WP01 | One minimal fixed-purpose confirmation record plus native authenticated action/message correlation; no external processor. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP03 Closed-loop shipper readiness | P02 | WP02 | Direct shipper READY for one exact load, named/time-bound evidence, counters and reminders stop correctly; approvals remain. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP04 Two-ended appointment coordination | P03 | WP03 | Destination-required appointment accepted before final pickup commitment; FCFS/unknown handled independently per facility. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP05 Current carrier booking and recovery | P04 | WP04 | Preserve SAL/manual RFQ/ranking; bind explicit accepted carrier capacity/equipment/windows; no unauthorized rebooking. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP06 Guarded packet and receipt-to-release | P05 | WP05 | One audience-safe current packet in Scheduled, true transport status, valid packet receipt then Dispatched. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP07 Verified checkpoints and one scheduler | P05 | WP06 | Due checkpoint requests, cancellation, concurrency, fair catch-up and actionable exceptions cover active transit, not just dispatch ACK. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP08 Current document evidence seam | P06 | WP02 | Exact current native attachment/legacy mirror and guarded verification; correct party/load/version and required document criteria. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP09 Verified delivery and downstream reconciliation | P06 | WP07, WP08 | Receiver-backed delivery, native stock validation, load closure and facts-only financial handoff; disputes stay open. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP10 Upgrade and controlled data adoption | P07 | WP09 | Preserve assertions, current IDs and prior business history; initialize only reviewed cohorts; disable specific conflicting rules. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |
| WP11 Isolated acceptance and pilot release decision | P07 | WP10 | Execute all relevant cases with source/run/DB/mail evidence; no fake PASS. Pilot needs separate live-send and deployment grant. | PROPOSED_SCOPE_REQUIRES_AUTHORIZATION |

### Concurrency without collisions

After WP02 freezes the request/evidence interface for implementation, WP08 document-owned work can proceed alongside WP03-WP05 logistics work. Contract fixtures can be prepared independently. One integrator owns `load.py`, shared state rules and `workflow_automations.xml`; do not assign independent agents overlapping edits and call that concurrency. Cohort migration waits for integrated proof.

Stage gates permit a useful readiness-only vertical slice before the final full lifecycle: the enabled slice must pass its own safety, authentication, identity, replay and reminder tests. Do not enable unimplemented downstream autonomous actions or claim complete logistics. This keeps the next useful release bounded instead of turning all 90 final scenarios into a blocker to a safe isolated readiness demonstration.

## 12. Decisions requiring explicit ownership, not guessed defaults
| Decision | Recommendation | Why required | Safe boundary |
| --- | --- | --- | --- |
| A01 Minimal request identity and secure confirmation interface | Recommend one load-confirmation entity owned by plasticos_logistics, using native Mail and authenticated partner-specific actions. | Needed because existing booleans/threads cannot express per-party competing requests, exact payload revision and verified response. No generic workflow engine. | Schema/naming/dependency review before WP02; proposed name is not an existing or admitted API. |
| A02 Evidence-only service authority | Recommend narrow operation permissions for routine facts, never blanket carrier/rate award. | Current freight operator gate covers both routine and commercial commands; unattended service needs an explicit bounded delegation. | Keep current operator gate until reviewed security contract exists. |
| A03 Current reminder timing and facility clock | Honor Monday-morning status intent; choose one approved hour/zone and reconcile daily readiness cadence. Preserve approved live thresholds until changed. | 2h/4h and pre-pickup times disagree across donors; some are expressly superseded. Exact Monday hour is not supplied. | Configuration approval before that touch is activated; do not block test of message correlation. |
| A04 Document verification and required receipt evidence | Preserve signed/current BOL requirements and receiver evidence; authenticated file attestation is not automatically a signature verifier. | Low-confidence or unverified scans cannot auto-close under the deterministic/no-AI constraint. | Use a real exception/manual verifier unless an existing lawful verification mechanism and authority are proven. |
| A05 Post-confirmation recovery and amendment | Recommend versioned cancellation/reconfirmation of affected future commitments; preserve physical milestones. | Current context guard blocks changed freight but a safe recovery action is not established. | No carrier substitution or exception->Draft physical rewind without an approved narrow recovery contract. |
| A06 Existing data and document adoption | Classify old values as verified, asserted, contradictory or unassociated; activate only explicit eligible cohort. | Donor schemas are design, not actual production rows. Historical flags cannot be upgraded to evidence. | No production backfill/migration until data inventory, backup and bounded write grant exist. |
| A07 Necessary integration mutation scope | Propose exact affected logistics, automation, transaction, document, facility and security paths, plus focused tests/migrations. | Original audit permitted adjacent inspection only. The transplant plan does not silently expand execution authority. | Obtain explicit path/delta grant before implementation; no repo writes in this campaign-pack task. |
| A08 Isolated runtime and live pilot | Use production-equivalent Odoo19/Enterprise disposable database with blocked operational recipients and controlled mail sink. | No deployed registry, mail routing, active crons or DB access is proven here. | Separate authorization for live mailbox/domain changes, real messages, deployment and production cohort enablement. |

## 13. Definition of done

For an enabled routine slice, each action has a source-backed prerequisite, authorized actor, exact identity, idempotent operation and honest transport/outcome status; each wait has one deadline owner; exceptions are actionable and resumable. Full lifecycle acceptance additionally requires correct receiver/doc evidence, native stock/transaction handoff and restart/replay without duplicate effects.

No claim of full unattended coordination is made until those real runtime receipts exist. Commercial rate/carrier decisions still reserved to a person remain intentionally human-gated. Free-form, disputed, unverified-scan and unavailable-carrier cases are genuine exceptions, not an AI dependency to conceal.

**Next Highest Leverage Move:** separately authorize the WP01-WP03 readiness foundation with the exact adjacent safety/identity/security paths needed. Preserve the current freight engine and stop at the first proven useful closed loop.

**Devil's Advocate:** Secure structured confirmation may require counterparties to use an authenticated response flow. Counterparty adoption and document-verification authority, not the number of Python methods, determine how much routine work becomes unattended.
