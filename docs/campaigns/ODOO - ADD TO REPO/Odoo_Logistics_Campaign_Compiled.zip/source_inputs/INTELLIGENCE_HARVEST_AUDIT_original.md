# Intelligence Harvest Audit: Linda Deterministic Logistics

**Bottom Line:** No inspected historical donor is a safe replacement for the current module. The useful combined design is current Odoo execution plus per-load shipper proof, two-ended appointment coordination, explicit carrier booking, audience-safe packet delivery, verified checkpoints and document-backed closeout.

Target `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e` on `Staging`; module `19.0.1.10.3`. This report records source observations and proposed corrections. It does not record a deployed incident, passing Odoo test or permission to mutate.

## 1. Executive judgment

**Current unattended lifecycle: NO. Existing component capability: PARTIAL. Deployed operational status: NOT_ESTABLISHED.** The preceding exact-SHA audit found missing response admission, appointment/carrier commitment, milestone evidence and downstream reconciliation, plus unsafe alternate send paths. The expanded donor harvest fills design gaps, not live integrations.

The main remaining work is orchestration under existing authority, not a new rate estimator or freight marketplace. Current SAL, context-bound rates, manual-only RFQ, immutable quote evidence and recommendation-only ranking are valuable and stay closed unless an affected regression proves a contradiction. [T01, T09-T12, T33, T37]

Three complementary donors materially change the roadmap:

- **D07 v1.3.1:** sales release is not shipper readiness; every load needs a direct named/time-bound READY response. If delivery needs an appointment, its accepted slot constrains pickup. Monday shipper updates use PO number plus shipper company. [E43-E44]
- **D02 v6:** contains actual Odoo representations for appointment acceptance and planned/actual checkpoints, but its code can finish a picking at pickup, select the first carrier and report placeholder actions as success. Harvest the missing facts and obligations, not those methods. [E21-E24]
- **D09 September v2.1:** explicitly preserves Odoo ownership and rejects earlier parallel services, custom threads, anonymous quote tokens, fixed timer policy and automatic award. Much of its freight intent already exists in the current target. Its AI/Gate portions are excluded by the current no-AI mission. [E46-E48]

D06 adds replay/conflict/version semantics, D04 supplies acknowledgment and role contracts, and D01/D10 supply strict communications and document ownership. Their contradictions are reconciled explicitly below.

## 2. Evidence discipline and scope

The current target SHA was re-read through GitHub's connected read interface. Prior primary file inspection at that identical revision is reused with exact coordinates; fresh inspection additionally covers native document synchronization. This does not transfer prior runtime validation, which was not established.

The uploaded v1 ZIP has SHA-256 `4b863c881af5e0d201d399fad0911e3306aa52e2197f25212a233cddfee273e7`. Its 115 extracted material files have per-file hashes in `evidence/uploaded_archive_inventory.json`. Selected original policy bytes are retained. Other local files are explicitly marked inspected, placeholder, adjacent, or inventoried-only; a file census is not a semantic audit of every line.

Remote Dropbox evidence is connector-extracted text, with source paths, modification dates and, for D09, Dropbox revision `65b89a8f685ae017b8a0b`. It is not represented as locally rehashed original bytes. Duplicate/mirrored archives do not count as independent confirmations. Current deployment claims embedded in old READMEs are treated as donor assertions, never operational proof.

The in-scope search covers the ten identified donor families, their selected logistics-relevant files and the nine-milestone operating lifecycle. It excludes n8n material, caches, virtual environments, secrets, unrelated accounting/CRM/matching code and duplicate backups without a demonstrated relevant delta. Uninspected remote tail files and complete original chat history remain a coverage limitation, not a claim that no additional useful artifact exists.

The installed `l9-intelligence-harvest` edition was inspected and has a fixed global `.github` semantic-foundation beneficiary. It was **not retargeted** to Odoo and its native HarvestIR identity was not imitated. This is a project-native intelligence ledger, with GAR architecture reasoning and native evidence assessment kept distinct. There is no global-law promotion, strategic admission or compiled coding-delegation claim.

## 3. Donor census and disposition
| Donor | Role in this harvest | Inspected coverage | Excluded/limited |
| --- | --- | --- | --- |
| D01 Uploaded Linda v1 package / embedded v5 and Odoo prototypes | Primary operator-intent and negative-code donor; source ZIP is not a deployment package. | 115 extracted non-directory, non-macOS files inventoried; selected logistics policies, schemas, document specs and prototypes inspected. | Odoo 18 manifest; tiny action stubs; adjacent accounting/product/AI material excluded. |
| D02 Linda v6 Odoo | Primary native-code concept donor: accepted appointment concept, actual/planned checkpoints, party deadlines. | Recursive folder listing completed; logistics_fields.py and logistics_automation.py inspected, including tail; manifest/imports and older source inspection retained. | Do not install sm.tx, generic status cascade, first-carrier selection, pretend-success helpers, direct stock done writes. |
| D03 Linda v4 Odoo dispatch variant | Dispatch prerequisites and acknowledgment examples; especially useful negative controls. | Root/controllers/models inventory in prior turn; dispatch variant re-read in this harvest; other helpers represented by local prototypes. | Mock lane/rate history, placeholder document validation, unauthorized auto-award, PO disclosure to carrier rejected. |
| D04 Linda FastAPI v7.9.8 / v7.9.9 | Complementary business contracts, not a second service runtime. | 57-item folder listing available from preceding discovery; selected workflow, document-completion, safety, readiness, threading, recovery and approval policies inspected. | Not every file independently fetched. Fixed scores/timers/fees, Supabase, reassignment and premature financial close rejected. |
| D05 Linda v7.9.1 five modules plus checkpoint ZIP | Negative controls and audience/communication intent. | All six ZIP text extractions inspected during preceding discovery; file census re-searched this harvest. | No drop-in reuse: arbitrary HTTP payloads/paths, no native state guards, weak keyword classification, independent databases. |
| D06 Standalone logistics DevKit, non-n8n material | Replay/conflict semantics, versioned evidence, separate planned/actual times and cancelable reminders. | Content Hash ACK, Idempotency Store, Escalation Ladder, Dispatch Templates and Close Out Pack inspected; Manus demo source inspected in preceding turn. | No Redis/S3/Kafka/i18n service stack, n8n wiring, SMS dependency, OCR gate, hash-as-delivery-proof or unsigned automatic closure. |
| D07 Canonical Logistics v1.3.1 | Strongest concrete per-load readiness and two-facility appointment ordering intent. | Both files fetched: End-to-End Workflow DOCX and Dispatch Templates Markdown. | DOCX text extraction only, not layout or signatures verified. Monday morning hour and other operational choices need approved configuration. |
| D08 Earlier plasticos_logistics Odoo19 snapshot | Historical comparison; acknowledgment-lock example worth preserving as a regression requirement. | Manifest, load, dispatch, state machine, cron and directory contents inspected previously. | Earlier version 19.0.1.2.0, not replacement for current 19.0.1.10.3. No byte-equivalence claim to target. |
| D09 Linda freight intelligence dev pack v2.1 | Supersession check and preservation of already-implemented freight controls. | Newly discovered. Metadata revision 65b89a8f685ae017b8a0b; locked decisions D-001 through D-029, baseline and transplant ledger inspected; remaining ZIP sections selectively located. | Historical evidence baseline is not current source. AI/Gate and buyer-ranking portions excluded; own validation claims not replayed. |
| D10 Linda v5 outer document/workflow narratives | Party-specific missing-document handling, store-once/tag-many views, native activity escalation. | Outer folder inventoried previously; logistics narrative previously read and document-management workflow fetched this harvest. | OCR-first classification, sender-domain assignment, SMS alternation and accounting redesign excluded. |

### What was not established

A source file's `production_ready: true`, successful archive extraction, a version number, a fake carrier-history return or an HTTP 200 test does not prove installation, authentication, correct business transitions or physical delivery. No donor code, historical test suite, SMTP send or Odoo database operation was executed.

## 4. Reconstructed operator intent, with fidelity tests

The commercial owner decides when a transaction enters logistics. Linda obtains missing operational facts and explicitly attributed acceptances, coordinates the parties, sends the permitted documents, chases only missing milestones and brings humans exact exceptions. An operator's freight decision remains legitimate human involvement, not an automation defect. [E43, E46-E47]

Per-load shipper READY requires a current supplier/facility identity and name/time evidence even after a sales release. A PO-level Boolean cannot prove readiness of every movement sharing that PO. The current unique load-to-transaction relationship must survive; ambiguous multi-movement association is resolved by existing exact allocation or blocked for a bounded cardinality decision, not hidden in first-record search. [E43, T01, T13]

Dock rules are independent at origin and destination. Unknown does not mean FCFS; FCFS does not mean immediate loading or material availability. A destination appointment constrains final pickup scheduling. Slot proposals, acceptances, cancellation and amendments retain their history. No new dock-capacity platform is justified merely to coordinate external facilities. [E43-E44, E21, T22]

Rate selection, carrier capacity commitment, packet receipt, pickup, receiver delivery and logistics close are separate milestones. The three carrier PDFs can be sent while Scheduled after readiness/appointments/booking are valid. Packet acknowledgment then permits Dispatched. This satisfies the v1.3.1 receipt-before-release intent without the circular dependency of demanding Dispatched before sending the request. [E44, T01, T25-T28]

Documents live once under existing Odoo ownership with role-filtered views. Required signed/current BOL and receiver evidence cannot be replaced by Boolean flags, filename tags, OCR guesses or matching content hashes. Logistics completion hands facts to finance without closing the commercial transaction or posting bills. [E08, E38, E41, E49, T04-T08]

## 5. Current execution versus the proposed connected path

```text
CURRENT SOURCE
PO/SO automation -> queued request -> free-text reply -> [no verified admission]
load form -> Draft -> [missing governed initiation/ready integration]
operator-ready -> existing SAL/manual freight -> dates -> Scheduled
assigned-picking alternate send -----------------------> dispatch_sent flag
canonical load Dispatch -> packet composer/direct send -> [unverified ACK]
private pickup/delivery edge -> flags -> Close
stock picking done -> first related transaction delivered (independent path)

PROPOSED, USING EXISTING OWNERS
commercial release + exact load/company/allocation
 -> direct shipper request -> authenticated current READY evidence
 -> resolve each facility's dock rule
 -> accept destination slot first when required -> feasible origin commitment
 -> existing authorized SAL/manual freight decision
 -> carrier accepts exact equipment/rate/windows/context
 -> Scheduled -> current three-document carrier packet queued/sent
 -> authenticated receipt of that packet revision -> Dispatched
 -> verified pickup -> picked_up + attributed in-transit checkpoints
 -> correct receiver/destination evidence -> Delivered
 -> required current verified documents + no unresolved close blockers
 -> logistics Closed -> verified facts handed to existing transaction/stock owners
 -> financial close stays under its separate existing authority

Every wait has one owner, a next expected fact and an approved due time.
Every ambiguous, unauthorized or contradictory event becomes retained evidence
and one actionable exception, not a guessed transition.
```

## 6. Concrete source risks that cannot be transplanted

**False movement facts:** v6 `action_confirm_pickup` writes `state=done` on the picking; generic cascade code directly writes stock state. Copying that path would turn pickup into delivery. [E21-E22]

**False execution success:** v6 portal/notification helpers return true after logging a placeholder, and dispatch updates can proceed even when an email helper returns false. API wrappers in v7.9.1 lack canonical load prerequisites. [E22, E32-E36]

**False commercial authority:** first active carrier, mock lane history, weighted readiness and 30-day string caches cannot replace current context/role/selection guards. [E22, E24, E27, E34, E46]

**False evidence equivalence:** document hashes prove byte identity; receipt of an email proves neither acceptance of its booking terms nor fulfillment. A supplied PO number or familiar sender cannot identify a unique load across companies. [E37-E38, E06, T01, T13]

**A newly inspected target seam:** the native-to-legacy document mirror's update helper copies verification/override fields but not the changed attachment, type or business-link identity. Required closeout tests must prove another owner handles these changes or repair this existing helper. This is a source-level seam finding, not a claim of a observed production misfile. [T07]

## 7. Cross-donor conflicts, resolved rather than accumulated
| Conflict | Conflicting donor interpretation | Selected resolution | Matrix row |
| --- | --- | --- | --- |
| C01 | FCFS means immediate dispatch/skip readiness | FCFS removes only appointment requirement. Direct cargo readiness remains mandatory. | H019 |
| C02 | Sales ready replaces shipper ready | Sales release starts the process; shipper named/timestamped readiness is still required per load. | H004 |
| C03 | Pickup-first booking everywhere | When delivery appointment is required, accepted destination slot constrains final pickup commitment. | H017 |
| C04 | Weighted readiness threshold | All mandatory dispatch prerequisites must hold; no score can omit rate/carrier/ready requirements. | H063 |
| C05 | First/next-best/cheapest carrier automatically wins | Preserve operator carrier/rate decision and manual RFQ; failed capacity is an exception, not automatic reassignment. | H028 |
| C06 | Any keyword, sender, subject or anonymous token proves acceptance | Authenticate intended party and current typed request; preserve free text as evidence only. | H011 |
| C07 | SMTP returned/no exception means received or fulfilled | Queue, transport acceptance, recipient acknowledgment and fulfillment are independent events. | H034 |
| C08 | Mark stock picking done at pickup | Pickup is not delivered stock. Use correct native move/route validation only on supported receipt/delivery facts. | H042 |
| C09 | Content hash or low-OCR archive unlocks financial close | Hash proves bytes, not signatures/receiver truth; required docs and existing financial close gates remain. | H048 |
| C10 | Install all historical timers and quiet hours | One approved policy per logical touch; no stacked reminders. Exact hour and changed thresholds remain explicit approvals. | H039 |
| C11 | Content-hash-only dedup and cache expiry imply exactly-once | Stable operation identity plus payload drift check, durable revision and transaction locking; uncertain SMTP effects require reconciliation. | H013 |
| C12 | Corporate partner/default field is facility confirmation | Actual origin/destination each supplies requirements; legacy defaults are assertions, not verified FCFS. | H016 |
| C13 | Required account numbers, fees, weights and carrier history may use defaults | No invented operational or commercial facts. Consume current approved inputs; missing stays unknown. | H064 |
| C14 | Legacy file version number supersedes current implementation | Current target source/policy and explicit mission control. September AI/Gate components are excluded by this deterministic mission. | H067 |
| C15 | Store copies per party folder or use Supabase archive SSOT | One existing Odoo attachment identity, versioned evidence and role-filtered views; no second archive system. | H046 |
| C16 | Buyer/Supplier threads or blanket Sales CC are harmless | No buyer-supplier cross-disclosure, no Sales CC on buyer SO, no archival CC; guard followers and quoted content too. | H032 |

## 8. Harvest matrix

The full machine matrix is `audit/harvest_matrix.csv`; `audit/harvest.json` retains source anchors, exact owners, approval boundaries, migration rules and acceptance cases. The following is its readable projection. **Preserve** means no new feature implementation is authorized by that row, not that runtime is proven. **Reimplement** means reuse domain meaning in existing owners, not copy unsafe source.
| ID | Capability / harvested meaning | Donor evidence | Current evidence | Disposition / stage | Target owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- |
| H001 | Sales release starts logistics; supplier READY remains separate | E43 E25 E20 | T04 T14 | NATIVE_REIMPLEMENTATION / P01 | plasticos_logistics/models/sale_order_inherit.py + models/load.py | V01 V02 V18 |
| H002 | Exact transaction/load/PO/SO association | E06 E43 E46 | T01 T13 T38 | MERGE_WITH_HARDENING / P01 | plasticos_logistics/models/load.py + models/transaction_inherit.py | V03 V04 V88 |
| H003 | Company ownership cannot be unknown for automation | E46 E06 | T01 T23 | MERGE_WITH_HARDENING / P01 | plasticos_logistics/models/load.py; plasticos_security_base/security/record_rules.xml | V04 V80 |
| H004 | Direct shipper READY for every load | E43 E01 E21 E22 | T01 T17 T04 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics/models/load.py; plasticos_automation supplier bridge | V11 V18 V21 |
| H005 | Ready date versus proposed date | E21 E22 E06 | T01 T04 | MERGE_WITH_HARDENING / P02 | plasticos_logistics/models/load.py | V17 V55 |
| H006 | Explicit negative and corrected responses | E09 E22 E43 | T01 T04 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics/models/load.py and native party conversation | V19 V16 V82 |
| H007 | Monday shipper status request | E43 E44 E14 | T17 T16 | CONFIGURE_AFTER_APPROVAL / P02 | existing plasticos_logistics cron + plasticos_automation mail templates | V20 V50 |
| H008 | Required cargo/equipment facts | E06 E43 E21 | T01 T12 | MERGE_WITH_HARDENING / P03 | plasticos_logistics/models/load.py | V36 V28 V68 |
| H009 | Native Odoo Mail, not a mailbox microservice | E30 E47 E02 | T01 T37 O01 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics Mail integration; configured Odoo alias domain | V09 V10 V78 |
| H010 | Typed request evidence with minimal new persistence | E06 E21 E37 E38 | T01 T09 T10 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics, one proposed load-confirmation record type | V11 V15 V16 V43 |
| H011 | Authenticated structured confirmation | E43 E06 E47 | T01 T09 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics confirmation command; native authenticated portal/mail capabilities | V11 V12 V13 V14 V84 |
| H012 | Separate transport, proposed observation and accepted fact | E28 E36 E46 | T01 T03 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics confirmation command | V10 V17 V35 V85 |
| H013 | Stable business identity independent of payload hash | E37 E38 E40 | T01 T09 | MERGE_WITH_HARDENING / P02 | plasticos_logistics confirmation/send command + native Mail | V15 V48 V49 |
| H014 | Stale, forwarded and contradictory replies | E37 E38 E46 E06 | T01 T09 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics confirmation command | V13 V15 V16 V19 |
| H015 | Evidence-only service capability | E31 E46 E01 | T01 T10 T24 | NATIVE_REIMPLEMENTATION / P02 | plasticos_logistics guarded actions; plasticos_security_base role owner | V08 V21 V80 |
| H016 | Per-facility unknown-safe dock rules | E43 E21 E17 | T22 T21 T01 | MERGE_WITH_HARDENING / P03 | plasticos_facility_profile actual facility fields; plasticos_logistics load | V22 V23 V25 |
| H017 | Delivery slot constrains pickup scheduling | E43 E44 E28 | T01 T21 | NATIVE_REIMPLEMENTATION / P03 | plasticos_logistics scheduling command | V24 V26 V28 |
| H018 | Proposal/request/acceptance/cancellation distinction | E21 E28 E43 | T03 T21 | NATIVE_REIMPLEMENTATION / P03 | plasticos_logistics confirmation records; existing SO bridge projection | V26 V29 V81 |
| H019 | FCFS removes only appointment gate | E17 E26 E43 | T01 T22 | MERGE_WITH_HARDENING / P03 | plasticos_logistics scheduling prerequisites | V18 V23 V32 |
| H020 | Facility time zones, hours and lead time | E21 E39 E43 | T01 T22 | NATIVE_REIMPLEMENTATION / P03 | facility requirements owner; plasticos_logistics scheduling | V27 V28 V52 |
| H021 | No invented dock-capacity subsystem | E21 E43 | T01 T22 | MERGE_WITH_HARDENING / P03 | plasticos_logistics scheduling | V26 V30 |
| H022 | Amendment invalidates dependencies | E38 E46 E43 | T01 T12 | NATIVE_REIMPLEMENTATION / P03 | plasticos_logistics recovery/confirmation command | V16 V29 V38 V82 |
| H023 | SAL and canonical executed history | E46 E47 E34 | T11 T12 T01 T33 | PRESERVE_EXISTING / P04 | existing SAL/context/rate owners | V31 V38 V79 |
| H024 | Estimate/recommendation/award/actual remain distinct | E46 E47 E34 | T09 T10 T37 | PRESERVE_EXISTING / P04 | existing local estimation, quote and actual-cost owners | V31 V34 V39 V40 V79 |
| H025 | Manual-only RFQ after SAL miss | E46 E47 E13 | T01 T09 T37 | PRESERVE_EXISTING / P04 | plasticos_logistics existing freight request action | V33 V34 |
| H026 | Immutable market response and recipient evidence | E46 E47 E06 | T09 T10 T33 | PRESERVE_EXISTING / P04 | plasticos_logistics/models/freight_quote.py | V39 V15 V79 |
| H027 | Carrier commitment beyond approved rate | E28 E21 E43 | T01 T09 | NATIVE_REIMPLEMENTATION / P04 | plasticos_logistics booking confirmation command | V32 V35 V36 |
| H028 | Unavailable carrier routes commercial exception | E22 E24 E30 E31 E47 | T01 T09 | MERGE_WITH_HARDENING / P04 | existing freight recovery and operator owner | V37 V38 V82 |
| H029 | One guarded dispatch authority | E02 E18 E47 E32 | T01 T03 T15 | MERGE_WITH_HARDENING / P01 | plasticos_logistics/models/load.py; plasticos_automation/data/workflow_automations.xml | V06 V07 V86 |
| H030 | Three documents, current version, then acknowledgment | E44 E40 E28 E33 | T01 T25 T26 T27 T28 | MERGE_WITH_HARDENING / P05 | existing load packet/report/Mail owners | V41 V42 V53 |
| H031 | Party-specific document and message audiences | E02 E03 E29 E44 E35 | T25 T26 T27 T28 | MERGE_WITH_HARDENING / P05 | existing templates/report generation and Mail guard | V43 V45 |
| H032 | No Sales CC on buyer SO; no archival CC | E03 E02 | T25 T01 | MERGE_WITH_HARDENING / P05 | plasticos_automation email templates; load Mail/composer guard | V44 V43 |
| H033 | No secret leakage through shared notes or chatter | E29 E35 E49 | T26 T27 T25 T01 | MERGE_WITH_HARDENING / P05 | report/template owners and party-scoped Mail records | V45 V43 V13 |
| H034 | Durable queue and truthful send status | E30 E35 E37 E22 | T01 T03 T25 | MERGE_WITH_HARDENING / P05 | load send command plus native mail.mail | V46 V47 V48 |
| H035 | Uncertain SMTP outcome is not safely retryable by default | E37 E35 E30 | T01 T16 | NATIVE_REIMPLEMENTATION / P05 | native Mail reconciliation and load activity owner | V47 V49 V77 |
| H036 | Currency, time zone and actual fields rendered correctly | E06 E46 E40 | T25 T28 T29 | MERGE_WITH_HARDENING / P05 | existing report/templates/load UX | V40 V27 V57 |
| H037 | One state-dependent milestone clock | E39 E40 E14 E45 | T16 T17 T18 T19 T20 | MERGE_WITH_HARDENING / P05 | existing logistics escalation/scheduler owner | V20 V53 V59 V75 |
| H038 | Race-safe due evaluation and catch-up | E37 E39 E40 E45 | T16 T20 | MERGE_WITH_HARDENING / P05 | existing logistics cron + guarded command | V49 V50 V51 V87 |
| H039 | Resolve conflicting historical timer policies | E39 E40 E43 E49 | T16 T17 T18 T19 | CONFIGURE_AFTER_APPROVAL / P05 | business policy owner + existing cron configuration | V20 V50 V52 |
| H040 | Actionable, deduplicated human exceptions | E39 E49 E31 | T17 T18 T01 | MERGE_WITH_HARDENING / P05 | native mail.activity and responsible business owner | V59 V71 V46 |
| H041 | Checkpoint vocabulary without new load states | E21 E25 E42 | T01 T02 T04 | NATIVE_REIMPLEMENTATION / P05 | plasticos_logistics checkpoint handler; transaction bridge | V54 V55 V57 |
| H042 | Pickup proof does not finish delivery picking | E21 E12 E43 | T01 T04 T03 | NATIVE_REIMPLEMENTATION / P05 | load checkpoint action and native stock/transaction bridge | V54 V69 |
| H043 | Out-of-order and stale event handling | E21 E37 E46 | T01 T02 T04 | NATIVE_REIMPLEMENTATION / P05 | load checkpoint command | V55 V56 V58 |
| H044 | No response after pickup is a monitored exception | E25 E39 E49 | T20 T19 | NATIVE_REIMPLEMENTATION / P05 | existing logistics scheduler | V53 V59 V51 |
| H045 | Receiver evidence and destination validation | E28 E41 E49 | T01 T04 T03 | NATIVE_REIMPLEMENTATION / P06 | load delivery action and existing receiver/document owners | V60 V61 V68 |
| H046 | Store once, preserve original and role views | E08 E49 E41 | T05 T07 | MERGE_WITH_HARDENING / P06 | plasticos_documents_native plus existing legacy compliance mirror | V64 V66 V71 |
| H047 | Deterministic association before classification | E08 E49 E06 | T05 T07 | NATIVE_REIMPLEMENTATION / P06 | existing document/mail intake seam | V88 V83 V63 |
| H048 | Current verified BOL/POD, not checkboxes | E38 E41 E28 | T01 T05 T06 T08 | MERGE_WITH_HARDENING / P06 | plasticos_documents/models/load_docs_bridge.py close guard; load action | V62 V63 V65 V67 |
| H049 | Native-to-legacy proof synchronization | E49 E38 E08 | T07 T05 T08 | MERGE_WITH_HARDENING / P06 | plasticos_documents_native/models/document_sync.py | V64 V63 V66 |
| H050 | Hash and supersession as integrity, not authority | E38 E41 E37 | T05 T07 | MERGE_WITH_HARDENING / P06 | existing document versioning and verification owner | V65 V66 V67 |
| H051 | Party-specific missing-document deadlines | E08 E49 E41 | T05 T16 T04 | CONFIGURE_AFTER_APPROVAL / P06 | existing document rules/cron and native activities | V71 V62 |
| H052 | Quantities, discrepancies and original unit evidence | E06 E41 E28 | T04 T05 | MERGE_WITH_HARDENING / P06 | existing transaction weight authority and document evidence | V68 V61 |
| H053 | Verified downstream synchronization | E12 E28 E22 | T04 T03 T13 T38 | MERGE_WITH_HARDENING / P06 | existing transaction/picking bridges and load owner | V69 V03 V56 |
| H054 | Financial close is a separate gate | E28 E38 E41 E46 | T04 T08 | PRESERVE_EXISTING / P06 | plasticos_transaction existing action_close and accounting owners | V70 V61 |
| H055 | Truthful operational metrics | E41 E49 E25 | T01 T04 T29 | MERGE_WITH_HARDENING / P06 | existing logistics dashboard/evidence projection | V72 V57 |
| H056 | Legacy assertions are not confirmed events | E21 E06 E48 | T01 T04 T05 | NATIVE_REIMPLEMENTATION / P07 | affected existing models migration/adoption owner | V73 V62 V05 |
| H057 | Fresh install and upgrade safety | E16 E23 E48 | T36 T23 T07 | MERGE_WITH_HARDENING / P07 | repository-owned module migration/test machinery | V74 V75 V80 |
| H058 | Rollback retains business history | E30 E38 E47 | T01 T16 T04 | NATIVE_REIMPLEMENTATION / P07 | existing coordination configuration and evidence owner | V76 V47 V82 |
| H059 | Replace fake green with real workflow proof | E07 E19 E24 E48 | T30 T31 T32 T33 | MERGE_WITH_HARDENING / P07 | existing logistics and repository runtime tests | V77 V79 V89 V74 |
| H060 | No second logistics platform/state store | E32 E35 E46 E47 E22 | T01 T02 T04 | REJECT / P00 | existing Odoo owners remain | V78 V90 |
| H061 | No n8n donor/runtime integration | E13 E47 | T37 | REJECT / P00 | campaign scope | V78 V90 |
| H062 | No AI/OCR business authority | E36 E41 E49 E46 | T37 T01 | REJECT / P00 | canonical Odoo guards | V10 V67 V78 |
| H063 | No weighted dispatch safety or fabricated facts | E27 E24 E42 | T01 T12 | REJECT / P00 | canonical load prerequisites | V06 V28 V36 |
| H064 | No historical penalties or fixed dollar formulas | E34 E39 E41 E47 | T01 T04 T37 | REJECT / P00 | existing commercial/financial policy owners | V40 V70 V90 |
| H065 | Supplier onboarding and preapproved party intent | E04 E05 E25 | T04 T24 | DEFER_OUT_OF_SCOPE / P00 | existing partner/onboarding and commercial release owner | V02 V84 V90 |
| H066 | Accounting, CRM, buyer ranking and broad QC platform | E46 E49 E23 | T04 T37 | DEFER_OUT_OF_SCOPE / P00 | existing respective domain owners | V70 V78 V90 |
| H067 | Retain useful working freight; do not repeat predecessor campaign | E46 E47 E48 | T09 T10 T11 T12 T33 | PRESERVE_EXISTING / P04 | current plasticos_logistics freight spine | V79 V78 V90 |
| H068 | Minimal operator-facing exception and next action | E25 E31 E46 | T01 T19 T04 | MERGE_WITH_HARDENING / P05 | existing Odoo load/activity/dashboard UI | V57 V59 V72 |

## 9. Finding closure accounting

All 24 original source findings are retained with proposed owner/test disposition; F-025 records the newly inspected document mirror. Nothing is claimed fixed. Corrections at automation, transaction, security and document owners are dependencies requiring explicit later scope, not permission smuggled into `plasticos_logistics`.
| Finding | Observed gap | Owner work package | Harvest rows | Disposition |
| --- | --- | --- | --- | --- |
| F-001 | Unsafe automatic dispatch bypass | WP01 WP06 | H029 H030 H034 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-002 | Inbound confirmations not integrated | WP02 | H009 H011 H012 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-003 | Cargo ready lacks supplier proof | WP03 | H004 H005 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-004 | Appointment request exists without accepted-slot workflow | WP04 | H016 H017 H018 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-005 | Truck scheduled without verified booking | WP05 | H027 H020 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-006 | Direct packet send lacks state and send idempotency | WP01 WP06 | H029 H034 H035 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-007 | Pickup/delivery transitions lack evidence | WP07 WP09 | H041 H042 H043 H045 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-008 | Picking completion marks TX delivered independently of load | WP09 | H053 H045 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-009 | Closeout trusts two Boolean BOL flags | WP08 WP09 | H048 H050 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-010 | Company identity absent on loads without SO | WP01 | H003 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-011 | Cron activity declarations conflict with canonical default | WP07 WP10 | H037 H057 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-012 | Repeated escalation tasks and unsound send counters | WP07 | H038 H040 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-013 | Carrier acknowledgment field not evidence-backed | WP02 WP06 | H010 H011 H014 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-014 | SLA checking is not shipment checkpoint tracking | WP07 | H037 H044 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-015 | SO load creation is human-form action | WP01 | H001 H002 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-016 | Stale transition test invocation | WP11 | H059 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-017 | Golden flow does not exercise email lifecycle | WP11 | H059 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-018 | Dispatch packet presents non-USD rates as USD | WP06 | H036 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-019 | Second dispatch state can diverge from load state | WP01 | H029 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-020 | Time guards enforce order only | WP04 | H020 H021 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-021 | Ambiguous transaction auto-link on one SO | WP01 | H002 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-022 | Cron test targets missing logistics method | WP11 | H059 H038 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-023 | Planned pickup timestamp presented as actual | WP07 | H036 H068 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-024 | Delivery-order linkage conflates PO and outbound picking | WP09 | H053 | OPEN_CORRECTION_DESIGNED_NOT_EXECUTED |
| F-025 | Native document mirror updates verification without refreshing core evidence identity | WP08 | H049 H050 | OPEN_SEAM_CORRECTION_OR_COUNTERPROOF_REQUIRED |

## 10. What is reusable today

Preserve the current load state values, command boundaries, SAL/current-context comparison, immutable quote/actuals evidence, native Mail and report generation, unique load/transaction association, document models, scheduler surface and financial close constraints. Existing good behavior should gain regression coverage, not a duplicate implementation. [T01-T16, T33-T37]

The most economical net-new capability is **one governed confirmation/evidence seam**, reused for readiness, appointments, booking, packet receipt and checkpoints. Existing models alone do not expose its request/party/revision semantics. A single narrow load-owned record is proposed and justified in the migration plan; its name/schema and authentication implementation are not silently frozen here.

## 11. Audit completion and limits

Every matrix row has a disposition, source coordinate, target owner/stage and named acceptance test. Every original material finding has a migration/repair or explicit proof obligation. All ten identified donor families are represented. This closes the bounded synthesis and pack-generation work, not remote corpus forensics or implementation readiness.

Native receipts retain `partial` evidence / blocked architecture-freeze status because raw remote completeness, runtime truth and necessary authority decisions are unresolved. Artifact integrity and cross-reference validation can pass while these product gates remain open. Read `validation/VALIDATION_REPORT.md` for exact executed checks.

**Next Highest Leverage Move:** authorize WP01-WP03 as one bounded readiness foundation: prevent unsafe alternate sends, establish exact identity, then prove one authenticated shipper response advances one load once using native Mail. Do not reopen the freight engine.

**Devil's Advocate:** A source donor can describe a perfect process and still contain unsafe placeholders. The migration must prove real state, message and document effects at the current Odoo interfaces; prose labels and schema validation do not move a truck.
