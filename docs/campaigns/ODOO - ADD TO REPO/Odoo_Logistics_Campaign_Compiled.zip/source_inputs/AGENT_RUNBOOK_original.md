# Agent Runbook: Linda Logistics Campaign

**Mission:** realize the accepted portion of this project-native harvest in the existing Odoo architecture, after explicit implementation authorization. This file is a readable scope/acceptance runbook, not a compiled native coding contract or a grant to publish.

## Current authorization

Read target `https://github.com/cryptoxdog/IB-Odoo_19` at `Staging` `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e` and the supplied campaign artifacts. Current writable repositories: **none**. Current writable Odoo databases: **none**. Current permission to send real email, configure mailbox credentials, publish, merge or deploy: **none**.

Local artifact construction and verification occurred in the analysis environment. Their success is not permission to mutate a target environment.

## Intake sequence

1. Verify this local pack with its included checker. Read the audit, migration plan, findings and open decisions. Do not run donor scripts or old deployment instructions.
2. Resolve current Staging HEAD through the authorized repository connection. If unchanged, reuse exact-revision evidence. If advanced, compare only affected current files/owners; mark stale evidence selectively and preserve prior scope/history.
3. Inspect target-local `AGENTS.md`, `INVARIANTS.md`, relevant architecture contracts and actual runner/publication implementations. Do not infer executable commands from names, README examples or a neighboring repository. Odoo uses its own current publishing plumbing; do not import an org-wide ceremony by assumption.
4. Inventory relevant open branches/PRs, installed modules/roles/automations and disposable environment availability. Avoid colliding with another owner already fixing the same seam. Do not touch live business data during this preflight.
5. Obtain a bounded owner-approved scope for the selected work package and its required seam dependencies, plus the decisions it needs. The original audit's adjacent read-only scope is not a mutation grant.
6. Route actual implementation to the authorized coding capability/agent using its current contract machinery. This runbook does not replace that compiler/protocol and does not fabricate a dispatch or agent receipt.

## Recommended first bounded implementation scope

WP01-WP03: canonical entry/association/send safety plus a native-Mail readiness loop. Required candidate write owners include `plasticos_logistics/models/load.py`, its existing relationship/entry extensions, the conflicting actions in `plasticos_automation/data/workflow_automations.xml`, existing supplier templates/projections, necessary security owners, the one approved confirmation representation, required addon metadata/migrations and focused tests.

Do not open all later-stage files automatically. If safe readiness requires a missing authoritative owner outside this granted list, report a dependency instead of patching a downstream symptom. A minimal new file must close a named current obligation and follow the repository's current wiring rules.

Acceptance: a released exact load sends one permitted readiness request; the authorized shipper submits a current structured reply; Odoo records named/timestamped evidence, advances exactly that load, stops that reminder obligation and denies an unauthorized rate/carrier action. Replays, two simultaneous loads and forged/forwarded/old responses cannot duplicate or misassociate actions. No carrier dispatch occurs merely because stock becomes assigned.

## Implementation discipline

Keep existing state values and freight meaning. Do not install a donor addon or create `sm.tx`, a parallel carrier database, free-form message interpreter, n8n workflow, separate mailbox watcher, generic rules platform or external storage authority.

All automatic and public paths must converge on the same existing load-owned business commands. Do not expose the internal state capability token or substitute a public context Boolean. Preserve least-privilege company/party relationships. Quoting/ranking does not grant commercial award; recorded physical events do not authorize financial close.

Use one integrator for shared `load.py`/workflow XML changes. Document-owned WP08 may proceed in parallel only after the WP02 interface is fixed; no overlapping autonomous edits. A matching file path is not evidence that two branches compose safely.

## Test execution

Before any command, verify its existence, effect and exact database target. Use the repository's actual test harness on a clean disposable production-equivalent Odoo19/Enterprise environment. Replace every possible operational recipient with a controlled sink and deny unapproved external traffic. Never run a whole donor deployment or connect its historical services.

Use focused tests first, then the affected integration suite once after consolidation. One replay means reprocessing the same logical business events, not fetching all historical ERP/CRM data again. Do not duplicate full-suite runs for ceremony. Any subsequent rerun must have a changed input/fix or a named missing proof.

Record actual command, target SHA, database identity, addon versions, actor permissions, test assertions, message/operation counts, event/document identities, output and status. Mocked mail results are unit proof only; actual controlled Mail/ORM/queue routing is a separate gate. Do not replace missing methods with `hasattr` skips or return True from a stub.

## Finding disposition

Every in-scope F-001 through F-025 must finish as fixed with exact proof, proven already satisfied/invalid, or explicitly blocked. New regression findings also require disposition. A proposed correction is not a fix, and a green artifact checker is not a product test.

Preserve all matrix rejections as negative tests. Do not weaken a required doc, identity, rate or transition guard merely to pass the happy path. Do not add unrelated housekeeping or reopen accepted freight design.

## Stop conditions

Stop the affected mutation when required authority, exact association, current policy, authentication, safe recovery, runtime isolation or source evidence is absent. Stop on scope expansion, unsafe real-email paths, a dependency cycle, unavailable native capability requiring another system, or regression of a retained invariant. Return the concrete blocker and smallest approved probe, not a speculative workaround.

## Publication / pilot

Publish, merge, deploy and send live mail only under separate authorization and verified target-local machinery. Never declare merge/deploy readiness from this pack's validation. Phase activation is cohort-based with known old-writer retirement, uncertain-send reconciliation and a kill switch.

## Completion handoff fields

Return exact base/head revisions, authorized paths and delta, implemented harvest rows, all finding dispositions, migration/adoption counts by evidence class, executed tests and their full result locations, unresolved decisions, mail/stock/document replay identities, prohibited-action denials, rollback evidence and publication/deployment state. Do not report completion until the selected work-package obligation set is closed.
