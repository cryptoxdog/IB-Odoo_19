# Logistics Campaign Specification

## 1. Frozen operator objective and scope

Mature existing PlasticOS Odoo 19 logistics into a rules-governed coordinator that progresses supplier readiness, pickup and delivery facilities, freight booking, dispatch, shipment checkpoints and document closeout by attributable evidence. The ordinary path should need no routine human chasing. Genuine business-risk, authorization, ambiguous language or evidence gaps become actionable exceptions.

**Not in scope:** any new separate logistics application, a second SQL/Supabase state store, n8n orchestration, speculative AI/OCR authority, automatic freight award, matching/CRM, broad accounting changes, financial posting, or retroactive rebuilding of old transactions. The target is `plasticos_logistics` and the *minimum affected existing integration owners*, not a new module family.

## 2. Observed implementation versus desired operation

**Confirmed source observations at 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e:** `plasticos.load` inherits `mail.thread` and `mail.activity.mixin`; contains the recorded draft -> awaiting_ready -> ready_confirmed -> rate_confirmed -> scheduled -> dispatched -> picked_up -> delivered -> closed, plus exception, and fields for ready confirmer, planned pickup/delivery, dispatch/ack, freight and BOL Boolean projections. Related owners exist for Odoo transactions, purchase/sale, facility default dock term, freight quote recipients, native Enterprise documents and a legacy compliance mirror. The current automation source contains a competing stock-picking dispatch path identified in F-001. This paragraph attests source inspection only, **not the deployed Odoo registry**.

**Business desired:** record *who actually committed which facts to what load revision*, then take only the next lawful Odoo action. Neither email delivery, date entry, operator stage click, quote recommendation, stock-picking status nor attachment presence is a substitute for its specific real-world confirmation.

## 3. Actors and authority

| Actor | Authoritative facts or permissions | Not authorized merely by participation |
|---|---|---|
| Salesperson / commercial operator | Commercial release/transaction scope; identity of supplier and buyer | Supplier physical READY; carrier acceptance; autonomous financial close |
| Supplier / shipper | Attributed material readiness, pickup constraints, pickup proof | Buyer details or buyer-facing papers; freight approval |
| Buyer / receiving facility | Receiving window, dock rule, delivery acknowledgment | Supplier commercial identity or supplier-facing papers |
| Freight operator | Required rate/quote/carrier decision under existing Odoo guarded actions | Rewriting physical proof or faking booking acceptance |
| Carrier / broker | Equipment, coverage and booking response, packet receipt, shipment checkpoints | Unilateral rate approval, buyer/supplier contact disclosures outside approved packet |
| Linda / routine Odoo automation | Send permitted party-specific requests; verify structured answers; invoke guarded Odoo actions within authorized scope | Bypass commercial gates, rewrite financial truth, invent missing observations |
| Odoo Documents verifier | Classify and verify current source documents under existing owner permissions | Treat a hash or OCR confidence as delivery evidence |
| Accounting/transaction owner | Independent financial close under existing posted-invoice and compliance rules | Imply finance close from logistics close |

## 4. Existing domain objects and relationships

- `plasticos.transaction`: commercial spine; `sale_order_id`, `purchase_order_ids`, supplier/buyer/carrier, `freight_rate` and `freight_actual`. `load_id` is injected by the logistics bridge.
- `plasticos.load`: primary logistics lifecycle, carrier/rate, schedule and dispatch actions, company relationship, movement facts and freight evidence; linked to one transaction through existing bridge constraints. **Do not add another load lifecycle owner.**
- `plasticos.freight.quote.request/recipient/quote` and `plasticos.freight.estimate`: existing constrained freight request, quote evidence and nonbinding estimation. Current methods require freight approval separation; reuse them rather than copying legacy calculators.
- `res.partner.default_delivery_term`: existing default facility term, with `appointment` default. It cannot itself prove facility acceptance or explicit appointment waiver for a specific load. Full facility hours/time-zone provenance requires WP04 inspection/proof.
- `stock.picking`: inventory movement, not an alternate logistics state authority or pickup/delivery oracle.
- `mail.message`, `mail.mail` and `mail.activity`: native Odoo message threading, sends and internal exception surface. Operational alias/receipt behavior **NOT VERIFIED**.
- `documents.document`, `plasticos.document`: existing Enterprise document and legacy compliance projection. A native-to-legacy mirror exists; its freshness must be proven at every consequential update.
- Proposed new request or evidence representation: **UNKNOWN / candidate only** under A01. Do not create new fields/models until an exact-source insufficiency counterexample establishes necessity, owner approves shape and upgrade semantics, and dependencies remain acyclic.

## 5. Source-backed lifecycle, without a new state machine

| Milestone | Evidence that must exist | Existing code authority | What does not count |
|---|---|---|---|
| Commercial release | Eligible approved transaction and exact physical movement/load association | Transaction, existing SO/load entry | An imported/created record alone |
| Supplier READY | Attributable per-load shipper confirmation, date/status, current request identity | `plasticos.load.action_confirm_ready` through scoped command | Salesperson button or email sent |
| Pickup/delivery terms | Current facility FCFS or accepted appointment; delivery slot constrains pickup | Facility profile + load scheduling | Blank treated as FCFS, or requested slot treated as accepted |
| Freight rate | SAL or manual/quote route through current approved load action; traceable currency | Load freight methods + quote service | Cheapest estimate, old cached actual or donated autopicker |
| Carrier BOOKED | Specific carrier accepts a feasible load with current equipment/window and governing rate | Current load carrier context plus proposed booking evidence | Rate confirmed, contact emailed or carrier selected |
| Dispatch packet SENT | Current role-safe packet, permitted recipients, durable mail send result | Guarded load action + existing reports/native mail | Uncontrolled stock-picking server action or timestamp alone |
| Dispatch acknowledgment | Authenticated attributable carrier response bound to latest packet | Existing load ack projection + proposed verified response | Generic keyword or unsourced Boolean |
| Physical pickup | Dated pickup evidence verified against load identity | Existing `picked_up` transition | Schedule time or picking marked done |
| Delivery | Receiver/transport proof and destination identity | Existing `delivered` transition + Documents bridge | Carrier claim alone or delivery window expiry |
| Logistics close | Required current BOL/POD documents and compliance checks, no unresolved blocker | `plasticos.load.action_close`, document compliance owner | Old Boolean attachment flags, hash alone |
| Financial close | Separate existing posted-invoice, accounting and transaction guards | `plasticos.transaction.action_close` | Logistics closed status alone |

The table describes acceptance obligations. No new Odoo `state` values are prescribed. An operator or implementation owner must determine the minimum lawful representation of intermediate evidence. It is not authorization to widen a locked model shape.

## 6. Safety invariants and authoritative control flow

- **One route to dispatch:** every route into dispatch mail or state stamps must call the canonical guarded load command; source F-001 is the earliest critical current violation.
- **Exact identity:** company, transaction, movement, PO/SO, supplier/receiver and freight context must be unambiguous at each external send. Wrong-company recipients always fail closed.
- **Structured inbound:** native Mail routes an identified message, but transport correlation does not authenticate a business actor. Accept structured, scoped, replay-resistant confirmation or send ambiguous/free-form text to a human exception. No automatic inference of physical readiness from a phrase.
- **Separation of rate and booking:** SAL resolves rate provenance, not current carrier capacity/commitment. Freight award retains its existing operator gate.
- **Double blind:** supplier, buyer and carrier communications use the separate, approved document/recipient projections; internal chatter cannot be broadly shared as an archive CC.
- **No false progression:** proposed appointments, booked rates, picked-up stock, delivered goods, verified documents and accounting close are distinct facts. Missing one cannot be bypassed with a success-shaped default.
- **Replay and concurrency:** repeated incoming/cron/sender operations cannot create duplicate requests, carrier solicitations, attachments, messages or state changes; unknown SMTP acceptance requires reconciliation, not blind retries.
- **Stop clock:** cancel stale reminders after acknowledged, canceled or superseded action. Contradictory or late replies remain evidence but cannot rewind physical milestones.
- **Data minimization:** reuse existing Odoo fields and native Mail/Document owners. No second service, custom memory store, mailbox parser service, or generic workflow engine.

## 7. Authorization and semantic freeze

This compiled candidate is **not** an accepted schema, registered BRS family, permission grant or deployment plan. Source-derived candidate rules live once in `business_rules/rules.json`; human BRS views and campaign policy pointers are derived. An implementation can begin only after WP00 refreshes authority and a separately authorized specific delta is fixed. At that point implementation is bounded by frozen accepted meaning; contradictions trigger a separate design decision, not silent expansion.

## 8. Evidence model and reconciliation

Retain source actor, source system, external message identifier where available, request correlation, load/company/transaction identity, event time, observation time, payload/version fingerprint, acceptance decision and supersession reference as **logical evidence requirements**. Technical field/model realization is not preapproved. Reconcile two or more messages for one PO/load, duplicate submissions, forwarded link, stale appointment, changed pickup address, carrier decline after rate confirmation, mail transport uncertainty, physical-event ordering, and documents superseded after verification. Material conflicts create a native activity with a precise blocking reason and responsible role.

## 9. Gate conditions

Minimum proofs are described in `ACCEPTANCE.md`; enforce expected failures as negative cases and preserve runtime NOT_RUN until an independent disposable Odoo 19/Enterprise execution produces revision-bound evidence. Cross-company and external-send negative cases are mandatory; one successful happy-path send is insufficient.
