```yaml
repository_access:
  writable: []
  read_only:
    - https://github.com/cryptoxdog/IB-Odoo_19
  unlisted_repositories: no_access
```

# Logistics Campaign Execution Handoff (ADVISORY / READ-ONLY FIRST)

## Operator authority boundary

This read-only header describes **WP00 preparation**, not implementation authorization. A future code-mutating session needs a separately authorized, exact-revision, path-scoped contract with its own approved access header. Package authoring, donor harvesting and GitHub read access cannot authorize target edits, branch pushes, PR creation, Odoo.sh module updates, real dispatch mail, migration or deployment.

## Binding procedure

1. Resolve the current `Staging` head; compare with the frozen compilation `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`. Any movement requires a delta census and selective invalidation, not blind reuse of earlier evidence.
2. Re-read actual current `INVARIANTS.md`, latest appended `AGENTS.md` corrections, applicable ADRs, target module manifests, tests, CI and work-package file owners. Verify repo-local command ownership and version-bump procedure. Do not inherit outdated commands from old donor scripts or historical instructions.
3. Inspect deployed Odoo 19/Enterprise registry and installed addon state only in an isolated disposable DB. Identify active crons, message routing, server actions, Mail aliases, document sync, installed security groups and actual access; preserve UNKNOWN where not verifiable.
4. Produce one source-bound preflight receipt containing immutable HEAD, module versions, available runner/environment evidence, precise allowed paths, complete impacted owners, any source drift and blocked requirements.
5. Request operator approvals A01..A08 only where needed for the specific next slice. Do not batch broad authority grants across unrelated future release decisions.

## Mandatory implementation protocol once authorized

- Implement only named WP(s), respecting dependency edges and source-cited existing owners.
- Do not create an addon, field, model, cron or rule family merely to match this package's conceptual columns. Prove the source/contract insufficiency and prefer existing Odoo constructs.
- Preserve the source invariant: one guarded canonical load state/action owner; existing rate approval; native Mail; existing documents and accounting controls; confidentiality and company isolation.
- Pair each change with exact positive, negative, concurrent and replay tests from its `acceptance_ids`, and version/migration tests whenever runtime manifest or storage evolves.
- Produce a proposed-fix ledger for *every* linked finding, including explicit blocked/upstream dispositions; no silent drops.
- Each PR should reflect a bounded concern and only the smallest affected existing source owners. WP08 can be developed independently after response identity is fixed; integrate at WP09.
- Run small target-declared static checks first and Odoo runtime once in a disposable DB with a controlled mail sink. Avoid the full suite twice for identical revision without a separately named verification obligation.
- Do not claim a test passed because it was declared, emitted, imported, or run on a different SHA/DB.

## Target-declared static commands (read in `AGENTS.md` at frozen SHA)

The repository text declares `python3 scripts/check_module_wiring.py`, `python3 ci/check_circular_deps.py`, `python3 ci/check_odoo19_xml.py` and `python3 tools/cron_invariant_check.py`. These are **eligibility leads only**, not executed or validated against a present local checkout in this compilation. The future executor must verify command implementation, precise affected paths, environment, and safety first. Odoo database tests/`-u` require an isolated disposable database and module-specific owner-approved paths.

## Per-work-package handoff obligation

For each work package, return:

```yaml
work_package_id: WPxx
current_target_sha: UNKNOWN
operator_delta_authorization: UNKNOWN
read_only_dependencies: []
exact_affected_paths: []
source_evidence_refs: []
requirement_ids: []
rule_ids: []
findings_closed: []
tests:
  source_revision: UNKNOWN
  isolated_database: UNKNOWN
  executed_cases: []
  failed_cases: []
  not_run_cases: []
  runner_log_evidence: []
  negative_and_replay_proof: UNKNOWN
schema_and_migration_proof: UNKNOWN
transport_and_security_negative_proof: UNKNOWN
regression_proof: UNKNOWN
remaining_blocked_unknowns: []
publication_state: NOT_AUTHORIZED
```

A placeholder is not a filled receipt. The executor reports only actual, independently checkable observations. Exact module version, current source, email send counts and independent verification receipts are necessary before any operational deployment claim.

## Safe first implementation selection

After WP00, WP01 addresses the critical competing stock-picking dispatch path and identity/company ambiguity. WP02/WP03 then create one authenticated supplier-ready round trip with replay, wrong-party, corrected, negative and two-load/one-PO cases. Stop at that functional slice before enabling unattended appointments or carrier communications.

## Publication boundary

Target `AGENTS.md` contains a later append-only correction retiring `make push` and asserting a `make pr` SSOT, while earlier operator discussions record a repo-specific transport exception. Publication is NOT in scope. Reconcile the exact current owner and independently validate any permitted publication ceremony at the future boundary; never invent, substitute, or execute a PR command here.

## Stop rules

Stop affected implementation upon missing current target rules, unauthorized security/cron/schema change, unknown auto-award policy, unjustified field, unavailable role-authenticated confirmations, stale load-context revision, absent company link, inability to isolate test emails, inaccurate document proof, unsupported model/relation cardinality, false-green tests, or requested cross-domain expansion. Safe unrelated branches may continue only when interfaces and write surfaces remain independent.
