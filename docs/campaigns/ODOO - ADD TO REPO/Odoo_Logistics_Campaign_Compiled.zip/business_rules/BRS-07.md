# BRS-07: Delivery, documents and operational closeout

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_documents_native + plasticos_documents + plasticos_logistics`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

Validated receiver/document truth and separate transaction close. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-07-R045: Receiver evidence and destination validation

- Requirement: `LR-045`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Carrier-reported delivered is an attributed claim; verified delivery requires correct receiver/destination evidence and unresolved dispute handling.
- Source evidence: `E28, E41, E49, T01, T04, T03`.
- Existing target path/owner: `load delivery action and existing receiver/document owners`.
- Intended negative/positive proof: `AC-V60, AC-V61, AC-V68`; none executed in this compilation.

### BRS-07-R046: Store once, preserve original and role views

- Requirement: `LR-046`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Native Documents owns file UX, existing attachment and mirror stay linked; supplier/carrier/buyer views use tags, not duplicate physical files.
- Source evidence: `E08, E49, E41, T05, T07`.
- Existing target path/owner: `plasticos_documents_native plus existing legacy compliance mirror`.
- Intended negative/positive proof: `AC-V64, AC-V66, AC-V71`; none executed in this compilation.

### BRS-07-R047: Deterministic association before classification

- Requirement: `LR-047`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Bind submitted attachment through authenticated request and exact company/load; ambiguous PO-only/domain matches go to review.
- Source evidence: `E08, E49, E06, T05, T07`.
- Existing target path/owner: `existing document/mail intake seam`.
- Intended negative/positive proof: `AC-V88, AC-V83, AC-V63`; none executed in this compilation.

### BRS-07-R048: Current verified BOL/POD, not checkboxes

- Requirement: `LR-048`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Required current signed/verified evidence for this load must exist before close; eligibility separate from file count/content hash.
- Source evidence: `E38, E41, E28, T01, T05, T06, T08`.
- Existing target path/owner: `plasticos_documents/models/load_docs_bridge.py close guard; load action`.
- Intended negative/positive proof: `AC-V62, AC-V63, AC-V65, AC-V67`; none executed in this compilation.

### BRS-07-R049: Native-to-legacy proof synchronization

- Requirement: `LR-049`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: The compliance mirror must track exact current attachment, tag, source link and verification/supersession; not only a stale verification flag.
- Source evidence: `E49, E38, E08, T07, T05, T08`.
- Existing target path/owner: `plasticos_documents_native/models/document_sync.py`.
- Intended negative/positive proof: `AC-V64, AC-V63, AC-V66`; none executed in this compilation.

### BRS-07-R050: Hash and supersession as integrity, not authority

- Requirement: `LR-050`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Hash binds exact bytes/version; corrected evidence is a successor; acceptance of old bytes cannot seal a new file.
- Source evidence: `E38, E41, E37, T05, T07`.
- Existing target path/owner: `existing document versioning and verification owner`.
- Intended negative/positive proof: `AC-V65, AC-V66, AC-V67`; none executed in this compilation.

### BRS-07-R051: Party-specific missing-document deadlines

- Requirement: `LR-051`. Source disposition: `CONFIGURE_AFTER_APPROVAL`. Admission: `PENDING_EXPLICIT_POLICY_APPROVAL`.
- Candidate rule meaning: Request only actually required missing docs from responsible party; keep internal escalations on existing activity surface.
- Source evidence: `E08, E49, E41, T05, T16, T04`.
- Existing target path/owner: `existing document rules/cron and native activities`.
- Intended negative/positive proof: `AC-V71, AC-V62`; none executed in this compilation.

### BRS-07-R052: Quantities, discrepancies and original unit evidence

- Requirement: `LR-052`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Separate expected/actual/source weights, normalize through existing units and block disputes; logistics does not settle financial variance.
- Source evidence: `E06, E41, E28, T04, T05`.
- Existing target path/owner: `existing transaction weight authority and document evidence`.
- Intended negative/positive proof: `AC-V68, AC-V61`; none executed in this compilation.

### BRS-07-R053: Verified downstream synchronization

- Requirement: `LR-053`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Idempotently publish verified dispatch/pickup/delivery facts to exact linked records; stock completion uses native business actions and valid route quantities.
- Source evidence: `E12, E28, E22, T04, T03, T13, T38`.
- Existing target path/owner: `existing transaction/picking bridges and load owner`.
- Intended negative/positive proof: `AC-V69, AC-V03, AC-V56`; none executed in this compilation.

### BRS-07-R054: Financial close is a separate gate

- Requirement: `LR-054`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Logistics close publishes evidence; posted financial docs, manager authority and current compliance/margin checks remain mandatory.
- Source evidence: `E28, E38, E41, E46, T04, T08`.
- Existing target path/owner: `plasticos_transaction existing action_close and accounting owners`.
- Intended negative/positive proof: `AC-V70, AC-V61`; none executed in this compilation.

### BRS-07-R055: Truthful operational metrics

- Requirement: `LR-055`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Measure event time vs accepted baseline, acknowledgment latency, overdue milestones and human exceptions; no fabricated KPI percentages.
- Source evidence: `E41, E49, E25, T01, T04, T29`.
- Existing target path/owner: `existing logistics dashboard/evidence projection`.
- Intended negative/positive proof: `AC-V72, AC-V57`; none executed in this compilation.

### BRS-07-R056: Legacy assertions are not confirmed events

- Requirement: `LR-056`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Classify existing fields as verified evidence, legacy assertion, contradictory or unassociated; automation activates only reviewed eligible cohort.
- Source evidence: `E21, E06, E48, T01, T04, T05`.
- Existing target path/owner: `affected existing models migration/adoption owner`.
- Intended negative/positive proof: `AC-V73, AC-V62, AC-V05`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
