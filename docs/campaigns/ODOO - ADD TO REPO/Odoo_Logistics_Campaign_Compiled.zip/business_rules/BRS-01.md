# BRS-01: Transaction, movement identity and company boundary

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_logistics`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

Load association, transaction spine and release eligibility. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-01-R001: Sales release starts logistics; supplier READY remains separate

- Requirement: `LR-001`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: One exact released transaction/movement starts one load-specific readiness obligation. Never trigger external coordination solely from import/create.
- Source evidence: `E43, E25, E20, T04, T14`.
- Existing target path/owner: `plasticos_logistics/models/sale_order_inherit.py + models/load.py`.
- Intended negative/positive proof: `AC-V01, AC-V02, AC-V18`; none executed in this compilation.

### BRS-01-R002: Exact transaction/load/PO/SO association

- Requirement: `LR-002`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Every consequential request identifies company, load, transaction and actual facilities; shared order reference alone is ambiguous.
- Source evidence: `E06, E43, E46, T01, T13, T38`.
- Existing target path/owner: `plasticos_logistics/models/load.py + models/transaction_inherit.py`.
- Intended negative/positive proof: `AC-V03, AC-V04, AC-V88`; none executed in this compilation.

### BRS-01-R003: Company ownership cannot be unknown for automation

- Requirement: `LR-003`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: No automatic coordination on company-less or conflicting source records, even when user has access to both companies.
- Source evidence: `E46, E06, T01, T23`.
- Existing target path/owner: `plasticos_logistics/models/load.py; plasticos_security_base/security/record_rules.xml`.
- Intended negative/positive proof: `AC-V04, AC-V80`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
