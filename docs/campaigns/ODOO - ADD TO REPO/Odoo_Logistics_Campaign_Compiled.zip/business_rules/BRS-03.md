# BRS-03: Facility terms and appointments

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_facility_profile + plasticos_logistics`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

Pickup and delivery independently determined and committed. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-03-R016: Per-facility unknown-safe dock rules

- Requirement: `LR-016`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Determine pickup and delivery dock requirements independently; blank/default/unverified differs from confirmed FCFS.
- Source evidence: `E43, E21, E17, T22, T21, T01`.
- Existing target path/owner: `plasticos_facility_profile actual facility fields; plasticos_logistics load`.
- Intended negative/positive proof: `AC-V22, AC-V23, AC-V25`; none executed in this compilation.

### BRS-03-R017: Delivery slot constrains pickup scheduling

- Requirement: `LR-017`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: When destination requires appointment, obtain accepted available slot before final pickup commitment and coordinate feasible pickup around it.
- Source evidence: `E43, E44, E28, T01, T21`.
- Existing target path/owner: `plasticos_logistics scheduling command`.
- Intended negative/positive proof: `AC-V24, AC-V26, AC-V28`; none executed in this compilation.

### BRS-03-R018: Proposal/request/acceptance/cancellation distinction

- Requirement: `LR-018`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Keep both-party proposals and explicit accepted slot/reference/source. appointment_requested remains a request indicator only.
- Source evidence: `E21, E28, E43, T03, T21`.
- Existing target path/owner: `plasticos_logistics confirmation records; existing SO bridge projection`.
- Intended negative/positive proof: `AC-V26, AC-V29, AC-V81`; none executed in this compilation.

### BRS-03-R019: FCFS removes only appointment gate

- Requirement: `LR-019`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Confirmed FCFS allows arrival within approved hours but does not prove material ready, immediate loading, truck acceptance or rate authority.
- Source evidence: `E17, E26, E43, T01, T22`.
- Existing target path/owner: `plasticos_logistics scheduling prerequisites`.
- Intended negative/positive proof: `AC-V18, AC-V23, AC-V32`; none executed in this compilation.

### BRS-03-R020: Facility time zones, hours and lead time

- Requirement: `LR-020`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Persist UTC instants and explicit facility-local windows; unknown hours/time zone require a question to the facility or exception.
- Source evidence: `E21, E39, E43, T01, T22`.
- Existing target path/owner: `facility requirements owner; plasticos_logistics scheduling`.
- Intended negative/positive proof: `AC-V27, AC-V28, AC-V52`; none executed in this compilation.

### BRS-03-R021: No invented dock-capacity subsystem

- Requirement: `LR-021`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Validate exact exclusive slot/resource only where actually known; two loads at a facility need not be an overlap violation.
- Source evidence: `E21, E43, T01, T22`.
- Existing target path/owner: `plasticos_logistics scheduling`.
- Intended negative/positive proof: `AC-V26, AC-V30`; none executed in this compilation.

### BRS-03-R022: Amendment invalidates dependencies

- Requirement: `LR-022`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Material accepted slot/readiness changes invalidate only dependent current requests and require renewed commitments; history remains.
- Source evidence: `E38, E46, E43, T01, T12`.
- Existing target path/owner: `plasticos_logistics recovery/confirmation command`.
- Intended negative/positive proof: `AC-V16, AC-V29, AC-V38, AC-V82`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
