# BRS-02: Supplier readiness and verified responses

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_logistics`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

One attributable supplier answer for the right load/request. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-02-R004: Direct shipper READY for every load

- Requirement: `LR-004`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Only attributed current shipper evidence authorizes readiness; record confirmer identity, event/received time and actual cargo availability.
- Source evidence: `E43, E01, E21, E22, T01, T17, T04`.
- Existing target path/owner: `plasticos_logistics/models/load.py; plasticos_automation supplier bridge`.
- Intended negative/positive proof: `AC-V11, AC-V18, AC-V21`; none executed in this compilation.

### BRS-02-R005: Ready date versus proposed date

- Requirement: `LR-005`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Ready interval, proposal, confirmation time and planned pickup remain different facts.
- Source evidence: `E21, E22, E06, T01, T04`.
- Existing target path/owner: `plasticos_logistics/models/load.py`.
- Intended negative/positive proof: `AC-V17, AC-V55`; none executed in this compilation.

### BRS-02-R006: Explicit negative and corrected responses

- Requirement: `LR-006`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Not-ready/correction blocks affected commitments, retains previous proof and resumes only through a current accepted revision.
- Source evidence: `E09, E22, E43, T01, T04`.
- Existing target path/owner: `plasticos_logistics/models/load.py and native party conversation`.
- Intended negative/positive proof: `AC-V19, AC-V16, AC-V82`; none executed in this compilation.

### BRS-02-R007: Monday shipper status request

- Requirement: `LR-007`. Source disposition: `CONFIGURE_AFTER_APPROVAL`. Admission: `PENDING_EXPLICIT_POLICY_APPROVAL`.
- Candidate rule meaning: Before final READY, one approved Monday-morning status touch uses PO number and shipper company, not just DO; stop on readiness/cancel.
- Source evidence: `E43, E44, E14, T17, T16`.
- Existing target path/owner: `existing plasticos_logistics cron + plasticos_automation mail templates`.
- Intended negative/positive proof: `AC-V20, AC-V50`; none executed in this compilation.

### BRS-02-R008: Required cargo/equipment facts

- Requirement: `LR-008`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Require material identity, authoritative quantity/weight when relevant, trailer/loading constraints and pickup contact; missing facts block.
- Source evidence: `E06, E43, E21, T01, T12`.
- Existing target path/owner: `plasticos_logistics/models/load.py`.
- Intended negative/positive proof: `AC-V36, AC-V28, AC-V68`; none executed in this compilation.

### BRS-02-R009: Native Odoo Mail, not a mailbox microservice

- Requirement: `LR-009`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Use native mail routing and retained message IDs/attachments; custom-domain routing must be tested in an isolated environment.
- Source evidence: `E30, E47, E02, T01, T37, O01`.
- Existing target path/owner: `plasticos_logistics Mail integration; configured Odoo alias domain`.
- Intended negative/positive proof: `AC-V09, AC-V10, AC-V78`; none executed in this compilation.

### BRS-02-R010: Typed request evidence with minimal new persistence

- Requirement: `LR-010`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: A fixed-purpose party-scoped request binds load/company/party/revision/payload and native messages. Response lifecycle is not another load state machine.
- Source evidence: `E06, E21, E37, E38, T01, T09, T10`.
- Existing target path/owner: `plasticos_logistics, one proposed load-confirmation record type`.
- Intended negative/positive proof: `AC-V11, AC-V15, AC-V16, AC-V43`; none executed in this compilation.

### BRS-02-R011: Authenticated structured confirmation

- Requirement: `LR-011`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Current authenticated party plus single-use scoped request and explicit POST are required for consequential acceptance; From or bearer link alone is not enough.
- Source evidence: `E43, E06, E47, T01, T09`.
- Existing target path/owner: `plasticos_logistics confirmation command; native authenticated portal/mail capabilities`.
- Intended negative/positive proof: `AC-V11, AC-V12, AC-V13, AC-V14, AC-V84`; none executed in this compilation.

### BRS-02-R012: Separate transport, proposed observation and accepted fact

- Requirement: `LR-012`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Queued/sent/received/accepted/fulfilled are separate; only typed validated evidence may affect the canonical milestone.
- Source evidence: `E28, E36, E46, T01, T03`.
- Existing target path/owner: `plasticos_logistics confirmation command`.
- Intended negative/positive proof: `AC-V10, AC-V17, AC-V35, AC-V85`; none executed in this compilation.

### BRS-02-R013: Stable business identity independent of payload hash

- Requirement: `LR-013`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Unique company/load/purpose/party/revision/touch key controls operation; payload fingerprint detects drift but cannot mint a duplicate by itself.
- Source evidence: `E37, E38, E40, T01, T09`.
- Existing target path/owner: `plasticos_logistics confirmation/send command + native Mail`.
- Intended negative/positive proof: `AC-V15, AC-V48, AC-V49`; none executed in this compilation.

### BRS-02-R014: Stale, forwarded and contradictory replies

- Requirement: `LR-014`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Validate exact request, current revision and party; duplicates are no-ops, conflicts retained, cancelled requests never revived.
- Source evidence: `E37, E38, E46, E06, T01, T09`.
- Existing target path/owner: `plasticos_logistics confirmation command`.
- Intended negative/positive proof: `AC-V13, AC-V15, AC-V16, AC-V19`; none executed in this compilation.

### BRS-02-R015: Evidence-only service capability

- Requirement: `LR-015`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Routine actor may record validated facts and advance allowed noncommercial transitions; may not select or approve carrier/rate.
- Source evidence: `E31, E46, E01, T01, T10, T24`.
- Existing target path/owner: `plasticos_logistics guarded actions; plasticos_security_base role owner`.
- Intended negative/positive proof: `AC-V08, AC-V21, AC-V80`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
