# BRS-06: Physical checkpoints and follow-ups

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_logistics + plasticos_automation`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

Physical evidence and event-specific escalation. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-06-R037: One state-dependent milestone clock

- Requirement: `LR-037`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: One evaluation owner schedules due readiness/slot/ack/checkpoint/doc obligations; other models project it rather than independently chase.
- Source evidence: `E39, E40, E14, E45, T16, T17, T18, T19, T20`.
- Existing target path/owner: `existing logistics escalation/scheduler owner`.
- Intended negative/positive proof: `AC-V20, AC-V53, AC-V59, AC-V75`; none executed in this compilation.

### BRS-06-R038: Race-safe due evaluation and catch-up

- Requirement: `LR-038`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Under transaction lock re-read current request/status; due<=now, bounded fair batches and durable touch keys.
- Source evidence: `E37, E39, E40, E45, T16, T20`.
- Existing target path/owner: `existing logistics cron + guarded command`.
- Intended negative/positive proof: `AC-V49, AC-V50, AC-V51, AC-V87`; none executed in this compilation.

### BRS-06-R039: Resolve conflicting historical timer policies

- Requirement: `LR-039`. Source disposition: `CONFIGURE_AFTER_APPROVAL`. Admission: `PENDING_EXPLICIT_POLICY_APPROVAL`.
- Candidate rule meaning: Preserve approved current limits until a single selected cadence is admitted; Monday status, pre-pickup and acknowledgment touch types are distinct.
- Source evidence: `E39, E40, E43, E49, T16, T17, T18, T19`.
- Existing target path/owner: `business policy owner + existing cron configuration`.
- Intended negative/positive proof: `AC-V20, AC-V50, AC-V52`; none executed in this compilation.

### BRS-06-R040: Actionable, deduplicated human exceptions

- Requirement: `LR-040`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: One unresolved activity per load/milestone/reason/revision names blocked step, owner, source, deadline and allowed resolution.
- Source evidence: `E39, E49, E31, T17, T18, T01`.
- Existing target path/owner: `native mail.activity and responsible business owner`.
- Intended negative/positive proof: `AC-V59, AC-V71, AC-V46`; none executed in this compilation.

### BRS-06-R041: Checkpoint vocabulary without new load states

- Requirement: `LR-041`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Driver assignment, en-route, arrival, pickup, departure, delay and destination arrival are attributed checkpoints; picked_up represents in-transit at load level.
- Source evidence: `E21, E25, E42, T01, T02, T04`.
- Existing target path/owner: `plasticos_logistics checkpoint handler; transaction bridge`.
- Intended negative/positive proof: `AC-V54, AC-V55, AC-V57`; none executed in this compilation.

### BRS-06-R042: Pickup proof does not finish delivery picking

- Requirement: `LR-042`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Accept pickup only with exact current load/facility/actor evidence; update actual pickup and in-transit projection once.
- Source evidence: `E21, E12, E43, T01, T04, T03`.
- Existing target path/owner: `load checkpoint action and native stock/transaction bridge`.
- Intended negative/positive proof: `AC-V54, AC-V69`; none executed in this compilation.

### BRS-06-R043: Out-of-order and stale event handling

- Requirement: `LR-043`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Retain late evidence, separate physical and receive times; hold missing predecessor; never overwrite delivered with an older delay.
- Source evidence: `E21, E37, E46, T01, T02, T04`.
- Existing target path/owner: `load checkpoint command`.
- Intended negative/positive proof: `AC-V55, AC-V56, AC-V58`; none executed in this compilation.

### BRS-06-R044: No response after pickup is a monitored exception

- Requirement: `LR-044`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Every active load has next expected milestone and due evidence; lost contact/overdue arrival creates an owned exception.
- Source evidence: `E25, E39, E49, T20, T19`.
- Existing target path/owner: `existing logistics scheduler`.
- Intended negative/positive proof: `AC-V53, AC-V59, AC-V51`; none executed in this compilation.

### BRS-06-R068: Minimal operator-facing exception and next action

- Requirement: `LR-068`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Show last verified checkpoint, next required fact, owner and blocked reason; routine email threads are not the work queue.
- Source evidence: `E25, E31, E46, T01, T19, T04`.
- Existing target path/owner: `existing Odoo load/activity/dashboard UI`.
- Intended negative/positive proof: `AC-V57, AC-V59, AC-V72`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
