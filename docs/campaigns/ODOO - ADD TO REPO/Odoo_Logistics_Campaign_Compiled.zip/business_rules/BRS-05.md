# BRS-05: Dispatch, messages and confidentiality

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_logistics + plasticos_automation`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

One guarded sender and party-scoped documents. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-05-R029: One guarded dispatch authority

- Requirement: `LR-029`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: All send/release paths call the canonical load checks; stock assigned is not a carrier instruction and no independent dispatch state can grant permission.
- Source evidence: `E02, E18, E47, E32, T01, T03, T15`.
- Existing target path/owner: `plasticos_logistics/models/load.py; plasticos_automation/data/workflow_automations.xml`.
- Intended negative/positive proof: `AC-V06, AC-V07, AC-V86`; none executed in this compilation.

### BRS-05-R030: Three documents, current version, then acknowledgment

- Requirement: `LR-030`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: A fully scheduled/booked load can send its packet in Scheduled; exact packet receipt gates Dispatched. Sending and releasing are separate facts.
- Source evidence: `E44, E40, E28, E33, T01, T25, T26, T27, T28`.
- Existing target path/owner: `existing load packet/report/Mail owners`.
- Intended negative/positive proof: `AC-V41, AC-V42, AC-V53`; none executed in this compilation.

### BRS-05-R031: Party-specific document and message audiences

- Requirement: `LR-031`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Supplier sees pickup-side allowed content, buyer delivery-side content, carrier execution itinerary. DO and combined packet only to carrier.
- Source evidence: `E02, E03, E29, E44, E35, T25, T26, T27, T28`.
- Existing target path/owner: `existing templates/report generation and Mail guard`.
- Intended negative/positive proof: `AC-V43, AC-V45`; none executed in this compilation.

### BRS-05-R032: No Sales CC on buyer SO; no archival CC

- Requirement: `LR-032`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Apply literal no-Sales-CC on buyer/SO and no buyer/supplier CC on trucker mail; archive in Odoo.
- Source evidence: `E03, E02, T25, T01`.
- Existing target path/owner: `plasticos_automation email templates; load Mail/composer guard`.
- Intended negative/positive proof: `AC-V44, AC-V43`; none executed in this compilation.

### BRS-05-R033: No secret leakage through shared notes or chatter

- Requirement: `LR-033`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Exclude shared internal notes and other-side identity from party documents; native followers must not relay cross-party replies.
- Source evidence: `E29, E35, E49, T26, T27, T25, T01`.
- Existing target path/owner: `report/template owners and party-scoped Mail records`.
- Intended negative/positive proof: `AC-V45, AC-V43, AC-V13`; none executed in this compilation.

### BRS-05-R034: Durable queue and truthful send status

- Requirement: `LR-034`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Persist one outbound obligation and enqueue atomically; queue/sent/ack are separate; failed mail does not produce sent/release success.
- Source evidence: `E30, E35, E37, E22, T01, T03, T25`.
- Existing target path/owner: `load send command plus native mail.mail`.
- Intended negative/positive proof: `AC-V46, AC-V47, AC-V48`; none executed in this compilation.

### BRS-05-R035: Uncertain SMTP outcome is not safely retryable by default

- Requirement: `LR-035`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: After post-accept timeout/crash, reconcile provider/native message identity or raise an exception; no exactly-once external-delivery promise.
- Source evidence: `E37, E35, E30, T01, T16`.
- Existing target path/owner: `native Mail reconciliation and load activity owner`.
- Intended negative/positive proof: `AC-V47, AC-V49, AC-V77`; none executed in this compilation.

### BRS-05-R036: Currency, time zone and actual fields rendered correctly

- Requirement: `LR-036`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Show approved currency and explicit local window, and label planned versus actual checkpoint honestly.
- Source evidence: `E06, E46, E40, T25, T28, T29`.
- Existing target path/owner: `existing report/templates/load UX`.
- Intended negative/positive proof: `AC-V40, AC-V27, AC-V57`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
