# BRS-04: Freight policy and carrier booking

**Status:** Candidate business-rule concern specification, not registered/admitted repository law.  
**Revision:** 0.1.0-proposed  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**Current implementation owners:** `plasticos_logistics`  
**Normative candidate source:** `business_rules/rules.json`; this document is generated from that catalog.

## Responsibility boundary

SAL/rate quote commercial policy and distinct booking acceptance. Only the code owners above may implement their respective portions; this index does not override current `INVARIANTS.md`, source actions or accepted ADRs.

## Evidence-traced candidate rules

### BRS-04-R023: SAL and canonical executed history

- Requirement: `LR-023`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Preserve exact elapsed-time and physical-context matching; reuse prior confirmed/booked rate, not actual invoice variance.
- Source evidence: `E46, E47, E34, T11, T12, T01, T33`.
- Existing target path/owner: `existing SAL/context/rate owners`.
- Intended negative/positive proof: `AC-V31, AC-V38, AC-V79`; none executed in this compilation.

### BRS-04-R024: Estimate/recommendation/award/actual remain distinct

- Requirement: `LR-024`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Nonbinding estimate and ranked recommendation cannot commit rate/carrier; actuals remain executed outcome.
- Source evidence: `E46, E47, E34, T09, T10, T37`.
- Existing target path/owner: `existing local estimation, quote and actual-cost owners`.
- Intended negative/positive proof: `AC-V31, AC-V34, AC-V39, AC-V40, AC-V79`; none executed in this compilation.

### BRS-04-R025: Manual-only RFQ after SAL miss

- Requirement: `LR-025`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Maintain deliberate manual RFQ and operator decision boundary; surfaced requirements are not permission for automated solicitation.
- Source evidence: `E46, E47, E13, T01, T09, T37`.
- Existing target path/owner: `plasticos_logistics existing freight request action`.
- Intended negative/positive proof: `AC-V33, AC-V34`; none executed in this compilation.

### BRS-04-R026: Immutable market response and recipient evidence

- Requirement: `LR-026`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Retain losing, late, declined and superseding quote facts without fabricated send evidence or zero-price declines.
- Source evidence: `E46, E47, E06, T09, T10, T33`.
- Existing target path/owner: `plasticos_logistics/models/freight_quote.py`.
- Intended negative/positive proof: `AC-V39, AC-V15, AC-V79`; none executed in this compilation.

### BRS-04-R027: Carrier commitment beyond approved rate

- Requirement: `LR-027`. Source disposition: `NATIVE_REIMPLEMENTATION`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Book only exact approved carrier/rate/currency/equipment/windows/current context with attributable carrier acceptance.
- Source evidence: `E28, E21, E43, T01, T09`.
- Existing target path/owner: `plasticos_logistics booking confirmation command`.
- Intended negative/positive proof: `AC-V32, AC-V35, AC-V36`; none executed in this compilation.

### BRS-04-R028: Unavailable carrier routes commercial exception

- Requirement: `LR-028`. Source disposition: `MERGE_WITH_HARDENING`. Admission: `CANDIDATE_REQUIRES_TARGET_OWNER_REVIEW`.
- Candidate rule meaning: Carrier decline/unavailability holds release; operator chooses permitted re-resolution. Preserve old evidence and document amendments.
- Source evidence: `E22, E24, E30, E31, E47, T01, T09`.
- Existing target path/owner: `existing freight recovery and operator owner`.
- Intended negative/positive proof: `AC-V37, AC-V38, AC-V82`; none executed in this compilation.

### BRS-04-R067: Retain useful working freight; do not repeat predecessor campaign

- Requirement: `LR-067`. Source disposition: `PRESERVE_EXISTING`. Admission: `EXISTING_BEHAVIOR_CLAIM_NOT_RUNTIME_PROVEN`.
- Candidate rule meaning: Current implementation outranks older donor baseline; retain already-satisfied interfaces and regressions.
- Source evidence: `E46, E47, E48, T09, T10, T11, T12, T33`.
- Existing target path/owner: `current plasticos_logistics freight spine`.
- Intended negative/positive proof: `AC-V79, AC-V78, AC-V90`; none executed in this compilation.

## Admission and evolution

A rule becomes operative only after the target domain owner and operator approve its scope, code boundary and tests. Supersession must explicitly name the former rule, authority and revision; no donor can silently override existing load/freight or document rules. Unknown thresholds remain unknown.
