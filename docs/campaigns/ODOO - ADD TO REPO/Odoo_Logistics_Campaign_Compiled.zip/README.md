# Logistics Campaign Compiled | PlasticOS / Linda

**Package:** `Logistics_Campaign_Compiled.zip`  
**Campaign:** `PLASTICOS-LINDA-LOGISTICS-COMPILE-2026-10` v1.0.0  
**Compiled:** 2026-10-20  
**Target:** `https://github.com/cryptoxdog/IB-Odoo_19` / `Staging` / `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`  
**State:** Candidate implementation campaign, **not admitted or implemented**.  
**Compilation:** Local structural validation required; live Odoo acceptance tests **NOT_RUN**.  
**Reference exemplar:** **NOT_SUPPLIED**. Structural fidelity to a separate exemplar remains **UNKNOWN**.

## Operator intent

Bring the current Odoo 19 `plasticos_logistics` foundation to a mostly unattended, deterministic, email-first logistics coordinator, without duplicating a load state machine, mailbox, freight/rate decision authority, document registry, financial closure, or external orchestration platform. Keep required human freight approval, company boundaries, recipient confidentiality, physical evidence, and separate transaction/accounting closure.

## Reading order

1. `CAMPAIGN_SPEC.md` for the operating model and boundaries.
2. `SOURCES_DECISIONS_AND_GAPS.md` for source identities, supersessions, decisions and unknowns.
3. `business_rules/OWNER_INDEX.json` + `business_rules/BRS-01.md` through `BRS-07.md` for seven candidate concern ownership definitions and evidence-linked rules.
4. `FIELD_ROUTING_AND_CONFORMANCE.md` for known target fields and proof requests for proposed gaps.
5. `ROADMAP.md` and `CAMPAIGN_GRAPH.mmd` for dependency-ordered implementation.
6. `LOGISTICS_COVERAGE.md`, `SOURCE_TO_REQUIREMENT_TRACEABILITY.csv`, `business_rules/BUSINESS_RULE_TRACEABILITY.csv` and `FINDINGS_CLOSURE.csv` for lossless traceability.
7. `ACCEPTANCE.md` for planned positive, negative and boundary scenarios.
8. `EXECUTION_HANDOFF.md` for a **non-authorizing** downstream agent plan.
9. `validation/VALIDATION_REPORT.json` for what this compiler actually checked.

## Machine-readable owners and projections

- `campaign.json`: campaign graph, requirements, decisions, policies (rule references), acceptance, findings and unknowns.
- `business_rules/rules.json`: **single normative candidate rule text** within this pack. Existing repository law and action methods remain authoritative outside the pack.
- `business_rules/OWNER_INDEX.json`: **candidate** concern ownership; no registry entry in the target has been found.
- `field_routing.json`: verified existing field identities and candidate migration/adaptation routes.
- `source_inputs/`: untouched relevant JSON/markdown inputs and raw locally available donor snippets. Source excerpts retrieved through connectors are not claimed to be source-byte rehashed.
- `validation/campaign.schema.json` + `validation/validate_campaign.py`: independent rerunnable structural, referential and checksum controls.

## Source completeness and structural reference limitation

The source logistics harvest identified 10 donor families and inspected selected artifacts, including local raw bytes and Dropbox textual excerpts. It did **not** independently retrieve and hash every remote original. The previous harvest's findings and limitations have been preserved without promotion into runtime proof. The only ZIP supplied as input is a *logistics* harvest pack; no unrelated structural exemplar was supplied. This successor follows the **explicit required file/graph/rule format in the operator task** rather than fabricating structural-reference fidelity or a lexical exclusion set for an unseen domain.

## Handoff rule

WP00 is read-only and can begin without code authorization. All code-changing work packages, rule-family admission, group/cron changes, sends, migrations, publication and deployment require exact later owner approval and fresh current-revision binding. Source inspection, compilation and a green local checker are not execution acceptance.
