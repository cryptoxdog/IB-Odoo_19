# Logistics Acceptance and Adversarial Cases

**Important distinction:** every `AC-Vxx` is a proposed, **unexecuted** operational scenario from the logistics harvest. `AC-CFxx` are new packaging/binding preflight obligations; their status is reported separately in the artifact validator. Package structural PASS does not promote Odoo runtime cases to PASS.

## Acceptance strategy

- Positive: one eligible load advances through an attributable, correctly scoped event; one current packet delivered to allowed recipient; verified arrival documents synchronize and close only required gate.
- Negative: duplicate, stale, ambiguous, forwarded, unauthorized, cross-company, mismatched role, conflicting physical event, invalid document, company-less load, concurrent attempt, and source revision drift are rejected with no external effect.
- Invariant: missing/failed Mail/enterprise/provider observation never becomes business success; human exception is allowed when necessary.
- Test environment: **disposable production-equivalent Odoo 19/Enterprise database and a no-external-delivery mail sink**. Never send to actual counterparties during verification.
- Evidence required: exact Odoo revision/build, installed module versions and active crons, seeded cohort identity, actions + mail counters, authoritative before/after records, source/reply/document evidence IDs, true negative checks and replay.

## All planned cases

### AC-V01 - Commercial eligibility

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An approved commercial transaction with complete supplier, buyer, company and exact movement allocation exists.
- **When:** The release event is retried.
- **Expected:** One load is resolved/created in Draft and one readiness request is eligible; no duplicate stock document or mail.
- **Trace:** LR-001; BRS-01-R001; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V02 - No release on import

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A draft/imported/cancelled transaction lacks logistics release.
- **When:** Create/write automation runs.
- **Expected:** No supplier request, booking, dispatch or financial action occurs.
- **Trace:** LR-001, LR-065; BRS-01-R001; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V03 - Ambiguous shared order

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** One SO or PO covers two transactions/loads.
- **When:** A handler only knows the common order number.
- **Expected:** It records an association exception; neither load is selected by first-match search.
- **Trace:** LR-002, LR-053; BRS-01-R002, BRS-07-R053; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V04 - Company collision

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Two allowed companies have similar order references.
- **When:** A message/request references the other company or lacks company.
- **Expected:** No cross-company link, response, document or state mutation; explicit exception.
- **Trace:** LR-002, LR-003; BRS-01-R002, BRS-01-R003; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V05 - Copied load proof

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A delivered load has readiness, acknowledgment, BOL and actual-time values.
- **When:** A new load is duplicated.
- **Expected:** New load is Draft; no accepted confirmations, actual milestones, dispatch attempt or completion proof is inherited.
- **Trace:** LR-056; BRS-07-R056; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V06 - Assigned stock is not dispatch

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A picking becomes assigned but no carrier booking/accepted appointments exist.
- **When:** The existing auto-dispatch rule fires.
- **Expected:** Zero carrier messages; no dispatch_sent; no canonical load transition.
- **Trace:** LR-029, LR-063; BRS-05-R029; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V07 - One dispatch writer

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A valid scheduled load has current acceptance prerequisites.
- **When:** UI, server action and cron simultaneously request the same packet.
- **Expected:** One business send operation is persisted through the canonical load command; no alternate writer.
- **Trace:** LR-029; BRS-05-R029; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V08 - Preserve protected source

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A non-logistics user has ordinary internal write access.
- **When:** They write freight provenance/state or invoke a commercial command.
- **Expected:** Access/state guards reject it; no broad sudo or context Boolean bypass is added.
- **Trace:** LR-015; BRS-02-R015; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V09 - Native mail routing

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Isolated Odoo19/Enterprise has controlled sender and sink domains.
- **When:** An outbound request receives a reply via configured Odoo Mail.
- **Expected:** Message and attachment appear on the correct party-scoped business conversation; no Gmail poller is introduced.
- **Trace:** LR-009; BRS-02-R009; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V10 - Thread is not authority

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A free-form reply contains confirmed, ready, quote or a quoted old acceptance.
- **When:** Native mail ingests it.
- **Expected:** Raw evidence is retained; no consequential transition or rate acceptance is inferred.
- **Trace:** LR-009, LR-012, LR-062; BRS-02-R009, BRS-02-R012; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V11 - Authenticated structured acceptance

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A current readiness request is bound to one approved shipper contact/facility/load/revision.
- **When:** That authorized identity submits explicit acceptance with ready interval.
- **Expected:** Evidence, actor, original request and event/received times persist; only that load can advance.
- **Trace:** LR-004, LR-010, LR-011; BRS-02-R004, BRS-02-R010, BRS-02-R011; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V12 - Forged sender

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An attacker supplies a familiar From address but no valid authentication for the request.
- **When:** A structured-looking acceptance arrives.
- **Expected:** No state change; sender address alone never grants authority.
- **Trace:** LR-011; BRS-02-R011; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V13 - Forwarded link

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A valid link is forwarded to a different partner.
- **When:** The wrong authenticated party attempts acceptance.
- **Expected:** Request remains unaccepted; identity mismatch is logged without exposing the other party.
- **Trace:** LR-011, LR-014, LR-033; BRS-02-R011, BRS-02-R014, BRS-05-R033; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V14 - Crawler-safe confirmation

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Email security scanners fetch a confirmation URL.
- **When:** GET or preview is performed without an explicit authenticated submission.
- **Expected:** No acceptance or workflow mutation; an expired/replayed nonce also fails closed.
- **Trace:** LR-011; BRS-02-R011; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V15 - Replay and payload drift

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** One source Message-ID/request is already processed.
- **When:** Exact replay and then changed content under the same identity are supplied.
- **Expected:** Exact replay returns the existing result; changed payload is a conflict, not a new business action.
- **Trace:** LR-010, LR-013, LR-014, LR-026; BRS-02-R010, BRS-02-R013, BRS-02-R014, BRS-04-R026; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V16 - Old revision

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A request was cancelled/superseded because dates or freight context changed.
- **When:** A late valid-looking response to that request arrives.
- **Expected:** It remains historical evidence and cannot revive the cancelled decision or overwrite current acceptance.
- **Trace:** LR-006, LR-010, LR-014, LR-022; BRS-02-R006, BRS-02-R010, BRS-02-R014, BRS-03-R022; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V17 - Readiness versus counterproposal

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A shipper offers tomorrow instead of the proposed pickup window.
- **When:** The typed response is a counterproposal.
- **Expected:** Store proposed availability; do not mark the old requested date accepted or book the truck.
- **Trace:** LR-005, LR-012; BRS-02-R005, BRS-02-R012; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V18 - Shipper confirmation after sales release

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Sales already marked ready to dispatch.
- **When:** Linda evaluates readiness without direct shipper confirmation.
- **Expected:** It requests shipper READY, with confirmer identity and time; sales release is not substituted.
- **Trace:** LR-001, LR-004, LR-019; BRS-01-R001, BRS-02-R004, BRS-03-R019; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V19 - Readiness retraction

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A shipper retracts readiness before dispatch.
- **When:** An authenticated current contradiction is received.
- **Expected:** Dependent booking/release is blocked, old proof retained and owner activity raised; no silent date overwrite.
- **Trace:** LR-006, LR-014; BRS-02-R006, BRS-02-R014; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V20 - Monday status touch

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A released but not-ready load is within the approved Monday status policy.
- **When:** Cron runs repeatedly across the configured morning window.
- **Expected:** One PO-number plus shipper-company status request, not DO-only; stops on final READY/cancel and is not stacked with a duplicate daily touch.
- **Trace:** LR-007, LR-037, LR-039; BRS-02-R007, BRS-06-R037, BRS-06-R039; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V21 - Evidence-only actor

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A service identity has routine confirmation permission but no freight-award grant.
- **When:** It records a valid readiness reply then attempts carrier/rate award.
- **Expected:** First action succeeds within scope; second is denied.
- **Trace:** LR-004, LR-015; BRS-02-R004, BRS-02-R015; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V22 - Unknown dock rule

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A facility has a legacy default but no verified current FCFS/appointment evidence.
- **When:** Slot coordination starts.
- **Expected:** Ask the relevant facility; a default is not silently treated as confirmed FCFS.
- **Trace:** LR-016; BRS-03-R016; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V23 - FCFS both ends

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Both actual facilities have confirmed FCFS requirements and hours.
- **When:** Supplier readiness and authorized freight are available.
- **Expected:** No appointment request is required; readiness, carrier booking and valid operating windows are still required.
- **Trace:** LR-016, LR-019; BRS-03-R016, BRS-03-R019; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V24 - Delivery-first constrained booking

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Delivery requires an appointment and the pickup window is not yet committed.
- **When:** Buyer proposes and then accepts a dock slot.
- **Expected:** Pickup proposal is derived from that accepted slot and valid duration/loading evidence; buyer slot is not guessed.
- **Trace:** LR-017; BRS-03-R017; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V25 - Separate pickup appointment

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Pickup requires an appointment but delivery is FCFS.
- **When:** Linda coordinates the load.
- **Expected:** Only the pickup appointment must be accepted; no invented delivery appointment gate.
- **Trace:** LR-016; BRS-03-R016; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V26 - Conflicting accepted slots

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Origin and destination offer incompatible windows.
- **When:** Both responses are processed.
- **Expected:** Scheduling stays blocked; neither accepted commitment is overwritten; owner gets one conflict with alternatives.
- **Trace:** LR-017, LR-018, LR-021; BRS-03-R017, BRS-03-R018, BRS-03-R021; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V27 - DST and local hours

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Origin and destination use different time zones, including DST fold/gap dates.
- **When:** A local slot is proposed/accepted.
- **Expected:** Ambiguous/nonexistent local time is resolved explicitly; UTC instants and original local zones remain auditable.
- **Trace:** LR-020, LR-036; BRS-03-R020, BRS-05-R036; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V28 - Feasibility without invented ETA

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** No authoritative travel-duration or carrier commitment can make two slots feasible.
- **When:** The scheduler considers a Haversine estimate.
- **Expected:** Great-circle distance is not converted to a fictional ETA; obtain carrier feasibility or raise an exception.
- **Trace:** LR-008, LR-017, LR-020, LR-063; BRS-02-R008, BRS-03-R017, BRS-03-R020; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V29 - Cancel after booking

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** An accepted appointment is cancelled after carrier booking.
- **When:** Current cancellation is received.
- **Expected:** Release is held, affected dependent booking/requests are invalidated and revisioned, not silently edited.
- **Trace:** LR-018, LR-022; BRS-03-R018, BRS-03-R022; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V30 - No facility overbooking claim

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Two loads share a facility, but dock capacity data is absent.
- **When:** Their windows overlap.
- **Expected:** Do not claim a facility-capacity conflict solely from overlap; honor specific dock/slot identifiers or obtain facility acceptance. Same exclusive slot resource cannot be double-booked.
- **Trace:** LR-021; BRS-03-R021; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V31 - Preserve SAL exact boundary

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Prior executed source matches current canonical context and booked currency/rate.
- **When:** SAL evaluates at exactly 30 days and one microsecond outside.
- **Expected:** Existing approved inclusion boundary is preserved; no actual-invoice variance is substituted for booked price.
- **Trace:** LR-023, LR-024; BRS-04-R023, BRS-04-R024; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V32 - SAL does not book capacity

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** SAL has reused a carrier/rate but no current carrier commitment exists.
- **When:** Scheduling is requested.
- **Expected:** Capacity/equipment/window acceptance is still required; SAL is not fabricated truck availability.
- **Trace:** LR-019, LR-027; BRS-03-R019, BRS-04-R027; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V33 - Manual RFQ boundary

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** SAL misses.
- **When:** Routine coordination tries to find freight.
- **Expected:** One operator exception/manual RFQ path; no broadcast, automatic quote send or winner selection.
- **Trace:** LR-025; BRS-04-R025; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V34 - Recommendation not award

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A valid quote is top-ranked.
- **When:** Ranking runs twice.
- **Expected:** No selected flag, carrier substitution, state transition or email award occurs merely from recommendation.
- **Trace:** LR-024, LR-025; BRS-04-R024, BRS-04-R025; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V35 - Carrier accepts price only

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A carrier quote is accepted commercially but excludes the proposed pickup slot.
- **When:** A booking confirmation is evaluated.
- **Expected:** Rate confirmation survives as evidence; Scheduled remains blocked until the exact slot/equipment commitment exists.
- **Trace:** LR-012, LR-027; BRS-02-R012, BRS-04-R027; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V36 - Equipment mismatch

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** The load requires a particular trailer/loading capability.
- **When:** A carrier confirms different equipment.
- **Expected:** A typed conflict is raised; no default 53-foot van or capacity is invented.
- **Trace:** LR-008, LR-027, LR-063; BRS-02-R008, BRS-04-R027; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V37 - Carrier becomes unavailable

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** The approved carrier declines after SAL/quote acceptance.
- **When:** Recovery is requested.
- **Expected:** No first/next-cheapest automatic replacement; route the authorized recovery/award decision and keep history.
- **Trace:** LR-028; BRS-04-R028; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V38 - Context changes

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A location is edited in place or required equipment/load facts materially change after rate confirmation.
- **When:** Booking or dispatch is attempted.
- **Expected:** Existing context guard blocks; old evidence is retained; re-resolution occurs only through approved recovery.
- **Trace:** LR-022, LR-023, LR-028; BRS-03-R022, BRS-04-R023, BRS-04-R028; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V39 - Quote revisions

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A carrier issues a changed rate, a decline and a late response.
- **When:** Evidence is recorded.
- **Expected:** Old quote is preserved; response kind/timing/lifecycle stay distinct; declines do not require fake zero-priced quotes.
- **Trace:** LR-024, LR-026; BRS-04-R024, BRS-04-R026; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V40 - Currency fidelity

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An approved non-USD freight rate exists.
- **When:** All carrier documents and emails render.
- **Expected:** Amount and actual currency match; no dollar/USD assumption or automatic FX conversion.
- **Trace:** LR-024, LR-036, LR-064; BRS-04-R024, BRS-05-R036; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V41 - Packet before release acknowledgment

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A scheduled load has readiness, appointments and carrier booking, but no packet receipt.
- **When:** The full packet is sent and then its exact revision is acknowledged.
- **Expected:** One packet may be queued in Scheduled; only valid receipt permits Dispatched. No circular rule requiring Dispatched before sending.
- **Trace:** LR-030; BRS-05-R030; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V42 - Packet completeness

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** One of the three required rendered carrier documents is missing or invalid.
- **When:** A send/release is requested.
- **Expected:** No partial-success dispatch claim; identify the absent report/attachment and retain failed attempt evidence.
- **Trace:** LR-030; BRS-05-R030; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V43 - Audience isolation

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Supplier, buyer and carrier conversations have distinct audiences.
- **When:** A packet is rendered/sent including To/CC/BCC/reply recipients.
- **Expected:** Carrier gets required full itinerary; supplier never gets buyer details, buyer never supplier details; no buyer/supplier CC on carrier mail.
- **Trace:** LR-010, LR-031, LR-032, LR-033; BRS-02-R010, BRS-05-R031, BRS-05-R032, BRS-05-R033; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V44 - SO no Sales CC

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** The outgoing document is a buyer SO communication.
- **When:** An ordinary user/composer attempts to add Sales or an archival CC.
- **Expected:** The explicit donor no-Sales-CC/no-archive-CC rule is enforced unless separately overridden by the user.
- **Trace:** LR-032; BRS-05-R032; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V45 - Hidden disclosure channels

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A shared note, filename, quoted reply, follower or composer attachment contains restricted counterparty data.
- **When:** Mail generation or resend is requested.
- **Expected:** It is excluded or blocked by deterministic audience policy before any outbound queue entry.
- **Trace:** LR-031, LR-033; BRS-05-R031, BRS-05-R033; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V46 - Transport failure before send

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Queue creation or SMTP rejection occurs.
- **When:** The worker handles the failure.
- **Expected:** Business acceptance/release does not advance; mail failure and exact retryable operation remain visible.
- **Trace:** LR-034, LR-040; BRS-05-R034, BRS-06-R040; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V47 - Uncertain external send

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** SMTP/provider may have accepted a message before a timeout/crash.
- **When:** A retry worker resumes.
- **Expected:** Outcome is UNKNOWN until reconciled; no blind new booking/dispatch send and no unsupported exactly-once delivery claim.
- **Trace:** LR-034, LR-035, LR-058; BRS-05-R034, BRS-05-R035; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V48 - One logical touch despite template edit

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** The initial packet business operation already exists.
- **When:** Template formatting changes and worker retries.
- **Expected:** Payload hash detects changed content; it does not create a second initial operation without explicit revision.
- **Trace:** LR-013, LR-034; BRS-02-R013, BRS-05-R034; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V49 - Concurrent scheduler

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Twenty workers evaluate the same due confirmation/reminder.
- **When:** They race around mail creation and acceptance.
- **Expected:** Unique business key and transaction lock permit one enqueue; followers/retries do not duplicate activities or transitions.
- **Trace:** LR-013, LR-035, LR-038; BRS-02-R013, BRS-05-R035, BRS-06-R038; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V50 - Missed cron instant

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A scheduler resumes after the exact pre-pickup timer time.
- **When:** It processes overdue work.
- **Expected:** Due<=now catch-up sends only still-relevant unsent touches; no exact-time equality loss or stale reminder after acceptance.
- **Trace:** LR-007, LR-038, LR-039; BRS-02-R007, BRS-06-R038, BRS-06-R039; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V51 - No batch starvation

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** More active loads than the batch limit exist; oldest loads remain blocked.
- **When:** Cron runs through successive batches.
- **Expected:** Every due load gets evaluation without repeatedly selecting only the same oldest records.
- **Trace:** LR-038, LR-044; BRS-06-R038, BRS-06-R044; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V52 - Quiet-hours urgent distinction

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** External quiet hours apply while an operational deadline is near.
- **When:** Reminder is due.
- **Expected:** Defer external routine touch according to approved policy; preserve actionable internal activity and do not silently miss the deadline.
- **Trace:** LR-020, LR-039; BRS-03-R020, BRS-06-R039; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V53 - Acknowledgment stops only its ladder

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Carrier confirms packet receipt.
- **When:** Remaining milestones are evaluated.
- **Expected:** Stop packet-receipt reminders, not pickup/delivery checkpoint monitoring.
- **Trace:** LR-030, LR-037, LR-044; BRS-05-R030, BRS-06-R037, BRS-06-R044; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V54 - Verified pickup

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Origin/carrier evidence matches current load, location and time.
- **When:** Pickup is accepted.
- **Expected:** Load advances to picked_up exactly once; actual pickup time is recorded separately; outgoing picking is not marked done merely for pickup.
- **Trace:** LR-041, LR-042; BRS-06-R041, BRS-06-R042; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V55 - Delayed pickup message

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A real pickup event occurred earlier than ingestion.
- **When:** The late evidence arrives after its expected deadline.
- **Expected:** Record event and received times separately, resolve applicable overdue activity and keep the truthful history.
- **Trace:** LR-005, LR-041, LR-043; BRS-02-R005, BRS-06-R041, BRS-06-R043; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V56 - Out-of-order delivery

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A delivery notice arrives before pickup evidence.
- **When:** The handler evaluates it.
- **Expected:** Retain pending evidence; do not skip load prerequisites or invent pickup; resume only after valid predecessor evidence.
- **Trace:** LR-043, LR-053; BRS-06-R043, BRS-07-R053; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V57 - Checkpoint without GPS

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Driver assignment/en-route/arrival/delay confirmations are received.
- **When:** Dashboard updates.
- **Expected:** Display attributed checkpoint and time, not continuous location, invented ETA or automatic physical movement.
- **Trace:** LR-036, LR-041, LR-055, LR-068; BRS-05-R036, BRS-06-R041, BRS-06-R068, BRS-07-R055; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V58 - Stale delay after delivery

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** The load is already verified delivered.
- **When:** An old in-transit delay notice arrives.
- **Expected:** Keep historical notice without overwriting delivered state or reopening resolved physical milestones.
- **Trace:** LR-043; BRS-06-R043; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V59 - Lost contact

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An active picked_up load misses the next promised checkpoint.
- **When:** Scheduler detects overdue evidence.
- **Expected:** One actionable exception names owner, missing checkpoint, last verified event and contact attempt; no false delivery.
- **Trace:** LR-037, LR-040, LR-044, LR-068; BRS-06-R037, BRS-06-R040, BRS-06-R044, BRS-06-R068; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V60 - Wrong destination delivery

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Carrier reports delivery to a facility other than accepted destination.
- **When:** Delivery evidence is evaluated.
- **Expected:** Load stays unverified delivered/blocked; preserve mismatch evidence and do not finish picking or transaction.
- **Trace:** LR-045; BRS-07-R045; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V61 - Receiver receipt independent of carrier claim

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Carrier says delivered but receiver proof is absent/disputed.
- **When:** Closeout runs.
- **Expected:** Carrier-reported status remains attributed, not independently verified receiver receipt or logistics closure.
- **Trace:** LR-045, LR-052, LR-054; BRS-07-R045, BRS-07-R052, BRS-07-R054; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V62 - Missing signed BOL

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A load has two legacy BOL booleans but no eligible signed/verified current attachments.
- **When:** Close Load is attempted.
- **Expected:** Closure is denied and required evidence is named; flags are not promoted into proof.
- **Trace:** LR-048, LR-051, LR-056; BRS-07-R048, BRS-07-R051, BRS-07-R056; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V63 - Wrong/superseded document

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A verified file is expired, inactive, superseded, from another load/company or wrong party.
- **When:** It is considered for closeout.
- **Expected:** It cannot satisfy this load requirement; matching hash or tag alone does not override ownership/currentness.
- **Trace:** LR-047, LR-048, LR-049; BRS-07-R047, BRS-07-R048, BRS-07-R049; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V64 - Exact current native mirror

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A native Enterprise document changes attachment, tag or business link after initial mirror creation.
- **When:** Native-to-legacy synchronization and compliance run.
- **Expected:** Mirror represents the exact current authorized file/link/type and prior evidence remains auditable; no stale proof satisfies closure.
- **Trace:** LR-046, LR-049; BRS-07-R046, BRS-07-R049; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V65 - Hash is integrity only

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An unsigned/wrong-party file has the expected content hash.
- **When:** An ACK is submitted.
- **Expected:** Integrity may pass, but delivery/verification authority does not; required signature/receiver checks remain separate.
- **Trace:** LR-048, LR-050; BRS-07-R048, BRS-07-R050; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V66 - Versioned correction

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A receiver corrects a document or quantity.
- **When:** A successor is uploaded twice.
- **Expected:** One successor is linked; prior version preserved; old ACK cannot certify new bytes; replay creates no duplicate file/verification.
- **Trace:** LR-046, LR-049, LR-050; BRS-07-R046, BRS-07-R049, BRS-07-R050; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V67 - Unclear handwritten evidence

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Required fields/signature cannot be deterministically verified.
- **When:** Document ingestion runs without AI/OCR.
- **Expected:** Archive original and create review exception; do not set verified or waive required closure facts.
- **Trace:** LR-048, LR-050, LR-062; BRS-07-R048, BRS-07-R050; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V68 - Weight/source fidelity

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Scale/receiver quantities conflict or use another unit.
- **When:** Evidence is received.
- **Expected:** Retain original units and source, use existing conversion/weight authority, block disputed closeout; no financial reconciliation guessed.
- **Trace:** LR-008, LR-045, LR-052; BRS-02-R008, BRS-07-R045, BRS-07-R052; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V69 - Native stock completion

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Verified delivery has complete move/quantity/route evidence.
- **When:** The owned integration completes the native picking.
- **Expected:** Use native validation and exact movement association; no raw state=done, wrong return picking or first SO match.
- **Trace:** LR-042, LR-053; BRS-06-R042, BRS-07-R053; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V70 - Financial boundary

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Logistics is complete but invoice/financial requirements are not.
- **When:** Logistics handoff executes.
- **Expected:** Publish verified logistics facts; do not auto-close the commercial transaction or bypass manager/posted-document/margin controls.
- **Trace:** LR-054, LR-064, LR-066; BRS-07-R054; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V71 - Missing-document reminders

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** One party lacks a required document past its approved deadline.
- **When:** Scheduler repeats and later eligible evidence arrives.
- **Expected:** One role-specific reminder/activity obligation persists and resolves; no duplicate copies or escalation emails to all parties.
- **Trace:** LR-040, LR-046, LR-051; BRS-06-R040, BRS-07-R046, BRS-07-R051; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V72 - KPI truth

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A load is shipped late and later rescheduled after the event.
- **When:** On-time metrics are calculated.
- **Expected:** Compare against the accepted baseline in force at execution, not rewritten dates; separate physical lateness and evidence latency.
- **Trace:** LR-055, LR-068; BRS-06-R068, BRS-07-R055; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V73 - Legacy flags adoption

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Existing open loads have asserted ready/ack/BOL values without sources.
- **When:** Upgrade/adoption runs in an isolated clone.
- **Expected:** Preserve them as legacy assertions; no fabricated authenticated acceptance or physical evidence; only reviewed cohorts activate.
- **Trace:** LR-056; BRS-07-R056; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V74 - Clean install and upgrade

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Fresh Odoo19/Enterprise and production-equivalent clone are available with mail sink.
- **When:** Modules are installed/upgraded using verified repository machinery.
- **Expected:** Registry/views/templates/security install cleanly; no real email, source mutation or broader policy change.
- **Trace:** LR-057, LR-059; no BRS business rule; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V75 - No duplicate legacy writers

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Old PO/picking automations and new coordination are present.
- **When:** A released cohort progresses.
- **Expected:** Exactly one workflow owns each logical action; old overlapping rules are disabled/migrated with recorded XML IDs, not all crons blindly enabled.
- **Trace:** LR-037, LR-057; BRS-06-R037; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V76 - Recovery and rollback

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A pilot encounters an unsafe or unknown delivery outcome.
- **When:** Kill switch and rollback operate.
- **Expected:** Stop new outbound coordination, retain mail/evidence/history, cancel only uncommitted work; never erase delivered loads or roll commercial history backward.
- **Trace:** LR-058; no BRS business rule; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V77 - Replay whole lifecycle

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** One test load completes all authorized routine milestones via structured partner actions.
- **When:** All inbound events and scheduler ticks are replayed after restart.
- **Expected:** No duplicate loads, bookings, dispatches, activities, stock completions or closeout; all evidence identities remain stable.
- **Trace:** LR-035, LR-059; BRS-05-R035; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V78 - No AI/no n8n/no second store

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** Deterministic cohort is configured.
- **When:** A routine full lifecycle is exercised with external intelligence and old donor services unavailable.
- **Expected:** All ordinary coordination continues within Odoo; human commercial and genuine evidence exceptions remain explicit.
- **Trace:** LR-009, LR-060, LR-061, LR-062, LR-066, LR-067; BRS-02-R009, BRS-04-R067; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V79 - Rate and architecture regression

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Current freight regression fixtures are valid.
- **When:** Coordination changes are tested across SAL, quotes, context and actuals.
- **Expected:** Existing protected freight semantics remain satisfied; do not weaken a guard to make the workflow green.
- **Trace:** LR-023, LR-024, LR-026, LR-059, LR-067; BRS-04-R023, BRS-04-R024, BRS-04-R026, BRS-04-R067; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V80 - Runtime identity and authorization

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Cron/service user is installed with proposed permissions.
- **When:** Real isolated scheduler processes permitted and forbidden operations.
- **Expected:** Least-privilege routine actions work; cross-company access/commercial awards remain denied; install status is not substituted for execution proof.
- **Trace:** LR-003, LR-015, LR-057; BRS-01-R003, BRS-02-R015; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V81 - Proposed is not accepted

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A facility sends a free-form next-available slot or a typed proposal.
- **When:** The proposal is recorded.
- **Expected:** It does not replace an accepted slot; carrier coordination only proceeds when the relevant commitments are valid.
- **Trace:** LR-018; BRS-03-R018; owner slice(s) WP04.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V82 - Rebooking without physical rewind

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** A load is already picked_up when equipment/contact details change.
- **When:** Operator invokes recovery.
- **Expected:** Preserve physical history; use a bounded exception/amendment, not exception->Draft to manufacture a fresh pre-pickup load.
- **Trace:** LR-006, LR-022, LR-028, LR-058; BRS-02-R006, BRS-03-R022, BRS-04-R028; owner slice(s) WP05.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V83 - Attachment path safety

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An inbound or composer request references an arbitrary server file path or remote URL.
- **When:** Attachment processing begins.
- **Expected:** Only authorized Odoo attachment IDs/allowed uploaded bytes are used; no arbitrary local file read or unapproved network fetch.
- **Trace:** LR-047; BRS-07-R047; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V84 - Authorization expires

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An approved contact is deactivated/reassigned after request issuance.
- **When:** It tries to accept the old request.
- **Expected:** Current authorization is checked again; possession of old link is insufficient.
- **Trace:** LR-011, LR-065; BRS-02-R011; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V85 - Structured buyer order receipt

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** Buyer confirms order receipt but no appointment.
- **When:** Linda records the typed response.
- **Expected:** Buyer acknowledgment is retained separately; it neither changes freight award nor pretends dock acceptance.
- **Trace:** LR-012; BRS-02-R012; owner slice(s) WP02, WP03.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V86 - Dispatch entity compatibility

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A used plasticos.dispatch row points to a load.
- **When:** A public dispatch action is called.
- **Expected:** No independent advancement beyond the canonical load; existing IDs/references remain intact or mutation is blocked pending usage evidence.
- **Trace:** LR-029; BRS-05-R029; owner slice(s) WP01.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V87 - Mail actor concurrency

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** A reply is accepted while a reminder transaction is acquiring its lock.
- **When:** Both transactions finish.
- **Expected:** Re-read current state under lock prevents obsolete enqueue; already-sent external mail is recorded honestly, not erased.
- **Trace:** LR-038; BRS-06-R038; owner slice(s) WP06, WP07.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V88 - Unsolicited attachment ambiguity

- **Kind:** NEGATIVE_OR_ADVERSARIAL. **Runtime result:** NOT_RUN.
- **Given:** One supplier has several open loads and submits a BOL with only a PO number.
- **When:** Ingestion tries to correlate it.
- **Expected:** Quarantine/review; sender domain or one arbitrary first record cannot select a load.
- **Trace:** LR-002, LR-047; BRS-01-R002, BRS-07-R047; owner slice(s) WP08, WP09.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V89 - Negative-control suite sensitivity

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** The isolated test branch deliberately bypasses one prerequisite or idempotency guard.
- **When:** Focused tests run with that bounded fault then restored code.
- **Expected:** Relevant negative tests fail on the fault and pass only after restoration; no pass inferred from test existence.
- **Trace:** LR-059; no BRS business rule; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-V90 - Scope containment

- **Kind:** POSITIVE_OR_BOUNDARY. **Runtime result:** NOT_RUN.
- **Given:** An implementation agent sees old donor accounting/CRM/matching modules.
- **When:** It attempts to integrate the campaign.
- **Expected:** No those modules, n8n workflows or external donor services enter the change set; only separately authorized seam paths change.
- **Trace:** LR-060, LR-061, LR-064, LR-065, LR-066, LR-067; BRS-04-R067; owner slice(s) WP10, WP11.
- **Required evidence:** isolated runtime assertion, business action count, evidence identity and retained history.

### AC-CF01 - Pinned source and declared laws

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** The target head, canonical local source references and original ZIP are accessible.
- **When:** Perform a read-only preflight against the pinned target.
- **Expected:** Actual immutable source references, SHA consistency and unknowns are reported; no remote mutation.
- **Trace:** LR-057, LR-059; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.

### AC-CF02 - Separate artifact proof from runtime proof

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** The campaign ZIP passes its compiler checks.
- **When:** Review its proof scope against actual Odoo test evidence.
- **Expected:** The report says compiler artifact validated, runtime NOT_RUN; no invented installed-mail/cron proof.
- **Trace:** LR-059; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.

### AC-CF03 - No auxiliary logistics runtime

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** Existing load and Mail action owners are identified.
- **When:** Evaluate the plan for any second state machine or separate orchestration service.
- **Expected:** Only current Odoo owners are named as implementation destinations.
- **Trace:** LR-060, LR-061; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.

### AC-CF04 - No unapproved selection formula

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** A donor contains a weighted gate or invented freight rate/cost formula.
- **When:** Reconcile the donor proposal against the rule register.
- **Expected:** The formula remains rejected and cannot appear as an operative prerequisite or award rule.
- **Trace:** LR-063, LR-064; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.

### AC-CF05 - No autonomous free-form authority

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** A donor offers natural-language or OCR confidence as proof.
- **When:** Review proposed automations and acceptance cases.
- **Expected:** Free-form interpretation cannot autonomously certify readiness, movement, freight award or verified document.
- **Trace:** LR-062; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.

### AC-CF06 - Reference-domain isolation coverage

- **Kind:** COMPILATION_PREFLIGHT. **Runtime result:** PACK_CHECK_PENDING_OR_BOUND_TO_VALIDATION.
- **Given:** The user-specified required structure exists but the distinct structural reference is unavailable.
- **When:** Run output lexical checks and record reference fidelity limitation.
- **Expected:** Logistics-only positive scope can be tested, but exact unseen-reference lexical exclusion stays UNKNOWN.
- **Trace:** LR-060, LR-061; no BRS business rule; owner slice(s) WP00.
- **Required evidence:** exact source reference, deterministic package validator or documented UNKNOWN.
