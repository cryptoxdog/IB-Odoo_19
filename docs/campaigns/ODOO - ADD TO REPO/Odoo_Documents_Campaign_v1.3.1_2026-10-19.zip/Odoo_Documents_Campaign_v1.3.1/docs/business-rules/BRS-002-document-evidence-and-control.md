# BRS-002: Document Evidence, Matching and Lifecycle

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Source provenance, safe classification, association, controlled corrections and idempotent intake
**ID:** `BRS-002` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md) (operator-approved proposal, not merged)
**Owned rule IDs:** `BR-EVD-001`, `BR-EVD-002`, `BR-EVD-004`, `BR-EVD-005`, `BR-EVD-006`, `BR-FLD-004`
**Related:** BRS-001, BRS-003, BRS-004, BRS-005, BRS-006, BRS-007

## Context

This BRS is the sole normative owner for its rule IDs. Other BRS files may reference those IDs but may not redefine their conditions, thresholds, terminology, eligibility or effects. Accepted rules are operator decisions, derived-safety rules require source-bound implementation evidence, and pending decisions are never auto-resolved. Source/architecture decisions are effective in this campaign only; repository admission, ORM changes, financial postings and actual runtime tests remain separate.

## 7. Evidence, safety and Odoo-native realization (BR-EVD-001 through BR-EVD-004)

**BR-EVD-001 · ACCEPTED:** Preserve the original file and source submission provenance. Copies of the same BOL may represent one document with two senders; the attachment identity and per-source receipt history are distinct. One PDF may reference multiple transactions; preserve existing associations without creating duplicate physical original files or duplicate supplier bills.

**BR-EVD-002 · DERIVED SAFETY:** AI/OCR produces candidate facts, not unrestricted ORM mutation authority. Require issuer, exact TX/PO/SO/DO/load identity, company, document class, source and net/gross semantics before writing. Use native Odoo 19 Documents (folders/aliases/tags/requests/shortcuts/versions/splitting as actually installed), native Vendor Bill digitization and Sales/Accounting. Do not create a parallel DMS, field named for every document class, AI-only mandatory review, or independent financial ledger.

**BR-EVD-004 · DERIVED SAFETY:** Do not silently delete original evidence or revise an already-posted invoice after a corrected report. Preserve accepted versions and an auditable RWN/invoice correction using native lifecycle. Protect company and double-blind access; do not send buyer receiving documentation to the supplier by default. Retries must not duplicate a notice, bill, claim, chargeback or send.

### 11.3 Required evidence to write an existing field

Every accepted write needs an exact current source record and revision, source class (PL / Receiving Report / CST etc.), authenticated issuer and submission role, company, transaction, load, material/product/line, original units plus a verified conversion to pounds, source-stated numeric basis, packaging inclusion and pairing, prior accepted value and controlled correction outcome. A matching email domain, a `SCALE` or `CST` tag, a high AI confidence score, a trailer reference, or a detected numeric string **alone** is insufficient. Missing numeric input does not become 0.00, unknown packaging is not a free pass, and a post-close document must retain its original historical receipt time.

### 11.5 Existing owners with a known source-level mismatch

The shared underweight formula and its financial attribution are governed by `BRS-007@1.0.1`, not this Documents BRS. The current carrier rule/matrix references `SCALE` and marks missing generic scale required for close; it must instead scope the existing carrier `CST` evidence, and must not block buyer invoice/normal commercial close. The current native-to-legacy sync maps all `doc_type='scale_ticket'` to `SCALE`; it cannot classify optional supplier/buyer scales versus carrier certified CST without verified issuer, role and certification. `plasticos.transaction._compute_final_weight` selects a false generic winner, the old `_compute_light_weight_deduction` consumes `final_weight` instead of obligation-scoped material net, and the commission SQL dashboard displays `final_weight`. `account.move.action_post` calls a generic global document-compliance gate. These are source-level gaps and must be closed in their native owners with exact regression proof, not called fixed by adoption of this BRS.

## Derived source and evidence integrity rules

**BR-FLD-004 · DERIVED SAFETY:** All party-specific gross/CST tare/CST net, packing unit counts, packaging tare, and material net measurements have an explicit source party, document part, issuer, company, transaction, load, product/line, unit and revision. The three existing transaction scalar weight fields store supplier/buyer accepted commercial material-net weights and an independent CST-normalized material-net **reference**. There is no approved transaction scalar for each source-side gross/tare intermediate. Keep intermediates as source-linked typed evidence through verified native facilities; if live persistence is insufficient, record D08 and block only unsupported automatic writeback. Never create a convenience ORM weight alias to force a green test.

**BR-EVD-005 · DERIVED SAFETY:** Reuse native Odoo Documents intake/AI classification and existing legacy document links to create one original source with provenance and one semantic association per exact transaction/load/party. A supplier and carrier may submit the same BOL; retain two delivery receipts without two business shipments. Multi-load totals must not be copied to each transaction. The currently observed `DOC_TYPE_TAG_MAP[scale_ticket]=SCALE` cannot classify a certified carrier CST without the separate verified issuer/role/certification mapping.

**BR-EVD-006 · DERIVED SAFETY:** Every accepted source quantity must preserve raw value, normalized unit, gross/net/packaging basis, source document and revision, issuer, line/load relationship, original accepted target value and subsequent correction. Native Documents/attachments/chatter are reuse candidates; verify actual installed persistence for typed multi-fact evidence and replay. If insufficient, D08 is an explicit bounded representation decision rather than burying facts in unrelated weight fields or claiming fields were updated when they were not.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-EVD-001`, `BR-EVD-002`, `BR-EVD-004`, `BR-EVD-005`, `BR-EVD-006`, `BR-FLD-004`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
