# BRS-005: Buyer Receiving and Customer Invoicing

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Buyer Receiving Report acceptance, material net and native invoice-line application
**ID:** `BRS-005` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md) (operator-approved proposal, not merged)
**Owned rule IDs:** `BR-REC-001`, `BR-REC-002`, `BR-REC-003`, `BR-REC-004`
**Related:** BRS-001, BRS-003, BRS-004, BRS-006

## Context

This BRS is the sole normative owner for its rule IDs. Other BRS files may reference those IDs but may not redefine their conditions, thresholds, terminology, eligibility or effects. Accepted rules are operator decisions, derived-safety rules require source-bound implementation evidence, and pending decisions are never auto-resolved. Source/architecture decisions are effective in this campaign only; repository admission, ORM changes, financial postings and actual runtime tests remain separate.

## 5. Mandatory buyer receiving and Customer Invoice (BR-REC-001 through BR-REC-003)

**BR-REC-001 · ACCEPTED:** The buyer **Receiving Report** is the mandatory document to fully bill a load. It may contain received material/line quantities, accepted received net (`buyer_weight`), package counts and packaging tare, date, references and discrepancy/damage details. Apply accepted facts to the **existing** transaction/load fields only with correct company/party/load identity and arithmetic. A buyer scale ticket alone, a signed BOL/POD, an unsupported tag or a manually populated `buyer_weight` does not prove the report was received.

**BR-REC-002 · ACCEPTED:** Customer invoicing quantity comes from the validated accepted `buyer_weight`; agreed price, tax, UoM, customer and order lines come from the existing native Sales/Accounting owner. Supplier weight, missing PL, optional supplier/buyer scale ticket and required-but-missing carrier scale documentation do not hold an otherwise valid Customer Invoice. The pending RWN/its email delivery does not hold customer invoicing.

**BR-REC-003 · DERIVED SAFETY:** A partial/corrected/multiload Receiving Report authorizes only the proven portion of the correct order/load and must not allocate unspecified totals equally across loads. Buyer adjustments, rejections, credits and native posted-invoice corrections follow approved separate accounting rules. A buyer Receiving Report cannot unilaterally change a sales price or supplier purchasing price.

### 11.4 Correct native financial bridge, not a new accounting system

An existing source-specific transaction weight is **not yet an invoice-line quantity**. The reference `scale_weight` must never automatically become one. The native sales owner provides `sale.order.line.product_uom_qty` (ordered), `product_uom_id`, `qty_delivered` (native delivery semantics), computed `qty_to_invoice`/`qty_invoiced`, `invoice_lines` and price; the eventual `account.move.line.quantity` belongs to the posted/draft Customer Invoice through the supported Odoo workflow. The purchase owner analogously provides `purchase.order.line.product_qty`, `product_uom_id`, `qty_received`, computed `qty_to_invoice`, `invoice_lines` and native Vendor Bill. No implementation may write computed `qty_to_invoice` directly, replace ordered quantity to imitate receipt, or create duplicate bills. Actual delivery/receipt route and UoM must be verified on a disposable installed Odoo 19 Enterprise environment before automatic posting is accepted.

## Native buyer invoice acceptance

**BR-REC-004 · DERIVED SAFETY:** `buyer_weight` alone is not a native Customer Invoice line. The existing sale order line fields `qty_delivered`, `qty_to_invoice`, `qty_invoiced`, `product_uom_qty`, `product_uom_id`, `price_unit`, `invoice_lines` and actual `account.move.line.quantity` must be integrated through the installed native Odoo invoicing policy. Never write computed `qty_to_invoice`, replace ordered quantity with received quantity, or change sale price from OCR. Buyer full invoicing requires an accepted current Receiving Report and authorized native line-level invoicing; an unsettled supplier RWN or missing CST obligation does not block it.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-REC-001`, `BR-REC-002`, `BR-REC-003`, `BR-REC-004`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
