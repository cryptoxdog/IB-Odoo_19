# BRS-001: Document Classes and Native Identity

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Document type, issuer, direction, source identity and existing technical identity
**ID:** `BRS-001` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md) (operator-approved proposal, not merged)
**Owned rule IDs:** `BR-DOC-001`, `BR-DOC-002`, `BR-FLD-001`, `BR-FLD-003`
**Related:** BRS-002, BRS-003, BRS-004, BRS-005, BRS-006

## Context

This BRS is the sole normative owner for its rule IDs. Other BRS files may reference those IDs but may not redefine their conditions, thresholds, terminology, eligibility or effects. Accepted rules are operator decisions, derived-safety rules require source-bound implementation evidence, and pending decisions are never auto-resolved. Source/architecture decisions are effective in this campaign only; repository admission, ORM changes, financial postings and actual runtime tests remain separate.

## 1. Controlled vocabulary (BR-DOC-001, BR-DOC-002)

| Business term | Direction, issuer and actual meaning | Mandatory status | Existing classification/field binding |
|---|---|---|---|
| **PL / Packing List** | INBOUND supplier material/packaging list: unit weights, packaging counts and possibly supplier-declared net. | Collect where applicable; **not an automatic RWN or buyer-invoice blocker**. | Existing `PACKING` document tag (verify XML external ID); supplier `doc_category`; `supplier_weight` if accepted net is evidenced. No new `doc_type='packing_list'`. |
| **BOL / Bill of Lading** | Shipment document received from supplier and/or carrier; often two copies of the same document. | Track under applicable document matrix; not a substitute for buyer Receiving Report. | Existing `BOL` document tag and existing source attachment/transaction links; separately preserve submission provenance. |
| **Supplier Scale Ticket** | Optional evidence of supplier-side weighing, including an onsite MRF scale or supplier-arranged nearby scale; **may not be certified**. It is not called a carrier CST merely because it has scale numbers. | **Supplier is not obligated to provide**. | Existing supplier category and `SCALE` tag; potentially supplier observation `supplier_weight`; independent scale eligibility remains D13, not automatic certification. |
| **CST / Certified Scale Ticket** | **Carrier-provided certified** truck-scale evidence for one load. CST means **Certified Scale Ticket**, distinct from optional supplier/buyer scale tickets that may not be certified. The exact CST/load-net/material-net arithmetic is owned once by **BRS-003 BR-CST-002 and BR-VOC-001**, not redefined by document classification. The carrier certification requirement itself is owned by BRS-006 BR-CAR-001. | **Required per load**, but absence is **nonblocking for customer billing, routine RWN document compliance and commercial close**; $150 carrier chargeback subject to due rules. | Reuse the **existing** PlasticOS `plasticos_documents.tag_cst` (`plasticos.document.tag`, `code='CST'`, existing code label `Carrier Scale Ticket (CST)`) for carrier CST tracking, plus carrier `doc_category`; the native bridge's existing `doc_type='scale_ticket'` may apply. The **distinct** existing `plasticos_documents.tag_scale_ticket` has `code='SCALE'` for generic tickets. Actual installed tags must still be verified. Never create a new `doc_type='cst'`, extra CST tag or gross/net technical field. The current tag label does not establish actual certification; validate source evidence separately. Preserve CST gross, CST tare, CST net, packaging tare, and net weight billed in evidence. |
| **Buyer Scale Ticket** | Optional buyer-generated weighing record; **may not be certified** and is not a carrier CST by default. Can corroborate buyer receiving weight. | Not mandatory. It does **not** automatically replace Receiving Report. | Buyer category and existing scale tag/evidence; `buyer_weight` only when the supported buyer Receiving Report/measurement rule validates the source. |
| **Receiving Report** | **INBOUND from buyer**. Document reporting accepted material/line, received weight, packaging tare/count and related receiving details. | **MANDATORY** to fully invoice a load. | Existing `RECEIVING` tag; buyer `doc_category`; `plasticos.transaction.buyer_weight`; accepted report identity/association. No new `doc_type='receiving_report'` without permission. |
| **Received Weight Notice / RWN** | **OUTBOUND from Scrap Management to supplier**. Confirms supplier settlement quantity, purchase price and applicable approved penalties, light-weight deductions or other chargebacks. | Generated only with a valid accepted supplier settlement quantity and action authorization. Not an inbound buyer Receiving Report. | Existing native report/`mail.template` when verified; `plasticos.transaction.supplier_weight` normally; exceptional selection requires explicit human review and commercially authorized evidence, never automatic `scale_weight` substitution; native purchase/commercial terms and approved deductions. |
| **Customer Invoice** | OUTBOUND seller accounting document to buyer. | Buyer Receiving Report required for final invoice of a load. | Native `account.move` Customer Invoice via sale/order links, buyer `buyer_weight` and native price/tax/UoM. |
| **Vendor Bill** | Supplier or carrier billing document received by Scrap Management; Odoo Accounting term is **Vendor Bill**. | Controlled by applicable supplier/carrier payable terms, not by Customer Invoice readiness. | Native `account.move` Vendor Bill; existing `vendor_bill_ids`/`freight_bill_ids` relations. |

**BR-DOC-001 · ACCEPTED:** Keep these document names, issuer and direction distinct. **CST means the carrier Certified Scale Ticket**, not any supplier/buyer scale ticket. RWN ≠ Receiving Report. PL ≠ BOL ≠ carrier CST. An inbound buyer weight claim is not an outbound supplier notice. A buyer scale ticket is not, merely by existing, the mandated buyer Receiving Report. Classification may use existing tags and role/category without introducing unsupported native `doc_type` enum values.

**BR-DOC-002 · ACCEPTED:** The same BOL sent by supplier and carrier is one underlying shipping document/evidence with distinct delivery provenance. Do not duplicate invoice, shipment or physical underlying attachment solely because two parties sent the same BOL. Do not discard the evidence that each source submitted it.

## 2. Exact native/PlasticOS technical vocabulary (BR-FLD-001 through BR-FLD-003)

| Business meaning | **Existing technical identity** | Existing display label/semantics at inspected revision | Safe binding |
|---|---|---|---|
| Supplier declared weight | `plasticos.transaction.supplier_weight` | **Supplier Weight (lbs)** | Source-specific material net quantity after applicable packaging treatment. **Never create** `shipper_weight` or `purchase_weight`. |
| Buyer received weight | `plasticos.transaction.buyer_weight` | **Buyer Weight (lbs)** | Buyer material net quantity after applicable source-side packaging treatment. User colloquialism “received weight” is an alias in speech, **not** technical `received_weight`. |
| Separate eligible scale weight | `plasticos.transaction.scale_weight` | **Scale Weight (lbs)** | Validated packaging-adjusted **material net reference** when derived from eligible certified CST evidence; never automatically an RWN/vendor-bill or Customer Invoice quantity. Raw CST gross/CST tare/CST net remain separate source evidence; human review is mandatory above the applicable direct commercial-spread threshold. |
| Computed old selected “gross” | `plasticos.transaction.gross_weight` | **Gross Weight (lbs)** | Current code chooses a source weight, not guaranteed measured CST gross; **do not feed raw carrier gross here**. Compatibility audit required. |
| Computed old “final” | `plasticos.transaction.final_weight` | **Final Net Weight (lbs)** | **RETIRED BUSINESS CONCEPT; code removal pending the verified consumer migration**. Never use as settlement authority or introduce a replacement universal weight. |
| Selection of old winner | `plasticos.transaction.weight_source` | **Weight Source**, keys `scale`,`buyer`,`supplier`,`none` | Obsolete computed winner-selection metadata. May survive only as the existing temporary compatibility field; preferred-weight screen priority is independent and display-only. |
| Packaging count/unit | `plasticos.transaction.unit_count` / `unit_type` | **Unit Count** / **Unit Type** | Existing `unit_type` is one selection, not a proof of mixed packaging. |
| Packaging tare per unit/override/total | `plasticos.transaction.tare_per_unit`, `tare_per_unit_override`, `total_tare` | Existing packaging-tare fields | Existing `total_tare=unit_count × tare_per_unit` cannot independently encode heterogeneous Gaylord/pallet combinations. |
| Discrepancy indicator | `plasticos.transaction.weight_discrepancy_pct`, `weight_discrepancy_flagged` | **Weight Discrepancy %**, **Discrepancy Flagged** | Comparison/review signal; a flag alone never authorizes a credit, RWN basis change or bill posting. |
| Load seal and trailer | `plasticos.load.seal_number`, `plasticos.load.trailer_number` | **Seal Number**, **Trailer Number** | Correct load owner. Neither is transaction model field or a container/chassis synonym. |
| Inbound supplier/buyer/carrier | `plasticos.transaction.supplier_id`, `buyer_id`, `carrier_id` | Existing commercial party roles | Not extra partner model fields or an alias for native Vendor Bill's `partner_id`. |
| Native commercial order lines | `sale.order.line`, `purchase.order.line`, `account.move.line` | Native Odoo 19 model identities | Native price, taxes, quantity/UoM, billing/posting/credit workflows, verified at installed runtime before use. |
| Existing document identity | `documents.document`, `plasticos.document` | Native bridge + custom evidence records | Reuse original attachment and existing role/classification/transaction/load relationships. |

**BR-FLD-001 · ACCEPTED:** `supplier_weight`, `buyer_weight` and `scale_weight` are different existing **PlasticOS** source-specific fields. Never add `shipper_weight`, `received_weight`, `purchase_weight`, `net_weight`, a separate `plasticos.document.transaction.link` or a new `doc_type` value just to restate existing meaning. The ordinary English terms *shipper*, *received*, *net* and *gross* may appear in quoted external paperwork, commercial text and source-extraction labels; this prohibition is on **invented technical identity**, not vocabulary in the wild.

**See BR-FLD-002 in `BRS-003@1.0.1` for mandatory universal Final Weight retirement and verified downstream consumer migration.**

**BR-FLD-003 · DERIVED SAFETY:** Native Odoo Accounting uses **Vendor Bill** and **Customer Invoice** terminology on `account.move`; PlasticOS transaction uses `supplier_id` and `buyer_id`. Native actions, selection keys, labels, units and field destinations must be verified against actual installed Odoo 19, not inferred from casual English or earlier ERP field names.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-DOC-001`, `BR-DOC-002`, `BR-FLD-001`, `BR-FLD-003`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
