# BRS-003: Weights, Packaging and Measurement Vocabulary

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Controlled five-stage measurement vocabulary, same-load CST physical and packaging tare, source-specific normalization and direct three-way reconciliation
**ID:** `BRS-003` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**Authority:** Operator-accepted Documents-family scoped BRS, governed by proposed ADR-025; repository adoption pending.
**Owned rules:** BR-VOC-001; BR-WGT-001 through BR-WGT-010; BR-CST-002; BR-FLD-002.
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md); repository admission pending.
**Future sibling:** `brs-logistics` not created. No new Odoo model/field/selection authorization.

## Canonical, non-interchangeable measurement vocabulary

**BR-VOC-001 · ACCEPTED:** The following exact concepts govern every source measurement, comparison, RWN, invoice and contractual shortfall computation:

| Stage | Exact operator meaning | Formula / consequence |
|---|---|---|
| **Document measurement** | The quantity actually shown on the PL, Receiving Report or scale ticket | Preserve original numeric text, unit, document and revision; no implicit commercial approval. |
| **Load net** | Gross less corresponding vehicle/CST tare | With carrier certification: `CST gross − CST tare = CST net = load net`. |
| **Packaging tare** | Weight of applicable Gaylords, pallets, etc. | Separate from CST tare. |
| **Material net** | Load net less applicable packaging tare, or independently verified material-only net | Only deduct packaging where not already excluded by verified source basis. |
| **Accepted commercial weight** | The validated material net used for supplier or buyer settlement | `supplier_weight` and `buyer_weight` are separate commercial accepted weights; `scale_weight` is not one. |

These terms have different physical and legal meanings even if numbers coincide; `load net == material net` for the same physical load **only when applicable packaging tare is zero**. A separately stated material-only number might happen to match a load-net reading numerically, but equality alone does not establish that tare is zero or that either source has been validated. The carrier CST derived phrase *net weight billed* describes the packaging-adjusted material net for reference, **not authorization to invoice automatically on scale**.

## Source-specific material-net conversion and comparison

**BR-WGT-001 · ACCEPTED:** Preserve the existing `plasticos.transaction.supplier_weight` for accepted supplier material-net commercial weight and `buyer_weight` for accepted buyer Receiving Report material-net commercial weight. A trusted `scale_weight` is a third *reference* measurement, with independent CST certification and document provenance; not a third billable/commercial value and not an override. No universal `final_weight` exists. Document evidence cannot become an accepted commercial weight without correct party/line/unit/source support.

**BR-WGT-002 · ACCEPTED:** CST gross, CST tare, CST net are physical same-load readings, with **CST gross − CST tare = CST net**. CST tare is vehicle/trailer tare and is not packaging tare. Optional supplier/buyer scale gross/tare/net are separate un-certified-unless-proven observations; their numbers never become carrier CST readings solely because they are on scale tickets. A document labeled only "net" is a **document measurement**, NOT yet verified material net. It does not establish packaging exclusion; the evidence stage remains unresolved until its measurement basis is proved. Unknown remains unknown, not zero.

**BR-WGT-003 · ACCEPTED:** Applicable standard packaging tare is 40 lb per Gaylord, 40 lb per pallet, 80 lb per Gaylord on a pallet. Ten such combinations have 800 lb tare. Apply tare consistently to physical package evidence for supplier, buyer and CST comparisons **without subtracting it twice from already-verified material net**. Source-specific package counts must be reconciled to the actual same load; do not copy unverified counts to another source merely to force agreement.

**BR-WGT-004 · DERIVED SAFETY / D15 OPEN:** Existing transaction fields `unit_count`, `unit_type`, `tare_per_unit`, `tare_per_unit_override`, `total_tare` cannot prove heterogeneous package arithmetic or which source already excluded tare. They may represent a homogeneous verified 80 lb packaging override; mixed packaging, boxes, super sacks and disputed package counts remain separately evidenced and subject to D15. Never invent default box tare or new ORM columns to conceal missing evidence.

**BR-WGT-005 · DERIVED SAFETY:** Supplier PL, BOL or optional Supplier Scale Ticket may yield a supplier measurement. A supplier source value becomes `supplier_weight` only after verified actual load/material/party, unit conversion, accepted quantity and packaging basis. Preserve original raw source and revision, avoid repeat packaging deduction or automatic source overwrites. A Packing List is useful but not a mandatory RWN blocker by itself.

**BR-WGT-006 · DERIVED SAFETY:** Buyer `buyer_weight` comes from an accepted current Buyer Receiving Report, not from optional buyer scale, supplier PL or carrier CST. Preserve received gross/units/packaging per exact load/line and compute material net only with substantiated source basis. Partial, revised and multi-load documents cannot duplicate or silently replace quantities. A buyer scale may corroborate but does not satisfy the report obligation.

**BR-WGT-007 · DERIVED SAFETY:** A certified carrier CST meeting the separately owned BR-CST-001 document obligation yields CST gross, CST tare and CST net evidence; packaging-adjusted material net may populate `scale_weight` as a *reference* only after verified load, unit and packaging basis. Missing packaging does not invalidate otherwise sufficient CST evidence or trigger the $150 CST-document chargeback, but may leave the material-net reference unavailable. Do not write raw CST gross/CST tare/CST net into existing computed `gross_weight`, `final_weight` or packaging `total_tare`.

**BR-WGT-008 · DERIVED SAFETY:** For every extracted number retain four independent evidence axes: issuer/source party, document class, exact company/transaction/load/line, and physical basis (source gross, vehicle/CST tare, load net, package tare or material net). The native `SCALE` or `CST` tag, filename, sender or one number does not prove its meaning. Missing unit, uncertified CST, inconsistent source revision or disputed package evidence creates a review rather than silent accepted-weight writeback.

**BR-WGT-009 · ACCEPTED:** For a **single transaction-screen display only**, show a validated packaging-adjusted **certified CST reference** first; otherwise show accepted buyer_weight, otherwise accepted supplier_weight, otherwise 'No accepted weight'. Always show which of the three sources is displayed. This is NOT a third billing basis and MUST NOT be passed as the calculation basis for RWN, buyer invoice, debit, claim, or supplier deduction. No stored replacement universal `final_weight` is created for the display.

**BR-WGT-010 · ACCEPTED / D13 OPEN DENOMINATOR:** Reconcile **direct supplier_weight vs buyer_weight** independently of **supplier_weight vs scale_weight** and **buyer_weight vs scale_weight**; two comparisons each within 5% of CST may still contain a >5% direct commercial discrepancy and do NOT clear it. Direct accepted material-net spread **strictly greater than 5%** mandates documented human review. `scale_weight` remains reference and cannot automatically substitute into the supplier RWN, supplier AP or buyer Customer Invoice; reviewer must record authorized commercial correction, not change raw source evidence. Ratio denominator and exact boundary precision remain D13 until operator approved. Example: supplier 38,400, CST 40,000, buyer 41,600; reference differences ±4% but direct supplier/buyer spread is 3,200 lb = 8% of CST or ~7.69% of larger commercial value, so **REVIEW**, never automatic PASS.

**BR-CST-002 · ACCEPTED:** Preserve the original carrier arithmetic: `CST gross − CST tare = CST net`; `CST net − applicable packaging tare = net weight billed`. `CST net` is **load net**, before packaging. `net weight billed` in the CST physical chain equals the derived **material net reference**, not an automatic supplier or buyer settlement authorization. With CST gross 72,000 lb, CST tare 32,000 lb and 800 lb Gaylord-on-pallet packaging, the CST net is 40,000 lb and the material net reference 39,200 lb. Source material-only net values do not receive repeated packaging deductions. If packaging basis remains unknown, preserve CST receipt separately and hold only the affected derived net calculation.

**BR-FLD-002 · ACCEPTED (business retirement; code migration pending):** There is no universal Final Weight. Existing stored computed `plasticos.transaction.final_weight` and `gross_weight`/`weight_source` currently encode a source-priority winner and are obsolete as commercial authority. Retire their **business meanings now**, and retire the technical fields only after verifying/migrating all Odoo compute dependencies, transaction views, commission SQL dashboard, imported historical data, reports, customizations, native order/accounting flows and tests. The screen preference in BR-WGT-009 is **display-only and cannot resurrect a stored global winner**.

## Normative measurement examples and falsifiers (BR-VOC-001, BR-WGT-003, BR-WGT-005/006/007)

| Observed evidence (same physical load) | Verified basis | Permitted outcome | Forbidden shortcut |
|---|---|---|---|
| Carrier-certified CST gross **72,000 lb**, CST tare **32,000 lb**; 10 Gaylord-on-pallet units, **800 lb** verified packaging | CST physical load net **40,000 lb**; 800 lb packaging is included in that load net | **39,200 lb** material-net **reference** may be eligible for `scale_weight`; certified source remains independent of commercial price/quantity | Calling 40,000 lb material net, CST tare 800 lb, or payable weight without buyer/supplier contract |
| Supplier PL reports **40,000 lb net** but does not prove whether packaging was deducted | Original document measurement is 40,000 lb labeled “net”; its physical basis is UNKNOWN | Keep raw quantity and source; hold automatic accepted `supplier_weight` write pending proof of material-only basis | Treating the word “net” as material-net authority or blindly subtracting 800 lb |
| Supplier load-net **40,000 lb** is independently established to include the SAME 800 lb of packaging | 10 verified Gaylord-on-pallet units on that load | Accepted supplier **material net 39,200 lb**, if identity, contract and source are valid | Subtracting 800 lb again from a verified material-only figure |
| Buyer Receiving Report explicitly establishes **39,200 lb material-only net** and identifies the same load/packages | Packaging is already excluded in that report | Accepted `buyer_weight = 39,200 lb`; no extra tare, even though physical packaging is 800 lb | Applying the packaging tare twice or claiming buyer gross=material net |
| Independently accepted supplier **39,200 lb** and buyer **38,800 lb**, CST reference **39,200 lb** | Three accepted material-net source quantities | Preserve all three, directly compare supplier/buyer; display may show certified CST reference | Replacing buyer invoice weight with CST or changing supplier RWN solely because reference differs |
| Same load reports different package counts without corroboration | Actual package facts unresolved | Preserve both source claims, route to evidence review (D15) | Forcing all three numbers to agree using a copied or invented packaging count |

**Falsification boundary:** the same *packaging tare policy* applies across observations of the same actual packaging; it is not a license to copy unsupported counts between parties, to assume a document's “net” means material-only, or to reuse the vehicle **CST tare** as packaging tare. **None of the intermediate observations are new ORM fields.**

## Field and ownership guard

`plasticos.transaction.supplier_weight`, `.buyer_weight`, `.scale_weight` are the only presently approved accepted transaction-level source weight identities. Existing `unit_count`, `unit_type`, `tare_per_unit`, `tare_per_unit_override`, `total_tare` remain packaging helpers, not physical CST tare fields. Never invent `shipper_weight`, `received_weight`, `supplier.weight.gross`, `cst_net_weight`, `net_weight_billed`, `material_net_weight` or a universal `final_weight` replacement in Odoo ORM. Retain original source documents and revision/measurement evidence through verified existing Documents mechanisms first; D08 governs any proven irreducible persistence gap.

## Consequences, compliance and references

This concern defines the single physical material-net vocabulary and material-net normalization. The sibling `BRS-007@1.0.1` **references BR-VOC-001/BR-WGT-001..010/BR-CST-002** for quantity inputs; it does not define a second tare formula. The Documents BRS references these rules when accepting a Receiving Report, generating a RWN or checking CST document completion. `brs-logistics` remains deferred.


## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-VOC-001`, `BR-FLD-002`, `BR-CST-002`, `BR-WGT-001`, `BR-WGT-002`, `BR-WGT-003`, `BR-WGT-004`, `BR-WGT-005`, `BR-WGT-006`, `BR-WGT-007`, `BR-WGT-008`, `BR-WGT-009`, `BR-WGT-010`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
