# BRS-004: Supplier Settlement and Received Weight Notice

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Supplier RWN terms, direct commercial spread, human adjudication and authorized supplier-side adjustments
**ID:** `BRS-004` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md) (operator-approved proposal, not merged)
**Owned rule IDs:** `BR-SET-001`, `BR-SET-002`, `BR-SET-003`, `BR-SET-004`, `BR-SET-005`, `BR-SET-006`
**Related:** BRS-001, BRS-003, BRS-005, BRS-007

## Context

This BRS is the sole normative owner for its rule IDs. Other BRS files may reference those IDs but may not redefine their conditions, thresholds, terminology, eligibility or effects. Accepted rules are operator decisions, derived-safety rules require source-bound implementation evidence, and pending decisions are never auto-resolved. Source/architecture decisions are effective in this campaign only; repository admission, ORM changes, financial postings and actual runtime tests remain separate.

## 4. Discrepancy and supplier settlement (BR-SET-001 through BR-SET-005)

**BR-SET-001 · ACCEPTED:** The **Received Weight Notice is supplier-facing**. It reports (a) the selected supplier settlement weight and explicit unit, (b) agreed **supplier purchase price** and relevant material/load/PO/TX references, (c) approved **light-weight deduction**, other chargebacks/penalties if applicable, and (d) a traceable stated supplier settlement amount or clear unresolved amount. It does **not** merely report buyer received weight. It never exposes protected buyer identity, buyer SO price, margin or unredacted buyer Receiving Report by default.

**BR-SET-002 · ACCEPTED:** The RWN normally uses accepted `supplier_weight`; accepted buyer `buyer_weight` is independently used for the Customer Invoice. **Direct supplier-to-buyer material-net discrepancy strictly greater than 5% mandates human reconciliation**, including both direction and scale corroboration. Exactly 5% does not trigger the special review threshold. Comparing supplier and buyer separately to the CST is NEVER sufficient to clear their direct spread (see BR-WGT-010). The existing `weight_discrepancy_flagged` is only a signal; it cannot change a supplier amount or authorize a settlement basis. Final percentage denominator and precision are D13, not silently decided by current code.

**BR-SET-003 · ACCEPTED WITH D13 OPEN:** `scale_weight` is an independently observed **reference**, not a third commercial billing basis. A >5% exception requires **human review and documented contractual resolution** before any supplier RWN or AP amount is adjusted; there is no automatic `scale_weight` substitution, even if it appears certified, close to the buyer value or marked eligible. Preserve the original supplier and buyer observations, the scale reference, the reviewing person, decision, supporting documents, amount and recipient. If the reviewer authorizes a settlement adjustment, use the approved corrected commercial quantity/terms in existing native commercial records; never relabel `scale_weight` as a self-authorizing payable field. Buyer invoicing may continue independently on accepted buyer Receiving Report data. Source qualification, denominator and review evidence are D13; no reversion to the old automatic substitute policy.

**BR-SET-004 · DERIVED SAFETY / OPEN DETAILS D14:** A valid buyer Receiving Report does not fabricate `supplier_weight`. The operator made the buyer report mandatory for **full Customer Invoice**, but did **not** explicitly approve its absence as a universal supplier RWN prohibition. Whether an ordinary supplier RWN may be sent before a buyer Receiving Report is available is **D18, OPEN**; a source-supported supplier RWN may be drafted but automatic send is held until the sequencing rule is accepted. This hold reflects an unresolved sending decision, not a purportedly accepted buyer-report prerequisite. If supplier quantity is unavailable and no separately authorized fallback exists, **hold the RWN's supplier settlement quantity and sending**, while keeping Customer Invoice eligibility intact. The supplier Packing List's absence alone does not block an RWN if a valid supplier quantity is established elsewhere. A supplier scale document is not required merely to send a routine RWN when no exceptional scale substitution is necessary.

**BR-SET-005 · ACCEPTED WITH NATIVE ACCOUNTING GUARD:** RWN includes only **authorized supplier-side** adjustments and recoveries supported by contract, including a light-weight deduction when an independently established supplier obligation exists. The amount and eligibility algorithm are **owned exclusively by BR-UND-001..007 in `BRS-007@1.0.1`**; the RWN is just one possible communication of its approved supplier-side application. Buyer-side underweight liability does not automatically create a supplier-side recovery. The old `_compute_light_weight_deduction` reliance on `final_weight` and the obsolete dead-freight Boolean must be retired by controlled code migration. A supplier RWN is not payment/posting proof and neither carries buyer confidential details nor duplicates a chargeback economically.

### Supplier RWN decision table (normative, with declared pending conditions)

| Buyer Receiving Report | Supplier quantity | Discrepancy | Eligible independent scale | Supplier RWN | Customer Invoice |
|---|---|---|---|---|---|
| Missing/invalid | Supplier quantity present | Uncomputable | Any | **Supplier RWN draft may be prepared; automatic send scoped HOLD D18** pending approved order of operations. Do not call buyer RR universally required for the RWN. | Hold full load invoice: Receiving Report required |
| Missing/invalid | Supplier quantity missing | Uncomputable | Any | HOLD supplier quantity under D14, and auto-send under D18; no buyer fallback | Hold full load invoice |
| Valid | Present | ≤5% under APPROVED D13 denominator | Not necessary | Use `supplier_weight`; verify purchase price/deductions/recipient | Eligible on `buyer_weight` + native sale conditions |
| Valid | Present | >5% | Any scale evidence | **HOLD supplier settlement pending documented human reconciliation**; scale is reference only, not an automatic RWN basis | Eligible independently on `buyer_weight` |
| Valid | Present | >5% | Missing/invalid scale evidence | **HOLD supplier settlement and review missing evidence**; no invented fallback or automatic override | Eligible independently on `buyer_weight` |
| Valid | Missing | Uncomputable | Any | Hold RWN quantity absent D14-approved substitute | Eligible independently on `buyer_weight` |
| Valid | Present | Exactly 5% | Any | **No threshold exception**; use `supplier_weight` unless a separate genuine dispute exists | Eligible independently on `buyer_weight` |

The scale value is evidence only. An authorized human-reviewed resolution can correct the supplier-side commercial settlement, but cannot silently overwrite the source quantities; confirm the applied contract and record its decision separately. The routine supplier quantity may be supported by a supplier invoice, purchase evidence, Packing List, or validated other supplier statement, with source mapping and current commercial agreement; a Packing List is not a mandatory document prerequisite. No Vendor Bill is payable merely because an RWN was generated.

## Native RWN correction and independence

**BR-SET-006 · DERIVED SAFETY:** The supplier RWN is a report/mail communication normally using supported `supplier_weight`, supplier purchase price and separately authorized deductions. When the >5% commercial discrepancy is unresolved, human adjudication is required; `scale_weight` remains reference and may support an explicitly approved correction but is never an automatic RWN/vendor-bill basis. The RWN is not an `account.move` Vendor Bill, payment proof, or buyer Receiving Report. Buyer-report-before-RWN sending is D18, not an admitted documentary gate. Neither unknown sequencing nor an incomplete commercial comparison authorizes a blind automatic notice send. Any corrected notice retains prior sent revisions and actual human decision evidence.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-SET-001`, `BR-SET-002`, `BR-SET-003`, `BR-SET-004`, `BR-SET-005`, `BR-SET-006`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
