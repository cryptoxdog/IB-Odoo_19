# PlasticOS Business Rules Specifications (BRS)

**Index status:** operator-accepted business policy, **PROPOSED** repository adoption | **Family selector:** `brs-documents@1.3.1` | **Charter:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md)

**Canonical BRS file location:** `docs/business-rules/`. One numbered `BRS-NNN-<scoped-concern>.md` per business concern. The numeric BRS ID is a unique repository-level concern identifier; it is not a rule ID. Existing `BR-*` identifiers remain stable through moves and version changes. **Only the owning numbered file states normative rules.** This README and `index.json` are navigation and verified lookup surfaces, not competing business rulebooks. Acceptance in conversation does not admit files to the repository.

## BRS index

| BRS | Concern | Version | Stable rule count | Admission |
|---|---|---|---:|---|
| [BRS-001](BRS-001-document-classes-and-identity.md) | Document Classes and Native Identity | `1.0.1` | 4 | Proposed to repo |
| [BRS-002](BRS-002-document-evidence-and-control.md) | Document Evidence, Matching and Lifecycle | `1.0.1` | 6 | Proposed to repo |
| [BRS-003](BRS-003-weights-and-packaging.md) | Weights, Packaging and Measurement Vocabulary | `1.0.1` | 13 | Proposed to repo |
| [BRS-004](BRS-004-supplier-settlement-and-rwn.md) | Supplier Settlement and Received Weight Notice | `1.0.1` | 6 | Proposed to repo |
| [BRS-005](BRS-005-buyer-receiving-and-invoicing.md) | Buyer Receiving and Customer Invoicing | `1.0.1` | 4 | Proposed to repo |
| [BRS-006](BRS-006-carrier-cst-and-document-collection.md) | Carrier CST and Document Collection | `1.0.1` | 6 | Proposed to repo |
| [BRS-007](BRS-007-underweight-and-chargebacks.md) | Underweight Calculations and Contractual Chargebacks | `1.0.1` | 7 | Proposed to repo |

## Rule lookup and precedence

- **Normative:** the owning BRS number + its stable `BR-*` ID at an exact revision, as verified by `index.json`. Other BRS files link instead of restating a rule table.
- **Architectural:** `ADR-025` governs authority, numbering and change control; accepted ADR-021 governs native-first Odoo technical naming. An ADR cannot silently invent business thresholds, a BRS cannot invent Odoo schema.
- **Technical:** field identity, type, constraints and native actions come from exact installed Odoo 19 registry and the owning PlasticOS module. The BRS describes desired business meaning; proposed renames/field retirement require an independent Odoo migration.
- **Derived:** `TRACEABILITY.md`, `campaign.json`, `FIELD_ROUTING_AND_CONFORMANCE.md` and tests must stay consistent with the indexed rules; a passing test cannot rewrite an accepted rule.
- **Unresolved:** owner-bounded decisions D01/D03/D04/D05/D08/D13/D15/D16/D18 remain scoped; **D17 is resolved for arithmetic**, not a substitute for proof of contractual responsibility or native financial postings.

## Coding and testing use

1. Locate the behavior by stable `BR-*` ID via `index.json.rule_index`, resolve its `owner_id`, and read only that numbered normative BRS and explicitly referenced siblings.
2. Check the exact application source revision, native Odoo 19 model registry, existing `AGENTS.md`/ADR boundaries and associated `requirement_ids` and `acceptance_ids`; do not invent a field or selection key from BRS terminology.
3. Implement at the existing source owner. Build positive, boundary, adversarial and economic-once tests for the owned rule. Write no new rule to a second BRS file.
4. Validate with `python docs/business-rules/check_brs.py docs/business-rules --self-test` inside a checkout containing this directory. This proves local BRS structure and arithmetic fixtures only. Separately run the repository's actual Odoo CI against the exact resulting revision; record real receipts, not synthetic PASS.
5. A rule revision updates its normative BRS file and version, the index hashes/ownership, derived traceability, affected implementation tests and source revision evidence atomically. No edits to frozen predecessor material, no unwarranted new schema, no automatic publication.

## Superseded paths (historical only)

The former unnumbered `brs-documents.md`, `brs-weights-and-packaging.md` and `brs-underweight-and-chargebacks.md` were authority-bearing in v1.2.1 of the **proposal pack**, not in the target repo's Staging. Their bytes remain available via the predecessor `Odoo_Documents_Campaign_v1.2.1_2026-10-19.zip` whose digest is pinned in `index.json`. The numbered files supersede their active content. Do not leave parallel live copies in the target repo.

**Deferred:** `brs-logistics`; no file or separate rules engine created. **Status:** no Odoo runtime execution, source DB mutation, repository publication, merge or deployment performed here.

## Downstream registration

**Read first:** `REPOSITORY_REGISTRATION_RUNBOOK.md` (supplied at the campaign ZIP root) and `REGISTRATION_MANIFEST.json` (supplied at the campaign ZIP root) in the campaign ZIP. These are transport/integration aids, **not installed repository law**. Verify current Staging SHA, path collisions and existing CI Gate ownership before adoption. The `T###` entries are specifications, NOT currently passing automated Odoo tests; the test executor must bind actual test paths and receipts.

**Admission constraint:** Buyer Receiving Report gates full Customer Invoice, but whether supplier RWN may be automatically sent before the buyer report is an OPEN D18 decision. A source-supported draft is not a send authorization.
