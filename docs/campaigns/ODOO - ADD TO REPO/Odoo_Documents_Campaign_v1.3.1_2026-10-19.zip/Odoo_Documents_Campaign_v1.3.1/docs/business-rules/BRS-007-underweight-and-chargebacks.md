# BRS-007: Underweight Calculations and Contractual Chargebacks

**Status:** OPERATOR_ACCEPTED_CALCULATION / CONTRACTUAL_APPLICATION_STILL_OBLIGATION_SCOPED / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** 53-foot light-weight deductions, continuous prorated rate only after inclusive threshold, owner-specific financial consequences, technical name migration
**ID:** `BRS-007` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**Authority:** Operator-approved obligation-scoped underweight business policy; governed by proposed ADR-025; repository adoption pending.
**Owned rules:** BR-UND-001 through BR-UND-007.
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md); **physical inputs:** [`BRS-003`](BRS-003-weights-and-packaging.md) BR-VOC-001/BR-CST-002/BR-WGT-001..010.
**Boundary:** Business eligibility and attribution for underweight and chargeback claims. NOT a second physical measurement/packaging spec, independent accounting ledger, or future `brs-logistics`.

## Contractual threshold and one deterministic calculator

**BR-UND-001 · ACCEPTED:** The stated policy applies to a contractually applicable **53-foot trailer** with required minimum **40,000 lb material net**. A light-weight deduction is eligible when the **shortfall is at least 2,000 lb inclusive**. A shortfall of 1,999 lb does not trigger. Do not generalize the 53-foot minimum to other trailer types or an agreement without this obligation.

**BR-UND-002 · ACCEPTED, OPERATOR-RESOLVED:** Light Weight Deduction (LWD) for a contractually applicable 53-foot trailer is **not shortfall pounds multiplied by a fixed $/lb rate**. The minimum material net is 40,000 lb, and the deduction triggers at **2,000 lb shortfall inclusive**. Starting at that threshold, **the effective $/lb LWD rate is continuously prorated** from a base `$0.01/lb per 2,000 lb of shortfall` (equivalently `$0.0025/lb per 500 lb`), including partial 500 lb quantities. No `floor`, `ceil`, completed 500-lb step, or early rounding is allowed. The effective rate applies to the **entire actual accepted material net weight**, not just the shortfall. For an independently proved and eligible contractual obligation:

```text
shortfall_lbs = max(0, minimum_material_net_lbs - accepted_material_net_lbs)
if shortfall_lbs < 2000 or obligation_not_applicable:
    qualifying_shortfall_lbs = 0
    effective_lwd_rate_usd_per_lb = 0
    light_weight_deduction_total = 0
else:
    qualifying_shortfall_lbs = shortfall_lbs
    effective_lwd_rate_usd_per_lb = contractual_base_rate_per_2000_lbs * (shortfall_lbs / 2000)
    light_weight_deduction_total = accepted_material_net_lbs * effective_lwd_rate_usd_per_lb
# Default scoped base rate: contractual_base_rate_per_2000_lbs = 0.01 USD/lb
# Quantize the final USD monetary amount to cents (ROUND_HALF_UP).
```

The existing `light_weight_deduction_rate` is proposed to represent the **contractual base rate per 2,000 lb of shortfall**, not the dynamically computed effective rate. No new stored rate field is authorized. An explicitly agreed zero rate yields zero and must never be changed into 0.01 via `rate or 0.01`. Missing obligation, missing material net, or unverified rate never becomes an invented payable charge. **D17 is RESOLVED for the calculation's rate and arithmetic**: the earlier `$200/$400` examples and the old full-shortfall multiplication are superseded, not competing active authorities. Liability, beneficiary, credits and amount posting still require D16 and native accounting/claims evidence.

| 53-foot material net | Shortfall lb | Effective rate ($/lb) | Total LWD ($) | Status |
|---|---:|---:|---:|---|
| 38,001 | 1,999 | 0.000000 | 0.00 | Below threshold |
| 38,000 | 2,000 | 0.010000 | 380.00 | Threshold inclusive |
| 37,750 | 2,250 | 0.011250 | 424.69 | Continuously prorated; NOT $377.50 |
| 37,501 | 2,499 | 0.012495 | 468.57 | Continuously prorated; NOT floor tier |
| 37,500 | 2,500 | 0.012500 | 468.75 | Quarter cent / full 500 lb |
| 37,000 | 3,000 | 0.015000 | 555.00 | Prorated |
| 36,000 | 4,000 | 0.020000 | 720.00 | 2 short tons below minimum |
| 34,000 | 6,000 | 0.030000 | 1,020.00 | 3 short tons below minimum |

The rate depends on *shortfall*, but the monetary deduction depends on *actual material net*. Extremely low weights can exhibit nonmonotonic charge totals; no arbitrary minimum/cap/extra fee is authorized. Such cases need explicit contract evaluation rather than extrapolating a new business rule.

**BR-UND-003 · ACCEPTED:** The formula is **obligation-scoped**. The applicable PO, SO, freight booking/terms or other controlling contract determines **whether an underweight obligation exists**, relevant trailer minimum/rate, the legally responsible party, beneficiary, effective date and valid material-net basis. A buyer handling freight may assess an underweight charge against Scrap Management; separately, Scrap Management may possess a contractually valid supplier recovery. They are **separate obligations**, never one automatically mirrored event. A valid buyer charge does not prove supplier liability or collection. Existing Sales, Purchase, Claims and native Accounting own each financial effect; no new parallel ledger or one global transaction payable value.

**BR-UND-004 · ACCEPTED NAMING; PROPOSED ORM MIGRATION:** Name the canonical proposed monetary compute method **`_compute_light_weight_deduction_total()`**, not `_compute_weight_deduction()`; it computes the **total amount**, not all weight semantics. Reusable obligation-scoped pure arithmetic may be named `_calculate_light_weight_deduction` (technical proposal only), returning eligible shortfall pounds, effective prorated $/lb and final dollars. Retain existing `light_weight_deduction_rate`; `light_weight_deduction_weight` is an initial **non-ORM calculated quantity** unless a proven requirement for an independently stored/readable Odoo field is approved. `light_weight_deduction_total` is the proposed explicit technical successor to the current stored `light_weight_deduction`, pending one controlled migration. The current implementation method `_compute_light_weight_deduction` is a known legacy name; no code has been changed. Since a transaction can have more than one obligation, any transaction-level amount may be an explicitly defined summary only, never the owner of individual buyer liabilities and supplier recoveries.

**BR-UND-005 · ACCEPTED BUSINESS RETIREMENT; TECHNICAL MIGRATION PENDING:** Retire the obsolete `dead_freight_chargeback` Boolean and its current rule `deduction_total > purchase_cost_total`. That code is not an approved definition of dead freight or party liability. Do not replace it with another inferred Boolean, automatically create a distinct freight fee, or delete the physical stored column before checking installed views, report/SQL/ORM consumers, historic record compatibility and tests. If a distinct future dead-freight contractual fee is required, it needs a separate operator-approved policy, not resurrection of the old test.

**BR-UND-006 · DERIVED SAFETY:** Compute against the accepted *material net* weight associated with the **specific contractual obligation**. For a supplier-side recovery, source/settlement basis is supplier-side accepted commercial material net subject to human reviewed corrections under BR-WGT-010 / BR-SET-003; for a buyer-side liability, use the contractually agreed measurement basis and its accepted material net evidence, not an unrelated supplier quantity or universal `final_weight`. Packaging tare is handled once upstream under BR-WGT-003; do not subtract again within the light-weight deduction calculator. Missing quantity/terms => explicit scoped hold, never silent zero/waiver or autopost.

**BR-UND-007 · DERIVED SAFETY:** The $150 **carrier missing-certified-CST documentation chargeback** under BRS-006 BR-CAR-003 is separate from the **rate-dependent light-weight deduction** here. D17 arithmetic conflict is operator-resolved; D16 party liability and authorized accounting remain independent. A claimed buyer underweight liability, authorized supplier recovery, and carrier document penalty can coexist, but may not be netted, mirrored, booked or added to margin twice. Distinguish calculated amount, contract eligibility, claimed amount, posted accounting adjustment, recovered/paid amount, and settled state. Existing `plasticos.claim` and native `account.move` plus sale/purchase actions own those transitions; no duplicate financial engine is authorized.

## Technical state and migration acceptance

At pinned Staging `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, `plasticos_transaction/models/transaction.py` declares `minimum_net_weight`, `light_weight_deduction_rate`, `light_weight_deduction`, `dead_freight_chargeback`; `_compute_light_weight_deduction()` uses deprecated `final_weight`, charges any shortfall, substitutes an explicit 0 rate with $0.01 via `rate or 0.01`, and computes the obsolete Boolean from the total versus purchase cost. These are **observed source facts**, not current business policy. Proposed field rename and method replacement require an explicit bounded Odoo migration; `light_weight_deduction_weight` initially remains an output contract, not an invented `fields.Float` on an existing model.

Acceptance must test: 38,001 -> $0; 38,000 -> $380; 37,750 -> $424.69; 37,501 -> $468.57; 37,500 -> $468.75; 37,000 -> $555; 36,000 -> $720; 34,000 -> $1,020; 2,249 versus 2,250 shortfall; continuous partial proration (not floor tiers), no early rate rounding; explicitly zero contractual base rate; inactive/non-53-foot obligations; no packaging double-subtraction; buyer liability separate from supplier recovery; no automatic scale-substituted billing; and legacy Boolean/`final_weight` migration. All actual Odoo runtime integration tests remain **NOT_RUN** until executed on the installed disposable target.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-UND-001`, `BR-UND-002`, `BR-UND-003`, `BR-UND-004`, `BR-UND-005`, `BR-UND-006`, `BR-UND-007`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
