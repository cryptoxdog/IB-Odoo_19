#!/usr/bin/env python3
"""Standalone numbered BRS index/owned-rule/underweight arithmetic conformance checker.

Local documentary and pure-Decimal assurance ONLY. No Odoo runtime, DB, mail or accounting test.
Use from an Odoo checkout: python docs/business-rules/check_brs.py docs/business-rules --self-test
"""
from __future__ import annotations
import argparse
import copy
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import sys

RULE = re.compile(r'^\*\*(BR-[A-Z]+-\d{3}) \u00b7', re.M)
ID = re.compile(r'^BRS-\d{3}$')
LEGACY = {'brs-documents.md','brs-weights-and-packaging.md','brs-underweight-and-chargebacks.md'}
EXPECTED_RULE_COUNTS = {'BRS-001':4,'BRS-002':6,'BRS-003':13,'BRS-004':6,'BRS-005':4,'BRS-006':6,'BRS-007':7}
EXPECTED_GOLDEN = {
 '38001':('1999','0','0.00'),
 '38000':('2000','0.010','380.00'),
 '37750':('2250','0.01125','424.69'),
 '37501':('2499','0.012495','468.57'),
 '37500':('2500','0.01250','468.75'),
 '37000':('3000','0.015','555.00'),
 '36000':('4000','0.020','720.00'),
 '34000':('6000','0.030','1020.00'),
}

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dec(v):return Decimal(str(v))

def calculate(material_net,min_net,base,applicable):
 net=dec(material_net); minimum=dec(min_net); base=dec(base)
 need(net >= 0 and minimum >= 0 and base >= 0,'negative weight/rate not allowed')
 shortfall=max(Decimal('0'), minimum-net)
 qualified=shortfall if applicable and shortfall>=Decimal('2000') else Decimal('0')
 effective=(base*shortfall/Decimal('2000')) if qualified else Decimal('0')
 total=(net*effective).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
 return shortfall,qualified,effective,total

def validate(root, idx=None, corp=None, fixtures=None):
 root=Path(root)
 idx=json.loads((root/'index.json').read_text()) if idx is None else idx
 fixtures=json.loads((root/'fixtures/light_weight_deduction.json').read_text()) if fixtures is None else fixtures
 need(idx['schema']=='plasticos.brs-index/v1','wrong index schema')
 need(idx['id']=='brs-documents','wrong family selector')
 need(idx['selector']==idx['id']+'@'+idx['version'],'version mismatch')
 need(idx['authority_class']=='DERIVED_ROUTING_INDEX_NOT_NORMATIVE_LAW','index becoming competing law')
 entries=idx['entries']
 need(len(entries)>=len(EXPECTED_RULE_COUNTS),'original seven numbered concerns may not be removed')
 ids=[e['id'] for e in entries]
 need(ids==[f'BRS-{n:03d}' for n in range(1,len(entries)+1)],'duplicate/gapped/reordered BRS numbering')
 baseline=entries[:len(EXPECTED_RULE_COUNTS)]
 need({x['id']:len(x['rule_ids']) for x in baseline}==EXPECTED_RULE_COUNTS,'original concern rule counts changed without approved revision')
 for entry in entries[len(EXPECTED_RULE_COUNTS):]:
  need(entry['status'] in ('OPERATOR_ACCEPTED_POLICY_REPO_PROPOSED','OPERATOR_ACCEPTED_POLICY_REPO_ADMITTED'),'new concern lacks operator-accepted provenance')
  need(bool(entry['rule_ids']),'empty newly numbered BRS is not an admitted concern')
 need(not any((root/x).exists() for x in LEGACY),'unnumbered normative BRS shadow owner')
 owners={};rule_details={}
 for e in entries:
  need(ID.fullmatch(e['id']) is not None,'bad numbered BRS identity')
  p=root/Path(e['path']).name
  need(e['path']=='docs/business-rules/'+p.name,'wrong normative relative path')
  need(p.name.startswith(e['id']+'-'),'numbered path mismatch')
  need(p.is_file(),'missing normative BRS file '+e['id'])
  data=p.read_text() if corp is None else corp.get(e['id'],p.read_text())
  # strict index hash and path contents are independently verified
  need(hashlib.sha256(data.encode()).hexdigest()==e['sha256'],'normative BRS digest mismatch '+e['id'])
  need(data.startswith('# '+e['id']+': '),'ADR-like BRS heading mismatch '+e['id'])
  need('**Version:** '+e['version'] in data,'normative BRS version mismatch '+e['id'])
  ids=RULE.findall(data)
  need(len(ids)==len(set(ids)),'duplicate rule in '+e['id'])
  need(set(ids)==set(e['rule_ids']),'owner/definitions diverged in '+e['id'])
  for rid in ids:
   need(rid not in owners,'duplicate rule across BRS files '+rid)
   owners[rid]=e['id'];rule_details[rid]=data
 need(len(owners)>=46 and all(len(e['rule_ids']) for e in baseline),'prior 46 stable rules not preserved')
 need(set(owners)==set(idx['rule_index']),'rule_index orphan/duplicate')
 for rid,v in idx['rule_index'].items():
  need(v['owner_id']==owners[rid],'wrong indexed owner '+rid)
  need(v['owner_path']==next(e for e in entries if e['id']==owners[rid])['path'],'bad owner path '+rid)
  need(bool(v['acceptance_ids']),'rule has no acceptance evidence link '+rid)
  need(len(v['acceptance_ids'])==len(set(v['acceptance_ids'])),'duplicate acceptance mapping '+rid)
  need(all(re.fullmatch(r'T\d{3}',x) for x in v['acceptance_ids']),'invalid test ID '+rid)
 b7=rule_details['BR-UND-002']
 for token in ('**BR-UND-002','2,000 lb','2,250','0.011250','424.69','36,000','720.00','partial 500','_compute_light_weight_deduction_total()'):
  need(token.lower() in b7.lower(),'formula/method missing from normative BRS-007: '+token)
 # Independent (not index-content-SHA-only) operator-policy sentinels. Source document "net" is not accepted material net;
 # an absent buyer report gates a full buyer invoice but is NOT an operator-proven blanket supplier-RWN prerequisite.
 b3=rule_details['BR-VOC-001'];b4=rule_details['BR-SET-004']
 need('document measurement' in b3.lower() and 'load net' in b3.lower() and 'material net' in b3.lower(),'five-stage vocabulary lost')
 need('D18, OPEN' in b4 and 'auto-send' in b4.lower(),'supplier RWN sequencing OPEN decision omitted')
 need('does not fabricate' in b4 and 'buyer Receiving Report' in b4,'supplier source must not be synthesized from buyer report')
 need('2,000 lb' in b7 and 'full' in b7.lower() and 'partial 500' in b7.lower(),'underweight continuous proration formula lost')
 need('**BR-VOC-001' in rule_details['BR-VOC-001'],'vocabulary definition missing')
 need('CST gross' in rule_details['BR-CST-002'] and 'CST tare' in rule_details['BR-CST-002'],'CST vocabulary drift')
 need('scale_weight' in rule_details['BR-WGT-010'] and 'human review' in rule_details['BR-WGT-010'].lower(),'scale reference review lost')
 need('Retire the obsolete `dead_freight_chargeback` Boolean' in rule_details['BR-UND-005'],'legacy boolean retirement lost')
 index_human=(root/'README.md').read_text()
 need(idx['selector'] in index_human,'human index version stale')
 for e in entries:
  need(index_human.count(']('+Path(e['path']).name+')')==1,'human BRS index missing/duplicate '+e['id'])
 trace=(root/'TRACEABILITY.md').read_text()
 for rid,v in idx['rule_index'].items():
  need(f'| `{rid}` | `{v["owner_id"]}` |' in trace,'traceability view missing rule '+rid)
 need(fixtures['schema']=='plasticos.brs-calculation-fixtures/v1' and fixtures['business_rule']=='BR-UND-002','wrong numeric fixture source')
 need(fixtures['normative_brs']=='BRS-007@'+next(e['version'] for e in entries if e['id']=='BRS-007'),'wrong formula owner')
 need(sha(root/'fixtures/light_weight_deduction.json')==idx['ci_contract']['fixture_sha256'] if fixtures is None else True,'fixture digest mismatch')
 need(fixtures['rounding']=='USD_CENTS_HALF_UP_AT_FINAL_AMOUNT' and fixtures['proration']=='CONTINUOUS_INCLUDE_PARTIAL_500','staircase/rounding drift')
 cases=fixtures['cases'];need(len(cases)>=16,'boundary fixture set incomplete')
 ids=[x['id'] for x in cases]; need(len(ids)==len(set(ids)),'duplicate numeric case id')
 covered={}
 for x in cases:
  short,qualified,rate,total=calculate(x['material_net_lbs'],x['minimum_material_net_lbs'],x['base_rate_per_2000_shortfall'],x['applicable_contract'])
  need((short,qualified,rate,total)==tuple(dec(x[k]) for k in ('shortfall_lbs','qualifying_shortfall_lbs','effective_rate_usd_per_lb','total_usd')),'numeric fixture mismatch '+x['id'])
  if x['applicable_contract'] and dec(x['base_rate_per_2000_shortfall'])==Decimal('.01'):
   covered[x['material_net_lbs']]=x
 for net,(short,rate,total) in EXPECTED_GOLDEN.items():
  need(net in covered,'missing independent numeric known-good witness '+net)
  need(dec(covered[net]['shortfall_lbs'])==dec(short) and dec(covered[net]['effective_rate_usd_per_lb'])==dec(rate) and dec(covered[net]['total_usd'])==dec(total),'golden numeric oracle mismatch '+net)
 need(any(not x['applicable_contract'] for x in cases),'missing contract non-applicability witness')
 need(any(x['applicable_contract'] and dec(x['base_rate_per_2000_shortfall'])==0 for x in cases),'missing explicit-zero witness')
 return {'numbered_brs':len(entries),'stable_unique_rule_ids':len(owners),'linked_acceptance_total':sum(len(x['acceptance_ids']) for x in idx['rule_index'].values()),'arithmetic_vectors':len(cases)}

def negative_controls(root):
 root=Path(root); idx=json.loads((root/'index.json').read_text()); fixture=json.loads((root/'fixtures/light_weight_deduction.json').read_text())
 mutations=[]
 def copy_run(name,modify):
  ix=copy.deepcopy(idx);fi=copy.deepcopy(fixture);corpus={}
  modify(ix,fi,corpus)
  try:validate(root,idx=ix,corp=corpus,fixtures=fi)
  except (ValueError,KeyError):mutations.append(name)
  else:raise ValueError('known bad passed BRS validator: '+name)
 def coherently_change_brs(entry_id,old,new,ix,corpus):
  ent=next(e for e in ix['entries'] if e['id']==entry_id)
  src=(root/Path(ent['path']).name).read_text();need(old in src,'bad negative control fixture')
  changed=re.sub(re.escape(old),new,src,flags=re.IGNORECASE); corpus[entry_id]=changed
  ent['sha256']=hashlib.sha256(changed.encode()).hexdigest()
 copy_run('coherent_hash_but_removed_RWN_unknown',lambda a,b,c:coherently_change_brs('BRS-004','D18, OPEN','D18_REMOVED',a,c))
 copy_run('coherent_hash_but_source_stage_erased',lambda a,b,c:coherently_change_brs('BRS-003','Document measurement','Measurement_undefined',a,c))
 copy_run('duplicate_owner',lambda a,b,c:a['entries'][1]['rule_ids'].append(a['entries'][0]['rule_ids'][0]))
 copy_run('orphan_rule',lambda a,b,c:a['rule_index'].pop('BR-DOC-001'))
 copy_run('wrong_rule_owner',lambda a,b,c:a['rule_index']['BR-UND-002'].__setitem__('owner_id','BRS-003'))
 copy_run('wrong_numbering',lambda a,b,c:a['entries'][1].__setitem__('id','BRS-001'))
 copy_run('stale_rule_acceptance',lambda a,b,c:a['rule_index']['BR-UND-002'].__setitem__('acceptance_ids',[]))
 copy_run('tampered_normative_rule',lambda a,b,c:c.__setitem__('BRS-007',(root/'BRS-007-underweight-and-chargebacks.md').read_text().replace('0.011250','0.010000',1)))
 copy_run('floor_500_tier',lambda a,b,c:next(x for x in b['cases'] if x['material_net_lbs']=='37750').__setitem__('effective_rate_usd_per_lb','0.01'))
 copy_run('shortfall_multiplication',lambda a,b,c:next(x for x in b['cases'] if x['material_net_lbs']=='38000').__setitem__('total_usd','20.00'))
 copy_run('rate_rounded_too_soon',lambda a,b,c:next(x for x in b['cases'] if x['material_net_lbs']=='37501').__setitem__('total_usd','468.75'))
 copy_run('threshold_1999_charged',lambda a,b,c:next(x for x in b['cases'] if x['material_net_lbs']=='38001').__setitem__('effective_rate_usd_per_lb','0.009995'))
 copy_run('rate_zero_ignored',lambda a,b,c:next(x for x in b['cases'] if x['id']=='LWD-015').__setitem__('total_usd','380.00'))
 copy_run('contract_missing_ignored',lambda a,b,c:next(x for x in b['cases'] if x['id']=='LWD-016').__setitem__('total_usd','720.00'))
 return mutations

def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('root',nargs='?',type=Path,default=Path(__file__).resolve().parent)
 a.add_argument('--self-test',action='store_true')
 args=a.parse_args()
 try:
  report={'status':'PASS_BRS_LOCAL_DOCUMENTARY_ARITHMETIC_ONLY','validation':validate(args.root)}
  if args.self_test:report.update(negative_controls=negative_controls(args.root))
  print(json.dumps(report,indent=2))
  return 0
 except (OSError,ValueError,KeyError,json.JSONDecodeError) as exc:
  print(json.dumps({'status':'FAIL','error':str(exc)},indent=2))
  return 1
if __name__=='__main__':sys.exit(main())
