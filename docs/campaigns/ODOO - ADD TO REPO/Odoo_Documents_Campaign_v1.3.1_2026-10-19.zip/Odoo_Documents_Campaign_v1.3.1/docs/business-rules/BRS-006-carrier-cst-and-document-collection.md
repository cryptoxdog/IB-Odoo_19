# BRS-006: Carrier CST and Document Collection

**Status:** OPERATOR_ACCEPTED_POLICY / PROPOSED_REPOSITORY_ADMISSION
**Date:** 2026-10-19
**Deciders:** Scrap Management operator
**Scope:** Carrier certified evidence sufficiency, collection, nonblocking policy and $150 document chargeback
**ID:** `BRS-006` | **Version:** 1.0.1 | **Family index:** [`brs-documents@1.3.1`](README.md)
**ADR:** [`ADR-025`](../adr/ADR-025-business-rules-specification-authority.md) (operator-approved proposal, not merged)
**Owned rule IDs:** `BR-CST-001`, `BR-CAR-001`, `BR-CAR-002`, `BR-CAR-003`, `BR-CAR-004`, `BR-EVD-003`
**Related:** BRS-001, BRS-002, BRS-003, BRS-005, BRS-007

## Context

This BRS is the sole normative owner for its rule IDs. Other BRS files may reference those IDs but may not redefine their conditions, thresholds, terminology, eligibility or effects. Accepted rules are operator decisions, derived-safety rules require source-bound implementation evidence, and pending decisions are never auto-resolved. Source/architecture decisions are effective in this campaign only; repository admission, ORM changes, financial postings and actual runtime tests remain separate.

## 3. Document weight vocabulary boundary

**Normative measurement vocabulary, normalization and package arithmetic are owned only by [`BRS-003@1.0.1`](BRS-003-weights-and-packaging.md)**, including BR-VOC-001, BR-WGT-001..010, BR-CST-002 and BR-FLD-002. This file owns source-document classification and the carrier's certified document obligation. CST arithmetic quoted in descriptions is a reference to BR-CST-002, not a second owner of the formula.

### 3.1 Required carrier CST document (BR-CST-001)

**BR-CST-001 · ACCEPTED:** **CST expands to Certified Scale Ticket and is the required carrier ticket**, not a catch-all label for any SCALE-tagged source. **Supplier Scale Ticket** and **Buyer Scale Ticket** remain optional and **may not be certified**; never infer certified status from sender, filename, generic `scale_ticket` selection, `SCALE` tag, the existing **`CST` tag**, or the presence of numbers. Confirm certification and per-load issuer/source evidence before accepting a carrier CST as complete. A certified supplier or buyer ticket remains classified by its submitting party and is evaluated for independent scale eligibility under D13; its existence alone never satisfies the carrier-submission obligation. The existing CST-tag external ID is `plasticos_documents.tag_cst`, and its business code is `CST`; do not confuse tag presence with certification proof. The carrier must provide certified source evidence for each load, and invalid/noncertified carrier tickets remain captured but do **not** complete the CST requirement. [D03]

**CST completeness and material-net calculation are separate gates.** A certified CST can satisfy its carrier-document obligation without complete packaging evidence; the reference `scale_weight` material net requires source-supported packaging normalization. Neither event grants commercial settlement authority.

## 6. Carrier document accountability and penalty (BR-CAR-001 through BR-CAR-003)

**BR-CAR-001 · ACCEPTED:** Every load requires a **carrier-provided Certified Scale Ticket (CST)** establishing gross and net weighing evidence for that load. Validate certificate/issuer and same-load CST gross, CST tare and CST net arithmetic where evidenced; preserve the BR-CST-002 separate packaging-tare/net-weight-billed calculation. A single valid CST can provide the required observations. Supplier and buyer scale tickets are optional and **may not be certified**; neither automatically discharges the carrier's certified document obligation. A `SCALE` tag, numbers alone, or an uncertified generic carrier ticket does **not** establish CST completeness. Missing or incomplete required CST evidence remains an outstanding carrier obligation; invoice/ordinary RWN documentary gates are unaffected. **Missing packaging data alone does not make otherwise valid certified CST gross/net evidence missing or incomplete and cannot by itself trigger the carrier $150 penalty.** It holds only the calculation that needs that packaging data.

**BR-CAR-002 · ACCEPTED:** The carrier scale-document requirement is **nonblocking** for buyer full invoicing, the supplier RWN *as a document-compliance gate*, and normal commercial close. A separate RWN above-5% discrepancy case may nevertheless require valid scale measurement as a factual settlement condition. Keep carrier collection and overdue obligations alive after close; never mark a missing ticket received because a penalty was assessed.

**BR-CAR-003 · ACCEPTED amount, OPEN mechanics D01/D03/D04/D05:** Missing/incomplete **certified carrier CST** evidence incurs **$150 chargeback to the carrier** under the approved applicability/deadline rules. The event unit, due clock/grace, evidence sufficiency and late-receipt reversal/accounting mechanism are not yet independently approved. The recommended one $150 event per qualifying load/carrier is a **proposal**, not an admitted repeat policy. Do not charge the supplier/buyer, silently debit a paid bill, count margin twice or fabricate a claim recovery as cleared cash.

## Independent document obligation and collection evidence

**BR-EVD-003 · ACCEPTED:** Track per-party document obligations and received/verified/current/incomplete/overdue independently of the commercial invoice/notice action. Supplier PL may be missing while its weight comes from another source; carrier **Certified Scale Ticket (CST)** remains due even after Customer Invoice and commercial close. Existing document rules/validation matrices must express operation-specific blocking truth without turning optional supplier scale tickets into a compliance requirement. The historical $300 CST amount is superseded by the accepted $150 amount. Certified CST completeness additionally requires the verified certification and component evidence in BR-CST-001/002.

**BR-CAR-004 · DERIVED SAFETY:** The existing PlasticOS `CST` tag and existing `SCALE` tag are different identities. The carrier CST requirement and reminder must be scoped to carrier certification, correct load, and gross/net sufficiency; the current generic `SCALE` tag, generic doc_type=scale_ticket, and a tagged empty document cannot satisfy it. Compliance rules and AR/close checks are operation-specific: an outstanding carrier CST may trigger collection and an authorized $150 chargeback but cannot force customer invoice or normal commercial close to wait.

The $150 missing-CST obligation is **distinct from** any separately applicable light-weight deduction. Carrier CST evidence remains collectable after buyer invoice and normal commercial close. D01/D03/D04/D05 remain bounded action-specific implementation/financial decisions; do not invent deadlines, one-event repetition, waivers or automatic cash recoveries.

## Consequences and implementation boundary

- Every change to these rules is reviewed by the operator, revisioned with the owning BRS and traced through [`index.json`](index.json), the campaign requirements and observable test receipts.
- Exact installed Odoo 19 registry, existing code ownership and native accounting/approval workflows govern technical realization. **No new ORM fields, native document type values, financial ledger, parallel validator workflow or independent DMS is authorized by this BRS.**
- Unknown input, uncertified evidence, wrong party, wrong source revision or missing contract blocks the *affected* derived value or financial action, not unrelated document capture or eligible buyer invoicing.

## Compliance and References

**Rule ownership:** `BR-CST-001`, `BR-CAR-001`, `BR-CAR-002`, `BR-CAR-003`, `BR-CAR-004`, `BR-EVD-003`. Use [`README.md`](README.md) for BRS number lookup, [`index.json`](index.json) for machine-consumable rule ownership and [`TRACEABILITY.md`](TRACEABILITY.md) for acceptance coverage. The campaign's `campaign.json`, `ACCEPTANCE.md` and `FIELD_ROUTING_AND_CONFORMANCE.md` are derived planning/testing artifacts, **not competing normative authority**.

**Source binding:** proposed ADR-025, pinned `cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and exact preserved original instructions in `source_inputs/` inside this pack. Runtime execution **NOT_RUN**. No target repository mutation.
