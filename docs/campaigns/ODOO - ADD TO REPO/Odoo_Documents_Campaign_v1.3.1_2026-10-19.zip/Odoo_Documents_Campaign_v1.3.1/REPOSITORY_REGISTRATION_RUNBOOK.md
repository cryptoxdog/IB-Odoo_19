# Repository Registration Runbook: Numbered Business Rule Specifications

**Status:** PLAN / NOT EXECUTED. Target: `cryptoxdog/IB-Odoo_19`, integration base `Staging`. This pack does not change the repository, CI, database or deployment. Follow the exact SHA-locked source->target file inventory in `REGISTRATION_MANIFEST.json`; do **not** interpret it as authorization to publish. Odoo uses its own existing publication plumbing, not a generic external `make pr --SSOT` assumption.

## A. Preflight and integrity (read-only)

1. Resolve current `origin/Staging` HEAD, working PR branch, module installation and local ADR state. Historical checked HEAD is `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`; do not assume still current. Inspect `AGENTS.md`, `CLAUDE.md`, `ARCHITECTURE.md`, `INVARIANTS.md`, `docs/adr/README.md`, `docs/README_INDEX.md`, `.github/workflows/ci.yml`, and the actual CI/static-checks owner.
2. Verify all archive and `SHA256SUMS.json` digests, `REGISTRATION_MANIFEST.json` source copies, numbered `BRS-NNN` headings and each BRS `sha256` in `docs/business-rules/index.json`. Preserve original v1.3.0 ZIP and historical source inputs. Any unexpected original diff or target path collision is an explicit STOP for the affected file.
3. Inspect `docs/adr/` for existing ADR-025 or numbered collisions. The pinned Staging index presently reaches ADR-021 and the campaign identifies local, unverified ADR-022/023 work. Do **not** overwrite an ADR or assume the next numeric ID. Reconcile collisions with the operator/repo owner before admission.
4. Inspect for existing `docs/business-rules/` paths, any separately operating BRS index/registry or agent dispatch mechanism, as well as the target's current `ci-gate-result` and `static-checks` structure. No second BRS rules engine, CI workflow, generic rule dispatcher, database model or schema addition.

## B. Apply minimal proposed policy-file changes (only when separately authorized)

1. Copy only the 13 exact source files listed in the manifest: ADR-025; seven `BRS-001`..`BRS-007`; BRS `README.md`, `index.json`, `TRACEABILITY.md`, `check_brs.py`, and the LWD fixture. Preserve exact relative paths/hashes. Maintain stable existing 46 `BR-*` rule IDs; the machine index is derived and not a second normative BRS. Avoid legacy unnumbered `brs-documents.md` as a competing authority.
2. Register ADR-025 in **existing** `docs/adr/README.md` with its full filename and proper current admission status. Update the ADR links in **existing** `ARCHITECTURE.md` and `docs/README_INDEX.md`; do not add broad duplicate policy text. In `AGENTS.md`, add one routing link to indexed `docs/business-rules/README.md` for Documents weight, scale, settlement, invoicing and chargeback tasks; agents must read the normative owner by stable `BR-*` ID and exact BRS revision.
3. In `.github/workflows/ci.yml`, inside the existing `static-checks` job and its `run_check` function context, add one blocking invocation:

```bash
run_check "Numbered BRS contract" python3 docs/business-rules/check_brs.py docs/business-rules --self-test
```

Do not create a new CI job/workflow, disable an existing check or bypass `ci-gate-result`. This is pure standard-library Python and does not require Odoo installed. Read the live workflow and `ci/check_github_actions_kernel.sh` before any modification; placement is illustrative until locally verified.
4. The BRS checker is a **documentary/Decimal arithmetic** prevention gate only; it does not verify actual application conformance to all 46 rules. Bind each affected `T###` case to a real Odoo test function, fixture and specific owner; run unit/pure semantic tests locally as appropriate, then ORM/mail/accounting/company-security/Odoo Enterprise tests in an isolated disposable Odoo database. Keep outbound email and finance posting intercepted in tests. Do not assert runtime green for an uncollected or skipped suite.

## C. Mandatory cross-file acceptance before publication

- Numeric case boundaries: material net 38,001=>0; 38,000=>380; 37,750=>424.69; 37,501=>468.57; 37,500=>468.75; 36,000=>720; explicit zero rate=>0. Continuous 500-lb partial proration; whole material-net multiplication; only final USD rounding.
- Source evidence: CST gross-CST tare is *load net*, CST net-packaging is reference *material net*; a raw document number labeled “net” is not accepted material net by that label alone. Two independent packaging-source claims cannot be forced to agree.
- Financial boundaries: supplier `supplier_weight` drives normal RWN, buyer RR `buyer_weight` drives full Customer Invoice; certified `scale_weight` remains a reference, never automatic billable weight. Direct supplier/buyer >5% invokes human review even if both are within 5% of CST. Denominator remains D13.
- RWN timing: Buyer RR is mandatory for full Customer Invoice. Its absence is **NOT proven** to universally forbid supplier RWN; D18 must remain open and auto-send held until accepted sequencing. A draft with source-backed supplier quantity is not consent to send.
- Documentation: Carrier-certified CST per load gross/net required but missing CST alone cannot block ordinary RWN, buyer AR, or normal commercial close. Missing packaging does not make certified CST missing or trigger $150 penalty. Carrier penalty timing/one event/native accounting D01/D03/D04/D05 bounded.
- ORM: Do not create `shipper_weight`, `received_weight`, `supplier.weight.net`, `stated_net_lbs`, `packaging_included`, `material_net_weight` or universal replacement for `final_weight`. `light_weight_deduction_weight` is non-ORM calculated output. `light_weight_deduction_total` and `_compute_light_weight_deduction_total()` are PROPOSED replacement names requiring a migration, not declared installed fields.
- Account: Buyer underweight liability and supplier recovery are distinct obligations, not one mirrored automatic charge. LWD monetary total does not prove a posted credit, customer payable, supplier receivable, offset, payment or margin recovery.
- Consumer census before retiring `final_weight`, `gross_weight` selected-source usage, `weight_source`, `dead_freight_chargeback`: transaction computations, deduction, transaction view, sales dashboard SQL/view, historic columns, tests, native purchase/sale/accounting/inherited views. Remove only after migration/zero-regression proof.

## D. Negative calibration and receipt

- Execute the exact copied `docs/business-rules/check_brs.py` against index and fixtures with `--self-test`; record stdout, code SHA, target HEAD and exit status. Its negative controls include *coherently updated SHA with illegally changed policy meaning*, floor-tier LWD, shortfall-times-rate, premature rounding, duplicate owner and missing supplier-notice unknown.
- Verify registered CI actually calls the checker in `static-checks` and that the gate aggregate fails on injected known-bad BRS content; confirm known-good remains green. A package validator's success is NOT evidence of installed GitHub Actions enforcement.
- Run only relevant nonduplicated Odoo proof on a fully specified disposable, Enterprise-equivalent database; distinguish loaded vs executed vs PASS, verify inherited view resolution and installed field selections, no alias/provider invented.
- Do not publish, merge, deploy or auto-send on the authority of this runbook. When target-local contracts allow a publication and the operator authorizes it, use only the actual Odoo repo's publishing plumbing, target base `origin/Staging`, and its verified command surface.

## E. Operator-facing handoff

Return exact Staging SHA and source/destination file digest inventory, ADR/BRS registration diff, current CI gate insertion and real run receipts, technical field-consumer census, failing known-bad calibration receipts, unresolved decisions D13/D15/D16/D18 and remaining Docs integration gaps. Keep historical precedent archived and source decisions separate from in-repo accepted statuses. **No claim of merge readiness or business policy enforcement without independent target execution.**
