# Sources, Policy Decisions, Gaps and Field Ownership

**Version:** 1.3.1 | **BRS:** brs-documents@1.3.1 | **Status:** package specification, not executed Odoo software.

**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed.** Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. Missing packaging alone is not missing CST.

## Evidence boundary and lineage

Source code and official Odoo citations below are inherited from the predecessor at pinned Staging 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e. The pinned Staging declarations were verified earlier in this campaign, not installed Enterprise runtime; U07 is the latest accepted numeric-proration and numbered BRS instruction; U06 physical vocabulary and prior source statements remain exact protected history. D17 pure mathematics is resolved; D16 contract and posting remain open. Original historical source_inputs, including the file named LATEST_OPERATOR_INSTRUCTION.txt, remain unchanged historical evidence rather than current execution instructions. The predecessor archive SHA-256 is `922a545e59a2cb0e7353c6e25bc14f39f3bd0cb63a1523611a98772be4ff01a2`.

## Source register

| ID | Source | Evidence status | Locator | Meaning/limit |
|---|---|---|---|---|
| U01 | Latest operator objective and document rules | CURRENT_EXPLICIT_INTENT | source_inputs/LATEST_OPERATOR_INSTRUCTION.txt | Substantive transcription of the current request; not an original chat export. |
| P01 | User starting plan | EXACT_BYTES_PRESERVED | source_inputs/document_transaction_match_3a3f9d7d.plan.md | SHA-256 5d69e3d5f9efea48ed96885b6200dc2c5b32377679bc4291635a5278eea3a4d1; reported local ADR commits are not independently verified. |
| P02 | Prior revised intent development pack | EXACT_BYTES_PRESERVED | source_inputs/Odoo19_Documents_Revised_Intent_Dev_Pack_2026-10-18.zip | SHA-256 388ae55a8aa4843ff4d43a91cadde779312d27415a884f0fb4fcc2549f0a7ccd; predecessor is proposed, not an admitted repository law. |
| H01 | Dropbox v4 Documents blueprint and comprehensive specification | PRIOR_CONVERSATION_FETCH | https://www.dropbox.com/scl/fi/bnfey544y5p66n5f7p32r | Original discovery/fetch in this conversation; not fetched anew during this compilation. Do not treat May 6 Dropbox modified time as authoring/admission date. Details also retained in P02. |
| G01 | Staging revision | RECHECKED_2026_10_19 | https://api.github.com/repos/cryptoxdog/IB-Odoo_19/branches/Staging | Staging resolved to 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e. Runtime installation not proved. Historical observation retained from predecessor; no live GitHub re-resolution in v1.2.0. |
| G02 | Native semantics and permissions | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/CLAUDE.md | Principle 7 requires existing native/PlasticOS semantics and explicit approval for new fields. Ask-before surfaces include cron, base and security changes. Examples are not guessed execution commands. |
| G03 | ADR-021 native-first decision | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/docs/adr/ADR-021-erp-sql-crm-api-import.md | Decision 6 reinforces native-first placement; its SQL/CRM import scope is not a mandate to route incoming business documents through the historical importer. |
| G04 | External intelligence authority boundary | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/docs/adr/ADR-003-single-external-intelligence-authority.md | Buyer matching/partner enrichment remains external through Gate. Document reference resolution is a different concern; native document extraction must not resurrect retired engines. |
| G05 | Native bridge installation PR 265 | OPEN_NOT_MERGED_AT_CHECK | https://github.com/cryptoxdog/IB-Odoo_19/pull/265 | Head fca79680b8a6ac7d9ef237662571d57f1327f2da; base Staging 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e. Existing owner of installation flags/views. Metadata read is not PR correctness certification. |
| G06 | Penalty rule owner | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_automation/models/penalty_rule.py | documentation selection, fixed method, penalty_rate, partner_ids and grace_period_days exist. calculate_penalty handles weight_variance/late_delivery, not documentation. |
| G07 | Existing outbound mail templates | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_automation/data/email_templates.xml | Existing supplier/carrier and DO/BOL templates; visible DO content asks for light/heavy certified tickets; double-blind pickup text confirms disclosure concern. RWN existence not established by broad search. |
| G08 | Claim and freight recovery owner | READ_AT_PINNED_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_claims/models/claim.py | Existing case_type freight_chargeback, transaction_id, related load_id, currency_id, claimed_amount, recovery_amount, assignee and lifecycle. |
| G09 | Document model and retention | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/document.py | Attachment, tag, direct and polymorphic links; verified/override/current/active/superseded fields. Refer to code ranges and recheck closure before changes. |
| G10 | Compliance owner | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/compliance_service.py | Rule checks use model/record/tag and verified-or-override. Operation/party/current-version semantics need closure. Default active_test must not be overlooked. |
| G11 | Transaction weight/accounting owner | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_transaction/models/transaction.py | Separate supplier/buyer/scale weights; computed gross/final fields; bill relations; missing-to-compliant posting side effect; inspect exact consumer closure. |
| G12 | Load details and company owner | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/load.py | Company relates to SO; references, seal_number, trailer_number, dates, pickup/delivery partner, freight actions, double_blind. |
| G13 | Native synchronization owner | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents_native/models/document_sync.py | Sync and batch methods; preserves shared attachment but incomplete lifecycle/direct-link propagation at Staging. |
| G14 | Native document extension | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents_native/models/document_native.py | Native Many2one links, doc_type enum, verified/override; unsafe helper present at Staging. P01 says local branch neutralizes it, not verified here. |
| G15 | Document access grants | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/security/ir.model.access.csv | Broad internal CRUD grants exist; role-specific grants are additive. Effective runtime ACLs/record rules still require inspection. |
| G16 | Existing missing-document and scale-ticket rules | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/models/transaction_docs.py | Missing flags/cron, generic aging from creation, limit=300, role categorization and scale-ticket search; not new policy. |
| G17 | Scale close requirement seed | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/data/scale_ticket_rule.xml | SCALE required_for_close true, required_for_invoice false; existing 2/7 day settings not automatically new penalty deadline. |
| G18 | Accounting adjustments and posting seam | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_automation/models/account_move_penalty.py | Existing move.transaction_id, reconciliation fields and invoice adjustment. action_apply_adjustment sets applied and posts chatter; does not itself create a journal entry. |
| G19 | Native invoice-to-transaction bridge | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_transaction/models/account_move_inherit.py | Origin-string matching, pre-post compliance and post linkage; credit/cancel guards. |
| G20 | Seeded document tags | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_documents/data/document_tags_data.xml | BOL, INV, SCALE, PHOTO, PACKING, CO, RECEIVING, CST, DO, CONTRACT, CERT, PERMIT, LAB, CORR, CLAIM_PHOTO, OTHER. |
| G21 | Load/transaction cardinality | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/plasticos_logistics/models/transaction_inherit.py | One transaction.load_id and unique load_id constraint. Multi-load file is not permission to change load cardinality. |
| G22 | Repository law ownership | PRIOR_INSPECTION_SAME_IMMUTABLE_REVISION | https://github.com/cryptoxdog/IB-Odoo_19/blob/4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e/skills/PLASTICOS_CANONICAL_LAW.md | Repo owns its policies and skills, scopes version bumps; global policy source stays read-only. No mutation commands emitted by campaign. |
| N01 | Odoo 19 Documents | WEB_CHECKED_2026_10_19 | https://www.odoo.com/documentation/19.0/applications/productivity/documents.html | Aliases, body-only mail files, tags, linked records and accounting centralization. Describes capability, not this database. This page and N02 differ on whether the AI app itself is required. |
| N02 | Odoo 19 AI document sort | WEB_CHECKED_2026_10_19 | https://www.odoo.com/documentation/19.0/applications/productivity/ai/document_sort.html | Folder prompts and permitted actions. A To Split tag does not automatically split a PDF. Installed addon/action surface must decide dependencies. |
| N03 | Odoo 19 document digitization | WEB_CHECKED_2026_10_19 | https://www.odoo.com/documentation/19.0/applications/finance/accounting/vendor_bills/invoice_digitization.html | Native bill OCR, journal aliases, PO matching and vendor auto-post settings; do not assume native OCR is a general scale-ticket parser. |
| X01 | Starting branch visibility | NOT_RESOLVED | https://api.github.com/repos/cryptoxdog/IB-Odoo_19/git/ref/heads/feat/inbound-document-linking | Connector returned 404. Does not prove the local branch or local commits do not exist. Resolve locally before S01 execution. |
| U02 | Verbatim operator clarification and BRS approval (October 19, 2026) | CURRENT_EXPLICIT_BUSINESS_INTENT | source_inputs/OPERATOR_BRS_DECISIONS_2026-10-19.md | Supersedes older campaign statements about RWN using buyer_weight; accepts ADR-025/BRS, future logistics BRS deferred. |
| A25 | ADR-025 Business Rules Specification authority (pack candidate) | OPERATOR_APPROVED_DESIGN_REPOSITORY_NOT_ADMITTED | docs/adr/ADR-025-business-rules-specification-authority.md | Complete proposed ADR; repository root has not admitted it. |
| BRS01 | Indexed numbered Documents BRS authority family (non-normative routing metadata) | OPERATOR_CONFIRMED_SCOPED_UNKNOWNS_PROPOSED_REPO_ADOPTION | docs/business-rules/index.json | Seven individually numbered BRS concern files with 46 exact unique stable BR-* rule IDs. Human index README, machine index, traceability and dedicated CI validator; repository admission remains proposed. |
| U03 | Verbatim certified carrier CST and net billed formula operator clarification (October 19, 2026) | LATEST_EXPLICIT_BUSINESS_INTENT | source_inputs/OPERATOR_BRS_DECISIONS_2026-10-19.md | Carrier CST means Certified Scale Ticket. The two-step formula is preserved; U04 standardizes the intermediate term to CST tare. Original operator words are retained unchanged. |
| U04 | Operator CST tare terminology and whole-ZIP v1.1.1 correction | CURRENT_EXPLICIT_INTENT | source_inputs/OPERATOR_V111_CORRECTION.txt | Use CST tare consistently; review and repair the complete campaign archive. No repository or runtime execution grant. |
| U05 | Operator demand for complete field/source-weight routing and native field authority | CURRENT_EXPLICIT_INTENT | source_inputs/OPERATOR_FIELD_FLOW_INTENT_2026-10-19.txt | Requires comprehensive source-specific field contract, three measurement lanes, native financial consumption, and no invented ORM synonyms. Additional risk/architecture detail is DERIVED, not new business authorization. |
| G23 | Staging source census: field, scale compliance and native sync call sites | READ_ONLY_GITHUB_SOURCE_REVERIFIED_ON_2026_10_19_NOT_INSTALLED_RUNTIME | cryptoxdog/IB-Odoo_19@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e | Read-only verified: transaction.py, load.py, document.py, document_native.py, document_sync.py, document_tag data, scale_ticket_rule.xml, transaction_docs.py, account_move_inherit.py, commission sales_dashboard.py, native sale/purchase/account model declarations. Concrete owner/line coordinates in field-flow contract. Exact custom-source code observations are cross-referenced by field_registry[].source_path and technical field identity; blob refs of official native source are separately captured. |
| N04 | Official Odoo 19 model declarations and native Documents/Sales/Accounting documentation | PUBLIC_ODOO19_CODE_AND_DOCUMENTATION_READ_NOT_INSTALLED_ENTERPRISE_PROOF | odoo/odoo 19.0 source + odoo.com/documentation/19.0 | Verified standard sale.order.line, purchase.order.line, account.move and account.move.line quantity/price fields. Documents alias, AI sort, requests and vendor bill digitization documented. Enterprise installation and configured actions remain runtime unknown. Official source module blob SHA coordinates recorded in field_routing_contract.native_source_coordinates; Enterprise Documents installed fields remain UNKNOWN. |
| U06 | Operator-approved weight vocabulary, manual reconciliation and underweight obligation-scoped formula / technical naming | HISTORICAL_APPROVED_INTENT_SUPERSEDED_FOR_LWD_ARITHMETIC_BY_U07 | source_inputs/OPERATOR_WEIGHT_CONVERGENCE_2026-10-19.md | Historical 2026-10-19 approved vocabulary/weight semantics and provisional underweight formula. Most recent operator correction in U07 supersedes the former full-shortfall multiplied by a fixed rate. |
| BRS02 | BRS-003 Weights and Packaging | OPERATOR_ACCEPTED_BUSINESS_MEANING_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-003-weights-and-packaging.md | Accepted operator vocabulary, CST material-net reference and direct supplier/buyer discrepancy human review; no new ORM field authorized. |
| BRS03 | BRS-007 Underweight and Chargebacks | OPERATOR_ACCEPTED_CONTRACTUAL_CALCULATION_WITH_PROPOSED_ORM_MIGRATION | docs/business-rules/BRS-007-underweight-and-chargebacks.md | Accepted continuous partial-500-lb rate applied to actual material net with 2000-lb inclusive gate; D17 historical resolved, D16 contractual/financial implementation still open. |
| U07 | Current operator correction: continuously prorated LWD rate and numbered BRS authority | CURRENT_EXPLICIT_OPERATOR_APPROVAL; TRANSCRIPTION_NOT_AUTHENTICATED_CHAT_EXPORT | source_inputs/OPERATOR_BRS_NUMERIC_CONVERGENCE_2026-10-19.md | 2k lb inclusive shortfall; $0.01/lb per short ton/2,000 lb of shortfall, equivalent $0.0025/lb per 500 lb prorated for partial increments, effective rate applied to entire material net, cents rounded at end. BRS files individually numbered and indexed; no Odoo writes. |
| BRS04 | BRS-004 Supplier Settlement and RWN | OPERATOR_ACCEPTED_POLICY_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-004-supplier-settlement-and-rwn.md | Independent supplier notice; direct commercial discrepancy human resolution; scale reference only. |
| BRS05 | BRS-005 Buyer Receiving and Customer Invoicing | OPERATOR_ACCEPTED_POLICY_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-005-buyer-receiving-and-invoicing.md | Accepted buyer material net and native invoice-line evidence with required Receiving Report. |
| BRS06 | BRS-006 Carrier CST and Document Collection | OPERATOR_ACCEPTED_POLICY_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-006-carrier-cst-and-document-collection.md | Separate mandatory carrier CST obligation and $150 document penalty only when due/financial rules are established. |
| BRS07 | BRS-002 Document Evidence and Control | OPERATOR_ACCEPTED_POLICY_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-002-document-evidence-and-control.md | Source evidence, original attachment, source provenance and exact safe association. |
| BRS08 | BRS-001 Document Classes and Native Identity | OPERATOR_ACCEPTED_POLICY_PENDING_REPOSITORY_ADMISSION | docs/business-rules/BRS-001-document-classes-and-identity.md | Document names, issuer and direction, current Odoo field/selection identities. |

## Policy delta and supersession

| ID | Topic | Predecessor | Disposition | Current instruction |
|---|---|---|---|---|
| POL01 | Original plan remains the opening slice | P01/U01 | PRESERVED | Original file is byte-preserved; completed local work needs exact evidence, not recreation. |
| POL02 | Sender majority rule | P01 line 99 | REQUIRES_SUCCESSOR_CORRECTION | Counts cannot authorize cross-company/party filing. S04 validates each logical-document match; no unsafe live activation first. |
| POL03 | Dropped citation deletes row | P01 line 109 | NARROW_SAFETY_GUARD | Do not destroy evidence; retain/archive/supersede under existing lifecycle. Record the original instruction as history. |
| POL04 | Supplier PL and supplier weight absent | H01/P02 ambiguities versus U01 | SPLIT_DOCUMENT_NONBLOCKER_FROM_SETTLEMENT_FACT | Supplier PL absent never blocks RWN or Customer Invoice by itself. Supplier weight missing does not block Customer Invoice, but holds supplier RWN quantity absent an approved D14 fallback; never fabricate payable weight. BRS BR-SET-004/BR-REC-002. |
| POL05 | Supplier RWN wrongly selected from buyer receiving weight in v1 campaign | P01 lines 127-133 versus U01 | SUPERSEDED_BY_OPERATOR_BRS | RWN normally confirms supplier_weight, supplier price and valid deductions. Only a strictly >5% supplier/buyer discrepancy with eligible scale evidence permits scale_weight under D13. Receiving Report remains inbound buyer evidence; Customer Invoice uses buyer_weight. BR-SET-001..005. |
| POL06 | Any SCALE document completes requirement | P01 line 139/G17 versus U01 | SUPERSEDED_FOR_SCALE_COMPLETENESS | Both gross and net evidence required per load; a lone light ticket can be received but incomplete. |
| POL07 | Carrier scale documents block buyer financial release | Earlier broad completeness interpretation versus U01 | EXPLICITLY_REJECTED | Outstanding scale obligation/penalty lane is independent of RWN/AR; normal commercial close also remains nonblocking; collection and penalty obligations survive close. |
| POL08 | Historical USD 300 CST penalty | Historical v4 narrative versus U01 | SUPERSEDED | USD 150 carrier penalty; no use of 300. Deadline/one-event/reversal rules must be bound. |
| POL09 | Only non-party sender can be trusted scale source | P01 lines 103,124-125 | SUCCESSOR_SOURCE_TRUST_REVIEW | Issuer and source chain establish measurement; transporter does not establish certification. Receipt obligation and scalar write authority separate. |
| POL10 | OCR always even for machine-readable content | H01 versus minimum realization | IMPLEMENTATION_EVOLUTION_PROPOSED | Read content first; use native text/XML/cell extraction where reliable, OCR when needed; preserve original content-first intent. |
| POL11 | Physical eighteen folders and old sm.transaction/x_ fields | H01 versus G02/G03 | SEMANTICS_PRESERVED_IMPLEMENTATION_EVOLVED | Native records/tags/views satisfy single original and role dossiers; no forced obsolete schema or empty folder bureaucracy. |
| POL12 | Inactive docs automatically satisfy compliance | Earlier audit F04 | PRIOR_CLAIM_NARROWED | Odoo default active_test excludes archived records. Current-version filtering and overridden context still require tests; do not repeat unsupported inactive claim. |
| POL13 | Generic full Documents implementation now | Prior over-expansion rejected by user | REJECTED_FOR_S01 | Keep successor slices and hard safety ceiling; no twelve-item rewrite appended to original plan. |
| POL14 | Business aliases versus exact existing Odoo field names | User colloquial label and P01 terminology | BRS_FIELD_AUTHORITY | supplier_weight, buyer_weight, scale_weight remain existing PlasticOS technical fields; never create shipper_weight/received_weight/purchase_weight or universal net_weight; authentic source prose and RWN title are allowed. BR-FLD-001..003. |
| POL15 | Inbound buyer Receiving Report vs outbound supplier RWN | v1 campaign notice origin and user correction U02 | OPERATOR_CLARIFICATION | Receiving Report (buyer -> us) maps received net to buyer_weight and gates full Customer Invoice. Received Weight Notice (us -> supplier) reports selected supplier settlement quantity, supplier price and approved deductions. BR-DOC-001,BR-SET-001,BR-REC-001. |
| POL16 | PL packaging evidence and tare | User explicit 40/40/80 rule U02 | OPERATOR_CLARIFICATION | Supplier PL and buyer Receiving Report may state count/weights; Gaylord 40 lb, pallet 40 lb, Gaylord on pallet 80 lb when not already net. Box/mixed forms pending D15. BR-WGT-002..004. |
| POL17 | Supplier vs carrier vs buyer scale documents | User explicit optionality and carrier requirement U02 | OPERATOR_CLARIFICATION | Supplier and buyer scale tickets optional, even supplier-requested nearby scale; carrier scale gross+net mandatory per load and nonblocking for AR/close. Scale eligibility for supplier settlement remains D13. BR-DOC-001,BR-CAR-001..003. |
| POL18 | One BRS authority, future logistics BRS | User accepts proposal and ADR-025 U02 | OPERATOR_APPROVED_ARCHITECTURE_CANDIDATE | ADR-025 explains BRS authority; brs-documents is normative for document business decisions; future brs-logistics is deferred/not created. All campaign projections bind BRS IDs. |
| POL19 | Universal Final Weight and gross semantic drift | Current code G11 and user correction U02 | RETIRED_AS_SETTLEMENT_AUTHORITY_COMPATIBILITY_PENDING | No global final_weight winner or reinterpretation of computed gross_weight as measured CST gross. Keep technical fields until downstream ledger/deduction/dashboard consumers are proven and corrected. BR-FLD-002. |
| POL20 | Inconsistent CST intermediate vocabulary across BRS, policies, cases and prose | Inconsistent CST intermediate vocabulary across BRS, policies, cases and prose | SUPERSEDED_BY_U04 | CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed. Source wording remains authentic only in immutable source_inputs; no technical field is added. |
| POL21 | Bare net label treated as packaging-excluded; missing packaging confused with missing certified evidence | Bare net label treated as packaging-excluded; missing packaging confused with missing certified evidence | CLARIFIED_WITHIN_BR_CST_002_AND_BR_CAR_001 | CST net always denotes CST gross minus CST tare. A clearly packaging-excluded source amount is net weight billed, not a redefinition of CST net. Unknown packaging does not by itself invalidate CST receipt or assess a $150 penalty. |
| POL22 | Old fixed shortfall-times-rate and completed-500 rate steps | v1.2.1 D17 OPEN, historical operator $200/$400 examples, subsequent 500-lb completed-tier recommendation | SUPERSEDED_BY_CURRENT_OPERATOR_CONTINUOUS_PRORATION | BRS-007 BR-UND-002: 2000-lb inclusive trigger; effective rate 0.01*(shortfall/2000) USD/lb including partial 500 increments, applied to entire actual material net, final cents only. At 36000 lb total 720; 37750 lb total 424.69. D17 resolved; financial terms still D16. |
| POL23 | Single unnumbered BRS Documents document and old unnumbered siblings | v1.2.1 README.md + BRS-003-weights-and-packaging.md + BRS-007-underweight-and-chargebacks.md | SUPERSEDED_BY_NUMBERED_ONE_CONCERN_PER_BRS | docs/business-rules/BRS-001..BRS-007 individually indexed in README.md/index.json; preserve all 46 stable BR-* IDs exactly once, map rules to requirements/tests, validate mechanical drift and negative controls; source original exists in SHA-pinned predecessor ZIP. |
| POL24 | RWN buyer Receiving Report prerequisite misclassified as accepted | v1.3.0 BRS-004 RWN table / C31 blanket buyer report gate | UNSUPPORTED_INFERENCE_RESCOPED_D18 | Buyer Receiving Report mandatory only for FULL buyer invoice; use for comparison when present. RWN draft can be based on supplier evidence; automatic send without buyer report is a bounded policy UNKNOWN D18, not a fabricated universal prerequisite. |
| POL25 | Unverified document net source fact treated as material net | S_STATED_NET/B_STATED_NET and source fact proposed ORM destinations | SEMANTIC_CORRECTION_NO_NEW_FIELD | S_DOCUMENT_NET/B_DOCUMENT_NET raw evidence concepts not automatically material net; require explicit physical basis and packaging proof before accepted supplier_weight/buyer_weight write. |

## Bounded decisions, not global blockers

### D01. Carrier penalty clock

**Evidence/basis:** U01 fixes amount, but not accrual event, elapsed/calendar/business days, deadline timezone, grace or notice requirement. Historical 6/7-day values conflict.

**Owner:** Operator with logistics owner

**Referencing slices:** S09

**Safe behavior:** No automatic assessment/posting until eligibility time is confirmed. Receipt tracking and Customer Invoice proceed.

**Remaining resolution:** Choose trigger and due rule; record effective date and applicable loads.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D02. Supplier purchase terms, notice deductions and AP accounting application

**Evidence/basis:** Normal supplier Weight RWN and purchase terms; >5% direct supplier/buyer discrepancy now requires human review, scale_weight reference-only. Approved underweight formula is separately owned by BR-UND-001..007; financial authority remains contract-controlled.

**Owner:** Operator with purchasing/accounting owner

**Referencing slices:** S06; S10

**Safe behavior:** Normal RWN may use accepted supplier_weight, price and authorized supplier-side deductions. For >5% dispute hold RWN supplier adjustment until human review; no automatic scale substitution; buyer Invoice remains independent.

**Remaining resolution:** Verify accepted supplier purchase terms, obligation-specific supplier recovery and native AP financial application. Scale remains reference-only; follow BRS underweight formula, do not duplicate it.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Approved normal RWN quantity and Customer Invoice can be prepared; unresolved purchase price/deductions hold only affected RWN financial content or AP posting.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D03. CST evidence-form sufficiency, not the confirmed arithmetic

**Evidence/basis:** Certified carrier CST and the formula CST gross - CST tare = CST net; CST net - packaging tare = net weight billed are confirmed. Only ticket-form/source sufficiency and whether multiple documented readings fulfill the carrier gross/net requirement remain unresolved.

**Owner:** Operator with logistics owner

**Referencing slices:** S05; S08; S09

**Safe behavior:** Validate available CST gross/CST tare/CST net evidence. Missing packaging information does not invalidate an otherwise complete carrier CST or trigger its penalty. Hold only the unsupported derived billed-net calculation or disputed evidence-form decision.

**Remaining resolution:** Bind accepted certification and per-load ticket forms/pair provenance. Do not reconfirm CST terminology, the arithmetic, optional supplier/buyer scales or the $150 amount.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** S05 can read and retain all source facts; only disputed CST obligation sufficiency in S08 and its S09 penalty action require this decision. S05 buyer_weight and Customer Invoice readiness remain independent.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D04. Penalty unit and late evidence

**Evidence/basis:** Recommended interpretation: one USD 150 event per load and carrier for incomplete scale evidence, not 150 for each missing number or daily repeat. Late receipt waiver/reversal not specified.

**Owner:** Operator with accounting owner

**Referencing slices:** S09

**Safe behavior:** No multiplication, recurrence, waiver or reversal is invented. One pending case can preserve intent; final action waits for this rule.

**Remaining resolution:** Confirm per-load unit, applicable carrier terms, late receipt/dispute/reversal treatment.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D05. Native financial realization

**Evidence/basis:** A chargeback may reduce an unpaid carrier bill through a native vendor credit/authorized adjustment; already paid bills and agreed carrier debits need explicit treatment.

**Owner:** Accounting owner

**Referencing slices:** S09; S10

**Safe behavior:** No manufactured vendor-issued document; no silent payment reduction or bank movement.

**Remaining resolution:** Select supported account.move mechanism, account/tax/company/currency, references and economic-once margin treatment.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D06. Accepted extraction/evidence host

**Evidence/basis:** ai_documents/provider/version/settings, extraction action signatures, usable evidence persistence, OCR credits and allowed outbound access are runtime unknown.

**Owner:** Odoo implementation owner

**Referencing slices:** S00; S03; S12

**Safe behavior:** No native provider dependency or new external service assumed. Supported native adapter first; narrow proven gap only.

**Remaining resolution:** Inventory installed registry and action surface; prove extracted field evidence against samples.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D07. Buyer Receiving Report acceptance

**Evidence/basis:** Report is mandatory. Accepted layouts, receipt confirmations embedded in email, required signature and partial delivery thresholds are not explicitly settled.

**Owner:** Operator with sales/logistics owner

**Referencing slices:** S05; S06; S07

**Safe behavior:** Conservative final gate: identifiable buyer Receiving Report with explicit net/unit/load; body-only messages require equivalent accepted evidence, not a filename guess.

**Remaining resolution:** Bind representative accepted reports, legitimate sender contacts and partial-load handling.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D08. New fields or models

**Evidence/basis:** P01 forbids new fields/models/selection values in opening slice; G02/G03 require explicit approval elsewhere. Native records may lack usable idempotency or multi-obligation evidence links.

**Owner:** Operator with authoritative model owner

**Referencing slices:** S02; S03; S04; S05; S11

**Safe behavior:** First prove existing-field/attachment/activity realization; otherwise expose minimum representation gap without overloading existing fields.

**Remaining resolution:** Resolve exact gap, owner, smallest delta and approval before any schema addition.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Only additions to technical schema need D08 approval; all existing/native field work continues.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D09. Reminder channels and schedule

**Evidence/basis:** Original business specification retains pickup+1 supplier, pickup+2 carrier and delivery+1 buyer collection starts, daily authorized email/SMS alternation, and 5/6/5-business-day manager escalation. Confirm actual calendar/recipient/provider configuration and resolve any source conflict without silently replacing approved collection policy. Collection timing is not the carrier penalty deadline.

**Owner:** Operator with operations owner

**Referencing slices:** S08

**Safe behavior:** No actual messages during campaign compilation; missing SMS must not disappear or block AR.

**Remaining resolution:** Verify channel authorization, recipient resolution, holiday calendar, stop/escalation rules and failure fallback.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D10. Closed transactions and corrections

**Evidence/basis:** P01 allows filing on non-cancelled transactions; current closed financial guards may forbid later adjustments. U01 does not authorize historical mass rewrites.

**Owner:** Operator with accounting owner

**Referencing slices:** S07; S08; S09; S10

**Safe behavior:** Evidence may be appended safely; financial correction uses approved native lifecycle, never reopening or bypassing guards silently.

**Remaining resolution:** Resolve narrow late correction route and any minimum closure-policy change.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D11. Sent-state ambiguity

**Evidence/basis:** Native queued/sent mail and external delivery acknowledgments are not identical. Retry after an ambiguous timeout can duplicate a notice or invoice.

**Owner:** Messaging owner

**Referencing slices:** S06; S07; S09; S12

**Safe behavior:** Use existing queue and durable outbound identity; ambiguous transport outcome is an exception, not unconditional resend.

**Remaining resolution:** Prove native queue retention, retry boundaries, recipient checks and dedupe receipt.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D12. First-slice branch and ADR status

**Evidence/basis:** P01 reports b57ce21/7a92cd9 and accepted ADR-022/023. Remote feature ref was not resolved.

**Owner:** Current coding agent with operator

**Referencing slices:** S00; S01

**Safe behavior:** Keep P01 bytes; do not recreate ADRs or declare work complete.

**Remaining resolution:** Inspect local branch, full SHAs, ADR text, current diff and actual test receipts before successor edits.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D13. Review denominator, CST corroboration and human decision evidence (NO automatic scale settlement)

**Evidence/basis:** Operator now confirms reference-only scale and human review for >5% direct supplier/buyer spread; previous automatic scale substitution is superseded. Current code uses max denominator but exact commercial denominator/rounding and review authority need operator admission.

**Owner:** Operator with purchasing and evidence-validation owner

**Referencing slices:** S05; S06; S10

**Safe behavior:** Direct supplier_weight versus buyer_weight >5% triggers mandatory human reconciliation regardless of both values being near CST. Retain scale_weight as reference only; no automatic RWN/AP substitution. Normal supplier RWN and independent buyer invoice remain functional; disputed supplier RWN held until human decision.

**Remaining resolution:** Approve denominator/rounding, source evidence admissibility and human decision record/escalation; specify authorized correction workflow instead of a scale override.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Only greater-than-5% supplier settlement adjudication and automatic dispute closure are held. No other buyer invoicing, normal RWN, CST capture or collection is blocked.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D14. Supplier RWN when supplier weight missing

**Evidence/basis:** No approved supplier-weight-absent fallback; earlier campaign incorrectly promised an RWN solely from buyer Receiving Report.

**Owner:** Operator with purchasing owner

**Referencing slices:** S05; S06

**Safe behavior:** Hold supplier notice quantity/send if no accepted supplier_weight or other expressly approved payable basis. Customer Invoice remains eligible independently. Supplier PL is tracked where applicable, not itself a billing blocker.

**Remaining resolution:** Specify if any contract-supported fallback exists and required recipient/amount wording; absent approval use conservative hold.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** This decision gates only its described consequential action, not all work in every referencing slice.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D15. Mixed packaging and unapproved box tare

**Evidence/basis:** Gaylord=40, pallet=40, Gaylord-on-pallet=80 explicitly accepted; box tare, mixed line package counts, and source net-of-packaging interpretation are not fully specified.

**Owner:** Operator with transaction/receiving owner

**Referencing slices:** S05; S06; S08; S09; S10; S11

**Safe behavior:** Compute approved 40/40/80 only for the actual evidenced packages and side of the transaction. A bare net label does not prove packaging excluded. Preserve unsupported mixed/box amounts as unknown, not zero. Do not penalize the carrier solely because PL/Receiving Report packaging data is missing.

**Remaining resolution:** Determine box/super sack/custom tare rules and needed existing line-level representation, source gross-vs-net packaging treatment.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Hold only the calculation depending on unknown packaging or its unrepresented mixed inputs. An otherwise complete certified CST remains received/complete; independently established buyer_weight and Customer Invoice remain eligible.

**Reference meaning:** Consult only for the specific action named in blocker_scoping; membership is not a whole-slice gate.


### D16. Underweight contract assignment and two-party liability/recovery realization

**Evidence/basis:** Operator-approved BR-UND-002 now fixes the exact continuously prorated arithmetic; D17 historical rate contradiction is resolved. D16 remains for the applicable PO/SO/freight contracts, liable/beneficiary parties, correction/recovery authority, accounting treatment and separate effects.

**Owner:** Operator with existing Sales, Purchase, Claims and Accounting owners

**Referencing slices:** S05; S06; S07; S09; S10; S12

**Safe behavior:** Pure accepted rate/threshold arithmetic may be calculated and tested; no monetary assessment/posting, supplier recovery, buyer liability or cross-party mirroring without applicable contract and native financial authorization. Preserve the display-only CST reference separation.

**Remaining resolution:** Bind supplier/buyer/freight contract, applicable 53-foot minimum and $0.01 base-per-2000 shortfall rate, responsible/beneficiary partner, effective terms and native accounting/claims lifecycle. No invented field or parallel engine.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Only automatic underweight assessment, party attribution, claim/credit posting or per-obligation live Odoo computed field realization is gated; calculation tests and document workflows continue.

**Reference meaning:** Reference does not block entire slice or create an obligation by implication.


### D17. RESOLVED: light-weight rate proration and previously contradictory dollar examples

**Evidence/basis:** Original operator wording and dollar examples were arithmetically inconsistent. Subsequent operator corrections fixed a 40000 lb 53-foot minimum, 2000 lb inclusive trigger, $0.01/lb per 2000 lb shortfall, applied to actual material net; continuous $0.0025/lb per 500 lb, INCLUDING partial increments, with final-cent rounding. Old $200/$400 examples and completed-500 step proposal are superseded.

**Owner:** Operator with Sales, Purchase and Accounting contract owners

**Referencing slices:** 

**Safe behavior:** Use the approved pure prorated calculation for accepted applicable contracts; do not equate a calculated amount with buyer/supplier liability or authorize financial posting, which remains D16/native-accounting-gated.

**Remaining resolution:** RESOLVED by explicit operator on 2026-10-19. BRS-007 BR-UND-002 is sole normative formula owner. Golden boundary vectors include 38001 -> 0, 38000 -> 380, 37750 -> 424.69, 37501 -> 468.57, 37500 -> 468.75, 36000 -> 720.

**Status:** RESOLVED_OPERATOR_2026_10_19

**Action-specific blocking scope:** NO_ACTIVE_BLOCKER. Previously unresolved monetary arithmetic is now accepted, but no automatic financial assessment/posting is authorized without D16 contract and native proof.

**Reference meaning:** Historical supersession only; D17 is NOT an action blocker. D16 governs contracts, liability, recoveries, posting.


### D18. Supplier RWN sending sequence when buyer Receiving Report has not arrived

**Evidence/basis:** Operator explicitly requires Buyer Receiving Report for full Customer Invoice and independently defines supplier RWN normally on supplier_weight. No explicit operator decision requires buyer Receiving Report for every supplier RWN send; predecessor projected an unapproved universal RWN hold.

**Owner:** Operator with purchasing and supplier communications owner

**Referencing slices:** S05; S06; S12

**Safe behavior:** Record source-supported supplier RWN draft and optional comparative diagnostics; do not auto-send before buyer report without operator-approved sequencing policy. Missing buyer report holds full customer invoice. Do not falsely label the report a proven mandatory RWN document. Preserve later correction/replay if an authorized notice preceded a discrepancy.

**Remaining resolution:** Determine whether and under which purchaser terms, timing, review and correction controls RWN may be sent before accepted Buyer Receiving Report; authorize no new automatic dependency until settled.

**Status:** OPEN_BOUND_TO_AFFECTED_ACTION

**Action-specific blocking scope:** Only auto-send before buyer report and its final-state claims are held; preparing an evidence-backed supplier notice, document collection and eligible independent actions continue.

**Reference meaning:** D18 is a distinct unknown; no invented yes/no buyer-report prerequisite may become machine policy.

## Exact source-declared field bindings

These are pinned-source declarations, not a live-registry receipt. Do not replace labels with conversational synonyms. CST measurement labels below are business terms and do not create fields.

| Existing technical identity | Owner | Declared label | Declared type | Use contract | BRS rule |
|---|---|---|---|---|---|
| plasticos.transaction.supplier_weight | plasticos_transaction | Supplier Weight (lbs) | fields.Float | source-specific supplier-declared net; normal RWN/AP quantity | BR-FLD-001 |
| plasticos.transaction.buyer_weight | plasticos_transaction | Buyer Weight (lbs) | fields.Float | accepted buyer Receiving Report net; Customer Invoice quantity | BR-REC-001 |
| plasticos.transaction.scale_weight | plasticos_transaction | Scale Weight (lbs) | fields.Float | certified CST packaging-adjusted material net REFERENCE ONLY; never an automatic supplier RWN/AP or buyer invoice quantity; human review on >5% direct commercial spread | BR-WGT-007 |
| plasticos.transaction.gross_weight | plasticos_transaction | Gross Weight (lbs) | fields.Float computed | OBSOLETE selected-source gross (not actual CST gross); retirement pending migration of existing consumers | BR-FLD-002 |
| plasticos.transaction.final_weight | plasticos_transaction | Final Net Weight (lbs) | fields.Float computed | OBSOLETE universal selected weight: business concept retired; technical deletion pending full compute/view/dashboard/import consumer migration | BR-FLD-002 |
| plasticos.transaction.weight_source | plasticos_transaction | Weight Source | fields.Selection computed | OBSOLETE universal winner enum; screen preference is display-only computed presentation without financial authority | BR-FLD-002 |
| plasticos.transaction.unit_count | plasticos_transaction | Unit Count | fields.Integer | existing package unit count; not a mixed line-unit map | BR-WGT-004 |
| plasticos.transaction.unit_type | plasticos_transaction | Unit Type | fields.Selection | single packaging selection; not a container+carrier representation | BR-WGT-004 |
| plasticos.transaction.tare_per_unit | plasticos_transaction | Tare per Unit (lbs) | fields.Float computed inverse | package tare per unit; source net double deduction forbidden | BR-WGT-003 |
| plasticos.transaction.tare_per_unit_override | plasticos_transaction | Tare Override (lbs) | fields.Float | existing manual override candidate for homogeneous combined package | BR-WGT-004 |
| plasticos.transaction.total_tare | plasticos_transaction | Total Tare (lbs) | fields.Float computed | Existing packaging aggregate unit_count x tare_per_unit; never CST tare. Do not assume one aggregate applies to both supplier and buyer evidence. | BR-WGT-002 |
| plasticos.transaction.weight_discrepancy_pct | plasticos_transaction | Weight Discrepancy % | fields.Float computed | existing difference ratio; denominator policy D13 | BR-SET-002 |
| plasticos.transaction.weight_discrepancy_flagged | plasticos_transaction | Discrepancy Flagged | fields.Boolean computed | Direct commercial discrepancy signal, >5% mandatory human review; source values and reference diagnostics require D13-approved denominator; Boolean cannot settle supplier amount. | BR-SET-003 |
| plasticos.transaction.minimum_net_weight | plasticos_transaction | Minimum Net Weight (lbs) | fields.Float | Existing configured contract minimum; use 40,000 lb only when applicable 53-foot contractual obligation established | BR-UND-001 |
| plasticos.transaction.light_weight_deduction_rate | plasticos_transaction | Deduction Rate ($/lb) | fields.Float | Existing $/lb base-rate field; eligible effective rate continuously scales per 2,000 lb of shortfall, applied to actual material net, not shortfall. Pending technical migration; never `or 0.01` when explicitly zero. | BR-UND-004 |
| plasticos.transaction.light_weight_deduction | plasticos_transaction | Light Weight Deduction ($) | fields.Float computed | OBSOLETE current monetary field and method; proposed successor light_weight_deduction_total pending controlled migration; no duplicate amount | BR-UND-004 |
| plasticos.transaction.dead_freight_chargeback | plasticos_transaction | Dead Freight Chargeback | fields.Boolean computed | OBSOLETE comparison-to-purchase-cost Boolean; retire after existing consumer census, do not relabel as contract liability | BR-UND-005 |
| plasticos.load.seal_number | plasticos_logistics | Seal Number | fields.Char | correct load owner, no invented transaction field | BR-FLD-003 |
| plasticos.load.trailer_number | plasticos_logistics | Trailer Number | fields.Char | correct load owner, not chassis/container | BR-FLD-003 |

## Field-owner and representation register

| Existing field/surface | Owner | Evidence status | Required behavior | Sources | Slices |
|---|---|---|---|---|---|
| plasticos.transaction.supplier_id / buyer_id / carrier_id | plasticos_transaction | EXISTING | Match/corroborate existing parties; incoming email does not silently reassign them. | G11; P01 | S04 |
| plasticos.transaction.sale_order_id / purchase_order_ids / delivery_order_id / do_number | plasticos_transaction | EXISTING | Use exact relations for reference match; no generic invented partner_id. | P01; G11 | S01; S04; S07; S10 |
| plasticos.transaction.load_id | plasticos_logistics/models/transaction_inherit.py | EXISTING_ONE_LOAD_PER_TX | Respect unique load association; multi-load source has multiple existing transactions. | G21 | S01; S04 |
| plasticos.transaction.supplier_weight | plasticos_transaction | EXISTING | Supplier material net with applicable packaging already accounted for, based on supplier evidence. Normal supplier RWN basis. Missing value holds RWN under D14, never Customer Invoice; do not overwrite with buyer_weight. | G11 | S01; S05; S10 |
| plasticos.transaction.buyer_weight | plasticos_transaction | EXISTING | Accepted buyer Receiving Report net quantity for native Customer Invoice; discrepancy comparison for RWN conditional eligibility, not normally supplier RWN quantity. Preserve buyer source and commercial order relationship. | G11 | S05; S06; S07 |
| plasticos.transaction.scale_weight | plasticos_transaction | EXISTING | Use packaging-adjusted certified scale material net as reference only, preserving raw CST gross/tare/net source. Never autoapprove supplier RWN/AP or buyer Invoice from scale_weight; direct supplier-vs-buyer >5% forces human review regardless of reference proximity. | G11 | S05 |
| plasticos.transaction.final_weight / gross_weight / weight_source | plasticos_transaction | EXISTING_COMPUTED_COMPATIBILITY | Retire universal selected weight business meaning; migrate all current compute consumers, transaction/commission/dashboard views and existing tests before safe technical field removal. Preferred display-only weight must not reuse obsolete financial authority. | G11; P01 | S05 |
| plasticos.transaction.total_tare / tare_per_unit / tare_per_unit_override / unit_count / unit_type | plasticos_transaction | EXISTING | Existing packaging fields, not CST tare. Bind actual source/side/package counts. Deduct only packaging still included; do not use supplier package counts as buyer facts or treat a bare net label as packaging-excluded. | G11 | S05 |
| plasticos.transaction.weight_discrepancy_flagged / weight_discrepancy_pct | plasticos_transaction | EXISTING | Reconcile sources and accepted threshold; flag is not an approval or provider-confidence indicator. | G11; P01 | S05 |
| plasticos.load.seal_number / trailer_number | plasticos_logistics | EXISTING | Exact string, leading zeros preserved; chronology-aware conflict handling; not aliases for container/chassis. | G12 | S05 |
| plasticos.load.pickup_reference / delivery_reference / name | plasticos_logistics | EXISTING | Reference match and verified details; immutable sequence identities not overwritten from incoming text. | G12 | S01; S04; S05 |
| plasticos.load.pickup_partner_id / delivery_partner_id | plasticos_logistics | EXISTING | Validate actual facility under parent hierarchy; an extracted address does not silently replace booked location. | G12 | S04; S05 |
| plasticos.load.dispatched_at / delivered_at / pickup_datetime / delivery_datetime | plasticos_logistics | EXISTING | Separate actual and scheduled events; invoke valid lifecycle action; dates need explicit source timezone. | G12 | S05; S08 |
| plasticos.transaction.actual_pickup_date / actual_delivery_date / expected_pickup_date / expected_delivery_date | plasticos_transaction | EXISTING_RECONCILE_OWNER | Resolve load/transaction synchronization before writing; no independent competing date source. | G11 | S05 |
| plasticos.load.actual_freight_cost / actual_freight_currency_id / rate_amount / rate_currency_id | plasticos_logistics | EXISTING | Use existing audited freight actions, not raw-write bypass; currency/terms matching required. | G12 | S10 |
| plasticos.transaction.customer_invoice_id / vendor_bill_ids / freight_bill_ids | plasticos_transaction | EXISTING_CARDINALITY_BOUND | Native invoice/bill relations, current uniqueness; source multi-load attachment does not authorize repeated bill identity. | G11; G19 | S07; S09; S10 |
| account.move.transaction_id / reconciliation_status / reconciliation_notes | plasticos_automation | EXISTING | Keep reciprocal business links consistent; reconcile status is not paid or permission to post. | G18 | S07; S09; S10 |
| plasticos.penalty.rule.rule_type / calculation_method / penalty_rate / partner_ids / grace_period_days | plasticos_automation | EXISTING_CONFIGURATION_BEHAVIOR_INCOMPLETE | Reuse documentation + fixed + 150; no deadline coercion into wrong calendar unit; missing evaluation is required behavior change. | G06 | S09 |
| plasticos.claim.case_type / transaction_id / claimed_amount / recovery_amount / currency_id / assignee_id | plasticos_claims | EXISTING | Use freight_chargeback; claim 150 is not recovery/posted credit/cash; no double addition to margin. | G08 | S09 |
| plasticos.document.attachment_id / tag_id / doc_category / transaction_id / load_id / res_model / res_id | plasticos_documents | EXISTING | Consistent roles and direct/polymorphic links; shared original; source correction cannot silently erase history. | G09; G13 | S01; S04; S08 |
| plasticos.document.verified / override / is_current / superseded_by / active / expiry_date | plasticos_documents | EXISTING | Protected lifecycle and current-valid evidence; never use override to bypass unresolved business policy. | G09 | S02; S04; S08 |
| documents.document.attachment_id / partner_id / transaction_id / load_id / plasticos_doc_id / doc_type | Native Documents + plasticos_documents_native | EXISTING_CUSTOM_EXTENSION_NATIVE_RUNTIME_UNKNOWN | Use one original; multiple TXs leave native single pointer unset while existing evidence rows are authoritative associations. | G14; G13 | S01; S03; S04 |
| plasticos.document.rule and plasticos.document.validation.matrix existing fields | plasticos_documents | EXISTING | Separate per-party requirement, operation gate and due policy; coarse enums are not enough to claim gross/net completeness. | G10; G16; G17 | S08 |
| mail.template / mail.message / mail.mail / mail.activity / ir.attachment | Native Odoo | NATIVE_SURFACES_VERIFY_INSTALLED_API | Reuse messaging/queue/activity/evidence; exact signatures and dedupe persistence must be proved. | N01; N02; G07 | S03; S06; S07; S08; S09 |
| Container/chassis scalar destination | Unresolved existing logistics owner | REPRESENTATION_GAP_NOT_AUTHORIZED | Retain exact value in source/extraction evidence; do not invent fields or overload trailer_number. | G12; P01 | S05; S11 |
| Per-load raw gross/net/source locations and durable processing/outbound identity | Native evidence surfaces first | REPRESENTATION_CHECK_REQUIRED | Prefer supported native metadata/evidence attachment; JSON vocabulary here is a specification, not a new ORM schema. | P01; P02; G09 | S03; S04; S08; S09 |
| plasticos.transaction.minimum_net_weight / light_weight_deduction_rate / light_weight_deduction / dead_freight_chargeback | plasticos_transaction | CURRENT_SOURCE_DECLARATIONS_LEGACY_FIELDS_PENDING_MIGRATION | Existing fields at pinned source. The accepted 53ft formula is inclusive 2000-lb threshold, continuously prorated effective $/lb rate (base $0.01 per 2000 lb shortfall, each 500 lb contributes $0.0025, fractional increments prorated) applied to entire obligation-specific actual material net, USD cents only at end. Explicit 0 remains 0. Proposed monetary total rename/method needs controlled migration; dead-freight Boolean retired; no new weight ORM column. Buyer/supplier accounting obligations require independent contracts. | G23; U06; BRS03 | S02; S05; S06; S09; S10; S12 |

## Inherited implementation findings and disposition

The following remain implementation obligations, not fixed by editing this pack. The predecessor v1.2.0 package repair census is in validation/DRIFT_REVIEW.md.

| ID | Finding | Evidence class/source | Owner slice | Disposition | Closure |
|---|---|---|---|---|---|
| F01 | Broad document/rule internal-user CRUD | SOURCE_RISK_SAME_SHA; G15 | S02 | Verify effective rights and close least-privilege tests; do not just add restrictive ACL rows. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F02 | Compliance computation auto-posts linked drafts | SOURCE_BEHAVIOR_SAME_SHA; G11 | S02 | Replace side-effect authority before automated writes/sends/posting activation. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F03 | Client/operation/party applicability incomplete | SOURCE_GAP_SAME_SHA; G10 | S08 | Operation-specific requirement evaluation; buyer receiving mandatory, scale nonblocking. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F04 | Superseded source and archived-context evaluation | NARROWED_SOURCE_GAP; G09 | S02 | is_current/revision and expiry correct; default active_test not falsely labeled absent. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F05 | Recency matcher and untrusted/mismatched parties | STAGING_RISK_LOCAL_FIX_REPORTED; G14 | S04 | Verify S01 no-op; do not revive recency or majority matching. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F06 | Native events/extraction/sync seam unproven | INTEGRATION_GAP; G13 | S03 | Actual installed mail/upload/provider round-trip; late extraction completion handled. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F07 | Direct/polymorphic mirror divergence | SOURCE_GAP_SAME_SHA; G13 | S04 | Consistent tag/party/load/TX links, multi-document replay and correction. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F08 | Weight meaning/tare/source precedence unsafe to reuse blindly | SOURCE_BEHAVIOR_POLICY_DELTA; G11 | S05 | Preserve supplier RWN versus Customer Invoice source authority and CST gross/CST tare/CST net minus packaging semantics. Reconcile every changed deduction/dashboard/native financial consumer; no universal final_weight or buyer-weight RWN default. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F09 | Company/attachment/override permissions unproven | SECURITY_GAP; G15 | S02 | End-to-end target, attachment, record and rule mutation denial tests. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F10 | Tests do not prove live complete workflow | PROOF_GAP; P02 | S12 | Scoped ORM/mail/AI/accounting/security replay and truthful execution ledger. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F11 | Native installation and PR 265 not admitted/installed | CONFIGURATION_UNKNOWN; G05 | S03 | Reuse PR owner; actual registry/alias/provider proof in disposable environment. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F12 | Native tag/classifier coverage omits business meanings | SOURCE_GAP_SAME_SHA; G20 | S04 | RECEIVING/PACKING/CST preserved through existing tag path; no new enum by default. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F13 | Missing Documentation penalty enum has no evaluator | FRESH_SOURCE_GAP; G06 | S09 | Implement documentation event calculation; literal 150 configuration alone insufficient. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F14 | Applied adjustment can be chatter-only | SOURCE_BEHAVIOR_SAME_SHA; G18 | S09 | Native accounting move/economic effect receipts, no fictional applied/paid state. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F15 | Carrier penalty may double-count recovery | TARGETED_REGRESSION_RISK; G11 | S09 | Prove move sign + claim recovery + margin/commission once; not claimed observed incident. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F16 | RWN flow and sensitive-recipient filters unproven | REQUIRED_CAPABILITY_GAP; G07 | S06 | Locate/reuse existing surface, prove correct recipient, privacy and correction/outbox semantics. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F17 | Blanket one-SCALE requirement misses gross/net completeness | POLICY_MISMATCH; G17 | S08 | Verify certified carrier CST gross/net completeness independently from packaging-tare calculation; neither CST nor SCALE tag alone suffices. No penalty for parser failure or missing packaging evidence alone. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F18 | Long plan and duplicate validation risk | CAMPAIGN_CONTROL; U01 | S00 | Do not bloat S01; separate coherent slices, named shared owners and no redundant full test runs. | OPEN_UNLESS_EXACT_SLICE_EVIDENCE_DISPOSES |
| F19 | No verified dedicated ORM scalar/typed table for each party source gross/tare/packaging/net and per-line source proof. | PROVEN_REPRESENTATION_PRESSURE_NOT_AUTHORIZATION; U05 | S03 | S03/S05 inspect installed Enterprise metadata and existing source-linked evidence; D08 decide smallest representation only if required for replay/line-level arithmetic | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F20 | Existing transaction unit_type/unit_count/total_tare represents one aggregate; multiple packaging types/parties require separate source evidence. | SUPPORTED_SINGLE_PACKAGE_ONLY; U05 | S05 | S05 prove homogeneous 80 lb override; hold mixed/unrepresentable D15, never copy supplier package numbers to buyer. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F21 | Carrier scale seeded compliance rule tag_id points to generic SCALE not existing CST, and required_for_close=True. | OBSERVED_AT_PINNED_STAGING; G23 | S02 | S02/S08 align carrier rule/matrix to exact CST tag and nonblocking close, and test synthetic supplier SCALE cannot complete carrier obligation. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F22 | document_sync.DOC_TYPE_TAG_MAP scale_ticket->SCALE, no role-aware CST routing; does not persist doc_category. | OBSERVED_AT_PINNED_STAGING; G23 | S04 | S01/S04 reuse existing native doc_type=scale_ticket, map verified carrier Certified Scale Ticket to existing CST tag and role association, preserve supplier/buyer SCALE; no new selection. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F23 | Legacy compliance_service.is_compliant aggregates all active required rules regardless required_for_invoice or document role; account_move_inherit.action_post uses it for out_invoice. | OBSERVED_AT_PINNED_STAGING; G23 | S02 | S02/S07 scope compliance to exact operation, verified buyer Receiving Report only for full buyer AR; prove missing carrier CST never blocks invoice or close. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F24 | Old final_weight/deduction/weight_source semantic consumers are incompatible with accepted two-commercial-one-reference architecture; retire with verified consumer migration. | OBSERVED_AT_PINNED_STAGING; G23 | S01 | Migrate compute, old deduction, transaction and commission dashboard views, imported/history consumers and tests; preserve source weights and display preference as distinct presentation, no universal settlement winner. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F25 | Native quantity/invoicing flow not yet wired to buyer_weight or supplier settlement; transaction.quantity is not native invoice line. | OBSERVED_SOURCE_GAP_RUNTIME_NOT_RUN; G23 | S07 | S05/S07/S10 prove actual line-level UoM and delivered/received qty supported route to account.move.line.quantity and existing invoice linkage. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F26 | D13 denominator/review evidence remains open; human review now mandatory for direct >5% commercial spread, automatic scale substitution rejected. | EXPLICIT_OPEN; U05 | S06 | Bind denominator precision and documented human adjudication outcome, ensure two within-5% CST comparisons never waive direct supplier/buyer spread; scale never automatic settlement. | Actual implementation tests and owner/decision resolution; package compilation alone cannot close. |
| F27 | Current light_weight_deduction compute charges any shortfall, applies flat shortfall-times-rate instead of accepted continuous effective rate on material net, and rate or 0.01 overrides explicit zero. | OBSERVED_AT_PINNED_STAGING_CONFLICTS_WITH_USER_ACCEPTED_FORMULA; U07 | S10 | Implement only for evidenced applicable 53-foot obligation: 2000-lb inclusive threshold, dynamic effective 0.01*(shortfall/2000) rate with continuous partial-500 proration, amount=actual_material_net*rate, final cents half-up. No posted financial effect unless D16 agreement; migrate method to _compute_light_weight_deduction_total and independently verify native consumers. | Odoo 19 isolated unit/ORM/replay proof including exact 1999/2000/2250/2499/2500/4000 shortfall and explicit zero; old 500-step floor and shortfall-times-rate must fail. |
| F28 | Existing dead_freight_chargeback Boolean compares deduction with purchase_cost_total, not a defensible separate contractual liability. | OBSERVED_SOURCE_BEHAVIOR_OPERATOR_RETIREMENT_APPROVED; G23 | S10 | Retire Boolean business meaning now; remove stored model/field consumers only after installed view/ORM/historical migration and claim/recovery proof. No invented replacement dead freight Boolean. | Code and runtime consumer census, safe migration test, no obsolete Boolean in active business logic. |
| F29 | Old RWN specifications and field routing allowed scale_weight as automatic substitute when >5%, now superseded by human-only review. | OPERATOR_POLICY_CHANGE; U06 | S06 | Update BRS, RWN flow, AP guards, task text, machine routes and known-bad tests so scale remains reference and direct commercial spread over 5% enters documented human review. | Affected Odoo runtime RWN and human-decision tests plus exact source revision proof required. |

## Representation and authority boundary

A proven gap does not authorize a new field, table, enum or parallel engine. Reuse native Odoo and existing PlasticOS owners; block only the unsupported action under D08. Preserve current field/source semantics, source evidence and prior approved policy. ADR-025 and BRS are proposed repository additions; brs-logistics and a semantic-kernel vocabulary framework remain deferred.
