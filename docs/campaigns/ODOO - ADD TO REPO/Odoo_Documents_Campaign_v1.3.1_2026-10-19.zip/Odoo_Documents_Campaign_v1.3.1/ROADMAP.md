# Documents Campaign Roadmap

**Version:** 1.3.1 | **BRS:** brs-documents@1.3.1 | **Status:** package specification, not executed Odoo software.

**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed.** Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. Missing packaging alone is not missing CST.

## Dependency map

Edges mean prerequisite outcome to dependent slice. Runtime dependency DEP265 is an inherited named PR owner, not a fresh claim about its current state.

```mermaid
flowchart TD
  S00["S00: Bind baseline and policy delta"]
  S01["S01: Finish the user plan and audit its actual result"]
  S02["S02: Protect document writes and financial side effects"]
  S03["S03: Capture and read incoming documents with native AI"]
  S04["S04: Apply matching, classification and synchronization safely"]
  S05["S05: Receiving report to transaction facts and business readiness"]
  S06["S06: Send the supplier Received Weight Notice"]
  S07["S07: Create, post and send the Customer Invoice"]
  S08["S08: Party checklists, missing-document follow-up and review"]
  S09["S09: Realize the USD 150 carrier CST-document penalty"]
  S10["S10: Complete supplier and freight AP, credits and deductions"]
  S11["S11: Cover remaining operational and supporting documents"]
  S12["S12: Prove the whole workflow and activate coherently"]
  DEP265["DEP265: Existing PR 265 native bridge installation/view work"]
  S00 --> S01
  S01 --> S02
  S00 --> S03
  S01 --> S04
  S02 --> S04
  S03 --> S04
  S04 --> S05
  S05 --> S06
  S05 --> S07
  S04 --> S08
  S02 --> S09
  S08 --> S09
  S02 --> S10
  S04 --> S10
  S04 --> S11
  S06 --> S12
  S07 --> S12
  S08 --> S12
  S09 --> S12
  S10 --> S12
  S11 --> S12
  DEP265 -.-> S03
```

## Milestones and earliest useful operation

| Milestone | Required outcomes | Result |
|---|---|---|
| M1: Evidence foundation | S00/S01/S02/S03/S04 | Source-correct intake and replay-safe associations; exact field/BRS checks. |
| M2: Receiving Report to independent outputs | S05 plus S06 and S07 | Customer Invoice on buyer_weight; RWN only when supplier quantity, price and deductions are supported. Joined T097/T105/T123 proof for this activation boundary; do not wait for all AP/penalty classes. |
| M3: Collection and carrier accountability | S08/S09 | Per-party document truth and approved one-event $150 carrier CST penalty; independent of M2. |
| M4: Complete declared coverage | S10/S11/S12 | Remaining AP/supporting documents and full joined operational proof. |

## Priority and parallelism

Finish the original S01 slice without pasting this campaign into it. Source/fixture preparation can be parallel; one writer owns a shared source file or test database. S06 and S07 are independent output lanes after S05. Supplier PL, missing supplier_weight, carrier CST/penalty and supplier AP are not hidden Customer Invoice prerequisites. Each slice must close any consumer it actually changes; preserve untouched compatibility until the bounded successor can safely change it.

## Slice summary

| Slice | Outcome | Prerequisite slices | Action-scoped decision references |
|---|---|---|---|
| S00 | Bind baseline and policy delta | None | D06; D12 |
| S01 | Finish the user plan and audit its actual result | S00 | D12 |
| S02 | Protect document writes and financial side effects | S01 | D08 |
| S03 | Capture and read incoming documents with native AI | S00 | D06; D08 |
| S04 | Apply matching, classification and synchronization safely | S01; S02; S03 | D08 |
| S05 | Receiving report to transaction facts and business readiness | S04 | D03; D07; D08; D13; D15; D14; D16; D18 |
| S06 | Send the supplier Received Weight Notice | S05 | D02; D11; D13; D14; D07; D15; D16; D18 |
| S07 | Create, post and send the Customer Invoice | S05 | D07; D10; D11; D16 |
| S08 | Party checklists, missing-document follow-up and review | S04 | D03; D09; D10; D15 |
| S09 | Realize the USD 150 carrier CST-document penalty | S02; S08 | D01; D03; D04; D05; D10; D11; D15; D16 |
| S10 | Complete supplier and freight AP, credits and deductions | S02; S04 | D02; D05; D10; D13; D15; D16 |
| S11 | Cover remaining operational and supporting documents | S04 | D08; D15 |
| S12 | Prove the whole workflow and activate coherently | S06; S07; S08; S09; S10; S11 | D06; D11; D16; D18 |

A decision reference means consult its blocker_scoping, not stop the whole slice. ADR-025/BRS adoption and CI pointer work is bounded in S02; repository writes still need a separate grant. brs-logistics stays deferred.

## S00. Bind baseline and policy delta

Prepare a source-bound handoff without rewriting the current plan.

**Owners:** Campaign operator; Current coding agent

**Prerequisites:** None

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R01; R02; R27; R31; R40; R47; R53

**Acceptance cases:** T001; T002; T096; T118; T177; T201

**Inherited findings:** F18

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-DOC-001; BR-EVD-002; BR-FLD-001; BR-FLD-002; BR-FLD-003; BR-FLD-004; BR-REC-002; BR-REC-003; BR-REC-004; BR-SET-004; BR-UND-002; BR-WGT-008

**BRS revision:** brs-documents@1.3.1

**Decisions:** D06; D12

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

Read-only baseline binding; no repository mutation.

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S00.01 | Record exact supplied plan and predecessor ZIP digests, current Staging SHA and PR 265 state; preserve originals byte-for-byte. | PLANNED |
| S00.02 | Read actual local feat/inbound-document-linking branch, ADR-022/023, and root ADR index; check actual ADR-025 admission status on the target branch rather than assuming adoption. Preserve the accepted BRS candidate and original plan without recreating ADR history. | PLANNED |
| S00.03 | Reconcile original S01 source plan against accepted Documents/Weights/Underweight BRS family: supplier_weight normal notice, direct >5% human review (scale only reference), typed measurements, no new ORM fields; preserve originals and record historical supersessions. | PLANNED |
| S00.04 | Record D13 direct commercial discrepancy denominator and human decision source, D14 missing supplier payable quantity, D15 mixed packaging, D16 obligation-specific underweight contracts, and earlier D01/D02 without blanket buyer invoice blocks. | PLANNED |
| S00.05 | Resolve installed Documents, documents_account, AI/extract actions, native mail hooks, current test harness and permitted disposable database identity before delegating executable details. | PLANNED |
| S00.06 | Capture repository law, scope-specific approvals and exact owner paths; list collision with PR 265 rather than duplicating its installation patch. | PLANNED |
| S00.F01 | Freeze exact Odoo 19 field names, source-declared types, label/selection vocabulary, source group authority, and proposed field-flow contract against the target Staging SHA and installed-registry UNKNOWN. | NOT_STARTED |
| S00.90 | Adopt seven numbered concern-scoped BRS-001..BRS-007 files plus machine index, README and traceability; ensure ADR-025 indexed and one-owner rule migrations tested against original IDs. Repo execution separately authorized, NOT_RUN. | PLANNED |

### Exit evidence

Original inputs preserved; baseline and decision register published inside pack; first slice scope remains bounded.

Baseline may close with explicitly bounded runtime UNKNOWNs. They block only dependent runtime invocations, not all source-only preparation or unrelated slices.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No code, repository mutation, external send or claim that local ADRs were fetched.

### Stop conditions and material risks

Remote branch lookup does not establish local absence.

## S01. Finish the user plan and audit its actual result

Deliver the planned document-to-transaction association and source-weight foundation, not the whole Documents campaign.

**Owners:** plasticos_documents_native; plasticos_transaction

**Prerequisites:** S00

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R01; R05; R06; R25; R27; R31; R35; R43; R45

**Acceptance cases:** T002; T003; T004; T006; T013; T116; T117; T168

**Inherited findings:** None

**BRS rules:** BR-CAR-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-FLD-001; BR-FLD-002; BR-FLD-003; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-WGT-007; BR-CAR-004; BR-FLD-004; BR-WGT-008

**BRS revision:** brs-documents@1.3.1

**Decisions:** D12

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents_native/models/document_native.py
plasticos_documents_native/models/document_sync.py
plasticos_transaction/models/transaction.py
plasticos_transaction/views/transaction_views.xml
tests/test_constraints_onchanges.py
plasticos_transaction/tests/test_transaction_form_ui.py
tests/test_transaction_profit_snapshot.py
plasticos_documents_native/__manifest__.py
plasticos_transaction/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S01.01 | Use source_inputs/document_transaction_match_3a3f9d7d.plan.md as the exact starting instructions; retain document-adr, weight-adr, matcher, sync, weight and tests identities. | PLANNED |
| S01.02 | Verify claimed local ADR-022/023 implementation and no-op matcher; do not recreate them. Resolve conflicting proposed ADR-022 weight prose against ADR-025/brs-documents as a bounded semantic correction, without renaming fields. | PLANNED |
| S01.03 | Implement/finish reference matching and one evidence row per cited transaction with shared source attachment, under the original no-new-schema constraint. | PLANNED |
| S01.04 | Prove actual hook invocability, zero/multiple hits and per-reference weights; do not interpret a pure-function test as full mail/OCR execution. | PLANNED |
| S01.05 | Keep the narrow safety ceiling: no destructive evidence deletion, ambiguous cross-company filing, or automatic financial effect from unvalidated text. Put nonessential hardening in S02/S04. | PLANNED |
| S01.06 | Apply the BRS overlay only to conflicts in this slice: no inclusive-at-5% substitution, unqualified weight selection, destructive evidence deletion or universal final_weight settlement authority. Preserve existing field names. Any consumer actually changed by S01 needs same-slice compatibility proof; otherwise retain its behavior and defer the bounded change to its named successor, not an acknowledged regression. | PLANNED |
| S01.07 | Run the existing scoped tests and affected contracts once per distinct proof obligation; preserve observed outcomes and any unrun Enterprise seam. | PLANNED |
| S01.08 | Independently inspect the resulting exact diff with the current audit capability before closing S01; route confirmed residual findings into their named successor slices. | PLANNED |
| S01.F01 | Bind starting-plan matching and weight writeback claims against BRS source role and packaging semantics; any changed compute must close affected dashboard/deduction consumers before claiming acceptance. | NOT_STARTED |

### Exit evidence

One/many valid reference files, safe no-match and no duplicate evidence on replay; source values remain distinct; no unsafe accounting side effect.

A receipt closes each actual opening task or explicitly blocks it; old plan success is not overall campaign success.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No PR 265 install flags; no new model/field/selection; no full reminder dashboard, carrier settlement or outward sends.

### Stop conditions and material risks

Do not knowingly introduce a harmful defect for a later slice to fix.

Do not claim supplier settlement behavior is final under the new operator delta.

**Shared write surfaces:** plasticos_documents_native/models/document_native.py; plasticos_documents_native/models/document_sync.py; plasticos_transaction/models/transaction.py; plasticos_transaction/views/transaction_views.xml; plasticos_documents_native/__manifest__.py; plasticos_transaction/__manifest__.py

## S02. Protect document writes and financial side effects

Make evidence capture safe before expanding automatic writeback.

**Owners:** plasticos_documents; plasticos_transaction; plasticos_documents_native; plasticos_security_base (scope-specific approval)

**Prerequisites:** S01

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R02; R07; R22; R23; R35; R36; R43; R45; R47; R52; R55

**Acceptance cases:** T009; T018; T019; T056; T057; T092; T093; T116; T118; T119; T120; T121; T125; T129; T155; T168; T170; T171; T177; T179; T197; T198; T199; T200; T221; T222

**Inherited findings:** F01; F02; F04; F09

**BRS rules:** BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-FLD-001; BR-FLD-002; BR-FLD-003; BR-WGT-007; BR-CAR-004; BR-FLD-004; BR-WGT-008; BR-REC-004; BR-UND-004; BR-UND-005; BR-VOC-001; BR-UND-002

**BRS revision:** brs-documents@1.3.1

**Decisions:** D08

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents/models/document.py
plasticos_documents/models/compliance_service.py
plasticos_documents/security/ir.model.access.csv
plasticos_documents_native/models/document_native.py
plasticos_transaction/models/transaction.py
plasticos_transaction/models/account_move_inherit.py
plasticos_security_base/security/record_rules.xml
plasticos_documents/__manifest__.py
plasticos_documents_native/__manifest__.py
plasticos_security_base/__manifest__.py
plasticos_transaction/__manifest__.py
docs/adr/ADR-025-business-rules-specification-authority.md
docs/business-rules/README.md
docs/adr/README.md
ARCHITECTURE.md
AGENTS.md
.github/workflows/ci.yml
ci/check_field_integrity.py
plasticos_documents/data/scale_ticket_rule.xml
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S02.01 | Replace compliance-compute posting side effects with an explicit operation-specific eligibility path in existing owners; an extracted/verified tag is never blanket posting authority. | PLANNED |
| S02.02 | Resolve effective ACL union and native attachment access; protect verify/override and rule mutation at ORM entry points, not only UI buttons. | PLANNED |
| S02.03 | Enforce company and target-record authorization for both direct and polymorphic links; reject mismatched supplier/facility/load links. | PLANNED |
| S02.04 | Preserve original evidence and supersession history on relink, reclassification, archive, deletion attempt and parent record deletion. | PLANNED |
| S02.05 | Make compliance scope operation/party/transaction/current document version aware, retaining default active_test behavior rather than claiming it absent. | PLANNED |
| S02.06 | Bind safe transaction/savepoint and outbound queue boundaries so a failed bill or email cannot silently consume a receipt or duplicate another transaction effect. | PLANNED |
| S02.07 | Prove native vendor auto-post settings cannot bypass custom eligibility; hold only the unsafe action, not the entire document inbox. | PLANNED |
| S02.08 | Adopt the packaged ADR-025/brs-documents and short AGENTS/index pointers under a separate explicit repository grant; extend the existing CI/field checker and actual Odoo tests for exact fields, labels, document directions and CST tare vocabulary. Prove known-bad cases fail the required gate. No parallel CI workflow, rule engine or brs-logistics. | PLANNED |
| S02.F01 | Audit existing carrier scale XML rule/matrix and compliance/account.move.action_post gates; prove generic SCALE never satisfies carrier certified CST and missing carrier CST cannot block buyer invoice or commercial close. | NOT_STARTED |
| S02.F02 | Adopt field/role naming conformance checks into existing CI only, without adding new workflow; reject changed buyer_weight labels, invented shipper_weight, or skipped mandatory installed registry tests. | NOT_STARTED |

### Exit evidence

Unauthorized field writes denied; no cross-company exposure; compliance flip does not post drafts; corrected/obsolete evidence does not satisfy active requirements.

Packaged BRS/ADR adoption, field/naming tests and required CI wiring have exact-head proof. Missing Odoo execution, skipped mandatory tests or a changed field label cannot be presented as PASS.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No global role redesign; no generic authorization framework; no unrelated financial refactor.

### Stop conditions and material risks

A new company/provenance field needs gap proof and explicit grant, not silent introduction.

**Shared write surfaces:** plasticos_documents/models/document.py; plasticos_documents/models/compliance_service.py; plasticos_documents_native/models/document_native.py; plasticos_transaction/models/transaction.py; plasticos_transaction/models/account_move_inherit.py; plasticos_documents/__manifest__.py; plasticos_documents_native/__manifest__.py; plasticos_transaction/__manifest__.py

## S03. Capture and read incoming documents with native AI

Convert inbound messages and files into preserved, structured candidate evidence.

**Owners:** plasticos_documents_native; Native Odoo Documents/Accounting configuration

**Prerequisites:** S00

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R03; R04; R12; R22; R38; R40; R41; R42; R46

**Acceptance cases:** T011; T012; T015; T021; T022; T023; T024; T025; T026; T027; T041; T111; T122; T137; T172; T173

**Inherited findings:** F06; F11

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-004; BR-REC-001; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-FLD-004; BR-WGT-008; BR-WGT-005; BR-WGT-006; BR-REC-004; BR-EVD-005; BR-EVD-006

**BRS revision:** brs-documents@1.3.1

**Decisions:** D06; D08

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents_native/models/document_native.py
plasticos_documents_native/data/document_folders.xml
plasticos_documents_native/data/document_tags.xml
plasticos_documents_native/models/document_sync.py
plasticos_documents_native/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S03.01 | Verify native bridge prerequisites using the existing PR 265 owner; capture installed addon/action/provider versions and native mail hook behavior. | PLANNED |
| S03.02 | Configure or reuse docs@scrapmanagement.com through a separately authorized configuration action; ensure one routing path rather than parallel journal and folder aliases creating duplicates. | PLANNED |
| S03.03 | Select the actual installed native Odoo Documents AI/text/OCR operation before adding custom extraction. Distinguish optional Supplier/Buyer Scale Tickets from certified carrier CST. Normalize source light/heavy wording to CST tare/CST gross only for a validated CST, preserve the original words and never add an AI alias field. | PLANNED |
| S03.04 | Use native text/structured XML first where reliable, OCR for scans, AI for classification and schema-bound extraction; expose unsupported spreadsheets/images/body-only evidence explicitly. | PLANNED |
| S03.05 | Use actual native PDF split/version/shortcut facilities where they meet the requirement; otherwise retain a bounded representation gap. Logical parts retain parent and page provenance. A To Split tag alone does not split a file; no second splitter/version store is introduced by this plan. | PLANNED |
| S03.06 | Allow extraction actions only; untrusted document instructions cannot select arbitrary ORM models, actions, recipients, websites or credentials. | PLANNED |
| S03.07 | Persist minimum extraction output/provenance in supported native evidence/attachment surfaces, with page/cell/span only when returned by the provider. | PLANNED |
| S03.08 | Use bounded retries and recorded parser/provider errors; no source silently disappears and no automated recipient or finance mutation occurs in this slice. | PLANNED |
| S03.F01 | Extract typed supplier/buyer/CST source facts with per-source gross/net/packaging basis, load/line/issuer and raw unit; verify native Documents/AI provides durable replayable storage or raise bounded D08. | NOT_STARTED |

### Exit evidence

Actual alias/upload/body-only paths preserve source and yield candidate facts; source errors remain reviewable; no domain or financial writes.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No new OCR platform, separate DMS, partner-enrichment engine or blanket AI dependency added from memory.

### Stop conditions and material risks

Native Documents AI and native account.move Vendor Bill digitization are different capabilities; actual installed evidence decides which is reused.

**Shared write surfaces:** plasticos_documents_native/models/document_native.py; plasticos_documents_native/models/document_sync.py; plasticos_documents_native/__manifest__.py

## S04. Apply matching, classification and synchronization safely

Promote candidate evidence into the correct existing transaction/document relationships.

**Owners:** plasticos_documents_native; plasticos_documents

**Prerequisites:** S01; S02; S03

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R02; R04; R05; R06; R07; R19; R22; R29; R34; R38; R40; R41; R42; R43; R46

**Acceptance cases:** T004; T005; T007; T008; T009; T010; T011; T012; T014; T015; T016; T017; T018; T020; T022; T028; T112; T122; T130; T131; T132; T134; T135; T142; T154; T156; T160; T161; T174; T175

**Inherited findings:** F05; F07; F12

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-FLD-001; BR-FLD-003; BR-REC-001; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-FLD-004; BR-WGT-008; BR-WGT-005; BR-WGT-006; BR-REC-004; BR-WGT-007; BR-CAR-004; BR-EVD-005; BR-EVD-006

**BRS revision:** brs-documents@1.3.1

**Decisions:** D08

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents_native/models/document_native.py
plasticos_documents_native/models/document_sync.py
plasticos_documents/models/document.py
plasticos_documents/models/compliance_service.py
plasticos_documents/__manifest__.py
plasticos_documents_native/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S04.01 | Consume per-logical-document content and scoped references, not the union of every attachment and the email body. | PLANNED |
| S04.02 | Resolve exact transaction/load/PO/SO/DO references with bounded indexed retrieval and token verification; preserve legitimate late documents on closed records without authorizing financial edits. | PLANNED |
| S04.03 | Validate each match independently against company, facility, counterparties and document issuer. Eliminate majority-of-hits authority and untrusted-scale-sender exemption. | PLANNED |
| S04.04 | Handle parent/contact identities and established authorized third parties without treating sender domain alone as business authority. | PLANNED |
| S04.05 | Synchronize direct transaction/load links, doc_category and existing PACKING/BOL/RECEIVING/SCALE tags. Reuse existing `plasticos_documents.tag_cst` (code `CST`) for carrier CST; `tag_scale_ticket` (code `SCALE`) remains generic. CST is not a new selection/tag or proof of issuer certification. Supplier/carrier BOL copies can share original evidence with distinct senders. | PLANNED |
| S04.06 | Prove logical-part/version/transaction identity for replay and concurrency. One attachment+transaction key alone cannot represent an invoice and Receiving Report for the same transaction in one PDF. Reuse native split/derivative or existing association mechanisms after proof; retain prior links as history, not destructive deletion. | PLANNED |
| S04.07 | Distinguish source issuer from mail transporter; carrier-forwarded certified scale evidence can satisfy carrier receipt rules even when it is not settlement authority. | PLANNED |
| S04.08 | Create one actionable review item with evidence and specific reason for unmatched/ambiguous documents; resolution deterministically replays only affected work. | PLANNED |
| S04.F01 | Use document issuer, verified party, native doc_type, existing tag codes and exact transaction/load/material bindings jointly; reuse CST versus SCALE tags without inventing doc_type selection values. | NOT_STARTED |
| S04.F02 | Repair native-to-legacy document synchronization so role-specific CST/RECEIVING/PACKING are correctly filed and current/duplicate/multi-load evidence is stable on replay. | NOT_STARTED |

### Exit evidence

All candidate matches either safely filed or reasoned exceptions; one original retained; shared attachments and native single-link limitations handled; no lost multi-transaction mirrors.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No new relationship model without explicit representation-gap approval; no buyer-search/matching engine.

### Stop conditions and material risks

One attachment+transaction key can be insufficient for multiple logical types; segmentation/association must be proven first.

**Shared write surfaces:** plasticos_documents_native/models/document_native.py; plasticos_documents_native/models/document_sync.py; plasticos_documents/models/document.py; plasticos_documents/models/compliance_service.py; plasticos_documents/__manifest__.py; plasticos_documents_native/__manifest__.py

## S05. Receiving report to transaction facts and business readiness

Apply separately sourced supplier_weight, buyer_weight and eligible scale_weight plus exact load facts; evaluate each downstream action independently.

**Owners:** plasticos_transaction; plasticos_logistics; plasticos_documents

**Prerequisites:** S04

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R08; R09; R10; R11; R12; R13; R29; R32; R33; R34; R35; R37; R39; R40; R41; R42; R43; R44; R45; R46; R48; R49; R50; R52; R54; R55

**Acceptance cases:** T013; T028; T029; T030; T031; T032; T033; T034; T036; T037; T038; T039; T040; T041; T042; T043; T044; T045; T046; T047; T048; T100; T101; T102; T103; T104; T105; T108; T109; T110; T113; T114; T117; T123; T124; T125; T126; T127; T128; T130; T133; T134; T135; T136; T137; T138; T139; T140; T141; T143; T144; T145; T146; T147; T151; T152; T153; T158; T159; T160; T172; T173; T175; T176; T181; T182; T183; T184; T185; T186; T187; T188; T189; T190; T191; T192; T193; T197; T198; T199; T200; T219; T220; T221

**Inherited findings:** F08

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-FLD-001; BR-FLD-002; BR-FLD-003; BR-REC-001; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-FLD-004; BR-WGT-008; BR-WGT-005; BR-WGT-006; BR-REC-004; BR-WGT-007; BR-CAR-004; BR-SET-006; BR-EVD-005; BR-EVD-006; BR-VOC-001; BR-WGT-009; BR-WGT-010; BR-UND-001; BR-UND-002; BR-UND-006; BR-UND-004; BR-UND-005

**BRS revision:** brs-documents@1.3.1

**Decisions:** D03; D07; D08; D13; D15; D14; D16; D18

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_transaction/models/transaction.py
plasticos_logistics/models/load.py
plasticos_documents/models/compliance_service.py
plasticos_documents/models/transaction_docs.py
plasticos_transaction/views/transaction_views.xml
plasticos_documents/views/transaction_docs_views.xml
plasticos_documents/__manifest__.py
plasticos_logistics/__manifest__.py
plasticos_transaction/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S05.01 | Validate current inbound buyer Receiving Report per load/material/line as the mandatory FULL CUSTOMER INVOICE gate and a source for direct supplier/buyer comparison when present. Do not invent a universal RWN sending prerequisite; D18 owns the unresolved buyer-report-before-RWN sequence. | PLANNED |
| S05.02 | Normalize supplier PL/other accepted supplier evidence to supplier_weight and the buyer Receiving Report to buyer_weight, each with its own packaging interpretation and source history. Do not copy values or package counts between parties. Missing supplier_weight holds only RWN under D14, not Customer Invoice readiness. | PLANNED |
| S05.03 | Extract/update seal_number, trailer_number, pickup/delivery references, actual event dates and other allowlisted existing fields with per-field evidence and conflict checks. | PLANNED |
| S05.04 | Extract CST gross, CST tare and CST net with same-load source evidence; validate CST gross - CST tare = CST net. Then derive net weight billed = CST net - applicable packaging tare. Never write raw CST values to legacy computed gross_weight/final_weight or invent a new quantity field. | PLANNED |
| S05.05 | Apply 40 lb/Gaylord, 40 lb/pallet and 80 lb/Gaylord-on-pallet to source-specific PL/Receiving Report quantities and CST net only when that packaging remains included. A bare net label is not proof of prior packaging deduction. Unknown/mixed/box inputs remain D15; no packaging guess and no carrier penalty from that gap alone. | PLANNED |
| S05.06 | Compare supplier_weight vs buyer_weight without universal winner. CST-derived scale candidate must be certified and packaging-adjusted where D13 authorizes its use; RWN exception requires strictly >5% plus exact scale eligibility. Preserve original source quantities. | PLANNED |
| S05.07 | Compute distinct Customer Invoice readiness, buyer Receiving Report acceptance, supplier RWN payable-basis readiness and carrier document obligations. Missing PL/carrier scales alone do not block either commercial action; missing supplier settlement weight blocks only RWN. | PLANNED |
| S05.08 | Close exact final_weight/gross_weight/weight_source, tare, light-weight deduction and commission/dashboard consumer behavior changed by this slice. No synthetic universal final net or double packaging tare. | PLANNED |
| S05.09 | Prepare source-bound buyer Receiving Report facts plus distinct supplier RWN settlement selection candidates for the later slices; do not reuse buyer_weight as normal supplier payable quantity. | PLANNED |
| S05.F01 | Apply supplier PL/BOL/optional supplier scale source facts only to supplier_weight and accepted buyer Receiving Report material net only to buyer_weight, preserving source-side packaging differences and revisions. | NOT_STARTED |
| S05.F02 | For carrier CST, calculate CST gross minus CST tare equals CST net, then CST net minus applicable packaging tare equals net weight billed; persist intermediate facts as linked evidence and use only eligible material net for scale_weight. | NOT_STARTED |
| S05.F03 | Close D15 representation for mixed Gaylords/pallets/boxes, prevent double tare, and block only the affected unrepresentable quantity; no fabricated net_weight or new document selection. | NOT_STARTED |
| S05.13 | Preserve exact five-stage vocabulary (document measurement, load net, packaging tare, material net, accepted commercial weight), compare source-specific material net and reject scale as automatic payable weight. | PLANNED |
| S05.14 | Implement direct supplier-vs-buyer commercial spread and two independent CST reference diagnostics; human review >5%, display-only certified scale first, no ORM synonym fields. | PLANNED |

### Exit evidence

A valid buyer Receiving Report can unlock Customer Invoice readiness without supplier weight, PL or CST. The supplier RWN separately requires supported supplier_weight (or resolved D13/D14 exception), purchase price and approved deductions; accepted source facts are replay-safe.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No silent supplier bill settlement change; no seal-to-container field overloading; no sending or posting in this slice.

### Stop conditions and material risks

Do not use one source-side packaging count for the other side or make packaging unknownness invalidate certified document receipt.

Mandatory buyer Receiving Report and supplier RWN payable-basis checks are independent from carrier document completeness.

**Shared write surfaces:** plasticos_transaction/models/transaction.py; plasticos_logistics/models/load.py; plasticos_documents/models/compliance_service.py; plasticos_documents/models/transaction_docs.py; plasticos_transaction/views/transaction_views.xml; plasticos_documents/views/transaction_docs_views.xml; plasticos_documents/__manifest__.py; plasticos_logistics/__manifest__.py; plasticos_transaction/__manifest__.py

## S06. Send the supplier Received Weight Notice

Prepare and, when the approved sequence allows, send a supplier RWN confirming supplier commercial material-net quantity, price and approved deductions. Buyer Receiving Report supplies a direct commercial comparison when available; missing-report send sequence is D18.

**Owners:** plasticos_automation; plasticos_transaction; Native mail/report owner

**Prerequisites:** S05

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R08; R16; R29; R32; R37; R39; R41; R44; R45; R42; R48; R49; R51; R52; R55

**Acceptance cases:** T030; T032; T043; T049; T050; T051; T052; T053; T102; T103; T104; T105; T106; T107; T111; T123; T140; T162; T163; T164; T165; T166; T167; T169; T150; T176; T181; T182; T183; T184; T185; T186; T187; T194; T195; T196; T197; T198; T199; T200; T219; T223

**Inherited findings:** F16

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-002; BR-EVD-004; BR-FLD-001; BR-FLD-002; BR-REC-001; BR-REC-002; BR-REC-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-WGT-003; BR-WGT-005; BR-SET-006; BR-FLD-004; BR-WGT-008; BR-WGT-006; BR-REC-004; BR-VOC-001; BR-WGT-009; BR-WGT-010; BR-UND-003; BR-UND-007; BR-UND-004; BR-UND-005

**BRS revision:** brs-documents@1.3.1

**Decisions:** D02; D11; D13; D14; D07; D15; D16; D18

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_automation/data/email_templates.xml
plasticos_transaction/models/transaction.py
plasticos_automation/models (existing applicable owner resolved at entry)
plasticos_automation/__manifest__.py
plasticos_transaction/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S06.01 | Locate a current RWN action/template before adding one; reuse native mail.template/report machinery and transaction chatter. | PLANNED |
| S06.02 | Generate RWN from supported supplier_weight normally; any >5% direct supplier/buyer spread requires recorded human review and prohibits automatic scale_weight substitution. For a CST-derived candidate use CST gross - CST tare = CST net, then CST net - packaging tare = net weight billed. Include purchase price and approved supplier deductions; never treat buyer_weight or raw CST net as the default supplier payable amount. | PLANNED |
| S06.03 | Apply double-blind disclosure rules: no buyer identity/address, SO price, margin, other party attachment or unredacted Receiving Report by default. | PLANNED |
| S06.04 | Resolve approved supplier contact and company; idempotent notice identity includes settlement basis, purchasing terms/deductions, transaction/load and actual source evidence; buyer Receiving Report reference only when available and applicable, with D18 gating premature automatic send. | PLANNED |
| S06.05 | Queue after committed accepted supplier settlement inputs and required buyer-report comparison. Use native report/mail queue state; do not let receipt acceptance alone release a notice with missing supplier quantity, price or deduction authority. | PLANNED |
| S06.06 | Deduplicate replay and issue corrected notice only for a material accepted quantity, purchase price, deduction or contract change; keep original settlement notice and recipients. | PLANNED |
| S06.07 | Test normal supplier-weight RWN without PL/supplier scale, exactly 5% no special trigger, >5% mandatory human review regardless CST proximity, missing source weight D14 holds RWN; buyer Invoice remains independent. | PLANNED |
| S06.F01 | Select accepted supplier commercial material net for routine RWN; for direct supplier/buyer spread strictly >5% require recorded human review with CST material net as reference, never automatic substituted scale amount. Bind correct purchase price and independent authorized supplier deductions. | NOT_STARTED |
| S06.09 | Replace obsolete automatic manual, documented settlement correction from supplier RWN with human-reviewed settlement correction; keep scale reference, supplier source, and buyer invoice independent. | PLANNED |

### Exit evidence

Exactly one queued business notice per accepted revision, correct recipient/content, safe correction and explicit transport failure.

D18 open: customer Receiving Report missing independently holds full buyer invoice; supplier RWN source-supported draft can exist but automatic send is separately held pending approved RWN timing policy.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No payment execution or representation that funds were disbursed; no buyer Receiving Report disclosure; no pass-through of the carrier-only $150 penalty to the supplier. Approved supplier light-weight/other deductions remain in scope.

### Stop conditions and material risks

Email transport cannot guarantee universal exactly-once delivery; ambiguous send result must not be blindly retried.

**Shared write surfaces:** plasticos_automation/data/email_templates.xml; plasticos_transaction/models/transaction.py; plasticos_automation/__manifest__.py; plasticos_transaction/__manifest__.py

## S07. Create, post and send the Customer Invoice

Convert accepted receiving evidence and existing sales terms into native AR.

**Owners:** plasticos_transaction; Native sale/account models; plasticos_automation

**Prerequisites:** S05

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R08; R10; R17; R23; R29; R37; R42; R47; R48; R51

**Acceptance cases:** T030; T032; T034; T043; T045; T053; T054; T055; T057; T058; T059; T083; T105; T107; T144; T147; T148; T149; T150; T151; T178; T165; T171; T176; T181; T182; T183; T194; T195; T196

**Inherited findings:** None

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-DOC-001; BR-EVD-002; BR-EVD-004; BR-FLD-002; BR-REC-001; BR-REC-002; BR-REC-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-WGT-006; BR-REC-004; BR-FLD-004; BR-VOC-001; BR-WGT-009; BR-UND-003; BR-UND-007

**BRS revision:** brs-documents@1.3.1

**Decisions:** D07; D10; D11; D16

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_transaction/models/account_move_inherit.py
plasticos_transaction/models/transaction.py
plasticos_transaction/models/sale_inherit.py
plasticos_automation/data/email_templates.xml
plasticos_automation/__manifest__.py
plasticos_transaction/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S07.01 | Bind native SO/order-line invoiceable-quantity path to accepted buyer Receiving Report and existing buyer_weight; preserve native delivered/invoiced quantities and Odoo 19 UoM fields. | PLANNED |
| S07.02 | Create or reconcile one authorized draft using accepted buyer_weight quantity, confirmed sale price/UoM/tax/currency and justified charges; never let buyer Receiving Report rewrite price. | PLANNED |
| S07.03 | Gate automatic posting on mandatory receiving evidence and true commercial/accounting controls, not supplier packing/weight or carrier scale receipt. | PLANNED |
| S07.04 | Use the same business eligibility for native auto-post and custom entry paths; posted moves are never silently rewritten. | PLANNED |
| S07.05 | Handle consolidated/partial invoices only through existing proven native relationships; honor current transaction bill cardinality or hold the specific case. | PLANNED |
| S07.06 | Queue native invoice send to correct buyer billing recipient without supplier cost/identity leakage; dedupe creation, posting and send separately. | PLANNED |
| S07.07 | Demonstrate Customer Invoice from accepted buyer_weight proceeds while supplier RWN is pending for missing supplier weight, direct >5% human reconciliation, or ambiguous notice transport; CST documentary obligations and carrier chargebacks remain separate. | PLANNED |
| S07.08 | Use approved native credit/debit mechanisms for corrected report quantities and retain source lineage to original invoice. | PLANNED |
| S07.F01 | Bind accepted buyer_weight to verified native sale.order.line delivered/invoice quantity and account.move.line.quantity using actual UoM/policy, without writing computed qty_to_invoice or changing ordered quantity. | NOT_STARTED |

### Exit evidence

Real account.move quantities/taxes/totals correct, journal posted only when eligible, Customer Invoice sent once; replay/correction leaves accounting consistent.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No bank settlement, payment collection or forced full supplier AP implementation first.

### Stop conditions and material risks

Invoice_origin strings alone are not safe identity for multi-company or consolidated origins.

**Shared write surfaces:** plasticos_transaction/models/account_move_inherit.py; plasticos_transaction/models/transaction.py; plasticos_automation/data/email_templates.xml; plasticos_automation/__manifest__.py; plasticos_transaction/__manifest__.py

## S08. Party checklists, missing-document follow-up and review

Make document receipt/completeness/action status visible and automate collection.

**Owners:** plasticos_documents; plasticos_automation; plasticos_logistics

**Prerequisites:** S04

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R09; R12; R13; R19; R20; R21; R30; R34; R37; R38; R39; R43

**Acceptance cases:** T019; T033; T034; T035; T036; T037; T061; T062; T063; T064; T065; T066; T090; T099; T113; T114; T115; T122; T123; T124; T126; T153; T154; T155; T157; T161; T131; T142

**Inherited findings:** F03; F17

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-003; BR-EVD-004; BR-FLD-001; BR-FLD-003; BR-REC-001; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-WGT-007; BR-CAR-004

**BRS revision:** brs-documents@1.3.1

**Decisions:** D03; D09; D10; D15

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents/models/document_rule.py
plasticos_documents/models/document_validation_matrix.py
plasticos_documents/models/transaction_docs.py
plasticos_documents/models/compliance_service.py
plasticos_documents/data/scale_ticket_rule.xml
plasticos_documents/data/cron_missing_docs.xml
plasticos_documents/views/transaction_docs_views.xml
plasticos_automation/data/email_templates.xml
plasticos_automation/__manifest__.py
plasticos_documents/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S08.01 | Track mandatory buyer Receiving Report, supplier PL collection where applicable but nonblocking, optional Supplier/Buyer Scale Tickets, and required certified carrier CST gross/net per load even after commercial close. | PLANNED |
| S08.02 | Distinguish not received, received incomplete, parser failure, validated, conflicting and obligation resolved without claiming new selection values are approved. | PLANNED |
| S08.03 | Evaluate carrier CST certification and per-load CST gross/CST tare/CST net evidence independently from the packaging-tare billing calculation. CST or SCALE tag alone is not certification. Missing packaging data cannot by itself mark an otherwise complete CST missing or trigger the carrier penalty. | PLANNED |
| S08.04 | Apply current approved pickup/delivery-based party SLAs; separate document due/overdue logic from penalty accrual and never age new requirements from transaction creation blindly. | PLANNED |
| S08.05 | Reuse native document requests/reminder activities and native Email/SMS actions where the installed capability fits; add only missing party/calendar/rotation logic. Preserve request-versus-received state, correct TX/PO/SO/DO recipients and dedupe; a request placeholder never satisfies a document obligation. | PLANNED |
| S08.06 | Assign manager activities for genuine overdue/ambiguous exceptions, not the cron user or routine AI extraction; retain original no-internal-email escalation intent. | PLANNED |
| S08.07 | Provide native transaction/document panels and Missing Docs views showing missing type, source, reason, owner, due time, final action eligibility and pending penalty separately. | PLANNED |
| S08.08 | Handle all overdue records through bounded pagination; replay does not create daily duplicate open review tasks. | PLANNED |
| S08.09 | Keep open scale obligations visible after buyer invoicing AND normal commercial close. Missing scales do not block that close; a penalty never fabricates document receipt or documentary completeness. | PLANNED |
| S08.F01 | Check certified carrier CST issuer, complete gross/net and source receipt separately from packaging sufficiency; enforce own CST tag, post-close obligations and no false SCALE tag satisfaction. | NOT_STARTED |

### Exit evidence

Per-party checklist truthful; no false all-complete; timers/recipients accurate; nonblocking docs do not gate notice or AR.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No new dashboard platform; no silent waiver of required carrier scale evidence; no actual chargeback realization here.

### Stop conditions and material risks

A penalty deadline is not automatically the old 2/7 or 5/6/5 follow-up SLA.

**Shared write surfaces:** plasticos_documents/models/transaction_docs.py; plasticos_documents/models/compliance_service.py; plasticos_documents/views/transaction_docs_views.xml; plasticos_automation/data/email_templates.xml; plasticos_automation/__manifest__.py; plasticos_documents/__manifest__.py

## S09. Realize the USD 150 carrier CST-document penalty

Apply the carrier documentation rule once with auditable native accounting.

**Owners:** plasticos_automation penalty owner; plasticos_claims; Native account.move; plasticos_transaction financial rollups

**Prerequisites:** S02; S08

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R14; R15; R29; R38; R43; R50; R51; R54

**Acceptance cases:** T067; T068; T069; T070; T071; T072; T073; T074; T075; T076; T077; T078; T082; T115; T122; T124; T126; T157; T188; T189; T190; T191; T192; T193; T194; T195; T196

**Inherited findings:** F13; F14; F15

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-REC-001; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004; BR-WGT-007; BR-CAR-004; BR-UND-001; BR-UND-002; BR-UND-006; BR-UND-003; BR-UND-007

**BRS revision:** brs-documents@1.3.1

**Decisions:** D01; D03; D04; D05; D10; D11; D15; D16

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_automation/models/penalty_rule.py
plasticos_automation/models/account_move_penalty.py
plasticos_claims/models/claim.py
plasticos_transaction/models/transaction.py
plasticos_transaction/models/account_move_inherit.py
plasticos_automation/data/email_templates.xml
plasticos_automation/__manifest__.py
plasticos_claims/__manifest__.py
plasticos_transaction/__manifest__.py
plasticos_logistics/report/report_delivery_order.xml
plasticos_logistics/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S09.01 | Bind deadline, qualifying evidence, per-load unit, applicable carrier terms, effective date, currency and late-evidence treatment before autonomous assessment. | PLANNED |
| S09.02 | Assess the $150 carrier documentation penalty only for qualifying missing/incomplete certified CST under resolved D01/D03/D04/D05. Unknown packaging, failed OCR, duplicate delivery or absent optional supplier/buyer tickets is not by itself carrier noncompliance. Never multiply by missing component or pass the charge to supplier/buyer. | PLANNED |
| S09.03 | Distinguish absent carrier evidence from unreadable/unprocessed evidence or system intake outage; the latter is a processing exception before adverse action. | PLANNED |
| S09.04 | Create/update a replay-safe existing freight_chargeback case with claimed_amount 150 and correct carrier/load/company; two missing measurements are not two charges. | PLANNED |
| S09.05 | Use an approved native account.move adjustment/credit linked to the carrier invoice when ready; no bill yet means a pending chargeback, not a fabricated payment or deleted amount. | PLANNED |
| S09.06 | Prove expense, vendor balance, transaction margin and commission impacts count USD 150 exactly once; claim recovery rollup and bill reduction must not both inflate profit. | PLANNED |
| S09.07 | Notify carrier through approved template and durable queue with TX/load, missing evidence, due rule, amount and dispute route; never charge buyer or supplier for this carrier failure. | PLANNED |
| S09.08 | Replay after concurrency/restart and handle late ticket/dispute/waiver through recorded policy and native reversal, retaining original evidence. | PLANNED |
| S09.09 | Keep Customer Invoice/notice eligibility independent from this lane throughout. | PLANNED |
| S09.F01 | Evaluate one qualifying carrier missing certified CST chargeback only under open D01/D04/D05 approvals, never because packaging value alone is absent; reconcile carrier claim and native freight credit once. | NOT_STARTED |
| S09.11 | Keep carrier missing-CST $150 claim distinct from $0.01/lb material-net underweight; accept native contract-based buyer liability and supplier recovery as separate independently posted obligations. | PLANNED |

### Exit evidence

One qualifying missing/incomplete load produces the approved USD 150 effect once; valid complete evidence produces zero; no repeat penalty on cron replay; buyer workflow remains unblocked.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No blanket deductions on historical/paid carrier bills; no automatic legal assertion, cash withdrawal or unapproved USD conversion.

### Stop conditions and material risks

calculated/applied flags and chatter do not prove accounting effect.

Penalty acknowledgment, posted recovery and bank settlement remain distinct.

**Shared write surfaces:** plasticos_automation/models/account_move_penalty.py; plasticos_claims/models/claim.py; plasticos_transaction/models/transaction.py; plasticos_transaction/models/account_move_inherit.py; plasticos_automation/data/email_templates.xml; plasticos_automation/__manifest__.py; plasticos_claims/__manifest__.py; plasticos_transaction/__manifest__.py; plasticos_logistics/report/report_delivery_order.xml; plasticos_logistics/__manifest__.py

## S10. Complete supplier and freight AP, credits and deductions

Reduce routine AP transcription through existing native bill workflows.

**Owners:** Native purchase/account; plasticos_transaction; plasticos_automation

**Prerequisites:** S02; S04

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R06; R10; R15; R18; R23; R28; R32; R44; R47; R49; R50; R51; R52; R54

**Acceptance cases:** T057; T060; T079; T080; T081; T082; T083; T084; T167; T178; T169; T184; T185; T186; T187; T188; T189; T190; T191; T192; T193; T194; T195; T196; T197; T198; T199; T200; T205; T206; T207; T208; T209; T210; T211; T212

**Inherited findings:** None

**BRS rules:** BR-CAR-003; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-FLD-002; BR-REC-002; BR-REC-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-SET-006; BR-FLD-004; BR-REC-004; BR-WGT-010; BR-UND-001; BR-UND-002; BR-UND-006; BR-UND-003; BR-UND-007; BR-UND-004; BR-UND-005

**BRS revision:** brs-documents@1.3.1

**Decisions:** D02; D05; D10; D13; D15; D16

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_transaction/models/account_move_inherit.py
plasticos_transaction/models/transaction.py
plasticos_automation/models/account_move_penalty.py
plasticos_logistics/models/load.py
plasticos_automation/__manifest__.py
plasticos_logistics/__manifest__.py
plasticos_transaction/__manifest__.py
plasticos_transaction/models/purchase_inherit.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S10.01 | Reuse native invoice digitization and PO/freight terms matching for supplier and carrier bills; prevent dual alias/digitizer creation. | PLANNED |
| S10.02 | Preserve original invoice number/vendor/company/currency and multi-line charges; reconcile quantities, agreed rate, tax, freight and accessorial authorization. | PLANNED |
| S10.03 | Use normal supplier_weight payable basis and contractual supplier purchase terms. Apply >5% human-reviewed supplier-side resolution only through approved D13 eligibility; RWN shows price/deductions, and buyer_weight is never an implicit supplier payable replacement. | PLANNED |
| S10.04 | Honor one bill identity for a consolidated supplier/carrier invoice; field cardinality limitations are named exceptions, not ten duplicate bills. | PLANNED |
| S10.05 | Post eligible drafts automatically under accepted policy; uncertain commercial differences route to specific review, not universal human approval. | PLANNED |
| S10.06 | Link vendor/freight credits and corrections natively; consume the S09 economic-once contract when that lane is enabled. | PLANNED |
| S10.07 | Never treat remittance advice or invoice reconciliation as payment settlement; preserve pending/posted/cash distinctions. | PLANNED |
| S10.08 | Prove native move/transaction links, closed-transaction correction behavior and totals through replay and negative tests. | PLANNED |
| S10.F01 | Use native supplier purchase.order.line and vendor bill quantity/price/UoM/reconciliation; prohibit RWN from creating duplicate Vendor Bill or treating supplier quantity as buyer weight. | NOT_STARTED |
| S10.10 | Reuse BRS-007 BR-UND-002 deterministic obligation-scoped 53-ft 40000-lb minimum, inclusive 2000-lb trigger, effective 0.01*(shortfall_lbs/2000) prorated continuously including partial 500 lb; total is actual material net times effective rate, only final USD cents rounded. Separate buyer liability and supplier recovery must have independently proven contract, native accounting and no double counting (D16). | PLANNED |
| S10.11 | Migrate obsolete final_weight/light_weight_deduction/dead_freight_chargeback consumers to proposed _compute_light_weight_deduction_total and contract-aware native finance without inventing a second field. | PLANNED |
| S10.90 | Replace obsolete fixed-shortfall and completed-500 weight deduction with BRS-007 BR-UND-002 continuous partial-500 effective rate on actual material net; bind separate financial owners, actual zero rate, final cents only and protected Odoo installed method/field migrations. | PLANNED |

### Exit evidence

Supplier/freight invoices become correct linked drafts and eligible posted moves without transcription; discrepancies, duplicates and unsupported allocation fail safely.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No historical SQL/CRM import changes, parallel ledger or bank-payment automation.

### Stop conditions and material risks

S10 does not gate S06/S07.

**Shared write surfaces:** plasticos_transaction/models/account_move_inherit.py; plasticos_transaction/models/transaction.py; plasticos_automation/models/account_move_penalty.py; plasticos_logistics/models/load.py; plasticos_automation/__manifest__.py; plasticos_logistics/__manifest__.py; plasticos_transaction/__manifest__.py

## S11. Cover remaining operational and supporting documents

Close the declared ordinary-document inventory without speculative document expansion.

**Owners:** Existing document/transaction/logistics/claim/partner owners

**Prerequisites:** S04

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R24; R28; R33; R34

**Acceptance cases:** T084; T085; T086; T087; T088; T089; T090; T091; T100; T110; T112; T127

**Inherited findings:** None

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-FLD-003; BR-REC-001; BR-REC-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**BRS revision:** brs-documents@1.3.1

**Decisions:** D08; D15

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
plasticos_documents_native/models/document_native.py
plasticos_documents_native/models/document_sync.py
plasticos_claims/models/document_inherit.py
plasticos_claims/models/claim.py
plasticos_documents/models/document.py
plasticos_claims/__manifest__.py
plasticos_documents/__manifest__.py
plasticos_documents_native/__manifest__.py
plasticos_automation/data/email_templates.xml
plasticos_automation/__manifest__.py
plasticos_logistics/report/report_delivery_order.xml
plasticos_logistics/report/report_bol_pickup.xml
plasticos_logistics/report/report_bol_delivery.xml
plasticos_logistics/__manifest__.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S11.01 | Qualify all remaining matrix rows including supplier Packing List, duplicate supplier/carrier BOL copies, optional supplier/buyer scale tickets, mandatory Receiving Report, outbound RWN/invoice and required carrier gross/net without adding enum values. | PLANNED |
| S11.02 | Apply only field-specific facts the source can authorize; orders confirm existing terms, contracts do not silently reprice deals, remittance does not mark payment. | PLANNED |
| S11.03 | Use existing claim lifecycle for quality/damage/rejection, with source attachments and no duplicate case from repeated email. | PLANNED |
| S11.04 | Route identity/bank/tax/onboarding changes to protected owner review; preserve valid evidence even when no automatic master-data action is allowed. | PLANNED |
| S11.05 | Use existing material/profile relations for certificates without permitting a certificate to overwrite global taxonomy or grade meaning. | PLANNED |
| S11.06 | Confirm each unsupported format or ambiguous class has one named exception path, not a silent drop or permanent requirement to read all documents manually. | PLANNED |

### Exit evidence

Every coverage row has an automated path or specific justified exception; source and destination correctness demonstrated with representative samples.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No outside document universe, external enrichment redesign or new compliance platform.

### Stop conditions and material risks

All-doc scope is the declared ordinary workflow, not a claim to understand every possible file.

**Shared write surfaces:** plasticos_documents_native/models/document_native.py; plasticos_documents_native/models/document_sync.py; plasticos_claims/models/claim.py; plasticos_documents/models/document.py; plasticos_claims/__manifest__.py; plasticos_documents/__manifest__.py; plasticos_documents_native/__manifest__.py; plasticos_automation/data/email_templates.xml; plasticos_automation/__manifest__.py; plasticos_logistics/report/report_delivery_order.xml; plasticos_logistics/__manifest__.py

## S12. Prove the whole workflow and activate coherently

Demonstrate no-routine-transcription outcomes and safe operation on exact deployed code.

**Owners:** Independent review owner; Odoo deployment operator; Business operations owner

**Prerequisites:** S06; S07; S08; S09; S10; S11

**Execution status:** NOT_STARTED_BY_THIS_CAMPAIGN

**Activation status:** NOT_AUTHORIZED

**Requirements:** R22; R24; R25; R26; R27; R30; R31; R35; R36; R45; R46; R47; R48; R49; R50; R51; R52; R53; R54; R55

**Acceptance cases:** T094; T095; T096; T097; T098; T099; T116; T118; T119; T120; T121; T125; T129; T170; T180; T181; T182; T183; T184; T185; T186; T187; T188; T189; T190; T191; T192; T193; T194; T195; T196; T197; T198; T199; T200; T202; T203; T204; T213; T214; T215; T216; T217; T218; T219; T220; T221; T222; T223

**Inherited findings:** F10

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-CST-001; BR-CST-002; BR-DOC-001; BR-EVD-002; BR-EVD-003; BR-EVD-004; BR-EVD-005; BR-EVD-006; BR-FLD-001; BR-FLD-002; BR-FLD-003; BR-FLD-004; BR-REC-001; BR-REC-002; BR-REC-003; BR-REC-004; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-UND-001; BR-UND-002; BR-UND-003; BR-UND-004; BR-UND-005; BR-UND-006; BR-UND-007; BR-VOC-001; BR-WGT-001; BR-WGT-008; BR-WGT-009; BR-WGT-010; BR-SET-006; BR-WGT-002; BR-WGT-005; BR-WGT-006

**BRS revision:** brs-documents@1.3.1

**Decisions:** D06; D11; D16; D18

### Proposed scope, not an execution grant

Scope proposal only. No native/Enterprise source edits; any inherited action or view extension belongs in the existing custom owner.

```text
Affected existing tests and module manifests only under separately authorized slice
plasticos_commission/models/sales_dashboard.py
```

### Granular tasks

| ID | Required result | State |
|---|---|---|
| S12.01 | Assemble representative consented/anonymized sample corpus by matrix class; preserve expected facts, recipients, accounting outcomes and unresolved cases. | PLANNED |
| S12.02 | Run focused unit, ORM, native mail/AI, security, concurrent replay and accounting tests in verified disposable Enterprise-equivalent Odoo with outbound interception. | PLANNED |
| S12.03 | Prove golden path with accepted buyer Receiving Report and accepted supplier_weight, no supplier PL or optional scale tickets and absent required carrier certified CST gross/net: supplier RWN uses supplier_weight+price+valid deductions, Customer Invoice uses buyer_weight, carrier missing obligation remains visible and one eligible USD 150 event occurs only after its approved due rule. | PLANNED |
| S12.04 | Verify BRS fields/labels, CST tare terminology, strict >5% boundary, separate supplier/buyer quantities, two-stage CST arithmetic, source-specific packaging and independent CST receipt. Execute required CI negative tests and actual disposable Odoo cases; package-only tests never prove runtime behavior. | PLANNED |
| S12.05 | Observe read-only/shadow extraction then bounded authorized apply/send/post; use native supported controls, not an added control-plane platform. | PLANNED |
| S12.06 | Measure per-class volume, touchless completions, review reasons, human minutes, duplicate effects, missing-doc age and outgoing failures using actual observed data. | PLANNED |
| S12.07 | Rehearse provider outage, mail failure, partial rollback, late corrections and feature disable while retaining sources and native queued work. | PLANNED |
| S12.08 | Produce exact revision/module/config/test receipts and operator rollout grant; never promote structural roadmap validation to runtime proof. | PLANNED |
| S12.09 | Close the campaign only when all required cases have demonstrated behavior or specifically accepted exception disposition and no material unknown is represented as PASS. | PLANNED |
| S12.F01 | Run joined three-source weight fixture plus exact installed-registry checks, existing legacy consumer compatibility tests, native AR/AP posting isolation, CI field-negative witnesses and replay acceptance. | NOT_STARTED |
| S12.11 | Prove operator vocabulary, direct >5% human review, two-sided underweight contractual attribution, 38,001/38,000/36,000 tests, approved method migration and one-owner BRS authority at exact installed runtime. | PLANNED |
| S12.90 | Execute standalone numbered BRS index/traceability and native core accepted 53ft rate tests against real changed target revision, with known-bad floor-500, shortfall-times-rate, premature rounding and duplicate normative owner mutants. No CI or runtime PASS without executed receipts. | PLANNED |

### Exit evidence

Golden path plus adverse cases proven on exact environment; business users can operate exception-only workflow; rollback and source trace are usable.

Existing affected module tests plus named cross-module contracts; add a focused test file only where no existing test can express the obligation.

Task closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.

### Exclusions

No deployment/merge/send authority implied by this pack; no benchmark accuracy invented.

### Stop conditions and material risks

A successful fixture is not production success; no repeated full-suite ceremonies without new proof obligation.
