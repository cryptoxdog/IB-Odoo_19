# v1.2.1 Field-Level Drift Audit and Reconciliation Ledger

**Scope:** exact v1.1.1 package, immutable historical sources, inspected `cryptoxdog/IB-Odoo_19` Staging at `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, and public Odoo 19.0 native field declarations. This is **source and package** analysis, not an Odoo runtime, live CI, or independent-agent audit. **Approval:** the operator requested comprehensive implementation specificity and preservation of the established `brs-documents` meanings. No new operational settlement condition or field is silently admitted.

## Drift categories, evidence and disposition

| Finding | Predecessor deficiency or observed source behavior | Package resolution / exact owner | Closure class |
|---|---|---|---|
| D12-F01 | Three weight groups described conversationally, without source specific gross/scale tare/net/packaging evidence dictionary | `brs-documents` §11 + `FIELD_ROUTING_AND_CONFORMANCE.md` 35 candidate typed facts for supplier, buyer and carrier CST; explicit non-ORM notation | SPEC_RESOLVED; persistence D08 remains OPEN |
| D12-F02 | No census of exact native/custom field labels/types/owners for the full source-to-invoice handoff | Source-declared register of 147 touched fields, verified code paths, native 19.0 model blob SHAs and field owners, linked technical write policy and consumer | SPEC_RESOLVED; installed field registry NOT_RUN |
| D12-F03 | Supplier and buyer optional scales conflated with carrier certified CST | Distinct source physical gross/scale tare/scale net for supplier and buyer, separate carrier CST certification, existing `SCALE` vs `CST` codes and document-role decision table | SPEC_RESOLVED; source code change NOT_RUN |
| D12-F04 | No explicit source facts per PL/Receiving Report, mixed Gaylords/pallets or packaging semantics | Per-source counts, gross/net, combined package rules, 40/40/80 lb, no double tare, D15 for mixed/boxes | SPEC_RESOLVED; D15 OPEN |
| D12-F05 | Conditional `scale_weight` population versus exceptional supplier settlement selection not cleanly separated | Source scale material-net may be retained when eligible and validated; supplier settlement above a strict >5% direct commercial spread requires human reconciliation (D13); `scale_weight` is reference-only and no automatic substitute is allowed. No cross-party fallback. | SPEC_RESOLVED; D13 OPEN |
| D12-F06 | Native invoice entry point unspecified beyond 'use buyer_weight' | Exact verified native `sale.order.line` delivered/ordered/computed to-invoice fields, `purchase.order.line` native received and billable fields, and `account.move.line.quantity`, UoM and company/price guards | SPEC_RESOLVED; installed route NOT_RUN |
| D12-F07 | Existing `gross_weight`/`final_weight` and source winner could be used as generic physical and billable net | Explicit forbidden semantics, actual `_compute_final_weight`/deduction/commission dashboard consumers and impacted owner tests | SPEC_RESOLVED; code remediation NOT_RUN |
| D12-F08 | Generic `SCALE` associated with carrier compliance rule, native `doc_type=scale_ticket` sync maps all to generic `SCALE` | Explicit existing CST tag code, role/certification and load gates, mandatory source-level remediation in S02/S04/S08 | SPEC_RESOLVED; code remediation NOT_RUN |
| D12-F09 | Generic `is_compliant` held out_invoice if any unrelated required doc absent | Precise out_invoice operation gate requiring accepted buyer Receiving Report, not supplier PL/CST, assigned S02/S07 regression | SPEC_RESOLVED; code remediation NOT_RUN |
| D12-F10 | Generated acceptance cases used wrong class IDs, e.g. carrier invoice rather than Receiving Report | T130-T180 linked to accurate C01-C33 current class IDs; coverage back-references regenerated | SPEC_RESOLVED; Odoo runtime NOT_RUN |
| D12-F11 | No actual numeric fixture vectors for individual lanes and >5% boundary | 12 worked examples with Decimal crosschecks for CST, supplier/buyer packaging, current-code denominator, pending D13 and no automatic buyer fallback | SPEC_RESOLVED; business denominator D13 OPEN |
| D12-F12 | No field-level CI prevention or actual positive/negative acceptance owner | Named T177-T180 installed field registry, native finance and CI witnesses; checker rejects source-role swaps, renamed labels/types, invented fields, CST taxonomy, computed native quantity mutations | SPEC_RESOLVED; repository CI integration NOT_RUN |
| D12-F13 | v1.1.1 derived specs had incorrect blanket counts (source said 129) | Reconciled exactly 180 acceptance cases, 47 requirements, 26 findings and 119 tasks in machine owners and rendered views | SPEC_RESOLVED; deployment NOT_RUN |
| D12-F14 | v1.1.1 had no agreed durable representation for multi-fact provenance and logical-document source location | D08 explicitly remains a bounded technical representation question; unverified installed Enterprise metadata is never promoted to an existing ORM field | SPEC_RESOLVED; D08 OPEN |

## Business and architectural boundaries preserved

- Buyer **Receiving Report** mandatory for full buyer invoice using `plasticos.transaction.buyer_weight`; optional buyer scale cannot substitute. Independent buyer invoicing must not wait for supplier RWN or absent CST.
- Supplier RWN outbound to supplier normally `supplier_weight`, strictly >5% direct discrepancy sent to human review; packaging-adjusted scale material net is REFERENCE ONLY. Supplier payable amount uses native PO purchase price and approved deductions; no invented fallback when supplier source quantity absent.
- Carrier Certified Scale Ticket gross and net are required per load but not buyer AR/close blockers; CST **gross − CST tare = CST net; CST net − applicable packaging tare = net weight billed**. Missing packaging alone is not missing CST or a $150 penalty.
- Supplier and buyer optional scale tickets may not be certified. No `shipper_weight`, `received_weight`, `cst_net_weight`, new `doc_type` choice, or universal `final_weight` is admitted.
- `brs-logistics` remains deferred. Original starting plan and prior development ZIP remain byte-identical.

## Open boundaries, not concealed omissions

- D08: Confirm actual installed native Enterprise metadata and durable typed per-document source evidence; no schema addition approved.
- D13: Confirm complete >5% denominator/independent scale comparison qualification and older plan extra predicates; normal RWN and buyer AR independently safe.
- D14: Without supplier settlement basis, hold RWN/affected AP only, not buyer invoice.
- D15: Source-side mixed/boxes packaging handling without inventing tare defaults.
- D01/D03/D04/D05: Exact carrier CST sufficiency, penalty clock/event unit and financial realization prerequisites.
- Native Enterprise apps, Odoo.sh installed registry, invoice send/post hooks and runtime conformance remain **NOT RUN**.

## Verification and residual risk

Pack checker validates declared source/field graphs, exact BRS/ADR digest, byte-identical historical sources, derived view equivalence, source naming policy, worked-example arithmetic, tests/coverage edges, companion field view and negative in-memory witnesses. These are **pack-level proofs only**. They do **not** certify every possible business ambiguity, full repo codebase closure or Odoo runtime behavior. No repo or database mutation performed.

## v1.2.1 additional accepted policy and name-migration findings

| Finding | Observed drift | Repaired planning contract | Runtime state |
|---|---|---|---|
| V121-F01 | Old RWN and supplier AP permitted automatic scale substitution in a >5% exceptional branch | `scale_weight` reference only; direct supplier-vs-buyer spread >5% always human-reviewed. 4% below/above CST witness cannot bypass primary spread. | NOT_RUN |
| V121-F02 | Measurement terms mixed CST load net with material net, and document weight with accepted commercial basis | Five exact operator-approved terms and single owning weights BRS; CST gross/CST tare/CST net, packaging and material net remain independent stages | NOT_RUN |
| V121-F03 | Existing `_compute_light_weight_deduction` charged any shortfall, used `final_weight`, and defaulted zero rate through `or 0.01` | Underweight BRS accepted full material-net charging base, 53-foot 40,000 min / 2,000 lb threshold, operator-resolved D17 continuous prorated rate, D16 accounting separation; T188-T193 | NOT_RUN |
| V121-F04 | `dead_freight_chargeback` Boolean read purchase cost, not a real separately accepted underweight obligation | Old Boolean business semantics retired; actual code/schema removal requires verified consumer migration (D08) | NOT_RUN |
| V121-F05 | Unclear method/field naming and one transaction amount could conflate buyer liability and supplier recovery | Proposed `_compute_light_weight_deduction_total`, pending `light_weight_deduction_total` rename, calculated NON-ORM `light_weight_deduction_weight`, independent native Sales/Purchase/Claims/Accounting D16 | NOT_RUN |
| V121-F06 | One giant BRS mixed documentary authority, weight physical arithmetic and financial attribution | Two new scoped BRS files with exactly one accepted rule owner, ADR-025 amended to per-concern ownership and family index, no `brs-logistics` created | NOT_RUN |

All v1.2.0 original source inputs are preserved. New operator evidence `source_inputs/OPERATOR_WEIGHT_CONVERGENCE_2026-10-19.md` is a separate explicitly current instruction record. No GitHub code or live Odoo field migration was performed.

**V121-F04 · HISTORICAL RATE CONFLICT NOW RESOLVED (D17):** The predecessor mixed flat $0.01 per shortfall pound with incompatible $200/$400 illustrations. Current U07 and BRS-007 BR-UND-002 supersede both: effective continuous prorated rate applies to material-net quantity after inclusive 2000 lb threshold. Historical source evidence is preserved; only D16 contract and native financial attribution remains OPEN.

## v1.3.1 new scoped repairs and independent concerns

| ID | Predecessor risk | Bounded local repair | Acceptance |
|---|---|---|---|
| V130-1 | A 45 KB omnibus unnumbered Documents BRS plus two unnamed concern files was hard to bind precisely. | Split 46 original stable rules into seven uniquely numbered `BRS-001..007`; norm text exactly once, machine index, human index and rule-test trace. | `check_brs.py` unique index/owner/hash tests and T201-T203; repo admission remains proposed. |
| V130-2 | D17 arithmetic conflict allowed incompatible $20/$40 and $200/$400 variants. | Accepted operator continuously prorated per-$500 effective rate, calculated on actual material net. D17 resolved historical, D16 contracts still open. | Pure-Decimal vectors, T205-T215, exact 38,001/38,000/37,750/37,501/37,500/36,000. |
| V130-3 | Floor-completed-500 step lowered charges at 2,250 lb and 2,499 lb shortfall. | No `floor`/`ceil`; fractional step prorated, no intermediate rate rounding; final USD cents half-up. | 12 BRS known-bad negative controls; live Odoo NOT_RUN. |
| V130-4 | Campaign generated tasks, views and tests could still cite obsolete BRS paths or D17 monetary hold. | Regenerate five derived reports from campaign graph; update version/owner/paths and acceptance, preserve predecessor exact bytes. | New source-bound artifact validator + policy assertions + derived parity + manifest. |
| V130-5 | Existing Odoo method/Boolean/`final_weight` conflict with approved business meaning. | Document controlled rename/retirement, including `_compute_light_weight_deduction_total()` and no extra weight ORM field; exact installed dependency census required. | NOT_RUN until an authorized isolated Odoo implementation PR proves full consumer migration. |
