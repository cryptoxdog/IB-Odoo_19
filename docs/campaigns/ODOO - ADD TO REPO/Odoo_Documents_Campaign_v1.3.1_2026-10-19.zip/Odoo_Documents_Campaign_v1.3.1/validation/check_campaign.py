#!/usr/bin/env python3
"""Validate this local planning artifact, not Odoo code or business runtime.

Only reads the campaign/input files unless --write-report is explicitly supplied.
Negative controls mutate independent in-memory copies, never repository artifacts.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
from pathlib import Path
import sys
import zipfile

INPUTS = {'LATEST_OPERATOR_INSTRUCTION.txt': '70c341a86d86d9c8344de48e181ab4fbdcca448a62dfaa3cb8cdacebca7ed0b9', 'OPERATOR_BRS_DECISIONS_2026-10-19.md': '4d6937479f84a8b8fa3a847f7c70d94dc672b921cd517a4b2fc2259a0433d730', 'Odoo19_Documents_Revised_Intent_Dev_Pack_2026-10-18.zip': '388ae55a8aa4843ff4d43a91cadde779312d27415a884f0fb4fcc2549f0a7ccd', 'document_transaction_match_3a3f9d7d.plan.md': '5d69e3d5f9efea48ed96885b6200dc2c5b32377679bc4291635a5278eea3a4d1', 'OPERATOR_FIELD_FLOW_INTENT_2026-10-19.txt': '55c0e1756696678568d2c807a2edc954fd5a1c0c755f3e8f098b8e48218d53ae', 'OPERATOR_WEIGHT_CONVERGENCE_2026-10-19.md': 'ca1296cc7883dfef35a5a331e74181510dea64294d284c7f68973e1b0e29dce4'}
DOCS = ('README.md',
 'CAMPAIGN_SPEC.md',
 'ROADMAP.md',
 'DOCUMENT_COVERAGE.md',
 'ACCEPTANCE.md',
 'SOURCES_DECISIONS_AND_GAPS.md',
 'EXECUTION_HANDOFF.md',
 'FIELD_ROUTING_AND_CONFORMANCE.md',
 'docs/adr/ADR-025-business-rules-specification-authority.md',
 'docs/business-rules/README.md',
 'docs/business-rules/TRACEABILITY.md',
 'docs/business-rules/BRS-001-document-classes-and-identity.md',
 'docs/business-rules/BRS-002-document-evidence-and-control.md',
 'docs/business-rules/BRS-003-weights-and-packaging.md',
 'docs/business-rules/BRS-004-supplier-settlement-and-rwn.md',
 'docs/business-rules/BRS-005-buyer-receiving-and-invoicing.md',
 'docs/business-rules/BRS-006-carrier-cst-and-document-collection.md',
 'docs/business-rules/BRS-007-underweight-and-chargebacks.md')


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def unique(items: list[dict], label: str) -> set[str]:
    keys = [x['id'] for x in items]
    require(len(keys) == len(set(keys)), 'duplicate '+label)
    return set(keys)

def validate_data(d: dict) -> dict:
    slices=unique(d['slices'],'slice'); nodes=unique(d['nodes'],'node')
    reqs=unique(d['requirements'],'requirement'); tests=unique(d['acceptance'],'test')
    docs=unique(d['coverage'],'coverage'); sources=unique(d['governing_sources'],'source')
    decisions=unique(d['decisions'],'decision'); findings=unique(d['findings'],'finding')
    policy_ids=unique(d['policy_delta'],'policy_delta')
    require({'POL22','POL23','POL24','POL25'}<=policy_ids,'missing/superseded delta identity')
    tasks=[t for s in d['slices'] for t in s['tasks']]
    unique(tasks,'task')
    require(slices <= nodes,'slice node missing')
    p=d['policy']
    for k in ('buyer_receiving_report_required','carrier_scale_gross_required_every_load',
              'carrier_scale_net_required_every_load','carrier_cst_certification_required',
              'rwn_requires_valid_supplier_settlement_quantity','no_invented_weight_alias_fields'):
        require(p[k] is True,'required policy not true: '+k)
    for k in ('supplier_packing_list_blocks_notice_or_ar',
              'supplier_weight_blocks_buyer_invoice',
              'carrier_scale_document_obligation_blocks_notice_or_ar',
              'carrier_scale_blocks_commercial_close',
              'rwn_delivery_blocks_ar','auto_schema_additions_authorized',
              'supplier_scale_certified_by_default','buyer_scale_certified_by_default',
              'carrier_cst_billable_quantity_automatically_overrides_buyer_weight',
              'carrier_cst_billable_quantity_automatically_overrides_supplier_weight',
              'carrier_cst_billable_quantity_automatically_sets_final_weight'):
        require(p[k] is False,'nonblocking/authorization policy violated: '+k)
    require(p['carrier_penalty_amount']=='150.00','penalty amount changed')
    require(p['scale_weight_reference_only'] and not p['scale_weight_automatic_settlement_authority'],'scale falsely payable')
    require(p['human_review_required_above_five_percent'] and p['direct_supplier_buyer_review_not_waived_by_two_near_CST_checks'],'commercial spread bypass')
    require(p['light_weight_threshold_inclusive'] and p['underweight_obligation_scoped'],'deduction threshold/obligation broken')
    require(p['light_weight_monetary_rate_status']=='OPERATOR_APPROVED_CONTINUOUS_PRORATION_D17_RESOLVED' and p['light_weight_automatic_posting_without_contract'] is False,'unapproved rate/financial authority')
    require(p['dead_freight_chargeback_semantics']=='OBSOLETE_BOOLEAN_NO_DISTINCT_ACCEPTED_POLICY_RETIRE_PENDING_MIGRATION','obsolete Boolean treated as law')
    must_equal={
      'carrier_cst_means':'CERTIFIED_SCALE_TICKET',
      'carrier_required_document_business_name':'CST_CERTIFIED_SCALE_TICKET',
      'carrier_cst_intermediate_net':'CST_GROSS_MINUS_CST_TARE',
      'carrier_cst_billed_net':'CST_NET_MINUS_APPLICABLE_PACKAGING_TARE',
      'carrier_cst_measurement_chain':'CST_GROSS_MINUS_CST_TARE_EQUALS_CST_NET;CST_NET_MINUS_PACKAGING_TARE_EQUALS_NET_WEIGHT_BILLED',
      'carrier_cst_scale_weight_write':'VERIFIED_PACKAGING_ADJUSTED_MATERIAL_NET_REFERENCE_ONLY',
      'buyer_invoice_quantity_field':'plasticos.transaction.buyer_weight',
      'rwn_default_quantity_field':'plasticos.transaction.supplier_weight',
      'rwn_exception_quantity_field':'REFERENCE_SCALE_ONLY_REVIEWER_DECIDES_AUTHORIZED_COMMERCIAL_CORRECTION',
      'rwn_discrepancy_trigger':'STRICTLY_GREATER_THAN_5_PERCENT',
      'buyer_receiving_report_document':'INBOUND_FROM_BUYER',
      'received_weight_notice_document':'OUTBOUND_TO_SUPPLIER_SETTLEMENT',
      'brs_logistics_status':'DEFERRED_NOT_CREATED',
    }
    for key,expected in must_equal.items():
        require(p[key]==expected,'business policy drift: '+key)
    brs=d['business_rules_binding']
    require(brs['id']=='brs-documents' and brs['version']=='1.3.1' and brs['charter_id']=='ADR-025','wrong numbered family selector')
    require(brs['index_path']=='docs/business-rules/index.json' and brs['human_index_path']=='docs/business-rules/README.md','wrong index paths')
    require(brs['family_role']=='NON_NORMATIVE_ROUTING_INDEX_NOT_AN_EIGHTH_BRS','non-normative index promoted')
    scopes=brs['scoped_concerns']
    require([x['id'] for x in scopes]==[f'BRS-{i:03}' for i in range(1,8)],'BRS numbering gap')
    require(brs['concern_authority']=='ONE_NUMBERED_BRS_FILE_PER_SCOPED_CONCERN_NO_DUPLICATE_RULE_OWNER','one-owner business law absent')
    claimed=[rid for scope in scopes for rid in scope['rule_ids']]
    require(len(claimed)==len(set(claimed)) and len(claimed)==46,'BRS duplicate/lost rule IDs')
    require(set(claimed)==set(brs['rule_ids']),'indexed BRS family rule set incomplete')
    require(not brs.get('remaining_document_rule_ids'),'unnumbered residual normative owner present')
    for scope in scopes:
        require(scope['version']=='1.0.1' and scope['normative_path'].startswith('docs/business-rules/'+scope['id']+'-'),'bad owner path/version')
    for obj in d['slices']+d['requirements']+d['coverage']+d['acceptance']:
        require(set(obj.get('brs_rule_ids',[]))<=set(claimed),'undeclared BRS reference on '+obj['id'])
    require({'BR-VOC-001','BR-WGT-010','BR-UND-002','BR-DOC-001'}<=set(claimed),'required current BRS identities absent')
    identities={x['identity'] for x in d['exact_brs_field_bindings']}
    require(len(identities)==len(d['exact_brs_field_bindings']),'duplicate exact BRS identity')
    require({'plasticos.transaction.supplier_weight','plasticos.transaction.buyer_weight',
             'plasticos.transaction.scale_weight','plasticos.load.seal_number'} <= identities,
            'missing exact source field identity')
    forbidden=('shipper_weight','received_weight','net_weight_billed','cst_net_weight','final_billed_weight')
    require(not any(any(identity.endswith('.'+bad) for bad in forbidden) for identity in identities),
            'invented technical weight field synonym')
    ratebinding=next(x for x in d['exact_brs_field_bindings'] if x['identity']=='plasticos.transaction.light_weight_deduction_rate')
    require('D17 arithmetic RESOLVED' in ratebinding['use_contract'] and 'actual accepted obligation-specific material net' in ratebinding['use_contract'],'obsolete D17 rate conflict in active technical contract')
    require('0.10/lb' not in ratebinding['use_contract'] and 'D17 OPEN' not in ratebinding['use_contract'],'stale historical LWD rate in accepted field contract')
    require(p['carrier_penalty_party']=='carrier','wrong liability party')
    require(p['carrier_penalty_deadline']=='UNKNOWN_PENDING_D01','unapproved deadline silently resolved')
    for k in ('repository_mutation','database_mutation','send','post','merge','deploy'):
        require(d['authorization'][k] is False,'unauthorized execution grant: '+k)
    graph={i:set() for i in nodes}
    edge_keys=set()
    for e in d['edges']:
        require(e['source'] in nodes and e['target'] in nodes,'dangling edge')
        require(e['relation'] in ('prerequisite','runtime_prerequisite'),'unknown relation')
        key=(e['source'],e['target'],e['relation'])
        require(key not in edge_keys,'duplicate edge');edge_keys.add(key)
        graph[e['target']].add(e['source'])
    def ancestors(node: str, visiting: set[str] | None=None) -> set[str]:
        visiting=set() if visiting is None else set(visiting)
        require(node not in visiting,'dependency cycle')
        visiting.add(node); found=set(graph[node])
        for q in graph[node]:found |= ancestors(q,visiting)
        return found
    for node in nodes:ancestors(node)
    require(not (ancestors('S07') & {'S06','S08','S09','S10'}),'false AR prerequisite')
    require('S05' in ancestors('S06') and 'S05' in ancestors('S07'),'receiving predecessor missing')
    for s in d['slices']:
        require(set(s['depends_on']) <= slices,'unknown slice prerequisite')
        declared={e['source'] for e in d['edges'] if e['target']==s['id'] and e['relation']=='prerequisite'}
        require(declared==set(s['depends_on']),'slice/graph mismatch')
        require(bool(s['owners']) and bool(s['tasks']) and bool(s['acceptance']),'empty slice contract')
        require(set(s['requirement_ids']) <= reqs,'unknown slice obligation')
        require(set(s['acceptance_ids']) <= tests,'unknown slice test')
        require(set(s['decision_refs']) <= decisions,'unknown slice decision')
        require(s['activation_status']=='NOT_AUTHORIZED','slice activation falsely authorized')
    for r in d['requirements']:
        require(set(r['owner_slices']) <= slices and bool(r['owner_slices']),'missing requirement owner')
        require(set(r['source_refs']) <= sources,'unknown requirement source')
        require(set(r['acceptance_ids']) <= tests and bool(r['acceptance_ids']),'uncovered requirement')
        actual={t['id'] for t in d['acceptance'] if r['id'] in t['requirements']}
        require(actual==set(r['acceptance_ids']),'requirement/test trace mismatch')
    for c in d['coverage']:
        require(set(c['owner_slices']) <= slices and bool(c['owner_slices']),'missing coverage owner')
        require(set(c['acceptance_ids']) <= tests and bool(c['acceptance_ids']),'untested document class')
        for key in ('extract','authoritative_source','destination','validation','automatic_action','exception','blocking_policy'):
            require(bool(c[key]),'missing coverage contract '+key)
    legacy={x for c in d['coverage'] for x in c['legacy_v4_items']}
    require(len(legacy)==18,'original eighteen dossier items not closed')
    for t in d['acceptance']:
        require(set(t['requirements']) <= reqs,'unknown test obligation')
        require(set(t['slices']) <= slices,'unknown test slice')
        require(set(t['coverage']) <= docs,'unknown test coverage')
        require(t['execution_status']=='NOT_RUN' and t['receipt'] is None,'fabricated runtime test result')
        for key in ('given','when','expected','proof_kind'):require(bool(t[key]),'empty test assertion')
    for f in d['findings']:
        require(f['owner_slice'] in slices,'missing finding owner')
        require(f['source_ref'] in sources and bool(f['disposition']),'finding source/disposition missing')
    for f in d['field_mapping']:
        require(bool(f['owner']) and bool(f['write_contract']),'field ownership/contract absent')
        require(set(f['source_refs']) <= sources,'field source unknown')
        require(set(f['owner_slices']) <= slices,'field slice unknown')
    require(d['version']=='1.3.1','wrong campaign version')
    require(d['business_rules_binding']['version']=='1.3.1','wrong indexed BRS version')
    validate_field_routing(d)
    for key,value in EXPECTED_POLICY.items():
        require(p.get(key)==value,'protected policy drift: '+key)
    actual_fields={x['identity']:(x['owner'],x['source_declared_label'],x['type_at_pinned_source']) for x in d['exact_brs_field_bindings']}
    require(actual_fields==EXPECTED_FIELDS,'exact field identity/owner/label/type drift')
    actual_surfaces={x['field_or_surface']:x['owner'] for x in d['field_mapping']}
    require(actual_surfaces==EXPECTED_SURFACES,'field surface or owner drift')
    for s in d['slices']:
        require(s['brs_binding_id']=='brs-documents@1.3.1' and s['required_brs_revision']=='brs-documents@1.3.1','stale slice BRS binding')
        require(s['id']=='S00' or bool(s['mutation_paths']),'empty implementation scope')
        require(s['execution_status']=='NOT_STARTED_BY_THIS_CAMPAIGN' and not s['closure_evidence'],'false slice execution evidence')
    for q in d['decisions']:
        actual={s['id'] for s in d['slices'] if q['id'] in s['decision_refs']}
        require(actual==set(q['affected_slices']),'decision/slice reference disagreement: '+q['id'])
        require(q['status']==('RESOLVED_OPERATOR_2026_10_19' if q['id']=='D17' else 'OPEN_BOUND_TO_AFFECTED_ACTION'),'unauthorized decision resolution: '+q['id'])
        require(bool(q['blocker_scoping']) and bool(q['reference_semantics']),'unscoped decision')
    for n in d['nodes']:
        match=next((s for s in d['slices'] if s['id']==n['id']),None)
        if match:require(n['title']==match['title'],'node/slice naming disagreement')
    for t in d['acceptance']:
        require(len(t['expected'].strip())>=30,'non-specific acceptance result')
    for obj in tasks:
        require(len(obj['description'].strip())>=30,'non-specific task')
    active_json=json.dumps(d,ensure_ascii=False)
    require(not BAD_CST.search(active_json),'CST terminology drift in campaign data')
    return dict(slices=len(slices),tasks=len(tasks),requirements=len(reqs),document_classes=len(docs),
                original_dossier_items=len(legacy),acceptance_cases=len(tests),findings=len(findings),
                bounded_decisions=len(decisions),nodes=len(nodes),edges=len(d['edges']))

def negative_controls(d: dict) -> list[str]:
    mutations=[
      ('resurrect_D17_rate_conflict',lambda x:next(z for z in x['exact_brs_field_bindings'] if z['identity']=='plasticos.transaction.light_weight_deduction_rate').__setitem__('use_contract','Old $0.01 base rate and $0.10 derived from incompatible examples, D17 OPEN')),
      ('duplicated_policy_delta_id',lambda x:x['policy_delta'][-1].__setitem__('id',x['policy_delta'][-3]['id'])),
      ('buyer_report_optional',lambda x:x['policy'].__setitem__('buyer_receiving_report_required',False)),
      ('supplier_weight_buyer_invoice_blocker',lambda x:x['policy'].__setitem__('supplier_weight_blocks_buyer_invoice',True)),
      ('scale_close_blocker',lambda x:x['policy'].__setitem__('carrier_scale_blocks_commercial_close',True)),
      ('carrier_CST_uncertified_allowed',lambda x:x['policy'].__setitem__('carrier_cst_certification_required',False)),
      ('buyer_scale_assumed_certified',lambda x:x['policy'].__setitem__('buyer_scale_certified_by_default',True)),
      ('supplier_scale_assumed_certified',lambda x:x['policy'].__setitem__('supplier_scale_certified_by_default',True)),
      ('CST_no_packaging_deduction',lambda x:x['policy'].__setitem__('carrier_cst_billed_net','CST_GROSS_MINUS_CST_TARE')),
      ('CST_wrong_intermediate_net',lambda x:x['policy'].__setitem__('carrier_cst_intermediate_net','GROSS_MINUS_PACKAGING_TARE')),
      ('CST_overrides_buyer_weight',lambda x:x['policy'].__setitem__('carrier_cst_billable_quantity_automatically_overrides_buyer_weight',True)),
      ('CST_overrides_supplier_weight',lambda x:x['policy'].__setitem__('carrier_cst_billable_quantity_automatically_overrides_supplier_weight',True)),
      ('CST_creates_final_weight',lambda x:x['policy'].__setitem__('carrier_cst_billable_quantity_automatically_sets_final_weight',True)),
      ('RWN_buyer_weight',lambda x:x['policy'].__setitem__('rwn_default_quantity_field','plasticos.transaction.buyer_weight')),
      ('invented_billed_field',lambda x:x['exact_brs_field_bindings'].append(dict(x['exact_brs_field_bindings'][0],identity='plasticos.transaction.net_weight_billed'))),
      ('penalty_300',lambda x:x['policy'].__setitem__('carrier_penalty_amount','300.00')),
      ('wrong_penalty_party',lambda x:x['policy'].__setitem__('carrier_penalty_party','supplier')),
      ('invented_deadline',lambda x:x['policy'].__setitem__('carrier_penalty_deadline','7 days')),
      ('false_AR_dependency',lambda x:x['edges'].append(dict(source='S09',target='S07',relation='prerequisite'))),
      ('dependency_cycle',lambda x:x['edges'].append(dict(source='S12',target='S00',relation='prerequisite'))),
      ('dangling_edge',lambda x:x['edges'].append(dict(source='MISSING',target='S01',relation='prerequisite'))),
      ('duplicate_task',lambda x:x['slices'][0]['tasks'].append(copy.deepcopy(x['slices'][0]['tasks'][0]))),
      ('uncovered_requirement',lambda x:x['requirements'][0].__setitem__('acceptance_ids',[])),
      ('uncovered_document',lambda x:x['coverage'][0].__setitem__('acceptance_ids',[])),
      ('fake_runtime_PASS',lambda x:x['acceptance'][0].__setitem__('execution_status','PASS')),
      ('implicit_mutation_grant',lambda x:x['authorization'].__setitem__('repository_mutation',True)),
    ]
    mutations.extend([
      ('proration_floor_500',lambda x:x['policy'].__setitem__('light_weight_rate_interpolation','COMPLETED_500_FLOOR')),
      ('proration_2250_wrong_total',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V23').__setitem__('total','377.50')),
      ('proration_2499_rate_rounded',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V24').__setitem__('effective_rate_usd_per_lb','0.012500')),
      ('proration_multiply_shortfall',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V13').__setitem__('total','20.00')),
      ('proration_without_contract',lambda x:x['policy'].__setitem__('light_weight_automatic_posting_without_contract',True)),
      ('BRS_numbering_collision',lambda x:x['business_rules_binding']['scoped_concerns'][3].__setitem__('id','BRS-003')),
      ('scale_payable_without_review',lambda x:x['policy'].__setitem__('scale_weight_automatic_settlement_authority',True)),
      ('supplier_buyer_commercial_spread_waived',lambda x:x['policy'].__setitem__('direct_supplier_buyer_review_not_waived_by_two_near_CST_checks',False)),
      ('underweight_threshold_exclusive',lambda x:x['policy'].__setitem__('light_weight_threshold_inclusive',False)),
      ('underweight_wrong_method_name',lambda x:x['field_routing_contract']['underweight_contract'].__setitem__('method_proposal','_compute_weight_deduction')),
      ('underweight_half_shortfall',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V15').__setitem__('total','200.00')),
      ('underweight_38001_wrong_charge',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V14').__setitem__('qualifying_weight_lbs','1999')),
      ('underweight_rate_zero_redefault',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V17').__setitem__('total','20.00')),
      ('buyer_charge_mirrored_to_supplier',lambda x:next(v for v in x['field_routing_contract']['underweight_obligation_flows'] if v['id']=='BUYER_LIABILITY').__setitem__('effect','Automatically recover from supplier; no checks')),
      ('old_dead_freight_boolean_resurrected',lambda x:x['policy'].__setitem__('dead_freight_chargeback_semantics','KEEP_EXISTING_BOOLEAN')),
      ('BRS_scoped_owner_duplicate',lambda x:x['business_rules_binding']['scoped_concerns'][2]['rule_ids'].append('BR-UND-002')),
      ('rwn_scale_automatic_substitution',lambda x:x['field_routing_contract']['weight_reconciliation_contract'].__setitem__('rwn_business_effect','AUTO_SCALE_SUBSTITUTE')),
      ('underweight_rate_conflict_reopened',lambda x:x['policy'].__setitem__('light_weight_monetary_rate_status','UNRESOLVED_PENDING_D17')),
      ('underweight_rate_auto_posting_enabled',lambda x:x['policy'].__setitem__('light_weight_automatic_posting_without_contract',True)),
      ('underweight_example_discrepancy_concealed',lambda x:next(v for v in x['field_routing_contract']['worked_examples'] if v['id']=='V13').__setitem__('total','20.00')),
    ])
    mutations.extend([
      ('CST_tare_alias',lambda x:x['policy'].__setitem__('carrier_cst_tare_business_term','truck'+' tare')),
      ('CST_gross_alias',lambda x:x['policy'].__setitem__('carrier_cst_gross_business_term','Gross Weight')),
      ('packaging_required_for_CST_receipt',lambda x:x['policy'].__setitem__('carrier_cst_completion_requires_packaging_data',True)),
      ('packaging_unknown_carrier_penalty',lambda x:x['policy'].__setitem__('packaging_unknown_alone_triggers_carrier_penalty',True)),
      ('bare_net_proves_packaging_excluded',lambda x:x['policy'].__setitem__('source_net_word_proves_packaging_excluded',True)),
      ('supplier_PL_blanket_optional',lambda x:x['policy'].__setitem__('supplier_packing_list_collection','OPTIONAL_NO_COLLECTION')),
      ('rename_buyer_weight_field',lambda x:x['exact_brs_field_bindings'][1].__setitem__('identity','plasticos.transaction.received_weight')),
      ('rename_buyer_weight_label',lambda x:x['exact_brs_field_bindings'][1].__setitem__('source_declared_label','Received Weight (lbs)')),
      ('wrong_field_type',lambda x:x['exact_brs_field_bindings'][1].__setitem__('type_at_pinned_source','fields.Char')),
      ('wrong_field_owner',lambda x:x['exact_brs_field_bindings'][1].__setitem__('owner','nonexistent_module')),
      ('wrong_seal_model',lambda x:x['exact_brs_field_bindings'][-2].__setitem__('identity','plasticos.transaction.seal_number')),
      ('rename_surface_weight_alias',lambda x:x['field_mapping'][1].__setitem__('field_or_surface','plasticos.transaction.shipper_weight')),
      ('wrong_mapping_owner',lambda x:x['field_mapping'][1].__setitem__('owner','nonexistent_module')),
      ('stale_BRS_binding',lambda x:x['slices'][1].__setitem__('brs_binding_id','brs-documents@1.0.0')),
      ('scope_disappears',lambda x:x['slices'][5].__setitem__('mutation_paths',[])),
      ('decision_reference_drift',lambda x:x['slices'][5]['decision_refs'].append('D01')),
      ('unapproved_decision',lambda x:x['decisions'][0].__setitem__('status','RESOLVED')),
      ('meaningless_test_oracle',lambda x:x['acceptance'][0].__setitem__('expected','Fine')),
      ('new_logistics_BRS',lambda x:x['policy'].__setitem__('brs_logistics_status','CREATED')),
      ('CST_tare_label_in_task',lambda x:x['slices'][5]['tasks'][3].__setitem__('description','Read '+'truck tare'+' and use it to derive payable weight without the CST term.')),
    ])
    mutations.extend([
      ('field_lane_buyer_to_supplier',lambda x:x['field_routing_contract']['source_groups'][1].__setitem__('destination','plasticos.transaction.supplier_weight')),
      ('field_lane_supplier_to_buyer',lambda x:x['field_routing_contract']['source_groups'][0].__setitem__('destination','plasticos.transaction.buyer_weight')),
      ('carrier_CST_mapped_GENERIC_SCALE',lambda x:next(z for z in x['field_routing_contract']['route_rules'] if z['id']=='ROUTE-CAR-CST').__setitem__('legacy_tag','SCALE')),
      ('supplier_OPTIONAL_scale_mapped_CST',lambda x:next(z for z in x['field_routing_contract']['route_rules'] if z['id']=='ROUTE-SUP-SCALE').__setitem__('legacy_tag','CST')),
      ('buyer_report_optional_scale_fallback',lambda x:next(z for z in x['field_routing_contract']['route_rules'] if z['id']=='ROUTE-BUY-REPORT').__setitem__('destination','plasticos.transaction.scale_weight')),
      ('invented_weight_ORM_field_in_ledger',lambda x:x['field_routing_contract']['field_registry'][3].__setitem__('identity','plasticos.transaction.shipper_weight')),
      ('wrong_native_qty_to_invoice_direct_write',lambda x:next(z for z in x['field_routing_contract']['financial_consumers'] if z['id']=='FIN-BUY-AR').__setitem__('guard','write qty_to_invoice now')),
      ('false_ERP_field_schema',lambda x:next(z for z in x['field_routing_contract']['field_registry'] if z['identity']=='plasticos.transaction.scale_weight').__setitem__('type','fields.Char')),
      ('wrong_CST_net_billable_arithmetic',lambda x:next(z for z in x['field_routing_contract']['worked_examples'] if z['id']=='V01').__setitem__('net_weight_billed','40000')),
      ('wrong_supplier_packaging_arithmetic',lambda x:next(z for z in x['field_routing_contract']['worked_examples'] if z['id']=='V03').__setitem__('material_net','40000')),
      ('buyer_invoice_uses_supplier_quantity',lambda x:next(z for z in x['field_routing_contract']['financial_consumers'] if z['id']=='FIN-BUY-AR').__setitem__('quantity','plasticos.transaction.supplier_weight')),
      ('source_fact_pretends_ORM_column',lambda x:next(z for z in x['field_routing_contract']['source_fact_types'] if z['id']=='C_TARE').__setitem__('is_odoo_field',True)),
      ('unverified_document_net_auto_writes_supplier',lambda x:next(z for z in x['field_routing_contract']['source_fact_types'] if z['id']=='S_DOCUMENT_NET').__setitem__('proposed_orm_destination','plasticos.transaction.supplier_weight')),
      ('unverified_document_net_auto_writes_buyer',lambda x:next(z for z in x['field_routing_contract']['source_fact_types'] if z['id']=='B_DOCUMENT_NET').__setitem__('proposed_orm_destination','plasticos.transaction.buyer_weight')),
      ('RWN_buyer_RR_inferred_global_gate',lambda x:x['policy'].__setitem__('rwn_buyer_report_sequence_decision','ALWAYS_REQUIRED_FOR_RWN')),
      ('source_fact_omits_issuer',lambda x:x['field_routing_contract']['source_fact_types'].__delitem__(0)),
      ('missing_native_field_owner',lambda x:next(z for z in x['field_routing_contract']['field_registry'] if z['identity']=='sale.order.line.qty_delivered').__setitem__('owner','arbitrary_new_owner')),
      ('false_installed_Enterprise_proof',lambda x:x['field_routing_contract']['field_registry'][0].__setitem__('evidence_status','RUNTIME_CONFIRMED')),
    ])
    results=[]
    for name,change in mutations:
        altered=copy.deepcopy(d);change(altered)
        try:validate_data(altered)
        except ValueError:results.append(name+': REJECTED_AS_EXPECTED')
        else:raise ValueError('negative control accepted: '+name)
    return results


EXPECTED_POLICY = {'buyer_receiving_report_required': True,
 'supplier_packing_list_blocks_notice_or_ar': False,
 'carrier_scale_blocks_commercial_close': False,
 'carrier_scale_gross_required_every_load': True,
 'carrier_scale_net_required_every_load': True,
 'carrier_penalty_amount': '150.00',
 'carrier_penalty_currency': 'USD_WORKING_ASSUMPTION_CONFIRM_D05',
 'carrier_penalty_party': 'carrier',
 'carrier_penalty_deadline': 'UNKNOWN_PENDING_D01',
 'carrier_penalty_repeat': 'NOT_AUTHORIZED',
 'penalty_unit': 'PROPOSED_ONCE_PER_LOAD_PENDING_D04',
 'supplier_payable_basis': 'ACCEPTED_SUPPLIER_WEIGHT_NORMAL_HUMAN_REVIEW_FOR_DIRECT_SPREAD_OVER_5_NO_AUTO_SCALE',
 'rwn_delivery_blocks_ar': False,
 'auto_schema_additions_authorized': False,
 'supplier_weight_blocks_buyer_invoice': False,
 'rwn_requires_valid_supplier_settlement_quantity': True,
 'rwn_missing_supplier_quantity': 'HOLD_RWN_ONLY_PENDING_D14',
 'rwn_default_quantity_field': 'plasticos.transaction.supplier_weight',
 'rwn_exception_quantity_field': 'REFERENCE_SCALE_ONLY_REVIEWER_DECIDES_AUTHORIZED_COMMERCIAL_CORRECTION',
 'rwn_discrepancy_trigger': 'STRICTLY_GREATER_THAN_5_PERCENT',
 'rwn_buyer_report_sequence_decision': 'OPEN_D18_NO_ACCEPTED_GLOBAL_RWN_GATE_NO_AUTOSEND_WITHOUT_POLICY',
 'buyer_receiving_report_required_for_full_ar': True,
 'document_net_unverified_is_material_net': False,
 'source_measurement_is_commercial_quantity_without_basis_proof': False,
 'acceptance_uses_actual_source_packaging_basis': True,
 'buyer_invoice_quantity_field': 'plasticos.transaction.buyer_weight',
 'buyer_receiving_report_document': 'INBOUND_FROM_BUYER',
 'received_weight_notice_document': 'OUTBOUND_TO_SUPPLIER_SETTLEMENT',
 'supplier_packing_list_required_for_notice': False,
 'supplier_scale_ticket_required': False,
 'buyer_scale_ticket_required': False,
 'carrier_scale_ticket_required': True,
 'carrier_scale_document_obligation_blocks_notice_or_ar': False,
 'rwn_scale_factual_prerequisite_when_over_5': 'HUMAN_REVIEW_REQUIRED_NOT_AUTOMATIC_SCALE_SETTLEMENT',
 'packaging_tare_gaylord_lbs': '40',
 'packaging_tare_pallet_lbs': '40',
 'packaging_tare_gaylord_on_pallet_lbs': '80',
 'packaging_tare_box_lbs': 'UNKNOWN_PENDING_D15',
 'universal_final_weight_settlement_authority': False,
 'no_invented_weight_alias_fields': True,
 'original_plan_preserved_as_history': True,
 'brs_logistics_status': 'DEFERRED_NOT_CREATED',
 'discrepancy_denominator': 'CURRENT_CODE_MAX_DENOMINATOR_PROVISIONAL_D13',
 'carrier_required_document_business_name': 'CST_CERTIFIED_SCALE_TICKET',
 'carrier_cst_means': 'CERTIFIED_SCALE_TICKET',
 'carrier_cst_certification_required': True,
 'supplier_scale_certified_by_default': False,
 'buyer_scale_certified_by_default': False,
 'carrier_cst_intermediate_net': 'CST_GROSS_MINUS_CST_TARE',
 'carrier_cst_billed_net': 'CST_NET_MINUS_APPLICABLE_PACKAGING_TARE',
 'carrier_cst_measurement_chain': 'CST_GROSS_MINUS_CST_TARE_EQUALS_CST_NET;CST_NET_MINUS_PACKAGING_TARE_EQUALS_NET_WEIGHT_BILLED',
 'carrier_cst_billable_quantity_automatically_overrides_buyer_weight': False,
 'carrier_cst_billable_quantity_automatically_overrides_supplier_weight': False,
 'carrier_cst_billable_quantity_automatically_sets_final_weight': False,
 'carrier_cst_nonguessed_packaging': 'UNKNOWN_IS_NOT_ZERO_D15',
 'carrier_cst_scale_weight_write': 'VERIFIED_PACKAGING_ADJUSTED_MATERIAL_NET_REFERENCE_ONLY',
 'carrier_cst_tare_business_term': 'CST tare',
 'carrier_cst_gross_business_term': 'CST gross',
 'carrier_cst_net_business_term': 'CST net',
 'packaging_tare_business_term': 'packaging tare',
 'net_weight_billed_business_term': 'net weight billed',
 'carrier_cst_completion_requires_packaging_data': False,
 'packaging_unknown_alone_triggers_carrier_penalty': False,
 'supplier_packing_list_collection': 'TRACK_IF_APPLICABLE_NONBLOCKING_NOT_BLANKET_OPTIONAL',
 'source_net_word_proves_packaging_excluded': False,
 'cst_net_meaning': 'CST_GROSS_MINUS_CST_TARE_BEFORE_PACKAGING',
 'packaging_adjusted_source_value': 'NET_WEIGHT_BILLED_NOT_REDEFINED_CST_NET',
 'scale_weight_reference_only': True,
 'scale_weight_automatic_settlement_authority': False,
 'scale_weight_automatic_customer_invoice_authority': False,
 'direct_supplier_buyer_spread_review_required_over_five_pct': True,
 'direct_supplier_buyer_review_not_waived_by_two_near_CST_checks': True,
 'human_review_required_above_five_percent': True,
 'reconciliation_review_discrepancy_denominator': 'D13_PENDING_EXACT_PERCENT_DENOMINATOR_AND_ROUNDING',
 'preferred_transaction_weight_display': 'CERTIFIED_CST_REFERENCE_THEN_BUYER_WEIGHT_THEN_SUPPLIER_WEIGHT_DISPLAY_ONLY',
 'weight_vocabulary': {'document_measurement': 'The quantity actually shown on the PL, Receiving Report or scale ticket',
                       'load_net': 'Gross less corresponding vehicle/CST tare',
                       'packaging_tare': 'Weight of applicable Gaylords, pallets, etc.',
                       'material_net': 'Load net less applicable packaging tare, or independently verified material-only net',
                       'accepted_commercial_weight': 'The validated material net used for supplier or buyer settlement'},
 'minimum_light_weight_contract_scope': '53_FOOT_TRAILER_WHERE_CONTRACT_APPLIES',
 'minimum_net_weight_53ft_lbs': '40000',
 'light_weight_threshold_shortfall_lbs': '2000',
 'light_weight_threshold_inclusive': True,
 'light_weight_deduction_basis': 'ACCEPTED_OBLIGATION_SPECIFIC_MATERIAL_NET_AFTER_PACKAGING',
 'light_weight_deduction_formula': 'THRESHOLD_2000_INCLUSIVE_RATE_BASE_0_01_PER_2000_SHORTFALL_CONTINUOUS_PARTIAL_500_RATE_ON_ACTUAL_MATERIAL_NET_CENTS_AT_END',
 'underweight_obligation_scoped': True,
 'buyer_liability_not_automatic_supplier_recovery': True,
 'light_weight_deduction_weight_name': 'NON_ORM_CALCULATION_OUTPUT_PENDING_PROVEN_REPRESENTATION_NEED',
 'light_weight_deduction_total_name': 'PROPOSED_REPLACEMENT_OF_EXISTING_light_weight_deduction_PENDING_MIGRATION',
 'light_weight_monetary_compute_name': '_compute_light_weight_deduction_total',
 'dead_freight_chargeback_semantics': 'OBSOLETE_BOOLEAN_NO_DISTINCT_ACCEPTED_POLICY_RETIRE_PENDING_MIGRATION',
 'final_weight_business_semantics': 'RETIRED_NO_UNIVERSAL_WEIGHT_TECHNICAL_REMOVAL_PENDING_CONSUMER_MIGRATION',
 'carrier_cst_150_separate_from_light_weight_deduction': True,
 'document_brs_concern_ownership': 'NUMBERED_ONE_FILE_PER_CONCERN_INDEX_ENFORCED',
 'light_weight_monetary_rate_status': 'OPERATOR_APPROVED_CONTINUOUS_PRORATION_D17_RESOLVED',
 'light_weight_base_rate_usd_per_lb_per_2000_shortfall': '0.01',
 'light_weight_rate_change_per_500_lbs': '0.0025',
 'light_weight_rate_interpolation': 'CONTINUOUS_PARTIAL_500_NO_FLOOR_NO_EARLY_ROUND',
 'light_weight_total_quantity_basis': 'ACTUAL_ACCEPTED_OBLIGATION_SPECIFIC_MATERIAL_NET',
 'light_weight_monetary_rounding': 'CENTS_HALF_UP_ONLY_FINAL_AMOUNT',
 'light_weight_automatic_posting_without_contract': False,
 'light_weight_rate_conflict_decision': 'D17_RESOLVED_OPERATOR_SUPERSESSION',
 'brs_index_numbering': 'BRS-001_THROUGH_BRS-007_NO_COLLISIONS_STAGING_4AC9_REF'}
EXPECTED_FIELDS = {'plasticos.transaction.supplier_weight': ('plasticos_transaction', 'Supplier Weight (lbs)', 'fields.Float'), 'plasticos.transaction.buyer_weight': ('plasticos_transaction', 'Buyer Weight (lbs)', 'fields.Float'), 'plasticos.transaction.scale_weight': ('plasticos_transaction', 'Scale Weight (lbs)', 'fields.Float'), 'plasticos.transaction.gross_weight': ('plasticos_transaction', 'Gross Weight (lbs)', 'fields.Float computed'), 'plasticos.transaction.final_weight': ('plasticos_transaction', 'Final Net Weight (lbs)', 'fields.Float computed'), 'plasticos.transaction.weight_source': ('plasticos_transaction', 'Weight Source', 'fields.Selection computed'), 'plasticos.transaction.unit_count': ('plasticos_transaction', 'Unit Count', 'fields.Integer'), 'plasticos.transaction.unit_type': ('plasticos_transaction', 'Unit Type', 'fields.Selection'), 'plasticos.transaction.tare_per_unit': ('plasticos_transaction', 'Tare per Unit (lbs)', 'fields.Float computed inverse'), 'plasticos.transaction.tare_per_unit_override': ('plasticos_transaction', 'Tare Override (lbs)', 'fields.Float'), 'plasticos.transaction.total_tare': ('plasticos_transaction', 'Total Tare (lbs)', 'fields.Float computed'), 'plasticos.transaction.weight_discrepancy_pct': ('plasticos_transaction', 'Weight Discrepancy %', 'fields.Float computed'), 'plasticos.transaction.weight_discrepancy_flagged': ('plasticos_transaction', 'Discrepancy Flagged', 'fields.Boolean computed'), 'plasticos.load.seal_number': ('plasticos_logistics', 'Seal Number', 'fields.Char'), 'plasticos.load.trailer_number': ('plasticos_logistics', 'Trailer Number', 'fields.Char'), 'plasticos.transaction.minimum_net_weight': ('plasticos_transaction', 'Minimum Net Weight (lbs)', 'fields.Float'), 'plasticos.transaction.light_weight_deduction_rate': ('plasticos_transaction', 'Deduction Rate ($/lb)', 'fields.Float'), 'plasticos.transaction.light_weight_deduction': ('plasticos_transaction', 'Light Weight Deduction ($)', 'fields.Float computed'), 'plasticos.transaction.dead_freight_chargeback': ('plasticos_transaction', 'Dead Freight Chargeback', 'fields.Boolean computed')}
EXPECTED_SURFACES = {'plasticos.transaction.supplier_id / buyer_id / carrier_id': 'plasticos_transaction', 'plasticos.transaction.sale_order_id / purchase_order_ids / delivery_order_id / do_number': 'plasticos_transaction', 'plasticos.transaction.load_id': 'plasticos_logistics/models/transaction_inherit.py', 'plasticos.transaction.supplier_weight': 'plasticos_transaction', 'plasticos.transaction.buyer_weight': 'plasticos_transaction', 'plasticos.transaction.scale_weight': 'plasticos_transaction', 'plasticos.transaction.final_weight / gross_weight / weight_source': 'plasticos_transaction', 'plasticos.transaction.total_tare / tare_per_unit / tare_per_unit_override / unit_count / unit_type': 'plasticos_transaction', 'plasticos.transaction.weight_discrepancy_flagged / weight_discrepancy_pct': 'plasticos_transaction', 'plasticos.load.seal_number / trailer_number': 'plasticos_logistics', 'plasticos.load.pickup_reference / delivery_reference / name': 'plasticos_logistics', 'plasticos.load.pickup_partner_id / delivery_partner_id': 'plasticos_logistics', 'plasticos.load.dispatched_at / delivered_at / pickup_datetime / delivery_datetime': 'plasticos_logistics', 'plasticos.transaction.actual_pickup_date / actual_delivery_date / expected_pickup_date / expected_delivery_date': 'plasticos_transaction', 'plasticos.load.actual_freight_cost / actual_freight_currency_id / rate_amount / rate_currency_id': 'plasticos_logistics', 'plasticos.transaction.customer_invoice_id / vendor_bill_ids / freight_bill_ids': 'plasticos_transaction', 'account.move.transaction_id / reconciliation_status / reconciliation_notes': 'plasticos_automation', 'plasticos.penalty.rule.rule_type / calculation_method / penalty_rate / partner_ids / grace_period_days': 'plasticos_automation', 'plasticos.claim.case_type / transaction_id / claimed_amount / recovery_amount / currency_id / assignee_id': 'plasticos_claims', 'plasticos.document.attachment_id / tag_id / doc_category / transaction_id / load_id / res_model / res_id': 'plasticos_documents', 'plasticos.document.verified / override / is_current / superseded_by / active / expiry_date': 'plasticos_documents', 'documents.document.attachment_id / partner_id / transaction_id / load_id / plasticos_doc_id / doc_type': 'Native Documents + plasticos_documents_native', 'plasticos.document.rule and plasticos.document.validation.matrix existing fields': 'plasticos_documents', 'mail.template / mail.message / mail.mail / mail.activity / ir.attachment': 'Native Odoo', 'Container/chassis scalar destination': 'Unresolved existing logistics owner', 'Per-load raw gross/net/source locations and durable processing/outbound identity': 'Native evidence surfaces first', 'plasticos.transaction.minimum_net_weight / light_weight_deduction_rate / light_weight_deduction / dead_freight_chargeback': 'plasticos_transaction'}
# Rejected strings are negative witnesses only, never active business terms.
BAD_CST = re.compile(r"\btruck[ _/-]*(?:tare|net|gross)\b|TRUCK_TARE|CST truck net|account\.invoice\b", re.I)


def validate_field_routing(d):
    f=d['field_routing_contract'];require(f['schema']=='documents.field-flow/v1','field schema mismatch')
    require(f['normative_brs']=='brs-documents@1.3.1','field mapping BRS revision')
    require(f['source_epoch']==d['observed_staging_sha'],'field ledger repo epoch mismatch')
    fields=f['field_registry'];facts=f['source_fact_types'];routes=f['route_rules'];fins=f['financial_consumers']
    require(len(fields)>=140,'field inventory incomplete')
    require(len(facts)>=35,'source measurements incomplete')
    require(f['source_fields_count']==len(fields),'reported field count drift')
    require(f['source_concept_count']==len(facts),'reported source concept count drift')
    require(len({x['identity'] for x in fields})==len(fields),'duplicate exact field in ledger')
    require(len({x['id'] for x in facts})==len(facts),'duplicate source fact identity')
    require(len({x['id'] for x in routes})==len(routes),'duplicate document route')
    require(len({x['id'] for x in fins})==len(fins),'duplicate financial consumer')
    require(len(routes)==8 and len(fins)==4,'document or financial lane missing')
    owners={'plasticos_transaction','plasticos_documents','plasticos_documents_native',
            'plasticos_logistics','Odoo Enterprise Documents','Odoo 19 Sales',
            'Odoo 19 Purchase','Odoo 19 Accounting','plasticos_automation'}
    for x in fields:
        for key in ('identity','owner','type','declared_label','source_path','source_revision','evidence_status','group','meaning','write_policy','consumer','assurance'):
            require(bool(x.get(key)),'empty field contract '+x.get('identity','?')+':'+key)
        require(x['owner'] in owners,'unknown owner in field ledger '+x['identity'])
        require(set(x['source_refs'])<={s['id'] for s in d['governing_sources']},'unbound source for '+x['identity'])
        require(set(x['owner_slices'])<={v['id'] for v in d['slices']},'unbound slice for '+x['identity'])
        require('::' not in x['identity'] and '.'.join(x['identity'].split('.')[:-1]),'bad exact technical field')
        require(not any(x['identity']==forbidden for forbidden in f['forbidden_orm_new_fields']), 'invented ORM field '+x['identity'])
        require(x['evidence_status']!='RUNTIME_CONFIRMED','false installed Enterprise proof')
    field_index={x['identity']:x for x in fields}
    for ident,owner,label,decl in [
        ('plasticos.transaction.supplier_weight','plasticos_transaction','Supplier Weight (lbs)','fields.Float'),
        ('plasticos.transaction.buyer_weight','plasticos_transaction','Buyer Weight (lbs)','fields.Float'),
        ('plasticos.transaction.scale_weight','plasticos_transaction','Scale Weight (lbs)','fields.Float'),
        ('plasticos.transaction.gross_weight','plasticos_transaction','Gross Weight (lbs)','fields.Float computed'),
        ('plasticos.transaction.final_weight','plasticos_transaction','Final Net Weight (lbs)','fields.Float computed'),
        ('plasticos.transaction.total_tare','plasticos_transaction','Total Tare (lbs)','fields.Float computed'),
        ('plasticos.load.seal_number','plasticos_logistics','Seal Number','fields.Char'),
        ('plasticos.load.trailer_number','plasticos_logistics','Trailer Number','fields.Char'),
        ('sale.order.line.qty_delivered','Odoo 19 Sales','Delivery Quantity','fields.Float computed'),
        ('purchase.order.line.qty_received','Odoo 19 Purchase','Received Qty','fields.Float computed inverse'),
        ('account.move.line.quantity','Odoo 19 Accounting','Quantity','fields.Float'),
    ]:
        v=field_index.get(ident)
        require(v is not None and (v['owner'],v['declared_label'],v['type'])==(owner,label,decl), 'field type/label/owner drift '+ident)
    require('CURRENT_ACCEPTED_BUYER_RECEIVING_REPORT' in field_index['plasticos.transaction.buyer_weight']['write_policy'],'buyer report source guard missing')
    require('VERIFIED_SUPPLIER' in field_index['plasticos.transaction.supplier_weight']['write_policy'],'supplier source guard missing')
    for stage_id in ('S_DOCUMENT_NET','B_DOCUMENT_NET'):
        sf=next((x for x in facts if x['id']==stage_id),None)
        require(sf is not None and sf['proposed_orm_destination']=='none' and sf['is_odoo_field'] is False,'source document net coerced into accepted commercial scalar '+stage_id)
        require('not accepted' in sf['meaning'].lower() or 'not established' in sf['meaning'].lower(),'ambiguous document net presented as material net '+stage_id)
    require(f['rwn_sequencing']=='D18_OPEN_SUPPLIER_RWN_DRAFT_POSSIBLE_AUTOSEND_WITHOUT_BUYER_REPORT_HELD_UNTIL_POLICY','unapproved RWN chronology silently determined')
    require(f['source_net_stage_policy']=='DOCUMENT_NET_IS_RAW_OBSERVATION_UNTIL_PACKAGING_BASIS_VERIFIED_NOT_MATERIAL_NET','source-stage proof lost')
    require('REFERENCE_ONLY' in field_index['plasticos.transaction.scale_weight']['write_policy'],'scale is only physical reference')
    require('NO_AUTOMATIC_SETTLEMENT' in field_index['plasticos.transaction.scale_weight']['write_policy'],'scale cannot auto win')
    require('RETIRE_PENDING_CONSUMER_MIGRATION' in field_index['plasticos.transaction.gross_weight']['write_policy'],'gross old winner retirement omitted')
    require('RETIRE_PENDING_CONSUMER_MIGRATION' in field_index['plasticos.transaction.final_weight']['write_policy'],'final old winner retirement omitted')
    must_sources={'SUPPLIER','BUYER','CARRIER_CST'}
    source_index={x['id']:x for x in f['source_groups']}
    require(must_sources<=source_index.keys(),'three lanes missing')
    for lane,target in [('SUPPLIER','plasticos.transaction.supplier_weight'),('BUYER','plasticos.transaction.buyer_weight')]:
        require(source_index[lane]['destination']==target,'wrong source lane -> field '+lane)
    require(source_index['CARRIER_CST']['destination'].startswith('plasticos.transaction.scale_weight'),'wrong carrier source field')
    fact_index={x['id']:x for x in facts};required={
      'SUPPLIER':{'S_DOC_ID','S_GROSS','S_PACK_TARE','S_DOCUMENT_NET','S_PER_UNIT_WEIGHT','S_SCALE_GROSS','S_SCALE_TARE','S_SCALE_NET'},
      'BUYER':{'B_DOC_ID','B_GROSS','B_PACK_TARE','B_DOCUMENT_NET','B_PER_UNIT_WEIGHT','B_SCALE_GROSS','B_SCALE_TARE','B_SCALE_NET'},
      'CARRIER_CST':{'C_DOC_ID','C_IS_CERTIFIED','C_GROSS','C_TARE','C_NET','C_PACK_TARE','C_NET_BILLED','C_GROSS_NET_COMPLETE','C_ISSUER','C_LOAD'},
    }
    for lane,names in required.items():
        for name in names:
            require(name in fact_index and fact_index[name]['source_group']==lane,'missing/wrong group source fact '+name)
    for x in facts:
        require(not x['is_odoo_field'],'source fact type presented as installed ORM field '+x['id'])
        require(x['persist_as']=='SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF','fake stored source field '+x['id'])
        require(x['source_group'] in {'SUPPLIER','BUYER','CARRIER_CST','CROSS_SOURCE'},'unknown source group '+x['id'])
        require(x['proposed_orm_destination'] in {'none','plasticos.transaction.supplier_weight',
            'plasticos.transaction.buyer_weight','plasticos.transaction.scale_weight'}, 'new ORM destination '+x['id'])
    require(fact_index['C_GROSS']['proposed_orm_destination']=='none' and fact_index['C_TARE']['proposed_orm_destination']=='none' and fact_index['C_NET']['proposed_orm_destination']=='none','CST physical fields cannot be legacy scalar')
    require(fact_index['C_NET_BILLED']['proposed_orm_destination']=='plasticos.transaction.scale_weight','CST packaged net target drift')
    route_index={x['id']:x for x in routes}
    route_contract={
      'ROUTE-SUP-PL':('supplier','PACKING','plasticos.transaction.supplier_weight'),
      'ROUTE-SUP-BOL':('supplier','BOL','plasticos.transaction.supplier_weight'),
      'ROUTE-SUP-SCALE':('supplier','SCALE','plasticos.transaction.supplier_weight'),
      'ROUTE-BUY-REPORT':('buyer','RECEIVING','plasticos.transaction.buyer_weight'),
      'ROUTE-BUY-SCALE':('buyer','SCALE','EVIDENCE_ONLY_CORROBORATION'),
      'ROUTE-CAR-BOL':('carrier','BOL','EVIDENCE_ONLY'),
      'ROUTE-CAR-CST':('carrier','CST','plasticos.transaction.scale_weight'),
      'ROUTE-EXT-SCALE':('independent','SCALE','EVIDENCE_ONLY_PENDING_D13')
    }
    for name,(party,tag,dest) in route_contract.items():
        x=route_index.get(name)
        require(x is not None and (x['party'],x['legacy_tag'],x['destination'])==(party,tag,dest),'route contract drift '+name)
        require(set(x['facts']) <= fact_index.keys(),'unknown source fact in '+name)
        require(set(x['rules']) <= set(d['business_rules_binding']['rule_ids']),'invalid BRS in '+name)
        require(x['native_doc_type'] not in {'cst','receiving_report','packing_list'},'fabricated native selection '+name)
    fin_index={x['id']:x for x in fins}
    assert_fin={
      'FIN-SUP-RWN':('plasticos.transaction.supplier_weight','NO AUTOMATIC SCALE SUBSTITUTION'),
      'FIN-BUY-AR':('plasticos.transaction.buyer_weight','NONE; carrier CST is not buyer invoice quantity'),
      'FIN-SUP-AP':('plasticos.transaction.supplier_weight','No automatic scale substitute'),
      'FIN-CARRIER-AP':('NO MATERIAL SETTLEMENT FIELD','N/A')}
    test_ids={x['id'] for x in d['acceptance']}
    for name,(default,exception) in assert_fin.items():
        x=fin_index.get(name)
        require(x is not None and x['quantity']==default,'wrong finance quantity '+name)
        require(x['exception'].startswith(exception),'wrong finance exception '+name)
        require(bool(x['guard']) and bool(x['actual']) and bool(x['price']),'empty native financial mapping '+name)
        require(set(x['tests'])<=test_ids and len(x['tests'])>=3,'missing finance tests '+name)
    require('no direct qty_to_invoice write' in fin_index['FIN-BUY-AR']['guard'],'native Sales computed field safety missing')
    require(len(f['representation_gaps'])>=8,'hidden implementation gaps')
    require(len(f['worked_examples'])>=12,'numeric example coverage incomplete')
    vector_index={x['id']:x for x in f['worked_examples']}
    from decimal import Decimal, ROUND_HALF_UP
    for name in ('V01','V02','V09'):
        x=vector_index[name];gross=Decimal(x['CST_gross']);tare=Decimal(x['CST_tare'])
        require(gross-tare==Decimal(x['CST_net']),'CST numeric relation fails '+name)
        if 'net_weight_billed' in x:require(Decimal(x['CST_net'])-Decimal(x['packaging_tare'])==Decimal(x['net_weight_billed']),'CST packaging relation fails '+name)
    x=vector_index['V03'];require(Decimal(x['count'])*Decimal(x['unit_tare'])==Decimal(x['packaging_tare']) and Decimal(x['gross'])-Decimal(x['packaging_tare'])==Decimal(x['material_net']),'supplier packaging arithmetic')
    x=vector_index['V04'];require(Decimal(x['received_gross'])-Decimal(x['packaging_tare'])==Decimal(x['buyer_net']),'buyer packaging arithmetic')
    for name in ('V05','V06','V07'):
        x=vector_index[name];sw=Decimal(x['supplier_weight']);bw=Decimal(x['buyer_weight']);pct=abs(sw-bw)/max(sw,bw)*100
        require(pct==Decimal(x['discrepancy_under_current_code_pct']),'current-code discrepancy diagnostic mismatch '+name)
    require(vector_index['V06']['RWN_quantity']==vector_index['V06']['supplier_weight'],'strict >5 threshold lost')
    require(vector_index['V07']['RWN_status']=='HOLD_HUMAN_RECONCILIATION_D13','unresolved D13 hidden')
    require(vector_index['V08']['RWN_status']=='HOLD_PENDING_D14','missing supplier weight replaced')
    require(vector_index['V09']['CST_obligation']=='COMPLETE_IF_D03','packaging falsely blocks CST receipt')
    required_new_rules={'BR-FLD-004','BR-WGT-005','BR-WGT-006','BR-WGT-007','BR-WGT-008',
        'BR-REC-004','BR-SET-006','BR-CAR-004','BR-EVD-005','BR-EVD-006'}
    require(required_new_rules<=set(d['business_rules_binding']['rule_ids']),'missing BRS technical safety rules')
    # v1.3.0 BRS-003/BRS-007 source-bound physical meaning and exact Decimal arithmetic.
    u=f['underweight_contract'];w=f['weight_reconciliation_contract']
    require(u['normative_owner']=='BRS-007@1.0.1' and u['physical_input_owner']=='BRS-003@1.0.1','underweight owner drift')
    require((u['trailer_length_ft'],u['required_minimum_material_net_lbs'],u['trigger_shortfall_inclusive_lbs'],u['base_rate_usd_per_lb_per_2000_shortfall'],u['rate_interpolation_per_500_lbs'])==('53','40000','2000','0.01','0.0025'),'deduction threshold/base/proration drift')
    require(u['partial_500_lbs']=='CONTINUOUS_LINEAR_PRORATION_NOT_COMPLETED_TIER_FLOOR','staircase proration reintroduced')
    require(u['method_proposal']=='_compute_light_weight_deduction_total','compute method naming drift')
    require(u['rate_status']=='OPERATOR_APPROVED_CONTINUOUS_PRORATION_FORMULA_D17_RESOLVED','old D17 conflict resurrected')
    require(u['automatic_financial_assessment']=='CONTRACT_AND_NATIVE_ACCOUNTING_AUTHORIZATION_REQUIRED_D16_NOT_AUTOMATIC_BY_CALCULATION','calculation made posting authority')
    require(u['blocking_decisions']==['D16'] and u['blocking_decision']=='D16','resolved D17 still global blocker')
    require('NON_ORM' in u['proposed_deduction_weight_output'] and 'NOT_PRESENT_PENDING_MIGRATION' in u['proposed_successor_total_field'],'unapproved ORM field')
    require(any('dead_freight_chargeback' in x for x in u['retired_business_concepts']),'legacy Boolean unretired')
    require(u['buyer_obligation']=='ACCOUNTING_LIABILITY_ONLY_IF_BUYER_CONTRACT_PROVES_IT' and u['supplier_obligation']=='INDEPENDENT_RECOVERY_ONLY_IF_SUPPLIER_CONTRACT_PROVES_IT','contract liability confused')
    require(u['separate_carrier_CST_document_penalty_usd']=='150.00','CST document penalty conflated with LWD')
    require(w['reference_only']=='plasticos.transaction.scale_weight','scale reference treated as commercial quantity')
    require(w['disallowed_clearance']=='TWO_NEAR_SCALE_COMPARISONS_DO_NOT_WAIVE_DIRECT_COMMERCIAL_SPREAD','direct weight spread bypassed')
    require(w['human_review_trigger']=='STRICTLY_GREATER_THAN_FIVE_PERCENT_DIRECT_COMMERCIAL_SPREAD','human review trigger drift')
    require(w['rwn_business_effect']=='NO_AUTO_SCALE_SUBSTITUTION_PENDING_HUMAN_REVIEW','scale auto settlement reintroduced')
    require(w['display_only_priority']==['CERTIFIED_CST_PACKAGING_ADJUSTED_MATERIAL_NET','ACCEPTED_BUYER_WEIGHT','ACCEPTED_SUPPLIER_WEIGHT','NO_ACCEPTED_WEIGHT'],'display priority drift')
    require(len(f['vocabulary_stages'])==5,'five business terms missing')
    for x in f['vocabulary_stages']:
        require(d['policy']['weight_vocabulary'][x['term']]==x['definition'] and x['rule']=='BR-VOC-001','five stage definitions drift')
    flows={x['id']:x for x in f['underweight_obligation_flows']}
    require(set(flows)=={'BUYER_LIABILITY','SUPPLIER_RECOVERY'},'missing independently owned obligation')
    require(all(v['calculation']=='SINGLE_SHARED_LIGHT_WEIGHT_CALCULATOR' for v in flows.values()),'duplicate liability formula')
    require('no automatic supplier recovery' in flows['BUYER_LIABILITY']['effect'].lower(),'buyer liability mirrored to supplier')
    for name in ('V13','V14','V15','V16','V17','V19',*[f'V{i}' for i in range(21,32)]):
        x=vector_index[name];m=Decimal(x['minimum_material_net']);net=Decimal(x['material_net'])
        sh=max(Decimal(0),m-net)
        qualifying=sh if sh>=Decimal('2000') else Decimal(0)
        base=Decimal(x['rate']);effective=base*sh/Decimal('2000') if qualifying else Decimal(0)
        total=(net*effective).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
        require(Decimal(x['shortfall_lbs'])==sh and Decimal(x['qualifying_weight_lbs'])==qualifying,'underweight threshold '+name)
        require(Decimal(x['effective_rate_usd_per_lb'])==effective,'continuous partial-500 prorated rate '+name)
        require(Decimal(x['total'])==total,'entire actual material-net amount '+name)
    for name,eff,total in [('V13','0.01','380.00'),('V14','0','0.00'),('V15','0.02','720.00'),('V23','0.01125','424.69'),('V24','0.012495','468.57'),('V25','0.0125','468.75')]:
        x=vector_index[name]
        require(Decimal(x['effective_rate_usd_per_lb'])==Decimal(eff) and Decimal(x['total'])==Decimal(total),'golden arithmetic mismatch '+name)
    x=vector_index['V18'];s=Decimal(x['supplier_weight']);b=Decimal(x['buyer_weight']);cs=Decimal(x['scale_weight'])
    require(abs(s-cs)/cs*100==Decimal(x['supplier_to_scale_pct_of_scale']) and abs(b-cs)/cs*100==Decimal(x['buyer_to_scale_pct_of_scale']),'CST diagnostic witness wrong')
    require(abs(b-s)==Decimal(x['direct_spread_lbs']) and abs(b-s)/max(s,b)*100>Decimal('5') and x['status']=='REVIEW_REQUIRED','direct 4+4 loophole')
    require(vector_index['V19']['supplier_recovery_status']=='NOT_AUTHORIZED' and vector_index['V19']['buyer_contract_applies'],'automatic buyer-to-supplier financial mirror')
    require(vector_index['V20']['status']=='SCALE_REFERENCE_ONLY','scale turned billable')
    require({'BR-VOC-001','BR-WGT-009','BR-WGT-010'} | {f'BR-UND-{i:03}' for i in range(1,8)} <= set(d['business_rules_binding']['rule_ids']),'scoped BRS identities missing')
    require({'R53','R54'}<={r['id'] for r in d['requirements']},'numbered BRS/proration requirements missing')
    require({f'T{i}' for i in range(201,219)}<={t['id'] for t in d['acceptance']},'numbered BRS/proration acceptance missing')
    require(all(rid in {r['id'] for r in d['requirements']} for rid in [f'R{i}' for i in range(40,49)]),'original source-field obligations missing')
    require(all(tid in {t['id'] for t in d['acceptance']} for tid in [f'T{i}' for i in range(130,181)]),'source-field acceptance lost')
    for tid in (f'T{i}' for i in range(130,181)):
        case=next(t for t in d['acceptance'] if t['id']==tid)
        for class_id in case['coverage']:
            row=next(cx for cx in d['coverage'] if cx['id']==class_id)
            require(tid in row['acceptance_ids'],'coverage/test inverse missing '+tid+'/'+class_id)


def cell(value):
    if isinstance(value,list):value='; '.join(str(x) for x in value)
    return str(value).replace('|','&#124;').replace('\n','<br>')

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join('---' for _ in headers)+'|']+['| '+' | '.join(cell(v) for v in row)+' |' for row in rows])+'\n'

def common(d):
    return ('**Version:** '+d['version']+' | **BRS:** brs-documents@'+d['business_rules_binding']['version']+
            ' | **Status:** package specification, not executed Odoo software.\n\n'
            '**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. '
            'Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; '
            'CST net - applicable packaging tare = net weight billed.** '
            'Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. '
            'Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. '
            'Missing packaging alone is not missing CST.\n\n')

def render_roadmap(d):
    out='# Documents Campaign Roadmap\n\n'+common(d)
    out+='## Dependency map\n\nEdges mean prerequisite outcome to dependent slice. Runtime dependency DEP265 is an inherited named PR owner, not a fresh claim about its current state.\n\n```mermaid\nflowchart TD\n'
    for n in d['nodes']:out+='  '+n['id']+'["'+n['id']+': '+n['title']+'"]\n'
    for e in d['edges']:out+='  '+e['source']+(' -.-> ' if e['relation']=='runtime_prerequisite' else ' --> ')+e['target']+'\n'
    out+='```\n\n## Milestones and earliest useful operation\n\n'
    out+=table(['Milestone','Required outcomes','Result'],[
      ['M1: Evidence foundation','S00/S01/S02/S03/S04','Source-correct intake and replay-safe associations; exact field/BRS checks.'],
      ['M2: Receiving Report to independent outputs','S05 plus S06 and S07','Customer Invoice on buyer_weight; RWN only when supplier quantity, price and deductions are supported. Joined T097/T105/T123 proof for this activation boundary; do not wait for all AP/penalty classes.'],
      ['M3: Collection and carrier accountability','S08/S09','Per-party document truth and approved one-event $150 carrier CST penalty; independent of M2.'],
      ['M4: Complete declared coverage','S10/S11/S12','Remaining AP/supporting documents and full joined operational proof.']])
    out+='\n## Priority and parallelism\n\nFinish the original S01 slice without pasting this campaign into it. Source/fixture preparation can be parallel; one writer owns a shared source file or test database. S06 and S07 are independent output lanes after S05. Supplier PL, missing supplier_weight, carrier CST/penalty and supplier AP are not hidden Customer Invoice prerequisites. Each slice must close any consumer it actually changes; preserve untouched compatibility until the bounded successor can safely change it.\n\n'
    out+='## Slice summary\n\n'+table(['Slice','Outcome','Prerequisite slices','Action-scoped decision references'],[[s['id'],s['title'],s['depends_on'] or 'None',s['decision_refs']] for s in d['slices']])
    out+='\nA decision reference means consult its blocker_scoping, not stop the whole slice. ADR-025/BRS adoption and CI pointer work is bounded in S02; repository writes still need a separate grant. brs-logistics stays deferred.\n'
    for s in d['slices']:
        out+='\n## '+s['id']+'. '+s['title']+'\n\n'+s['goal']+'\n\n'
        for key,label in [('owners','Owners'),('depends_on','Prerequisites'),('execution_status','Execution status'),('activation_status','Activation status'),('requirement_ids','Requirements'),('acceptance_ids','Acceptance cases'),('finding_ids','Inherited findings'),('brs_rule_ids','BRS rules'),('required_brs_revision','BRS revision'),('decision_refs','Decisions')]:out+='**'+label+':** '+cell(s[key] or 'None')+'\n\n'
        out+='### Proposed scope, not an execution grant\n\n'+s['activation_scope']+'\n\n'
        if s['mutation_paths']:out+='```text\n'+'\n'.join(s['mutation_paths'])+'\n```\n'
        else:out+='Read-only baseline binding; no repository mutation.\n'
        out+='\n### Granular tasks\n\n'+table(['ID','Required result','State'],[[t['id'],t['description'],t['status']] for t in s['tasks']])
        out+='\n### Exit evidence\n\n'+'\n\n'.join(s['acceptance'])+'\n\n'+s['test_scope']+'\n'
        out+='\nTask closure requires exact source/implementation/configuration/test evidence or an explicit scoped blocker. A neighboring PASS does not close this task.\n'
        out+='\n### Exclusions\n\n'+'\n\n'.join(s['exclusions'])+'\n\n### Stop conditions and material risks\n\n'+'\n\n'.join(s['risks'])+'\n'
        if s['shared_write_surfaces']:out+='\n**Shared write surfaces:** '+cell(s['shared_write_surfaces'])+'\n'
    return out

def render_coverage(d):
    out='# Document Coverage and Field-Action Inventory\n\n'+common(d)
    out+='## Gate shorthand\n\nBuyer Receiving Report is mandatory for full Customer Invoicing. Supplier PL is tracked where applicable but nonblocking; supplier/buyer Scale Tickets are optional. Missing supplier_weight holds the RWN under D14, not the Customer Invoice. Carrier CST is mandatory/nonblocking; its certified-document sufficiency is separate from packaging-tare billing readiness.\n\n'
    out+='## Inventory\n\n'+table(['ID','Document','Party/direction','Owner slices','Acceptance'],[[c['id'],c['name'],c['party'],c['owner_slices'],c['acceptance_ids']] for c in d['coverage']])
    labels={'business_event':'Business event','receiving_channel':'Receiving or outgoing channel','existing_classification':'Existing classification, not new enum','extract':'Extraction or generated content','authoritative_source':'Authoritative evidence','destination':'Correct destination','validation':'Validation','automatic_action':'Automated result','exception':'Specific exception','blocking_policy':'Blocking scope','owner_slices':'Owner slices','legacy_v4_items':'Original dossier items','implementation_status':'Implementation evidence','acceptance_ids':'Acceptance cases','brs_rule_ids':'BRS rules'}
    for c in d['coverage']:
        out+='\n## '+c['id']+'. '+c['name']+'\n\n'+table(['Concern','Specification'],[[label,c.get(key,[])] for key,label in labels.items()])
    out+='\n## Original v4 dossier crosswalk\n\n'+table(['Preserved dossier item','Coverage'],[[item,c['id']] for c in d['coverage'] for item in c['legacy_v4_items']])
    return out

def render_acceptance(d):
    out='# Acceptance and Test Evidence Contract\n\n'+common(d)
    out+='## Test execution discipline\n\nAll '+str(len(d['acceptance']))+' cases are specifications with execution_status NOT_RUN and no runtime receipt. A package check is not an Odoo test. Each activated case needs a real named test, exact code/config/BRS/source-fixture revision, a disposable Enterprise-equivalent database where required, and intercepted outbound effects. No absent dependency, skipped required case or zero collection is a PASS.\n\n'
    out+='## Cross-interface proof layers\n\nPure arithmetic/matching tests prove only those functions; ORM tests prove field/action effects; real native mail/AI/accounting tests prove their invoked interfaces; a joined case proves the named workflow, not production operation. Reuse valid same-head evidence and avoid redundant full suites.\n\n## Cases\n'
    for t in d['acceptance']:
        out+='\n### '+t['id']+'. '+t['title']+'\n\n'
        for k,label in [('requirements','Requirements'),('slices','Owner slices'),('coverage','Document classes'),('brs_rule_ids','BRS rules'),('given','Given'),('when','When'),('expected','Expected'),('proof_kind','Required proof'),('execution_status','Execution')]:out+='**'+label+':** '+cell(t[k] or 'None')+'\n\n'
        out+='**Receipt:** None.\n'
    out+='\n## Requirement-to-acceptance trace\n\n'+table(['Requirement','BRS IDs','Owner slices','Acceptance IDs'],[[r['id']+': '+r['obligation'],r['brs_rule_ids'],r['owner_slices'],r['acceptance_ids']] for r in d['requirements']])
    return out

def render_sources(d):
    out='# Sources, Policy Decisions, Gaps and Field Ownership\n\n'+common(d)
    out+='## Evidence boundary and lineage\n\nSource code and official Odoo citations below are inherited from the predecessor at pinned Staging '+d['observed_staging_sha']+'. The pinned Staging declarations were verified earlier in this campaign, not installed Enterprise runtime; U07 is the latest accepted numeric-proration and numbered BRS instruction; U06 physical vocabulary and prior source statements remain exact protected history. D17 pure mathematics is resolved; D16 contract and posting remain open. Original historical source_inputs, including the file named LATEST_OPERATOR_INSTRUCTION.txt, remain unchanged historical evidence rather than current execution instructions. The predecessor archive SHA-256 is `'+d['predecessor_archive_sha256']+'`.\n\n'
    out+='## Source register\n\n'+table(['ID','Source','Evidence status','Locator','Meaning/limit'],[[s['id'],s['title'],s['evidence_status'],s['locator'],s['notes']] for s in d['governing_sources']])
    out+='\n## Policy delta and supersession\n\n'+table(['ID','Topic','Predecessor','Disposition','Current instruction'],[[p['id'],p['topic'],p['predecessor'],p['disposition'],p['successor']] for p in d['policy_delta']])
    out+='\n## Bounded decisions, not global blockers\n'
    for q in d['decisions']:
        out+='\n### '+q['id']+'. '+q['title']+'\n\n'
        for k,label in [('basis','Evidence/basis'),('owner','Owner'),('affected_slices','Referencing slices'),('safe_behavior','Safe behavior'),('resolution','Remaining resolution'),('status','Status'),('blocker_scoping','Action-specific blocking scope'),('reference_semantics','Reference meaning')]:out+='**'+label+':** '+cell(q[k])+'\n\n'
    out+='## Exact source-declared field bindings\n\nThese are pinned-source declarations, not a live-registry receipt. Do not replace labels with conversational synonyms. CST measurement labels below are business terms and do not create fields.\n\n'
    out+=table(['Existing technical identity','Owner','Declared label','Declared type','Use contract','BRS rule'],[[b['identity'],b['owner'],b['source_declared_label'],b['type_at_pinned_source'],b['write_or_semantic_contract'],b['brs_rule_id']] for b in d['exact_brs_field_bindings']])
    out+='\n## Field-owner and representation register\n\n'+table(['Existing field/surface','Owner','Evidence status','Required behavior','Sources','Slices'],[[f['field_or_surface'],f['owner'],f['status'],f['write_contract'],f['source_refs'],f['owner_slices']] for f in d['field_mapping']])
    out+='\n## Inherited implementation findings and disposition\n\nThe following remain implementation obligations, not fixed by editing this pack. The predecessor v1.2.0 package repair census is in validation/DRIFT_REVIEW.md.\n\n'
    out+=table(['ID','Finding','Evidence class/source','Owner slice','Disposition','Closure'],[[f['id'],f['title'],f['evidence_class']+'; '+f['source_ref'],f['owner_slice'],f['disposition'],f['closure']] for f in d['findings']])
    out+='\n## Representation and authority boundary\n\nA proven gap does not authorize a new field, table, enum or parallel engine. Reuse native Odoo and existing PlasticOS owners; block only the unsupported action under D08. Preserve current field/source semantics, source evidence and prior approved policy. ADR-025 and BRS are proposed repository additions; brs-logistics and a semantic-kernel vocabulary framework remain deferred.\n'
    return out


def render_field_contract(d):
    f=d['field_routing_contract']
    text='# Three-Source Weight Field Routing and Native Commercial Conformance\n\n'+common(d)
    text+='**Purpose:** field-by-field adapter contract for Documents, supplier RWN, buyer Customer Invoice, supplier Vendor Bill and required carrier certified CST. **Business law** lives ONLY in seven numbered, independently scoped BRS-001..007 files selected via the non-normative `docs/business-rules/index.json`. This is the derived source-declared implementation projection, **not** an Odoo model/schema or an independently admitted vocabulary. See ADR-025.\n\n'
    text+='**Evidence status:** `Staging` '+d['observed_staging_sha']+' and public Odoo 19.0 code were inspected through read-only source; no installed Odoo Enterprise registry, DB, CI runtime or actual mail/accounting action was tested. Types marked ENTERPRISE are wrapper claims, not independently verified installed fields.\n\n'
    text+='## 1. Business-authorized source lanes\n\n'
    text+=table(['Lane','Identity-binding fields','Source documents','Only accepted existing scalar destination','Commercial use'],[[x['id'],x['party_field'],x['source_class'],x['destination'],x['business_use']] for x in f['source_groups']])
    text+='\n**Rule:** names like `supplier_scale_gross`, `CST tare`, `S_DOCUMENT_NET` and `B_DOCUMENT_NET` are typed **document observations only**; document-labeled net is not by itself material net, so neither observed field is an Odoo `fields.Float` nor may it auto-write accepted scalar weights without proving the physical measurement and packaging basis. The exact installed field selection/type remains a runtime proof obligation.\n\n'
    text+='## 2. Gross, tare, net and packaging physical equations by source\n\n'
    text+=table(['Measurement lane','Formula/meaning'],[[k,v] for k,v in f['gross_tare_net_definition'].items()])
    text+='\nA named **CST net** is not yet billable material net. Missing packaging alone does not make a certified gross/net CST missing. Gross and paired scale tare must describe the same issuer, load, unit, vehicle/time event. The independent supplier/buyer scale tare terms are not CST tare and cannot discharge the carrier documentation obligation.\n\n'
    text+='## 3. Document-specific source routing matrix\n\n'
    text+=table(['Route','Issuer party','Business document','Actual existing native doc_type','Legacy tag','Mandatory validation','Source facts','Exact write target or evidence only','Result and prohibition'],[[x[k] for k in ('id','party','document','native_doc_type','legacy_tag','requires','facts','destination','action')] for x in f['route_rules']])
    text+='\n**Existing tag identities:** `plasticos_documents.tag_cst` has code `CST`; `plasticos_documents.tag_scale_ticket` has code `SCALE`; `plasticos_documents.tag_receiving_report` has code `RECEIVING`; `plasticos_documents.tag_packing_list` has code `PACKING`. Native custom `documents.document.doc_type` permits `scale_ticket` but does not have `cst`, `receiving_report` or `packing_list`. Role/issuer/real tag and company/load scope must supply that distinction without adding selection values. A tag cannot prove actual certification or gross/net contents.\n\n'
    text+='## 4. Candidate source fact dictionary (NOT existing ORM fields)\n\n'
    text+='Every source concept must be retained with document logical part, revision, raw value, original units, validated basis and exact load/material/line. Persistence is a real D08 installed-Enterprise/native-evidence decision, **not** permission to create 35 new fields or a parallel ledger.\n\n'
    for group in ('SUPPLIER','BUYER','CARRIER_CST','CROSS_SOURCE'):
        xs=[x for x in f['source_fact_types'] if x['source_group']==group]
        text+='### '+group+' source facts\n\n'+table(['Concept ID (not ORM)','Document class','Meaning','Value format','Proposed scalar if accepted','Dependencies','Validation','Persistence status'],[[x[k] for k in ('id','document_class','meaning','value_representation','proposed_orm_destination','dependencies','validation','persist_as')] for x in xs])+'\n'
    text+='## 4A. Operator-approved five-stage measurement vocabulary (weights BRS only)\n\n'
    text+=table(['Stage','Exact operator meaning','Normative owning rule'],[[v['term'],v['definition'],v['rule']] for v in f['vocabulary_stages']])+'\n'
    text+='## 4B. Direct commercial reconciliation and preferred display (weights BRS only)\n\n'
    text+=table(['Key','Contract'],[[k,v] for k,v in f['weight_reconciliation_contract'].items()])+'\n'
    text+='## 4C. Obligation-scoped underweight calculation and financial owners (underweight BRS only)\n\n'
    text+=table(['Key','Contract'],[[k,v] for k,v in f['underweight_contract'].items()])+'\n'
    text+=table(['Obligation','Commercial source','Shared calculator','Native owner','Independent effect','Authority','Status'],[[x[k] for k in ('id','source','calculation','accounting_owner','effect','authority','status')] for x in f['underweight_obligation_flows']])+'\n'
    text+='Proposed ORM method `_compute_light_weight_deduction_total` and `light_weight_deduction_total` successor field are NOT present in the pinned source; `light_weight_deduction_weight` remains a computed pure output, not approval to create an Odoo field.\n\n'
    text+='## 5. Complete exact field registry, grouped by existing owner/function\n\n' 
    text+='The registry catalogs **'+str(len(f['field_registry']))+' real declared/wrapper-claimed fields** relevant to this campaign. The labelled technical identity, source file, type, write permission and downstream use must be checked against the **installed** registry and composed views on the actual execution revision. "(default label)" means the source declaration did not explicitly set a business label; this pack does not invent one. Field source provenance statuses are not hosted Odoo validation.\n\n'
    for group in dict.fromkeys(x['group'] for x in f['field_registry']):
        items=[x for x in f['field_registry'] if x['group']==group]
        text+='### '+group+' ('+str(len(items))+' relevant fields)\n\n'
        text+=table(['Exact technical field','Owner','Type','Inspected label','Source path/revision','Actual meaning','Write/access policy','Downstream consumer','Assurance'],[[x[k] for k in ('identity','owner','type','declared_label','source_path','meaning','write_policy','consumer','assurance')] for x in items])
        text+='\n**Source epoch:** '+d['observed_staging_sha']+' for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.\n\n'
    text+='## 6. Commercial consumers and exact native quantity bridges\n\n'
    text+=table(['Consumer','Standard commercial quantity','Allowed exceptional quantity','Price source','Native action and proper line model','Validation/authorization gates','Required tests'],[[x[k] for k in ('flow','quantity','exception','price','actual','guard','tests')] for x in f['financial_consumers']])
    text+='\n**No direct writes to computed `sale.order.line.qty_to_invoice`, `purchase.order.line.qty_to_invoice`, or any `final_weight` / `weight_source` selected winner.** Actual installed native Sales delivered and Purchase received invoicing policies determine how `buyer_weight`/supplier payable quantity become valid `account.move.line.quantity`. Ordered native quantity is not overwritten as a substitute for delivery. Native posting and mailing are separately authorized, never proven by a document classification boolean.\n\n'
    text+='## 7. Proposed unit/threshold/negative worked examples (NOT hosted tests)\n\n'
    for x in f['worked_examples']:
        text+='### '+x['id']+': '+x['case']+'\n\n'
        text+=table(['Key','Value'],[[k,v] for k,v in x.items() if k not in ('id','case')])+'\n'
    text+='**Numeric disclaimers:** the current discrepancy diagnostic formula uses `abs(supplier_weight - buyer_weight)/max(supplier_weight,buyer_weight)`; the operator has approved strictly >5%, not independently the denominator or D13 extras. Examples V05-V07 test the currently implemented denominator only as diagnostics; V13-V20 check operator-approved 53-foot shortfall and direct-spread human-review boundaries. The business denominator and human adjudication process remain D13/D16; D17 arithmetic is resolved; D16 applicable contract and financial effect remain unproven. All figures are synthetic, not live financial instructions. Packaging values must reflect per-source inclusion evidence, never assumed zero.\n\n'
    text+='## 8. Inspected code-level gaps, exact remedial owner and allowed stop\n\n'
    text+=table(['Gap','Observed limitation','Existing owner','Evidence class','Minimum bounded follow-up','Scoped blocker'],[[x[k] for k in ('id','finding','owner','classification','next','blocked')] for x in f['representation_gaps']])
    text+='\n## 9. Field-contract prohibited declarations\n\n'
    text+='The following identifiers have **no accepted new transaction ORM field** and may occur only in authentic source text or negative examples:\n\n'+ '\n'.join('- `'+x+'`' for x in f['forbidden_orm_new_fields'])+'\n\nUnsupported native selection declarations: '+', '.join('`'+x+'`' for x in f['native_selection_nonexistent'])+'.\n\n'
    text+='## 10. Required implementation and proof sequence\n\n'
    text+='1. Resolve installed `documents.document` and exact Odoo field registry, current `Staging`/feature revision, native AI/extraction capability and safe writable models.\n\n'
    text+='2. Validate sender versus actual issuer, source document class, company, exact transaction/load/material line, unit and raw/gross/tare/packaging basis. Record source fact and current revision before any write.\n\n'
    text+='3. Select one source lane and only its permitted existing scalar. No cross-lane auto-fallback, no missing→zero, no blanket newer→winner. Reconcile the native Documents↔legacy per-record link with CST versus SCALE tag.\n\n'
    text+='4. Prove CST certification and gross/net obligation independently of packaging; do not let missing packaging turn into $150 penalty. Derive packaging-adjusted net only after applicable source facts are validated.\n\n'
    text+='5. Normal supplier RWN uses supplier commercial net and correct PO price. A direct supplier/buyer discrepancy strictly >5% requires human reconciliation with CST as reference only; never automatic scale substitute. Buyer Customer Invoice remains on accepted buyer_weight and native Sales line flow. Independently applicable underweight obligations use the scoped BRS formula, but D17 historical arithmetic is resolved; financial posting remains dependent on D16 controlling contract and native financial authorization; native financial owners remain separate.\n\n'
    text+='6. Retire obsolete `final_weight`, selected `gross_weight`, `weight_source` and `dead_freight_chargeback` only after verified consumer migration; use proposed `_compute_light_weight_deduction_total` for monetary output and separate calculation output `light_weight_deduction_weight` as NON-ORM until authorized.\n\n'
    text+='7. Execute named `T130`–`T223` tests at the appropriate pure/ORM/hosted/CI layer; replay and concurrently invoke affected paths with one economic effect. Zero collected, skipped or missing mandatory runtime test = NOT RUN.\n\n'
    text+='8. Resolve D08/D13/D14/D15/D16/D18 through operator authorization (D17 calculation is already resolved) when needed; preserve original historical plan and previous BRS rules unchanged as sources.\n\n'
    text+='**Deferred:** `brs-logistics` and a semantic-kernel vocabulary framework. **Not authorized:** repository commit, PR, merge, deployment, Odoo DB mutation, send/post or new ORM fields from this ZIP.\n'
    return text

RENDERERS={'ROADMAP.md':render_roadmap,'DOCUMENT_COVERAGE.md':render_coverage,'ACCEPTANCE.md':render_acceptance,'SOURCES_DECISIONS_AND_GAPS.md':render_sources,'FIELD_ROUTING_AND_CONFORMANCE.md':render_field_contract}

def validate_views(d, views):
    for name,renderer in RENDERERS.items():
        require(views[name]==renderer(d),'derived-view content drift: '+name)
    for name,text in views.items():
        require(not BAD_CST.search(text),'active CST/native-model terminology drift: '+name)
        require(text.count('```')%2==0,'unbalanced code fence: '+name)
    brs=d['business_rules_binding']
    definition=re.compile(r'^\*\*(BR-[A-Z]+-\d{3}) \u00b7',re.M)
    owners={}
    for scope in brs['scoped_concerns']:
        path=scope['normative_path'];data=views[path]
        require(data.startswith('# '+scope['id']+': '),'numbered BRS heading drift '+scope['id'])
        require('**Version:** '+scope['version'] in data,'BRS version mismatch '+scope['id'])
        defs=definition.findall(data)
        require(len(defs)==len(set(defs)) and set(defs)==set(scope['rule_ids']),'unique BRS owner/definition mismatch '+scope['id'])
        for rid in defs:
            require(rid not in owners,'duplicate normative owner '+rid)
            owners[rid]=scope['id']
    require(set(owners)==set(brs['rule_ids']),'BRS rule family set incomplete')
    weights=views['docs/business-rules/BRS-003-weights-and-packaging.md']
    under=views['docs/business-rules/BRS-007-underweight-and-chargebacks.md']
    for term in d['policy']['weight_vocabulary'].values():require(term in weights,'missing accepted vocabulary definition: '+term)
    for term in ('CST gross','CST tare','CST net','packaging tare','material net','38,400','41,600'):
        require(term in weights,'physical quantity authority term missing: '+term)
    require('**BR-WGT-010 \u00b7 ACCEPTED' in weights and 'human review' in weights.lower(),'human direct commercial review missing')
    for item in ('**BR-UND-002 \u00b7 ACCEPTED','0.011250','424.69','0.012495','468.57','720.00','partial 500','_compute_light_weight_deduction_total()'):
        require(item.lower() in under.lower(),'approved continuous rate formula absent: '+item)
    require('Retire the obsolete `dead_freight_chargeback` Boolean' in under,'Boolean retirement weakened')
    human=views['docs/business-rules/README.md']
    require('brs-documents@1.3.1' in human and 'BRS-001' in human and 'BRS-007' in human,'BRS numbered index missing')
    trace=views['docs/business-rules/TRACEABILITY.md']
    for rid in owners:require('| `'+rid+'` | `'+owners[rid]+'` |' in trace,'BRS acceptance mapping disappeared '+rid)
    for name in ['README.md','CAMPAIGN_SPEC.md','EXECUTION_HANDOFF.md']:
        require('brs-documents@1.3.1' in views[name] and 'BRS-007' in views[name],'stale campaign BRS index/version '+name)
        require('720.00' in views[name] and '424.69' in views[name],'final prorated formula not in campaign handoff '+name)
        require('>5%' in views[name] and 'human' in views[name].lower(),'commercial human review lost '+name)

def negative_view_controls(d, views):
    mutations=[
        ('roadmap_task_content_changed','ROADMAP.md',lambda s:s.replace('CST tare','truck'+' tare',1)),
        ('coverage_RWN_wrong_default','DOCUMENT_COVERAGE.md',lambda s:s.replace('supplier_weight','buyer_weight',1)),
        ('acceptance_expected_value_changed','ACCEPTANCE.md',lambda s:s.replace('39200','38400',1)),
        ('source_mapping_owner_changed','SOURCES_DECISIONS_AND_GAPS.md',lambda s:s.replace('plasticos_transaction','nonexistent_module',1)),
        ('master_old_CST_term','CAMPAIGN_SPEC.md',lambda s:s.replace('CST tare','truck'+' tare',1)),
        ('README_old_CST_term','README.md',lambda s:s.replace('CST tare','truck'+' tare',1)),
        ('handoff_old_revision','EXECUTION_HANDOFF.md',lambda s:s.replace('brs-documents@1.3.1','brs-documents@1.0.0')),
        ('BRS_old_CST_term','docs/business-rules/BRS-003-weights-and-packaging.md',lambda s:s.replace('CST tare','truck'+' tare',1)),
        ('field_companion_wrong_buyer_field','FIELD_ROUTING_AND_CONFORMANCE.md',lambda s:s.replace('plasticos.transaction.buyer_weight','plasticos.transaction.received_weight',1)),
        ('BRS_underweight_rate_tamper','docs/business-rules/BRS-007-underweight-and-chargebacks.md',lambda s:s.replace('0.011250','0.010000',1)),
        ('BRS_underweight_method_rename_drift','docs/business-rules/BRS-007-underweight-and-chargebacks.md',lambda s:s.replace('_compute_light_weight_deduction_total()','_compute_weight_deduction()',1)),
        ('BRS_weight_human_review_deleted','docs/business-rules/BRS-003-weights-and-packaging.md',lambda s:s.replace('**BR-WGT-010 \u00b7 ACCEPTED', '**BR-WGT-010 \u00b7 REMOVED',1)),
        ('BRS_double_owned_rule','docs/business-rules/BRS-001-document-classes-and-identity.md',lambda s:s+'\n**BR-UND-002 \u00b7 ACCEPTED:** Invalid duplicate definition.\n'),
    ]
    results=[]
    for name,path,mutate in mutations:
        bad=dict(views); bad[path]=mutate(bad[path]);require(bad[path]!=views[path],'invalid negative witness: '+name)
        try:validate_views(d,bad)
        except ValueError:results.append(name+': REJECTED_AS_EXPECTED')
        else:raise ValueError('negative view control accepted: '+name)
    return results

def validate_registration_and_chat_policy(root, d, idx, manifest=None, audit=None):
    """Validate transport and bounded source-fidelity ledger, never target admission or full donor completeness."""
    manifest=json.loads((root/'REGISTRATION_MANIFEST.json').read_text()) if manifest is None else manifest
    audit=json.loads((root/'validation/CHAT_POLICY_AUDIT.json').read_text()) if audit is None else audit
    require(manifest['schema']=='documents.proposed-repository-registration-manifest/v1','registration manifest schema')
    require(manifest['status']=='PREPARED_NOT_INSTALLED_NOT_MERGED','registration falsely installed')
    require(manifest['campaign_version']==d['version'] and manifest['family_selector']==idx['selector'],'registration selector drift')
    require(manifest['target_repository']=='https://github.com/cryptoxdog/IB-Odoo_19' and manifest['target_branch']=='Staging','wrong target integration base')
    require(manifest['observed_source_sha']==d['observed_staging_sha'],'stale manifest observed target snapshot')
    require(manifest['publication']['authorized'] is False and manifest['publication']['merge'] is False and manifest['publication']['deploy'] is False,'publication authorized by planning evidence')
    expected={d['business_rules_binding']['charter_path'], d['business_rules_binding']['index_path'],d['business_rules_binding']['human_index_path'],
              'docs/business-rules/TRACEABILITY.md','docs/business-rules/check_brs.py','docs/business-rules/fixtures/light_weight_deduction.json'}
    expected|={e['path'] for e in idx['entries']}
    paths=[x['repository_destination'] for x in manifest['copy_new_sources']]
    require(set(paths)==expected and len(paths)==len(set(paths)) and len(paths)==len(expected),'registration file census wrong/duplicate')
    for item in manifest['copy_new_sources']:
        require(item['source_path']==item['repository_destination'],'source/destination misleading alias')
        path=Path(item['source_path']);require(not path.is_absolute() and '..' not in path.parts,'registration traversal')
        require((root/path).is_file() and hashlib.sha256((root/path).read_bytes()).hexdigest()==item['sha256'],'registration exact source bytes altered '+str(path))
        require(item['action']=='CREATE_ONLY_IF_UNOCCUPIED_ELSE_RECONCILE','silent overwrite in registration')
    modifications={x['path'] for x in manifest['modify_existing_repository_files']}
    require(modifications=={'docs/adr/README.md','ARCHITECTURE.md','AGENTS.md','docs/README_INDEX.md','.github/workflows/ci.yml'},'unscoped existing-file registration')
    ci=manifest['ci_gate']
    require(ci['actual_file']=='.github/workflows/ci.yml' and ci['actual_job']=='static-checks' and ci['actual_aggregator']=='ci-gate-result','duplicate CI job or missing aggregate')
    require(ci['argv']==['python3','docs/business-rules/check_brs.py','docs/business-rules','--self-test'] and ci['existing_helper']=='run_check','unverified BRS CI invocation')
    require(manifest['acceptance']['target_ci_enforcement']=='NOT_RUN' and manifest['acceptance']['target_odoo_runtime']=='NOT_RUN','preemptively claimed runtime or CI')
    require(audit['schema']=='documents.chat-policy-audit/v1' and audit['campaign_revision']==d['version'],'chat audit revision mismatch')
    require(audit['donor_completeness']=='PARTIAL_NOT_INDEPENDENT_EXPORT' and audit['independent_blind_reconstruction']=='NOT_RUN','fake full donor independence claim')
    require(audit['case_count']==len(audit['cases']) and audit['case_count']>=30,'chat policy census missing')
    require(audit['finding_count']==len(audit['findings']) and audit['finding_count']>=10,'chat defect inventory absent')
    require(len({x['id'] for x in audit['cases']})==len(audit['cases']),'duplicate chat evidence')
    known_tests={x['id'] for x in d['acceptance']}
    for row in audit['cases']:
        require(row['interpretation_status'] in {
            'ACCEPTED','ACCEPTED_BUSINESS_RETIREMENT','ACCEPTED_ARCHITECTURAL_DIRECTION','ACCEPTED_NO_UNPROVEN_SCHEMA',
            'ACCEPTED_INTENT','ACCEPTED_DISPLAY_ONLY','ACCEPTED_WITH_SOURCE_PROOF','ACCEPTED_CURRENT_BRS_SOURCE',
            'ACCEPTED_AMOUNT_PENDING_TIMING','ACCEPTED_FORMULA_RATE_REVISED_LATER','ACCEPTED_FINAL_LATEST',
            'HISTORICAL_SUPERSEDED_NUMERIC_EXAMPLE','ACCEPTED_NAMING_PROPOSED_TECHNICAL_MIGRATION',
            'ACCEPTED_BASICS_D15_OPEN','ACCEPTED_NAME_REJECTION','UNKNOWN_SCOPED_D18'},'fabricated chat policy state')
        require(bool(row['operator_chat_excerpt']) and len(row['operator_chat_excerpt'])>=13,'empty chat basis')
        rid=row['stable_rule_id']
        require(rid in idx['rule_index'],'unregistered BRS rule in chat mapping '+rid)
        if row['normative_owner']!='ADR-025':
            require(idx['rule_index'][rid]['owner_id']==row['normative_owner'],'wrong owner for chat claim '+rid)
        require(set(row['target_acceptance_ids'])<=known_tests,'unknown chat policy acceptance ref '+rid)
    for f in audit['findings']:
        require(bool(f['repair']) and bool(f['status']) and bool(f['issue']),'incomplete finding')
        if f['status'].startswith('OPEN_'):require(f['status'] in ('OPEN_RUNTIME_PROOF','OPEN_BUSINESS_DECISIONS'),'unknown open class')
    return {'planned_copy_files':len(paths),'target_existing_file_touchpoints':len(modifications),'visible_chat_policy_claims':len(audit['cases']),
            'fidelity_findings':len(audit['findings']),'authority_class':'PROPOSED_NOT_ADMITTED','target_ci_state':'NOT_RUN','odoo_tests':'NOT_RUN'}

def negative_registration_controls(root,d,idx):
    import copy
    original=json.loads((root/'REGISTRATION_MANIFEST.json').read_text())
    audit=json.loads((root/'validation/CHAT_POLICY_AUDIT.json').read_text())
    witnesses=[]
    changes=[
      ('forged_copy_sha',lambda m,a:m['copy_new_sources'][0].__setitem__('sha256','0'*64)),
      ('copy_path_traversal',lambda m,a:m['copy_new_sources'][0].__setitem__('repository_destination','../evil.md')),
      ('duplicated_copy_destination',lambda m,a:m['copy_new_sources'][1].__setitem__('repository_destination',m['copy_new_sources'][0]['repository_destination'])),
      ('unsupported_ci_job',lambda m,a:m['ci_gate'].__setitem__('actual_job','new-brs-gate')),
      ('unapproved_publication',lambda m,a:m['publication'].__setitem__('authorized',True)),
      ('unrun_odoo_declared_pass',lambda m,a:m['acceptance'].__setitem__('target_odoo_runtime','PASS')),
      ('claimed_full_chat_coverage',lambda m,a:a.__setitem__('donor_completeness','FULL_CERTIFIED')),
      ('unregistered_rule_chat_claim',lambda m,a:a['cases'][0].__setitem__('stable_rule_id','BR-FAKE-999')),
      ('buyer_report_fake_RWN_owner',lambda m,a:a['cases'][-1].__setitem__('normative_owner','BRS-007')),
    ]
    for ident,mutator in changes:
        m=copy.deepcopy(original);a=copy.deepcopy(audit);mutator(m,a)
        try:validate_registration_and_chat_policy(root,d,idx,manifest=m,audit=a)
        except (ValueError,KeyError):witnesses.append(ident)
        else:raise ValueError('registration false green: '+ident)
    return witnesses

def inspect_nested_sources(root):
    nested=root/'source_inputs/Odoo19_Documents_Revised_Intent_Dev_Pack_2026-10-18.zip'
    with zipfile.ZipFile(nested) as z:
        require(z.testzip() is None,'nested archive CRC failed')
        manifest=json.loads(z.read('MANIFEST.json'))
        for name,meta in manifest['files'].items():
            require(hashlib.sha256(z.read(name)).hexdigest()==meta['sha256'],'historical nested member changed: '+name)
        return len(z.infolist())

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path);parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--write-report',type=Path)
    a=parser.parse_args();root=a.root.resolve()
    report={'status':'FAIL','claim_scope':'DECLARED_ARTIFACT_CONSISTENCY_AND_SOURCE_BOUND_PACKAGE_REVIEW_ONLY','odoo_tests':'NOT_RUN','repository_ci_enforcement':'NOT_RUN','independent_session_review':'NOT_RUN','live_source_reverification':'READ_ONLY_REPOSITORY_SOURCE_RECHECKED_HOSTED_ENTERPRISE_NOT_RUN','repository_mutation':'NONE'}
    try:
        d=json.loads((root/'campaign.json').read_text());report['inventory']=validate_data(d)
        views={p:(root/p).read_text() for p in DOCS};validate_views(d,views)
        report['full_derived_view_parity']='PASS'
        for name,expected in INPUTS.items():
            require(hashlib.sha256((root/'source_inputs'/name).read_bytes()).hexdigest()==expected,'historical source changed: '+name)
        report['nested_historical_members_checked']=inspect_nested_sources(root)
        b=d['business_rules_binding']
        for field,key in [('index_path','index_sha256'),('human_index_path','human_index_sha256'),('charter_path','charter_sha256')]:
            require(hashlib.sha256((root/b[field]).read_bytes()).hexdigest()==b[key],'indexed BRS/ADR bound digest mismatch '+field)
        for concern in b['scoped_concerns']:
            require(hashlib.sha256((root/concern['normative_path']).read_bytes()).hexdigest()==concern['normative_sha256'],'numbered BRS content hash mismatch '+concern['id'])
        # The standalone checker is copyable to the Odoo repo without the campaign's giant graph.
        import importlib.util
        spec=importlib.util.spec_from_file_location('plasticos_check_brs',root/'docs/business-rules/check_brs.py')
        checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
        index=json.loads((root/'docs/business-rules/index.json').read_text())
        res=checker.validate(root/'docs/business-rules')
        require(index['selector']==d['field_routing_contract']['normative_brs'],'BRS rule owner binding mismatch')
        for rid,ref in index['rule_index'].items():
            rule_req=[r['id'] for r in d['requirements'] if rid in r.get('brs_rule_ids',[])]
            rule_tests=[t['id'] for t in d['acceptance'] if rid in t.get('brs_rule_ids',[])]
            rule_slices=[s['id'] for s in d['slices'] if rid in s.get('brs_rule_ids',[])]
            require(ref['requirement_ids']==rule_req and ref['acceptance_ids']==rule_tests and ref['slice_ids']==rule_slices,'cross-campaign rule/test index drift '+rid)
        report['standalone_brs_validation']=res
        if a.self_test:report['standalone_brs_negative_controls']=checker.negative_controls(root/'docs/business-rules')
        report['registration_and_chat_fidelity']=validate_registration_and_chat_policy(root,d,index)
        if a.self_test:report['registration_negative_controls']=negative_registration_controls(root,d,index)
        report['brs_adr_hash_binding']='PASS'
        report['scoped_brs_owners']=[c['id'] for c in b['scoped_concerns']]
        policy=json.loads((root/'validation/DECLARED_POLICY_ASSERTIONS.json').read_text())
        for rule in policy['assertions']:
            if rule['kind']=='equals':
                v=d
                for part in rule['pointer'].strip('/').split('/'):
                    v=v[int(part)] if isinstance(v,list) else v[part]
                require(v==rule['value'],'declared assertion failed: '+rule['id'])
            else:
                present=any(e['source']==rule['source'] and e['target']==rule['target'] and e['relation']==rule['relation'] for e in d['edges'])
                require(present==(rule['kind']=='edge_exists'),'edge assertion failed: '+rule['id'])
        report['declared_policy_assertions']=len(policy['assertions'])
        manifest=json.loads((root/'SHA256SUMS.json').read_text())['sha256_by_path']
        actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json' and '__pycache__' not in p.parts}
        require(set(manifest)==actual,'manifest member census disagreement')
        for name,expected in manifest.items():require(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,'manifest digest mismatch: '+name)
        report['manifest_integrity']='PASS';report['members_checked']=len(actual)+1
        continuation=json.loads((root/'validation/SUCCESSOR_CONTINUITY.json').read_text())
        for name,expected in continuation['protected_inputs_sha256'].items():require(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,'predecessor input preservation failed: '+name)
        require(d['predecessor_archive_sha256']==continuation['predecessor_archive_sha256'],'predecessor binding drift')
        report['predecessor_source_preservation']='PASS'
        if a.self_test:
            report['negative_controls']=negative_controls(d)+negative_view_controls(d,views)
            report['negative_control_count']=len(report['negative_controls'])
        report['status']='PASS_DECLARED_ASSERTIONS_AND_ARTIFACT_CONSISTENCY'
        report['campaign_json_sha256']=hashlib.sha256((root/'campaign.json').read_bytes()).hexdigest()
    except (ValueError,KeyError,OSError,TypeError,json.JSONDecodeError,zipfile.BadZipFile) as exc:report['error']=str(exc)
    out=json.dumps(report,indent=2)+'\n';print(out,end='')
    if a.write_report:
        require(not a.write_report.resolve().is_relative_to(root),'write report outside the hashed package')
        a.write_report.write_text(out)
    return 0 if report['status'].startswith('PASS_') else 1

if __name__=='__main__':sys.exit(main())
