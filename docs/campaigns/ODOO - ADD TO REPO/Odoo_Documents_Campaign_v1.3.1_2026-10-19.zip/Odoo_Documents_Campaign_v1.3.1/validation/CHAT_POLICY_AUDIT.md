# User-Chat to Numbered BRS Fidelity Audit (v1.3.1)

**Audit donor boundary:** User messages visible in this conversation (29 interpreted quotes) and prior curated `source_inputs` (6 semantic paraphrases) inside the exact predecessor v1.3.0 ZIP; **NOT** an independently enumerated original full-chat export. This is a high-fidelity bounded review but cannot certify hidden messages, independent blinded reconstruction, or target repository admission. Source snippets represent user statements when available; some historical operator provisions are preserved as semantic summaries, not purported verbatim quote proofs.

## Audit findings and closure

| Finding | Severity | Predecessor defect | v1.3.1 action | Proof state |
|---|---|---|---|---|
| AUD-01 | HIGH | Inferred universal buyer RR prerequisite for supplier RWN | D18 scoped UNKNOWN; buyer RR gates full buyer Invoice, supported RWN draft allowed, auto-send held pending sequencing approval | REPAIRED_SPEC_ONLY |
| AUD-02 | HIGH | Unverified source document-labeled net falsely treated as accepted material net | S_DOCUMENT_NET/B_DOCUMENT_NET evidence only, no ORM write before basis proof; 6 falsifying examples | REPAIRED_SPEC_ONLY |
| AUD-03 | MEDIUM | Physical load-net/material-net equality incorrectly allowed just because independent report is material-only | Equality for same load only if packaging tare zero; independent report equality not proof | REPAIRED_SPEC_ONLY |
| AUD-04 | MEDIUM | Classifier BRS-001 duplicated physical CST arithmetic owned by BRS-003 | Reference BRS-003 physical owner; own document classification only | REPAIRED_SPEC_ONLY |
| AUD-05 | MEDIUM | BRS checker hard-coded exactly seven owners and v1.0.0 formula owner | Preserve baseline seven/46, sequential extensible BRS numbering and version-bound formula fixture | REPAIRED_LOCAL_TESTED |
| AUD-06 | HIGH | Self-consistent hashes can conceal policy drift | Add independent critical-meaning sentinels and coherent-hash altered-BRS known-bad witnesses | REPAIRED_LOCAL_TESTED |
| AUD-07 | HIGH | Target repository admission lacked executable bounded registration/collision protocol | Exact source/destination digest manifest, review/update existing ADR/AGENTS/ARCHITECTURE/index and use original static-checks without parallel CI | REPAIRED_PACK_NOT_APPLIED |
| AUD-08 | MEDIUM | No explicit policy quote-to-normative owner and test audit ledger | Visible-conversation 35-item signed-off-business-meaning review ledger with status, BRS rule, test refs and known incompleteness | REPAIRED_LIMITED_CHAT_VISIBILITY |
| AUD-09 | MEDIUM | Generated handoff/report retained stale v1.3.0 owner labels and D17 status wording | Repair renderer and generate exact parity against v1.3.1 source, mark D17 resolved and D18 unknown | REPAIRED_LOCAL_TESTED |
| AUD-10 | HIGH | No executed Odoo 19/Enterprise/Accounting/CI implementation evidence | Do not mark closed; run target-specific isolated Odoo runtime/CI integration before merge or policy enforcement claim | OPEN_RUNTIME_PROOF |
| AUD-11 | MEDIUM | Open D13 denominator/scale review, D15 packages, D16 contractual liability and D18 RWN timing | Preserve bounded unknowns, no financial automatic action or unapproved recovery; DO NOT hold independently eligible buyer invoice | OPEN_BUSINESS_DECISIONS |
| AUD-12 | LOW | Host CI validation stage must be checked for parallel-workflow drift | Register BRS checker as fail-slow run_check in static-checks only; existing CI scripts and hosted Odoo proof remain distinct | REPAIRED_PLAN_ONLY_NOT_REGISTERED |

| AUD-13 | HIGH | Active rate field binding still claimed D17 OPEN and $0.10/lb derived from historical arithmetic | Correct exact field to accepted rate/whole material net and assert no old conflict is active | REPAIRED_LOCAL_TESTED |

| AUD-14 | MEDIUM | Two new supersession rows reused existing POL22/POL23 IDs | Preserve original IDs, assign POL24/POL25, and fail closed on duplicate policy-delta identity | REPAIRED_LOCAL_TESTED |

## Material policy census with supersession/owner/test binding

| Source claim | Operator excerpt or preserved semantic paraphrase (see JSON evidence_class) | Status | Normative owner | Rule ID | Tests |
|---|---|---|---|---|---|
| CHAT-01 | There is no true "final weight" | ACCEPTED_BUSINESS_RETIREMENT | BRS-003 | BR-FLD-002 | T197, T218 |
| CHAT-02 | Shouldn’t we ultimately treat Business Rules Specifications the same way that ADR’s are treated one file for each scoped concern? | ACCEPTED_ARCHITECTURAL_DIRECTION | ADR-025 | BR-EVD-002 | T222 |
| CHAT-03 | i’d rather NOT introduce fields! | ACCEPTED_NO_UNPROVEN_SCHEMA | BRS-003 | BR-WGT-008 | T221 |
| CHAT-04 | The quantity actually shown on the PL, Receiving Report or scale ticket | ACCEPTED | BRS-003 | BR-VOC-001 | T181, T220 |
| CHAT-05 | Gross less corresponding vehicle/CST tare | ACCEPTED | BRS-003 | BR-VOC-001 | T181, T220 |
| CHAT-06 | Weight of applicable Gaylords, pallets, etc. | ACCEPTED | BRS-003 | BR-VOC-001 | T127, T220 |
| CHAT-07 | Load net less applicable packaging tare, or independently verified material-only net | ACCEPTED | BRS-003 | BR-VOC-001 | T127, T220 |
| CHAT-08 | The validated material net used for supplier or buyer settlement | ACCEPTED | BRS-003 | BR-VOC-001 | T181, T220 |
| CHAT-09 | technically Scale Weight isn't a billable weight... it's more of a reference weight | ACCEPTED | BRS-003 | BR-WGT-001 | T182, T184 |
| CHAT-10 | if supplier weight is 4% below scale and buyer weight is 4% above scale it would pass | ACCEPTED_INTENT | BRS-003 | BR-WGT-010 | T184, T185 |
| CHAT-11 | certified weight, if not available then buyer weight, if not available then supplier weight | ACCEPTED_DISPLAY_ONLY | BRS-003 | BR-WGT-009 | T182, T183 |
| CHAT-12 | material net weight and load net weight (cst gross-cst tare) | ACCEPTED | BRS-003 | BR-CST-002 | T123, T124 |
| CHAT-13 | both should have the same packaging tare | ACCEPTED_WITH_SOURCE_PROOF | BRS-003 | BR-WGT-003 | T127, T220 |
| CHAT-14 | shipper weight for computing the billable weight that goes to the rwn | ACCEPTED | BRS-004 | BR-SET-001 | T049, T051 |
| CHAT-15 | buyer received weight to compute the invoice weight | ACCEPTED | BRS-005 | BR-REC-001 | T053, T054 |
| CHAT-16 | the RWN and the buyer Receiving Report are distinct | ACCEPTED_CURRENT_BRS_SOURCE | BRS-001 | BR-DOC-001 | T111, T219 |
| CHAT-17 | CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed | ACCEPTED_CURRENT_BRS_SOURCE | BRS-003 | BR-CST-002 | T035, T036, T124 |
| CHAT-18 | supplier PL absent never blocks RWN or Customer Invoice by itself | ACCEPTED_CURRENT_BRS_SOURCE | BRS-004 | BR-SET-004 | T033, T140 |
| CHAT-19 | missing CST does not block buyer invoice, regular RWN, or commercial close | ACCEPTED_CURRENT_BRS_SOURCE | BRS-006 | BR-CAR-002 | T034, T035 |
| CHAT-20 | carrier late missing-CST chargeback $150 | ACCEPTED_AMOUNT_PENDING_TIMING | BRS-006 | BR-CAR-003 | T067, T069 |
| CHAT-21 | 40,000 lbs / 53' Trailer | ACCEPTED | BRS-007 | BR-UND-001 | T205, T206 |
| CHAT-22 | 38,001 lbs shipped = no deduction because it's not 2k lbs below | ACCEPTED | BRS-007 | BR-UND-001 | T205, T206 |
| CHAT-23 | 36,000 lb × $0.02/lb | ACCEPTED_FORMULA_RATE_REVISED_LATER | BRS-007 | BR-UND-002 | T209, T210 |
| CHAT-24 | Looking at the deduction column I’m inclined to revise my answer | ACCEPTED_FINAL_LATEST | BRS-007 | BR-UND-002 | T207, T208 |
| CHAT-25 | 40k lbs/53’ Trailer Minimum Weight 38k net weight | HISTORICAL_SUPERSEDED_NUMERIC_EXAMPLE | BRS-007 | BR-UND-002 | T205, T206 |
| CHAT-26 | _compute_light_weight_deduction Be compute_light_weight_deduction_total instead? | ACCEPTED_NAMING_PROPOSED_TECHNICAL_MIGRATION | BRS-007 | BR-UND-004 | T197, T218 |
| CHAT-27 | light_weight_deduction_rate light_weight_deduction_weight light_weight_deduction_total | ACCEPTED_NAMING_PROPOSED_TECHNICAL_MIGRATION | BRS-007 | BR-UND-004 | T197, T218 |
| CHAT-28 | The Boolean logic seems outdated | ACCEPTED_BUSINESS_RETIREMENT | BRS-007 | BR-UND-005 | T197, T199 |
| CHAT-29 | Yes make it obligation-scoped | ACCEPTED | BRS-007 | BR-UND-003 | T212, T216, T217 |
| CHAT-30 | if we sell to someone and they handle freight we can be penalized for light weight | ACCEPTED | BRS-007 | BR-UND-003 | T212, T216 |
| CHAT-31 | One deterministic calculation produces an eligible shortfall and amount. Then existing Purchase, Sales, Claims and Accounting owners determine whose obligation it is | ACCEPTED | BRS-007 | BR-UND-007 | T217 |
| CHAT-32 | transforming the bps into a format like ADR’s with an index numbering etc | ACCEPTED_ARCHITECTURAL_DIRECTION | ADR-025 | BR-EVD-002 | T222 |
| CHAT-33 | RWN normally uses supplier weight; buyer Received Report is mandatory for full buyer invoice | UNKNOWN_SCOPED_D18 | BRS-004 | BR-SET-004 | T219, T223 |
| CHAT-34 | 40 lb Gaylord, 40 lb pallet, combined 80 lb | ACCEPTED_BASICS_D15_OPEN | BRS-003 | BR-WGT-004 | T127, T220 |
| CHAT-35 | stated_net_lbs -> why "stated" | ACCEPTED_NAME_REJECTION | BRS-003 | BR-WGT-002 | T220, T221 |

## Negative controls and unresolved-policy instructions

- **D13:** Direct commercial discrepancy >5% requires human review. The denominator is not independently operator approved; keep source code's max-denominator percentage PROVISIONAL, do not present it as finalized legal/business rule. CST measurements are references only.
- **D14:** Supplier net missing holds RWN quantity, never substitutes buyer net. Buyer invoice independently eligible when buyer report accepted.
- **D15:** Mixed packaging, boxes, custom pack tare and disputed source quantities require evidence. The 40/40/80 lb accepted basics do not authorize inventing zero tare or double subtraction.
- **D16:** Buyer liability, supplier recovery, claim and accounting documents require contract and native posting authority. Continuous LWD formula is not an invoice or a journal entry.
- **D18:** Whether supplier RWN may be sent before buyer Receiving Report is missing remains an open concern; buyer report definitely gates full buyer invoice. A supported supplier RWN draft is not automatic send permission.
- **D01/D03/D04/D05:** Carrier certified gross/net document obligation, form sufficiency, $150 missing-CST chargeback eligibility and native accounting remain appropriately scoped. Do not confuse missing packaging or uncertified supplier scale with missing certified CST.
- **Rate historical corrections:** Historical $200/$400, shortfall-times-fixed-rate, complete-500-only tiers and 38,000/36,000 mental-arithmetic corrections are **superseded**. Current accepted formula is continuous `.01 * (shortfall/2000)` per-lb against ACTUAL material net, active after inclusive 2,000 lb shortfall; round only final USD amount to cents. Correct 36,000 example = **$720**; 37,750 -> **$424.69**, 37,501 -> **$468.57**.
- **No new data models:** Proposed field renames (`light_weight_deduction_total`, `_compute_light_weight_deduction_total`) are not installed or authorized schema changes; `light_weight_deduction_weight` stays a pure calculation output; `final_weight` and dead-freight Boolean technical retirement waits for full consumer and historical migration proof.

## Source-evidence and test proof boundaries

Operator acceptance in this chat establishes intended **business** policy, not admission into repository. Rule SHA and machine index parity are documentary consistency, not proof of source-independent business correctness. All `T001`..`T223` remain **NOT_RUN** as actual Odoo tests until explicitly bound to actual test functions and receipt under the pinned disposable Enterprise-equivalent target. The existing root CI workflow is `.github/workflows/ci.yml`, `static-checks` and `ci-gate-result`; do not create a duplicate workflow.
