# Validation Scope, Replay and Evidence Distinctions

**Campaign:** v1.3.1, BRS `brs-documents@1.3.1`. **Target:** `cryptoxdog/IB-Odoo_19`, Staging source 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e. **Status:** operator-requested planning artifact, not a committed/deployed repository implementation.

## Sources and unchanged predecessor

Immediate predecessor: **`Odoo_Documents_Campaign_v1.3.0_2026-10-19.zip`**, SHA-256 **`922a545e59a2cb0e7353c6e25bc14f39f3bd0cb63a1523611a98772be4ff01a2`**. Earlier frozen `source_inputs/` documents remain byte-identical, not rewritten after later user corrections. Current chat audit is `validation/CHAT_POLICY_AUDIT.json` and `.md`, with **partial source boundary**: model-visible turns plus preserved historical sources; no full independently exported chat/donor proof.

**Pinned repository observation:** `cryptoxdog/IB-Odoo_19` `Staging@4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`. Read-only inspection confirms `docs/adr/README.md`, existing `.github/workflows/ci.yml` static-checks/ci-gate-result, and that `docs/business-rules/` is not admitted at the observed revision. Read-only source is not Odoo.sh installed Enterprise registry proof. **Re-resolve Staging and existing ADR/path collisions before implementation.**

## Current inventory and counted proofs

- **13 slices, 129 tasks, 55 requirements, 33 document classes, 223 acceptance specifications** (all `NOT_RUN`), 29 source findings, 18 bounded decisions (D17 calculation resolved; D18 scoped unknown).
- **Seven independent numbered BRS sources, 46 immutable original `BR-*` IDs, 147 declared field/wrapper identities, 35 source fact/evidence concepts (not ORM fields), 8 routes and 4 native financial consumers**, plus illustrative Decimal arithmetic and falsification fixtures.
- **13 proposed repository copy files**, one exact `REGISTRATION_MANIFEST.json`, one downstream registration runbook, a chat-to-rule fidelity ledger with 35 bounded entries and 12 findings. All policy-bearing files are still PROPOSED to the repository.
- Automated local proofs: version/index/SHA/owner consistency, pure Decimal arithmetic, known-bad policy mutation rejection, and full ZIP round trip; no actual Odoo runtime or remote CI execution.

## Package-level tests and exact command

After extracting the ZIP's single top-level folder, run **only**:

```sh
python3 validation/check_campaign.py . --self-test
```

This validator is read-only by default, and writes a receipt only on explicit `--write-report` to a path **outside** the ZIP root. It runs declared policy assertions, schema/identity/ownership checks, byte-level continuity, generated-view parity, typed routing conformance, 16 accepted Decimal fixtures and explicit edge witnesses and deliberately invalid in-memory witnesses. It cannot execute Odoo ORM, deployed AI workflows, Postgres data mutations, email delivery, native invoice posting, or actual CI. It does **not** prove installed field declarations merely by reading code. The old global make publication ritual is not applicable to this Odoo repository.

## Required future runtime proof (NOT_RUN)

Execute actual instantiated Odoo 19 Enterprise tests in a disposable production-equivalent DB with real installed modules, correct branch/commit, verified BRS revision and realistic separate supplier/buyer/CST source documents. Prove required `documents.document` fields/selection/AI actions exist, correct `plasticos.document` role+tag mapping, no wrong source field writes, per-line net with UoM and packaging, native `sale.order.line`/`purchase.order.line` invoiceability, native `account.move` posting/send guards, supplier RWN revisions, scale compliance and $150 chargeback idempotency. CI must fail on known-bad field names, fake `CST` certification, net packaging double deduction, false buyer invoice blocker and silent skipped ORM tests; same-code-head known-good fixtures must pass. New negative witnesses include scale-as-payable, 4%/4% direct spread masked by reference comparisons, threshold 38,001/38,000, full 4,000 lb shortfall, zero-rate `or` fallback, supplier recovery mirrored from buyer liability and resurrection of obsolete `dead_freight_chargeback` Boolean. Full behavior cannot be promoted to PASS by this ZIP's 223 unexecuted cases.

## Package validation receipt

`SHA256SUMS.json` verifies every other member. The final externally stored receipt records whole ZIP digest, predecessor, source preservation, derived view parity, actual data/view negative control counts and structural assertion count. That receipt lives **outside** the ZIP to avoid circular self-hashing. No agent-issued execution grants arise from a local pack checksum or the ADR-025 draft.

## Seven numbered scoped business-rule owners and approval boundary

`docs/business-rules/README.md` is the Documents concern index/family, not a monopoly owner of all rules. `docs/business-rules/BRS-003-weights-and-packaging.md` owns physical vocabulary, reference scale and commercial spread review. `docs/business-rules/BRS-007-underweight-and-chargebacks.md` owns threshold amount and contractual/accounting attribution. The validator checks every rule ID is normatively declared in **exactly one** BRS. Code-method naming is a **proposed controlled Odoo migration**, not proof that `_compute_light_weight_deduction_total` exists. No ORM/runtime/financial tests run from this packaging step.

**D17 resolved calculation:** Earlier v1.2.1 arithmetic compared incompatible operator examples and $0.01 per shortfall pound, but U07 explicitly replaces them with a 53-foot 40000 lb minimum, inclusive 2000 lb trigger, continuous 500 lb pro-rata rate on actual material-net amount (BRS-007 BR-UND-002). D17 no longer blocks pure calculation; D16 independently controls contractual applicability, beneficiary and native accounting effects. Local fixture arithmetic is NOT actual Odoo proof.

## v1.3.1 numbered BRS and accepted LWD formula

The submitted `index.json`, `README.md`, `TRACEABILITY.md`, seven numbered BRS files and standalone `docs/business-rules/check_brs.py` form a *proposed* downstream coding/test contract. BRS checker PASS proves unique numbered rule ownership, exact digests, and 16 pure Decimal fixture vectors. It does NOT mean Odoo CI is configured to call it. The package's source statements are bound to earlier Staging SHA; installed Odoo 19 Enterprise, Documents provider, accounting flows, migration, security, and actual producer/consumer tests are NOT_RUN. Current approved D17 arithmetic is no longer a monetary-rate blocker; D16 contract and native financial authority remain open.
