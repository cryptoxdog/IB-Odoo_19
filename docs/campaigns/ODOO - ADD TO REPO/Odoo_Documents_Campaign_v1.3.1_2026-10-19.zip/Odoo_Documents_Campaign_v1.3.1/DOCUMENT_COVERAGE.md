# Document Coverage and Field-Action Inventory

**Version:** 1.3.1 | **BRS:** brs-documents@1.3.1 | **Status:** package specification, not executed Odoo software.

**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed.** Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. Missing packaging alone is not missing CST.

## Gate shorthand

Buyer Receiving Report is mandatory for full Customer Invoicing. Supplier PL is tracked where applicable but nonblocking; supplier/buyer Scale Tickets are optional. Missing supplier_weight holds the RWN under D14, not the Customer Invoice. Carrier CST is mandatory/nonblocking; its certified-document sufficiency is separate from packaging-tare billing readiness.

## Inventory

| ID | Document | Party/direction | Owner slices | Acceptance |
|---|---|---|---|---|
| C01 | Supplier invoice | supplier | S10 | T004; T011; T012; T013; T057; T060; T079; T081; T167; T178; T188; T189; T190; T191; T192 |
| C02 | Supplier credit note | supplier | S10 | T082 |
| C03 | Supplier order or purchase confirmation | supplier | S11 | T089 |
| C04 | Supplier Packing List (PL) / material manifest | supplier | S05; S11 | T033; T107; T108; T109; T110; T127; T128; T130; T132; T133; T136; T137; T138; T139; T140; T141; T143; T162; T163; T172; T220; T221 |
| C05 | Optional supplier scale ticket or supplier weight declaration | supplier | S05 | T032; T107; T113; T122; T131; T142; T155; T156 |
| C06 | Supplier loading photographs | supplier | S11 | T091 |
| C07 | Bill of Lading (BOL): supplier/carrier copy | supplier/carrier | S05; S11 | T003; T112; T174 |
| C08 | Required carrier Certified Scale Ticket (CST): CST gross, CST tare, CST net and net weight billed | carrier | S05; S08; S09 | T028; T034; T035; T036; T037; T038; T040; T063; T067; T068; T069; T070; T071; T072; T076; T097; T099; T115; T122; T123; T124; T125; T126; T127; T128; T130; T131; T132; T133; T134; T135; T136; T142; T152; T153; T154; T155; T156; T157; T158; T159; T160; T161; T163; T164; T171; T172; T173; T175; T176 |
| C09 | Independent scale certificate | other established issuer | S05; S08 | T028; T103; T104; T113 |
| C10 | Delivery BOL / proof of delivery | carrier/buyer | S05; S11 | T100 |
| C11 | Carrier dispatch/DO acknowledgment | carrier | S11 | T089 |
| C12 | Carrier freight invoice/accessorials | carrier | S09; S10 | T004; T060; T073; T075; T080; T082 |
| C13 | Container/trailer/chassis/seal record | carrier | S05; S11 | T007; T029; T046; T047 |
| C14 | Pickup/delivery confirmation message | supplier/carrier/buyer | S05; S11 | T048 |
| C15 | Damage/shipping discrepancy report | carrier/buyer | S11 | T085 |
| C16 | Buyer purchase order | buyer | S11 | T089 |
| C17 | Buyer Receiving Report (mandatory inbound) | buyer | S05; S06; S07; S08 | T011; T012; T024; T029; T030; T031; T032; T034; T039; T045; T055; T063; T081; T097; T105; T108; T109; T110; T111; T114; T127; T128; T130; T132; T133; T134; T135; T136; T137; T144; T145; T146; T147; T148; T149; T150; T151; T162; T163; T164; T165; T172; T175; T176; T219; T220; T221; T223 |
| C18 | Optional buyer scale ticket (not Receiving Report) | buyer | S05; S07 | T013; T101; T107; T114; T122; T144; T156 |
| C19 | Buyer weight adjustment/deduction report | buyer | S05; S07; S10 | T043; T059 |
| C20 | Buyer quality/rejection claim and photos | buyer | S11 | T085 |
| C21 | Buyer remittance/payment advice | buyer | S10; S11 | T084 |
| C22 | Buyer debit/credit note | buyer | S07; S10 | T083; T194; T195 |
| C23 | Certificate of analysis/material specification | supplier/issuer | S11 | T086 |
| C24 | Quality certificate/permit/vendor compliance | supplier/carrier/issuer | S11 | T086 |
| C25 | Contract/recurring pricing terms | counterparty | S11 | T087 |
| C26 | Transaction correspondence/supporting evidence | all established parties | S03; S11 | T005; T021; T091 |
| C27 | Vendor onboarding/tax/bank documents | vendor | S11 | T026; T088 |
| C28 | Our PO to supplier | outbound_supplier | S06; S11 | T090 |
| C29 | Our SO to buyer | outbound_buyer | S07; S11 | T090 |
| C30 | Our delivery order/dispatch packet | outbound_carrier | S08; S09; S11 | T090 |
| C31 | Received Weight Notice (RWN, outbound to supplier) | outbound_supplier | S06 | T030; T032; T049; T050; T051; T052; T053; T097; T102; T103; T104; T105; T106; T107; T111; T117; T123; T125; T126; T140; T150; T162; T163; T164; T165; T166; T167; T169; T182; T184; T185; T186; T187; T219; T223 |
| C32 | Our Customer Invoice | outbound_buyer | S07 | T030; T032; T034; T053; T054; T055; T058; T059; T097; T105; T140; T144; T147; T148; T149; T150; T151; T165; T171; T178; T219 |
| C33 | Carrier missing-CST chargeback notice | outbound_carrier | S09 | T067; T069; T073; T074; T076; T077; T078; T097; T157; T196 |

## C01. Supplier invoice

| Concern | Specification |
|---|---|
| Business event | Material invoicing |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | invoice -> INV |
| Extraction or generated content | invoice number/date; PO/TX references; line material; quantity/unit; price; tax; currency; freight/deductions; totals |
| Authoritative evidence | Supplier invoice claims amounts; accepted PO/contract and validated receipt govern reconciliation. |
| Correct destination | account.move Vendor Bill; plasticos.transaction.vendor_bill_ids; native purchase lines |
| Validation | Vendor/company, invoice identity, terms, arithmetic, quantity basis and duplicate checks |
| Automated result | Native digitization -> matched draft -> eligible posting |
| Specific exception | Unknown AP weight terms, mismatch, duplicate, consolidated allocation gap |
| Blocking scope | AP-specific prerequisites only; never required for RWN/AR |
| Owner slices | S10 |
| Original dossier items | 07_Supplier_Invoice |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T004; T011; T012; T013; T057; T060; T079; T081; T167; T178; T188; T189; T190; T191; T192 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C02. Supplier credit note

| Concern | Specification |
|---|---|
| Business event | Correction/credit |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | invoice -> INV plus native move_type |
| Extraction or generated content | original invoice; credit reference; line/reason; tax/currency; amount |
| Authoritative evidence | Supplier-issued correction plus approved matching original |
| Correct destination | Native in_refund or approved native correction; transaction bill relationships |
| Validation | Correct original vendor/company/sign, no duplicate credit or posted rewrite |
| Automated result | Create/reconcile eligible native credit |
| Specific exception | Unsupported consolidation, disputed reason, original not found |
| Blocking scope | Does not hold unrelated RWN/AR |
| Owner slices | S10 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T082 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C03. Supplier order or purchase confirmation

| Concern | Specification |
|---|---|
| Business event | Confirm purchase terms/readiness |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | Existing CO/CORR or OTHER; do not call it buyer SO |
| Extraction or generated content | PO/TX; material; quantity/unit; price/terms; dates; readiness |
| Authoritative evidence | Supplier statement confirms evidence; accepted PO owns price/commitment |
| Correct destination | purchase.order and existing transaction ready/date fields via native actions |
| Validation | PO/party identity and no unilateral commercial amendments |
| Automated result | File and compare; apply allowed readiness facts |
| Specific exception | Changed price/dates/quantity requiring owner decision |
| Blocking scope | No blanket document gate; existing permitted event prerequisites only |
| Owner slices | S11 |
| Original dossier items | 01_Supplier_SO |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T089 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C04. Supplier Packing List (PL) / material manifest

| Concern | Specification |
|---|---|
| Business event | Load/material detail |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | PACKING exists; native bol/other fallback must preserve tag |
| Extraction or generated content | TX/load references; line/material; package counts; unit weights; source gross/net/units; Gaylord and pallet presence; lot/seal/trailer when explicit |
| Authoritative evidence | Supplier Packing List supports supplier quantity and packaging. Track and collect where applicable; absence is nonblocking, not an automatic waiver of collection. Use approved 40/40/80 only for evidenced packages and never infer buyer receipt. |
| Correct destination | supplier_weight when eligible; load/transaction known fields and evidence |
| Validation | Per-load line and package count, correct material and units, avoid double packaging tare, D15 for mixed/boxes. |
| Automated result | Extract and fill eligible facts; update checklist |
| Specific exception | Missing/misaligned/ambiguous facts; never infer receipt |
| Blocking scope | Supplier PL absence is NOT a documentary RWN or Customer Invoice blocker; supplier RWN still needs a valid payable quantity from some authorized source. |
| Owner slices | S05; S11 |
| Original dossier items | 04_Supplier_Packing_List |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T033; T107; T108; T109; T110; T127; T128; T130; T132; T133; T136; T137; T138; T139; T140; T141; T143; T162; T163; T172; T220; T221 |
| BRS rules | BR-DOC-001; BR-EVD-001; BR-EVD-002; BR-WGT-003; BR-WGT-004 |

## C05. Optional supplier scale ticket or supplier weight declaration

| Concern | Specification |
|---|---|
| Business event | Declare loaded quantity |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | scale_ticket -> SCALE; source category supplier |
| Extraction or generated content | weight value/unit; stated gross/tare/net or pair; ticket/date; load |
| Authoritative evidence | Supplier or supplier-arranged nearby scale evidence is optional; issuer/certification unknown until verified. May corroborate accepted supplier material net and independent reference reconciliation, but cannot authorize scale_weight as payable RWN basis. |
| Correct destination | plasticos.transaction.supplier_weight for supported net; raw numbers in source evidence |
| Validation | Explicit units, complete derivation, matching source/load, no double tare |
| Automated result | Apply eligible supplier observation, compare but do not block by absence |
| Specific exception | Incomplete pair, conflicting revisions, absent unit |
| Blocking scope | Supplier scale ticket NOT REQUIRED; missing supplier weight holds only RWN if no other payable basis and no approved D14 fallback; never Customer Invoice. |
| Owner slices | S05 |
| Original dossier items | 05_Supplier_Scale_Ticket |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T032; T107; T113; T122; T131; T142; T155; T156 |
| BRS rules | BR-CST-001; BR-DOC-001; BR-EVD-001; BR-EVD-002; BR-SET-003; BR-WGT-001 |

## C06. Supplier loading photographs

| Concern | Specification |
|---|---|
| Business event | Support load condition/count |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | loading_pic/photo -> PHOTO |
| Extraction or generated content | source identity; load; date if evidenced; visible package/seal labels |
| Authoritative evidence | Photo supports claims/visible facts; AI estimates are not measured weight |
| Correct destination | Existing attachments/documents and load evidence; claim when justified |
| Validation | Identity, no inferred mass, tamper/unreadability handling |
| Automated result | File/tag and propose visible fact candidates |
| Specific exception | Uncertain visual interpretation or quality issue |
| Blocking scope | Track per applicable requirement; no inferred new global billing gate |
| Owner slices | S11 |
| Original dossier items | 06_Supplier_Loading_Pics |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T091 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C07. Bill of Lading (BOL): supplier/carrier copy

| Concern | Specification |
|---|---|
| Business event | Origin movement evidence |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | bol -> BOL with responsible party |
| Extraction or generated content | BOL/TX/PO/load; pickup; date; carrier; material; weight/unit; trailer/seal |
| Authoritative evidence | Actual movement details corroborated with booked load |
| Correct destination | load references, seal/trailer, dates and document linkage; source weights only by role |
| Validation | Unique load, event chronology, party, gross/net meaning; supplier and carrier may submit same original BOL, one underlying doc and both source submissions retained. |
| Automated result | Fill eligible shipment facts and track receipt |
| Specific exception | Wrong destination, missing signature where required, conflicting seal |
| Blocking scope | Existing event-specific rules; not assumed Receiving Report substitute |
| Owner slices | S05; S11 |
| Original dossier items | 03_Supplier_BOL; 16_Carrier_BOL |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T003; T112; T174 |
| BRS rules | BR-DOC-002; BR-EVD-001; BR-EVD-002 |

## C08. Required carrier Certified Scale Ticket (CST): CST gross, CST tare, CST net and net weight billed

| Concern | Specification |
|---|---|
| Business event | Provide required load weighing evidence |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | Existing PlasticOS `plasticos_documents.tag_cst` (`code CST`, current label Carrier Scale Ticket (CST)) is available alongside generic `plasticos_documents.tag_scale_ticket` (`code SCALE`). Carrier `doc_category` and native `doc_type=scale_ticket` may apply. Reuse tags; actual certification must be verified from source, and do not add `doc_type=cst`. |
| Extraction or generated content | certification/issuer evidence; ticket/load/vehicle identity; CST gross; CST tare; CST net; source-specific packaging count and packaging tare when available; net weight billed (derived billing result, not an ORM field); unit/time/revision |
| Authoritative evidence | Carrier submitted certified CST from trustworthy scale issuer, load-matched. Optional supplier/buyer tickets may be uncertified; no unverified certification inference. |
| Correct destination | Keep original certified CST physical gross/tare/net and source-linked packaging evidence; packaging-adjusted material net may populate existing plasticos.transaction.scale_weight as REFERENCE ONLY when independently verified. Human review required for >5% direct supplier/buyer settlement dispute, never auto scale substitute. |
| Validation | Document branch: certification, issuer/load identity, valid required CST gross/net and supported CST tare arithmetic. Billing branch: source-specific packaging evidence and no double deduction. D15 packaging unknownness does not undo otherwise complete CST receipt or itself qualify the $150 penalty. |
| Automated result | Complete only the certified-document components actually satisfied; independently derive net weight billed when packaging is known. Missing packaging holds that calculation only, not CST receipt or Customer Invoice. |
| Specific exception | Document exception: uncertified/contradictory/incomplete required CST or failed parsing. Separate calculation exception: missing/mixed packaging or unsupported net-label interpretation. Do not conflate the two. |
| Blocking scope | Certified CST REQUIRED per load, but absent/invalid carrier evidence cannot automatically block buyer Invoice, ordinary supplier RWN or commercial close. Separately authorized $150 carrier documentation claim may apply. Direct supplier/buyer spread >5% needs human review independently of CST documentary compliance. |
| Owner slices | S05; S08; S09 |
| Original dossier items | 17_Carrier_CST |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T028; T034; T035; T036; T037; T038; T040; T063; T067; T068; T069; T070; T071; T072; T076; T097; T099; T115; T122; T123; T124; T125; T126; T127; T128; T130; T131; T132; T133; T134; T135; T136; T142; T152; T153; T154; T155; T156; T157; T158; T159; T160; T161; T163; T164; T171; T172; T173; T175; T176 |
| BRS rules | BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-CST-001; BR-CST-002; BR-EVD-001; BR-EVD-002 |

## C09. Independent scale certificate

| Concern | Specification |
|---|---|
| Business event | Independent weighing |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | scale_ticket -> SCALE with issuer evidence; blank party does not mean trusted |
| Extraction or generated content | issuer; certification; gross/tare/net; unit; time; load |
| Authoritative evidence | Scale-source issuer/measurement must be validated; supplier-arranged nearby independent scale or carrier copy may be evidence if D13 criteria qualify; not automatically settlement authority. A certified independent ticket is not automatically a carrier CST without actual carrier delivery; certification does not by itself resolve D13 or the carrier submission obligation. |
| Correct destination | Source evidence; optional `scale_weight` only for qualified packaging-adjusted material net (D13), not the raw CST gross or preliminary CST net. |
| Validation | Issuer/load trust, pair consistency, complete arithmetic and units |
| Automated result | Store separate scale observation and reconcile |
| Specific exception | Unknown issuer, changed PDF, unrelated sender, contradiction |
| Blocking scope | Does not substitute buyer Receiving Report; may fulfill carrier scale obligation only under bound evidence policy |
| Owner slices | S05; S08 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T028; T103; T104; T113 |
| BRS rules | BR-CST-001; BR-EVD-001; BR-EVD-002; BR-SET-003; BR-WGT-002 |

## C10. Delivery BOL / proof of delivery

| Concern | Specification |
|---|---|
| Business event | Delivery evidence |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | BOL or DO existing tag with clear subtype evidence |
| Extraction or generated content | load/BOL; date/time; recipient/location; signature where required; condition |
| Authoritative evidence | Actual delivery confirmation; not necessarily receiving quantity report |
| Correct destination | load delivery evidence/actions, actual date fields |
| Validation | Correct recipient/load, event identity, signature policy, no report-equivalence guess |
| Automated result | File and apply eligible event/date |
| Specific exception | Wrong facility, partial delivery, damage |
| Blocking scope | Does not automatically replace mandatory buyer Receiving Report |
| Owner slices | S05; S11 |
| Original dossier items | 16_Carrier_BOL |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T100 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C11. Carrier dispatch/DO acknowledgment

| Concern | Specification |
|---|---|
| Business event | Acknowledge dispatch instructions |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | DO/CORR |
| Extraction or generated content | DO/TX/load; acknowledgment; time; carrier |
| Authoritative evidence | Carrier acknowledgment of our booked instruction |
| Correct destination | Existing dispatch_acknowledged/date/action and carrier docs |
| Validation | Authorized carrier contact, correct document version |
| Automated result | Record receipt/acknowledgment via owner method |
| Specific exception | Ambiguous acceptance, changed booking/price |
| Blocking scope | Operation-specific requirement; no new AR prerequisite |
| Owner slices | S11 |
| Original dossier items | 15_Carrier_DO_Confirmation |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T089 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C12. Carrier freight invoice/accessorials

| Concern | Specification |
|---|---|
| Business event | Bill transport and charges |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | invoice -> INV; party carrier |
| Extraction or generated content | invoice/DO/load; carrier; base freight; accessorial details; tax/currency; total |
| Authoritative evidence | Carrier claim versus booked freight/authorized extras |
| Correct destination | account.move Vendor Bill; plasticos.transaction.freight_bill_ids; existing load freight reconciliation |
| Validation | Invoice identity, rate, taxes, authorized accessorials, penalty linkage |
| Automated result | Native draft/reconcile/eligible post with separate chargeback |
| Specific exception | Disputed rate/extras, unknown company, paid/consolidated handling |
| Blocking scope | AP/freight-specific; not Customer Invoice gate |
| Owner slices | S09; S10 |
| Original dossier items | 18_Carrier_Invoice |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T004; T060; T073; T075; T080; T082 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C13. Container/trailer/chassis/seal record

| Concern | Specification |
|---|---|
| Business event | Transport identifiers |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | BOL/CORR/OTHER |
| Extraction or generated content | container; trailer; chassis; seal; event time; TX/load |
| Authoritative evidence | Matched transport evidence; later changes are versioned events |
| Correct destination | plasticos.load.seal_number and plasticos.load.trailer_number where meanings match; container/chassis scalar remains unbound, preserved as evidence. |
| Validation | No identifier conflation, leading zeros, conflicts and chronology |
| Automated result | Apply supported fields, retain all exact identifiers in evidence |
| Specific exception | No native destination for container/chassis, conflicting seal |
| Blocking scope | Unsupported scalar destination does not justify abusing trailer field |
| Owner slices | S05; S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T007; T029; T046; T047 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C14. Pickup/delivery confirmation message

| Concern | Specification |
|---|---|
| Business event | Movement/readiness event |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CORR/DO |
| Extraction or generated content | reference; event; timestamp; location; party |
| Authoritative evidence | Authorized explicit operational statement |
| Correct destination | Existing load/transaction event fields/actions |
| Validation | Timezones, scheduled versus actual, correct sender/record |
| Automated result | Record permitted fact and evidence |
| Specific exception | Forwarded ambiguous message, missing identity |
| Blocking scope | No body-only inference of full buyer Receiving Report unless accepted format |
| Owner slices | S05; S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T048 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C15. Damage/shipping discrepancy report

| Concern | Specification |
|---|---|
| Business event | Transport claim |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CORR/CLAIM_PHOTO/OTHER |
| Extraction or generated content | load; damage; weight/quantity affected; amount/reason; photos |
| Authoritative evidence | Claim allegation, not automatic accepted liability |
| Correct destination | plasticos.claim with existing category; source evidence |
| Validation | Identity, duplicate case, affected scope and counterparty |
| Automated result | Create/augment claim and appropriate exception |
| Specific exception | Unclear responsibility/amount, unsupported deduction |
| Blocking scope | Hold only materially affected settlement or operation |
| Owner slices | S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T085 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C16. Buyer purchase order

| Concern | Specification |
|---|---|
| Business event | Customer order |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | customer_order -> CO |
| Extraction or generated content | buyer PO; our SO/TX; lines/material; quantity/unit; price; dates/terms |
| Authoritative evidence | Accepted native SO owns commercial terms; buyer PO is corroborating/new request |
| Correct destination | sale.order existing native reference/lines under approved workflow |
| Validation | Buyer/facility/company, duplicate/order identity, terms mismatch |
| Automated result | File, match, propose valid existing-order update |
| Specific exception | New commitment, price mismatch, unknown customer |
| Blocking scope | Does not itself establish delivery or invoice creation |
| Owner slices | S11 |
| Original dossier items | 09_Buyer_PO |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T089 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C17. Buyer Receiving Report (mandatory inbound)

| Concern | Specification |
|---|---|
| Business event | Receipt of material |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | RECEIVING existing custom tag; use supported native tag/other mapping |
| Extraction or generated content | report ID/revision; TX/SO/PO/BOL/load; buyer facility; receipt date; material/line; accepted received net/unit -> buyer_weight; packaging unit counts and tare; gross/tare if stated; deductions/rejections; trailer/seal |
| Authoritative evidence | INBOUND buyer Receiving Report, mandatory acceptance proof for full Customer Invoice. Supplies buyer_weight only; it is NOT an outbound Received Weight Notice or ordinary supplier payable quantity. |
| Correct destination | plasticos.transaction.buyer_weight; plasticos.load evidence/fields; validated buyer receipt for invoice and supplier RWN comparison. |
| Validation | Required load/party/net/unit, quantities/arithmetic, revision, rejection, active source |
| Automated result | Apply validated buyer_weight/load facts and establish Customer Invoice readiness. Reevaluate supplier RWN comparison separately; do not release RWN until its supplier quantity, price and deductions are supported. |
| Specific exception | Missing/unclear net, wrong facility, partial report, material contradiction |
| Blocking scope | MANDATORY for full Customer Invoice; when present supports direct supplier/buyer reconciliation. Its absence alone has no operator-admitted universal RWN prerequisite; supplier notice ordering D18 is separately open. |
| Owner slices | S05; S06; S07; S08 |
| Original dossier items | 10_Buyer_Receiving_Report |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T011; T012; T024; T029; T030; T031; T032; T034; T039; T045; T055; T063; T081; T097; T105; T108; T109; T110; T111; T114; T127; T128; T130; T132; T133; T134; T135; T136; T137; T144; T145; T146; T147; T148; T149; T150; T151; T162; T163; T164; T165; T172; T175; T176; T219; T220; T221; T223 |
| BRS rules | BR-DOC-001; BR-EVD-001; BR-EVD-002; BR-REC-001; BR-WGT-003; BR-WGT-004 |

## C18. Optional buyer scale ticket (not Receiving Report)

| Concern | Specification |
|---|---|
| Business event | Buyer weight/settlement detail |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | Existing SCALE tag with buyer doc_category; not RECEIVING by tag substitution. A separately approved D07 report-equivalent document must satisfy report content, not merely carry scale numbers. |
| Extraction or generated content | received net/unit; gross/tare; report/load; settlement line; date |
| Authoritative evidence | Optional buyer-side weighing corroboration; does not by itself satisfy mandatory inbound buyer Receiving Report. May not be certified; not a carrier CST or substitute for buyer Receiving Report. |
| Correct destination | buyer_weight and evidence; AR input through validated receipt path |
| Validation | No generic scale tag substitute, price/deduction authority, revision checks |
| Automated result | Record measurement; qualify report completeness independently |
| Specific exception | Measurement without actual report essentials |
| Blocking scope | Buyer scale ticket NOT REQUIRED; does not replace mandatory Receiving Report without approved D07 accepted equivalence. |
| Owner slices | S05; S07 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T013; T101; T107; T114; T122; T144; T156 |
| BRS rules | BR-CST-001; BR-DOC-001; BR-EVD-001; BR-EVD-002; BR-REC-001 |

## C19. Buyer weight adjustment/deduction report

| Concern | Specification |
|---|---|
| Business event | Correct receipt/settlement |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | RECEIVING/CORR |
| Extraction or generated content | original report; revised weight; amount; reason; affected lines/date |
| Authoritative evidence | Revised buyer evidence plus accepted commercial deduction terms |
| Correct destination | buyer_weight corrected source, native AR credit/debit if approved; claim for dispute |
| Validation | Original lineage, math, allowed deduction and posted-state guard |
| Automated result | Revalidate affected facts and draft correction |
| Specific exception | Unapproved deduction, unsupported revision, dispute |
| Blocking scope | No original invoice deletion; no silent supplier AP deduction |
| Owner slices | S05; S07; S10 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T043; T059 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C20. Buyer quality/rejection claim and photos

| Concern | Specification |
|---|---|
| Business event | Material acceptance dispute |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CLAIM_PHOTO/CORR/PHOTO |
| Extraction or generated content | report/load; rejection scope; material; reason; claim value; photos |
| Authoritative evidence | Buyer allegation requires appropriate quality/commercial validation |
| Correct destination | plasticos.claim; linked original documents and existing adjustment path |
| Validation | Duplicate claim, load scope, actual rejected quantity, authority |
| Automated result | File/open or update claim; hold only affected amount/action |
| Specific exception | Unclear financial responsibility or unsupported evidence |
| Blocking scope | Genuine exception, not automatic admitted liability |
| Owner slices | S11 |
| Original dossier items | 13_Buyer_Claim_Pics |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T085 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C21. Buyer remittance/payment advice

| Concern | Specification |
|---|---|
| Business event | Payment reference evidence |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CORR/INV/OTHER |
| Extraction or generated content | invoice refs; amount/currency; deduction; advice date; remittance ID |
| Authoritative evidence | Remittance is stated intent/advice, not bank-settlement proof |
| Correct destination | Native accounting matching evidence/communication; no automatic paid flag |
| Validation | Correct invoices/company, totals and duplicates |
| Automated result | Link advice and propose reconciliation references |
| Specific exception | Unmatched deduction, misleading bank instructions |
| Blocking scope | Not required for invoice creation; bank settlement outside scope |
| Owner slices | S10; S11 |
| Original dossier items | 12_Buyer_Payment |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T084 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C22. Buyer debit/credit note

| Concern | Specification |
|---|---|
| Business event | Commercial adjustment request |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | invoice -> INV plus native direction verification |
| Extraction or generated content | original invoice; amount/sign; currency/tax; reason |
| Authoritative evidence | Incoming buyer document is a request/evidence, not authorization to generate seller AR twice |
| Correct destination | Native out_refund/debit only through approved original invoice correction |
| Validation | Party, direction, original, terms, duplicate and closed-period handling |
| Automated result | Reconcile/request native correction when eligible |
| Specific exception | Dispute or unsupported liability |
| Blocking scope | Does not create a new sale simply because document says invoice |
| Owner slices | S07; S10 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T083; T194; T195 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C23. Certificate of analysis/material specification

| Concern | Specification |
|---|---|
| Business event | Technical support |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | LAB/CERT |
| Extraction or generated content | issuer; material/grade/lot; tests; units; date; spec revision |
| Authoritative evidence | Issuer test facts apply to identified lot/product only |
| Correct destination | Existing product/material/facility links plus retained document |
| Validation | Lot/facility identity, units and valid scope |
| Automated result | Classify/link and expose test facts; fill only eligible existing fields |
| Specific exception | Material spec conflict, no authoritative field, unreadable result |
| Blocking scope | Only contract-specific compliance gates; no invented global report requirement |
| Owner slices | S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T086 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C24. Quality certificate/permit/vendor compliance

| Concern | Specification |
|---|---|
| Business event | Qualification evidence |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CERT/PERMIT |
| Extraction or generated content | holder; issuer; scope; effective/expiry; facility; certificate number |
| Authoritative evidence | Validated credential within its scope |
| Correct destination | plasticos.document.expiry_date/current evidence and existing partner links |
| Validation | Expiry/current revision, holder/facility scope and issuer |
| Automated result | Track expiry, receipt and appropriate reminder |
| Specific exception | Expired/invalid/conflicting identity |
| Blocking scope | Only existing applicable policy may block a restricted operation |
| Owner slices | S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T086 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C25. Contract/recurring pricing terms

| Concern | Specification |
|---|---|
| Business event | Commercial agreement |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CONTRACT |
| Extraction or generated content | parties; material; effective dates; price basis; UoM/currency; terms; version |
| Authoritative evidence | Executed accepted agreement, not AI interpretation alone |
| Correct destination | Existing contract/PO/SO owner plus linked evidence |
| Validation | Authority, signatures if required, scope, conflict/supersession |
| Automated result | Classify/link and propose approved term application |
| Specific exception | Unilateral amendment or unclear applicability |
| Blocking scope | No silent repricing or blanket policy override |
| Owner slices | S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T087 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C26. Transaction correspondence/supporting evidence

| Concern | Specification |
|---|---|
| Business event | Operational conversation |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CORR/PHOTO/OTHER |
| Extraction or generated content | references; asserted event/fact; source date; sender/forward chain |
| Authoritative evidence | Statement scoped to authorized source; quoted prior thread not current authority |
| Correct destination | Correct native chatter/documents and allowlisted fact candidates |
| Validation | Attachment scope, identity, quote chronology, prompt injection |
| Automated result | File/link and update only eligible explicit fact |
| Specific exception | Unknown type/sender, instructions masquerading as data |
| Blocking scope | Specific exception, never silent loss |
| Owner slices | S03; S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T005; T021; T091 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C27. Vendor onboarding/tax/bank documents

| Concern | Specification |
|---|---|
| Business event | Master-data qualification |
| Receiving or outgoing channel | Native Documents alias/upload; source message retained; actual runtime configuration UNKNOWN |
| Existing classification, not new enum | CERT/CORR/OTHER |
| Extraction or generated content | legal entity; facility; tax identifier; bank-change request; effective date |
| Authoritative evidence | Sensitive master-data assertion requires protected validation |
| Correct destination | Existing res.partner and linked document review; bank changes remain protected |
| Validation | Identity, approved recipients, privacy and no automatic banking authority |
| Automated result | Capture/classify and route protected approval |
| Specific exception | New entity, changed bank/tax, untrusted sender |
| Blocking scope | Not arbitrary blocker on existing received load; protected master changes held |
| Owner slices | S11 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T026; T088 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C28. Our PO to supplier

| Concern | Specification |
|---|---|
| Business event | Purchase commitment |
| Receiving or outgoing channel | OUTBOUND native document/report/accounting workflow with authorized recipient and retained generated evidence; not incoming Documents alias or OCR. |
| Existing classification, not new enum | Native purchase PDF and existing document tag |
| Extraction or generated content | TX; PO; material; quantity/price/terms; delivery rules |
| Authoritative evidence | Accepted native purchase order |
| Correct destination | Native mail/report + single attached PDF and transaction evidence |
| Validation | Correct supplier, TX/PO in subject, no buyer leakage |
| Automated result | Render and send through existing authorized purchase action |
| Specific exception | Missing purchase authority/recipient |
| Blocking scope | Pre-existing commercial workflow, not new commitment generator |
| Owner slices | S06; S11 |
| Original dossier items | 02_PO_Issued_To_Supplier |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T090 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C29. Our SO to buyer

| Concern | Specification |
|---|---|
| Business event | Sale confirmation |
| Receiving or outgoing channel | OUTBOUND native document/report/accounting workflow with authorized recipient and retained generated evidence; not incoming Documents alias or OCR. |
| Existing classification, not new enum | Native sale PDF and existing CO/CORR |
| Extraction or generated content | TX; SO/buyer PO; material; quantity/price; terms |
| Authoritative evidence | Accepted native sale order |
| Correct destination | Native mail/report and transaction evidence |
| Validation | Buyer recipient, no supplier cost/identity leakage |
| Automated result | Existing approved outbound order path |
| Specific exception | New/changed commitment |
| Blocking scope | Not created merely from OCR instruction |
| Owner slices | S07; S11 |
| Original dossier items | 08_Our_SO_To_Buyer |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T090 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C30. Our delivery order/dispatch packet

| Concern | Specification |
|---|---|
| Business event | Carrier booking/instructions |
| Receiving or outgoing channel | OUTBOUND native document/report/accounting workflow with authorized recipient and retained generated evidence; not incoming Documents alias or OCR. |
| Existing classification, not new enum | Existing DO/BOL reports |
| Extraction or generated content | TX/DO/load; rate; pickup/delivery; required certified CST gross and CST net, with CST tare source arithmetic; approved deadline and $150 penalty terms |
| Authoritative evidence | Booked load and approved carrier terms |
| Correct destination | Existing load send methods/templates and document evidence |
| Validation | Correct carrier, policy applicability, required TX/ref, double-blind copies |
| Automated result | Render/send existing packet with approved scale obligations |
| Specific exception | Unsettled deadline or terms must not be invented |
| Blocking scope | Can state gross/net requirement and USD 150 policy only under approved applicability/wording |
| Owner slices | S08; S09; S11 |
| Original dossier items | 14_Delivery_Order_To_Carrier |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T090 |
| BRS rules | BR-EVD-001; BR-EVD-002 |

## C31. Received Weight Notice (RWN, outbound to supplier)

| Concern | Specification |
|---|---|
| Business event | Supplier settlement weight/price/approved deduction communication |
| Receiving or outgoing channel | OUTBOUND native report/mail template from independently supported supplier settlement quantity/terms; buyer Receiving Report participates in discrepancy comparison when available. Sending before buyer report is D18, not accepted or rejected by invented policy. |
| Existing classification, not new enum | Native mail/report action; existing RWN template not established |
| Extraction or generated content | TX/PO/load/material/date; accepted supplier settlement quantity and source evidence; normally supplier_weight, human-approved corrected commercial basis after >5% review; accepted supplier purchase unit price; authorized obligation-specific supplier-side underweight or other contract claims; supplier settlement net amount and correction/revision; supplier-approved recipient; buyer confidentiality |
| Authoritative evidence | Supplier PO terms plus independently validated accepted supplier material net; buyer report establishes direct comparison and independent Customer Invoice quantity; certified CST scale_weight is reference only, not a payable third weight. D13 human decision for any >5% direct spread and D14 missing supplier weight. |
| Correct destination | Native Odoo mail.template/report output to approved supplier recipient; accepted supplier-side settlement evidence, no parallel financial ledger. |
| Validation | Verify supported supplier weight, purchase price, supplier consent/recipient, approved adjustments and corrected revisions. When buyer report exists, check direct >5% material-net spread; otherwise preserve uncomputable comparison and D18 auto-send hold. CST reference only. |
| Automated result | Draft source-supported supplier notice; only send when existing native authorization, valid source/price/recipient, no unresolved dispute, and D18 sequencing rule permits. Never infer buyer RR automatically required or unnecessary for RWN. |
| Specific exception | Supplier source weight absent D14, >5% direct commercial spread pending human D13, unclear PO price/contract deduction, unauthorized recipient, incompatible correction. |
| Blocking scope | Supplier source quantity/terms required (D14), >5% direct spread requires human settlement review (D13); buyer RR is mandatory for buyer invoice ONLY. RWN auto-send timing without buyer RR remains D18 scoped UNKNOWN, no universal buyer-report documentary prerequisite. PL/carrier document obligations nonblocking. |
| Owner slices | S06 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T030; T032; T049; T050; T051; T052; T053; T097; T102; T103; T104; T105; T106; T107; T111; T117; T123; T125; T126; T140; T150; T162; T163; T164; T165; T166; T167; T169; T182; T184; T185; T186; T187; T219; T223 |
| BRS rules | BR-CST-001; BR-CST-002; BR-DOC-001; BR-EVD-001; BR-EVD-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-010; BR-UND-003 |

## C32. Our Customer Invoice

| Concern | Specification |
|---|---|
| Business event | Native Customer Invoice from buyer Receiving Report and accepted sale price |
| Receiving or outgoing channel | OUTBOUND native document/report/accounting workflow with authorized recipient and retained generated evidence; not incoming Documents alias or OCR. |
| Existing classification, not new enum | Native account.move out_invoice/report |
| Extraction or generated content | invoice/TX/SO; accepted buyer_weight quantity; price/tax/currency; totals |
| Authoritative evidence | Buyer Receiving Report accepted net -> buyer_weight; native sale.order and account.move prices/taxes/UoM, never supplier RWN basis. |
| Correct destination | Native draft/post/send and plasticos.transaction.customer_invoice_id |
| Validation | Report required; matching/tax/price/duplicate/authority checks |
| Automated result | Eligible native creation/post/send |
| Specific exception | Material dispute, unknown price/tax, duplicate or correction |
| Blocking scope | No dependency on supplier notice delivery or carrier penalty resolution |
| Owner slices | S07 |
| Original dossier items | 11_Buyer_Invoice |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T030; T032; T034; T053; T054; T055; T058; T059; T097; T105; T140; T144; T147; T148; T149; T150; T151; T165; T171; T178; T219 |
| BRS rules | BR-EVD-001; BR-EVD-002; BR-REC-001; BR-REC-002 |

## C33. Carrier missing-CST chargeback notice

| Concern | Specification |
|---|---|
| Business event | Notify eligible documentation penalty |
| Receiving or outgoing channel | OUTBOUND native document/report/accounting workflow with authorized recipient and retained generated evidence; not incoming Documents alias or OCR. |
| Existing classification, not new enum | Native mail/report plus freight_chargeback case |
| Extraction or generated content | TX/load/DO; missing gross/net; due basis; USD 150; credit/claim refs; dispute contact |
| Authoritative evidence | Approved carrier documentation rule and verified eligible missing evidence |
| Correct destination | Native message + existing claim/account.move references |
| Validation | One per event; correct carrier; no unapproved financial statement Separate carrier missing-CST $150 documentation chargeback from contractual material-net underweight deductions; no buyer liability/supplier recovery mirroring. |
| Automated result | Assess/notify approved USD 150 carrier chargeback under bound D01/D03/D04/D05; no carrier documentary obligation blocks Customer Invoice. |
| Specific exception | Unknown due/terms, unreadable intake vs absence, disputed applicability |
| Blocking scope | Never a buyer/supplier charge or AR blocker |
| Owner slices | S09 |
| Original dossier items |  |
| Implementation evidence | SOURCE_STORAGE_OR_FIELDS_ONLY; END_TO_END_NOT_PROVEN |
| Acceptance cases | T067; T069; T073; T074; T076; T077; T078; T097; T157; T196 |
| BRS rules | BR-CAR-003; BR-EVD-001; BR-EVD-002; BR-UND-007 |

## Original v4 dossier crosswalk

| Preserved dossier item | Coverage |
|---|---|
| 07_Supplier_Invoice | C01 |
| 01_Supplier_SO | C03 |
| 04_Supplier_Packing_List | C04 |
| 05_Supplier_Scale_Ticket | C05 |
| 06_Supplier_Loading_Pics | C06 |
| 03_Supplier_BOL | C07 |
| 16_Carrier_BOL | C07 |
| 17_Carrier_CST | C08 |
| 16_Carrier_BOL | C10 |
| 15_Carrier_DO_Confirmation | C11 |
| 18_Carrier_Invoice | C12 |
| 09_Buyer_PO | C16 |
| 10_Buyer_Receiving_Report | C17 |
| 13_Buyer_Claim_Pics | C20 |
| 12_Buyer_Payment | C21 |
| 02_PO_Issued_To_Supplier | C28 |
| 08_Our_SO_To_Buyer | C29 |
| 14_Delivery_Order_To_Carrier | C30 |
| 11_Buyer_Invoice | C32 |
