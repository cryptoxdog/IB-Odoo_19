# Three-Source Weight Field Routing and Native Commercial Conformance

**Version:** 1.3.1 | **BRS:** brs-documents@1.3.1 | **Status:** package specification, not executed Odoo software.

**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed.** Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. Missing packaging alone is not missing CST.

**Purpose:** field-by-field adapter contract for Documents, supplier RWN, buyer Customer Invoice, supplier Vendor Bill and required carrier certified CST. **Business law** lives ONLY in seven numbered, independently scoped BRS-001..007 files selected via the non-normative `docs/business-rules/index.json`. This is the derived source-declared implementation projection, **not** an Odoo model/schema or an independently admitted vocabulary. See ADR-025.

**Evidence status:** `Staging` 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e and public Odoo 19.0 code were inspected through read-only source; no installed Odoo Enterprise registry, DB, CI runtime or actual mail/accounting action was tested. Types marked ENTERPRISE are wrapper claims, not independently verified installed fields.

## 1. Business-authorized source lanes

| Lane | Identity-binding fields | Source documents | Only accepted existing scalar destination | Commercial use |
|---|---|---|---|---|
| SUPPLIER | plasticos.transaction.supplier_id | PL, BOL, optional Supplier Scale Ticket | plasticos.transaction.supplier_weight | Accepted supplier commercial material net; normal supplier RWN and PO/AP only. Direct supplier/buyer >5% requires human review; scale is never an automatic payable substitute. |
| BUYER | plasticos.transaction.buyer_id | Required buyer Receiving Report plus optional Buyer Scale Ticket | plasticos.transaction.buyer_weight | Accepted buyer commercial material net; Customer Invoice quantity independently after required report. Buyer contractual underweight liabilities separately owed only where proven. |
| CARRIER_CST | plasticos.transaction.carrier_id / plasticos.load.carrier_id | Required Carrier Certified Scale Ticket | plasticos.transaction.scale_weight (verified packaging-adjusted material net REFERENCE ONLY; no automatic supplier/buyer settlement) | CST certified gross/net mandatory per load; packaging-adjusted material net reference for triad reconciliation/display, not third billable basis. |

**Rule:** names like `supplier_scale_gross`, `CST tare`, `S_DOCUMENT_NET` and `B_DOCUMENT_NET` are typed **document observations only**; document-labeled net is not by itself material net, so neither observed field is an Odoo `fields.Float` nor may it auto-write accepted scalar weights without proving the physical measurement and packaging basis. The exact installed field selection/type remains a runtime proof obligation.

## 2. Gross, tare, net and packaging physical equations by source

| Measurement lane | Formula/meaning |
|---|---|
| supplier_optional_scale | Supplier scale gross - matching supplier scale tare = supplier scale net (not automatically packaging-excluded supplier_weight). |
| buyer_optional_scale | Buyer scale gross - matching buyer scale tare = buyer scale net (not mandatory Receiving Report). |
| carrier_cst | CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed. |
| supplier_pl | Supplier declared material gross - supplier packaging tare = supplier material net only if source supports inclusion and count. |
| buyer_receiving | Buyer received gross - buyer packaging tare = buyer material net only if the report establishes that basis. |
| billing | Accepted commercial material-net quantities remain supplier_weight for normal RWN and buyer_weight for customer Invoice. CST scale material net is independent REFERENCE only; >5% direct supplier/buyer discrepancy mandates recorded human review and no automatic substitution. |

A named **CST net** is not yet billable material net. Missing packaging alone does not make a certified gross/net CST missing. Gross and paired scale tare must describe the same issuer, load, unit, vehicle/time event. The independent supplier/buyer scale tare terms are not CST tare and cannot discharge the carrier documentation obligation.

## 3. Document-specific source routing matrix

| Route | Issuer party | Business document | Actual existing native doc_type | Legacy tag | Mandatory validation | Source facts | Exact write target or evidence only | Result and prohibition |
|---|---|---|---|---|---|---|---|---|
| ROUTE-SUP-PL | supplier | Packing List (PL) | bol or other (per verified classification) | PACKING | Supplier/source document accepted, exact load/material and net/packaging basis confirmed; PL collection nonblocking | S_GROSS; S_PACK_GAYLORD; S_PACK_PALLET; S_PACK_COMBINED; S_PACK_TARE; S_DOCUMENT_NET; S_PER_UNIT_WEIGHT | plasticos.transaction.supplier_weight | Write validated packaging-excluded supplier material net only; otherwise source evidence plus review; PL absence itself does not block buyer AR/RWN. |
| ROUTE-SUP-BOL | supplier | Bill of Lading (BOL) | bol | BOL | issuer/shipper corroborated; shipment identity | S_DOCUMENT_NET; S_DOC_ID | plasticos.transaction.supplier_weight | May corroborate supplier net when explicit; file same underlying BOL sent by carrier with distinct source delivery, no duplicate bill. |
| ROUTE-SUP-SCALE | supplier | Supplier Scale Ticket | scale_ticket | SCALE | verified supplier/scale issuer + exact matched event and load; optional; may be uncertified | S_DOCUMENT_NET; S_DOC_ID; S_SCALE_GROSS; S_SCALE_TARE; S_SCALE_NET; S_PACK_TARE | plasticos.transaction.supplier_weight | Optional supplier scale evidence: preserve physical gross/scale tare/scale net separately from packaging, derive validated material net only under source-specific supplier rules, never mark carrier CST complete. |
| ROUTE-BUY-REPORT | buyer | Receiving Report | other or native tag mapping (no new enum) | RECEIVING | Verified buyer source and accepted current Receiving Report with exact load/material/line and package inclusion semantics | B_DOC_ID; B_GROSS; B_PACK_GAYLORD; B_PACK_PALLET; B_PACK_COMBINED; B_PACK_TARE; B_DOCUMENT_NET; B_PER_UNIT_WEIGHT | plasticos.transaction.buyer_weight | Mandatory current accepted Receiving Report. Material net only; eligible full Customer Invoice via native sale line quantities. |
| ROUTE-BUY-SCALE | buyer | Buyer Scale Ticket | scale_ticket | SCALE | verified buyer source; optional | B_OPTIONAL_SCALE_NET; B_SCALE_GROSS; B_SCALE_TARE; B_SCALE_NET | EVIDENCE_ONLY_CORROBORATION | Optional buyer scale evidence: preserve physical gross/scale tare/scale net and corroborate accepted Receiving Report only; cannot replace mandatory report or unilaterally update buyer_weight. |
| ROUTE-CAR-BOL | carrier | Bill of Lading (BOL) | bol | BOL | carrier role + matching load | C_LOAD | EVIDENCE_ONLY | Share underlying BOL interpretation when copy from supplier, retain separate carrier delivery provenance. |
| ROUTE-CAR-CST | carrier | Certified Scale Ticket (CST) | scale_ticket | CST | actual certifying issuer; carrier provided; certified gross and net per load | C_DOC_ID; C_IS_CERTIFIED; C_GROSS; C_TARE; C_NET; C_PACK_TARE; C_NET_BILLED; C_GROSS_NET_COMPLETE | plasticos.transaction.scale_weight | Carrier-certified CST document obligation independently requires gross/net per load. Preserve CST gross/tare/net in source evidence; with supported packaging basis an eligible material net can feed scale_weight. RWN selection requires strict >5% and D13; buyer AR never uses CST as automatic invoice quantity. |
| ROUTE-EXT-SCALE | independent | Independent Scale Ticket | scale_ticket | SCALE | actual independent issuer + exact load; third-party authority D13 | COMMON_UNIT; COMMON_REVISION | EVIDENCE_ONLY_PENDING_D13 | Source evidence retained without pretending sender is supplier/buyer/carrier or automatically selecting settlement field. |

**Existing tag identities:** `plasticos_documents.tag_cst` has code `CST`; `plasticos_documents.tag_scale_ticket` has code `SCALE`; `plasticos_documents.tag_receiving_report` has code `RECEIVING`; `plasticos_documents.tag_packing_list` has code `PACKING`. Native custom `documents.document.doc_type` permits `scale_ticket` but does not have `cst`, `receiving_report` or `packing_list`. Role/issuer/real tag and company/load scope must supply that distinction without adding selection values. A tag cannot prove actual certification or gross/net contents.

## 4. Candidate source fact dictionary (NOT existing ORM fields)

Every source concept must be retained with document logical part, revision, raw value, original units, validated basis and exact load/material/line. Persistence is a real D08 installed-Enterprise/native-evidence decision, **not** permission to create 35 new fields or a parallel ledger.

### SUPPLIER source facts

| Concept ID (not ORM) | Document class | Meaning | Value format | Proposed scalar if accepted | Dependencies | Validation | Persistence status |
|---|---|---|---|---|---|---|---|
| S_DOC_ID | PL/BOL/SUPPLIER_SCALE | Original supplier document/issuer/load/line revision | REFERENCE | none | exact document part and issuer | not by email sender alone | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_GROSS | PL/BOL/SUPPLIER_SCALE | Supplier stated load/material gross before its applicable packaging | DECIMAL_LB | none | source-specific amount+basis | do not equate with CST gross | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_PACK_GAYLORD | PL | Supplier count of Gaylords | INTEGER | none | line+load/package pairing | not identical to buyer packaging count | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_PACK_PALLET | PL | Supplier count of pallets | INTEGER | none | line+load/package pairing | no double count when nested | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_PACK_COMBINED | PL | Supplier combined Gaylord-on-pallet units | INTEGER | none | explicit combination | 80 lb each only if supported | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_PACK_TARE | PL | Supplier packaging tare for load/line | DECIMAL_LB | none | package count and documented basis | must not include CST tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_DOCUMENT_NET | PL/BOL/SUPPLIER_SCALE | Supplier document quantity explicitly labeled net; packaging-exclusion and physical measurement stage are not established by the word net | DECIMAL_LB + SOURCE_STAGE_UNRESOLVED | none | original source/revision/unit + separately verified physical basis before commercial write | DOC_NET_IS_NOT_ACCEPTED_MATERIAL_NET; do not auto-write accepted commercial scalar or subtract tare without evidence | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_PER_UNIT_WEIGHT | PL | Per-unit material weight gross or net as printed | DECIMAL_LB + BASIS | none | unit count/material/load | no unauthorised lump total allocation | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_SCALE_GROSS | SUPPLIER_SCALE | Physical gross on supplier-arranged optional scale ticket | DECIMAL_LB + UNIT | none | signed source and same load/scale event | Not CST gross; issuer/scale may not be certified | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_SCALE_TARE | SUPPLIER_SCALE | Corresponding supplier scale tare, distinct from packaging | DECIMAL_LB + UNIT | none | same load scale event and reference | Not CST tare or packaging tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| S_SCALE_NET | SUPPLIER_SCALE | Supplier optional scale gross minus corresponding tare | DECIMAL_LB + BASIS | none | validated same-event gross/tare or stated net | Net before applicable packaging unless explicitly excluded in source | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |

### BUYER source facts

| Concept ID (not ORM) | Document class | Meaning | Value format | Proposed scalar if accepted | Dependencies | Validation | Persistence status |
|---|---|---|---|---|---|---|---|
| B_DOC_ID | RECEIVING_REPORT | Accepted buyer report revision, issuer and exact load/material | REFERENCE | none | verified buyer identity | optional scale alone never satisfies | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_GROSS | RECEIVING_REPORT | Buyer received gross before applicable packaging tare | DECIMAL_LB | none | per line/load+source basis | never CST gross | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_PACK_GAYLORD | RECEIVING_REPORT | Count received Gaylords | INTEGER | none | per line/load | not copied from supplier | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_PACK_PALLET | RECEIVING_REPORT | Count received pallets | INTEGER | none | per line/load | not copied from supplier | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_PACK_COMBINED | RECEIVING_REPORT | Count received combined units | INTEGER | none | per line/load | do not double count pallet within combined | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_PACK_TARE | RECEIVING_REPORT | Buyer packaging tare deduction | DECIMAL_LB | none | approved 40/40/80 or source validation | never CST tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_DOCUMENT_NET | RECEIVING_REPORT | Buyer Receiving Report quantity labeled net; original document observation is not accepted buyer material net until its physical packaging basis is proved | DECIMAL_LB + SOURCE_STAGE_UNRESOLVED | none | original source/revision/unit + separately verified physical basis before commercial write | DOC_NET_IS_NOT_ACCEPTED_MATERIAL_NET; do not auto-write accepted commercial scalar or subtract tare without evidence | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_PER_UNIT_WEIGHT | RECEIVING_REPORT | Received unit weight | DECIMAL_LB + BASIS | none | line counts and unit | verify aggregation and no double tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_OPTIONAL_SCALE_NET | BUYER_SCALE | Optional corroborating buyer scale number | DECIMAL_LB + BASIS | none | issuer verified and load matched | not report replacement | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_SCALE_GROSS | BUYER_SCALE | Physical gross from optional buyer-side scale ticket | DECIMAL_LB + UNIT | none | authenticated buyer issuer and load event | Buyer optional scale is not certified carrier CST | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_SCALE_TARE | BUYER_SCALE | Buyer optional scale tare matching scale gross | DECIMAL_LB + UNIT | none | same unit and weighing event | Neither CST tare nor packaging tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| B_SCALE_NET | BUYER_SCALE | Buyer optional scale gross minus corresponding scale tare | DECIMAL_LB + BASIS | none | valid paired source scale readings | May corroborate mandatory Receiving Report, cannot replace it | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |

### CARRIER_CST source facts

| Concept ID (not ORM) | Document class | Meaning | Value format | Proposed scalar if accepted | Dependencies | Validation | Persistence status |
|---|---|---|---|---|---|---|---|
| C_DOC_ID | CST | CST document identity, certifying issuer and carrier-submitted proof | REFERENCE | none | must tie to carrier and load | CST tag does not prove certified | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_IS_CERTIFIED | CST | Verifiable certification evidence | BOOLEAN + EVIDENCE | none | source validity | filename/CST tag alone not sufficient | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_GROSS | CST | CST gross same load+vehicle+measurement | DECIMAL_LB | none | CST actual source and unit | not transaction.gross_weight | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_TARE | CST | CST tare of matching scale event | DECIMAL_LB | none | CST matching event unit | not transaction.total_tare | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_NET | CST | CST net = CST gross minus CST tare, before packaging | DECIMAL_LB | none | validated gross/tare pair | not yet net weight billed | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_PACK_TARE | CST + PL/RECEIVING | Applicable per-load packaging tare | DECIMAL_LB | none | source-appropriate package count and included/excluded status | unknown is not zero | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_NET_BILLED | CST | CST net minus applicable packaging tare | DECIMAL_LB | plasticos.transaction.scale_weight | source-authenticated CST gross/tare pair, source-appropriate packaging inclusion evidence and scale eligibility; settlement choice D13 separately | never direct buyer_weight/supplier_weight; candidate scale net may be recorded independently of threshold, but supplier notice selection remains conditional | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_ISSUER | CST | Certified scale issuer, actual source and carrier sender | REFERENCES | none | legal/load/record authority | issuer not equal email sender by default | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_LOAD | CST | Load/vehicle/trailer/time binding | REFERENCES | none | exact ID and source timestamps | trailer alone not identity | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| C_GROSS_NET_COMPLETE | CST | Carrier cert+gross+net sufficiency for obligation | BOOLEAN_EVIDENCE | none | D03 acceptance | missing packaging alone not missing CST | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |

### CROSS_SOURCE source facts

| Concept ID (not ORM) | Document class | Meaning | Value format | Proposed scalar if accepted | Dependencies | Validation | Persistence status |
|---|---|---|---|---|---|---|---|
| COMMON_UNIT | ALL | Original unit and Odoo conversion into pounds | UOM + RAW_VALUE | none | same dimension consistent rounding | never infer tonnes by size | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |
| COMMON_REVISION | ALL | Original file, logical part, scope, current revision and source location | SOURCE_REF | none | record/part/issuer/provenance | replay and corrections must retain original | SOURCE_LINKED_EVIDENCE_ONLY_UNTIL_D08_HOSTED_PROOF |

## 4A. Operator-approved five-stage measurement vocabulary (weights BRS only)

| Stage | Exact operator meaning | Normative owning rule |
|---|---|---|
| document_measurement | The quantity actually shown on the PL, Receiving Report or scale ticket | BR-VOC-001 |
| load_net | Gross less corresponding vehicle/CST tare | BR-VOC-001 |
| packaging_tare | Weight of applicable Gaylords, pallets, etc. | BR-VOC-001 |
| material_net | Load net less applicable packaging tare, or independently verified material-only net | BR-VOC-001 |
| accepted_commercial_weight | The validated material net used for supplier or buyer settlement | BR-VOC-001 |

## 4B. Direct commercial reconciliation and preferred display (weights BRS only)

| Key | Contract |
|---|---|
| status | ACCEPTED_DIRECT_COMPARISON_MANDATORY_HUMAN_REVIEW;D13_DENOMINATOR_PENDING |
| source_fields | plasticos.transaction.supplier_weight; plasticos.transaction.buyer_weight; plasticos.transaction.scale_weight |
| commercial_pairs | supplier_weight; buyer_weight |
| reference_only | plasticos.transaction.scale_weight |
| pairwise_diagnostics | supplier_vs_buyer; supplier_vs_scale; buyer_vs_scale |
| disallowed_clearance | TWO_NEAR_SCALE_COMPARISONS_DO_NOT_WAIVE_DIRECT_COMMERCIAL_SPREAD |
| human_review_trigger | STRICTLY_GREATER_THAN_FIVE_PERCENT_DIRECT_COMMERCIAL_SPREAD |
| denominator_status | UNKNOWN_D13_NO_INVENTED_APPROVAL |
| rwn_business_effect | NO_AUTO_SCALE_SUBSTITUTION_PENDING_HUMAN_REVIEW |
| buyer_invoice_effect | REMAIN_INDEPENDENT_ON_ACCEPTED_BUYER_REPORT |
| display_only_priority | CERTIFIED_CST_PACKAGING_ADJUSTED_MATERIAL_NET; ACCEPTED_BUYER_WEIGHT; ACCEPTED_SUPPLIER_WEIGHT; NO_ACCEPTED_WEIGHT |
| owned_by | BRS-003@1.0.1 |
| refs | BR-VOC-001; BR-WGT-009; BR-WGT-010; BR-SET-002; BR-SET-003 |
| business_rule_owner | BRS-003@1.0.1 |

## 4C. Obligation-scoped underweight calculation and financial owners (underweight BRS only)

| Key | Contract |
|---|---|
| status | ACCEPTED_40000_2000_INCLUSIVE_CONTINUOUSLY_PRORATED_PER_500_RATE_ON_ACTUAL_MATERIAL_NET; APPLICABLE_CONTRACT_AND_ORM_MIGRATION_STILL_PENDING |
| normative_owner | BRS-007@1.0.1 |
| physical_input_owner | BRS-003@1.0.1 |
| trailer_length_ft | 53 |
| required_minimum_material_net_lbs | 40000 |
| trigger_shortfall_inclusive_lbs | 2000 |
| rate_usd_per_lb | 0.01 |
| formula | shortfall=max(0,minimum_material_net-accepted_material_net). If no proved applicable contract or shortfall<2000 then zero. Otherwise effective_usd_per_lb=base_usd_per_lb_per_2000_lbs*(shortfall/2000), including partial 500 lb increments with no floor, ceil, or early rate rounding. Deduction_total=actual_material_net*effective_usd_per_lb, final cents rounded half-up. The rate applies to actual material net, NOT to shortfall. |
| method_proposal | _compute_light_weight_deduction_total |
| reusable_calculator_proposal | _calculate_light_weight_deduction |
| current_existing_fields | plasticos.transaction.minimum_net_weight; plasticos.transaction.light_weight_deduction_rate; plasticos.transaction.light_weight_deduction; plasticos.transaction.dead_freight_chargeback |
| proposed_successor_total_field | plasticos.transaction.light_weight_deduction_total (NOT_PRESENT_PENDING_MIGRATION) |
| proposed_deduction_weight_output | light_weight_deduction_weight (NON_ORM_PURE_CALCULATION_OUTPUT) |
| retired_business_concepts | plasticos.transaction.dead_freight_chargeback; plasticos.transaction.final_weight |
| buyer_obligation | ACCOUNTING_LIABILITY_ONLY_IF_BUYER_CONTRACT_PROVES_IT |
| supplier_obligation | INDEPENDENT_RECOVERY_ONLY_IF_SUPPLIER_CONTRACT_PROVES_IT |
| no_parallel_system | True |
| no_automatic_accounting_effect | True |
| no_duplicate_recovery | True |
| blocking_decision | D16 |
| separate_carrier_CST_document_penalty_usd | 150.00 |
| rules | BR-UND-001; BR-UND-002; BR-UND-003; BR-UND-004; BR-UND-005; BR-UND-006; BR-UND-007 |
| rate_status | OPERATOR_APPROVED_CONTINUOUS_PRORATION_FORMULA_D17_RESOLVED |
| operator_stated_examples_imply_usd_per_lb | SUPERSEDED_OLD_200_400_EXAMPLES_HISTORICAL_ONLY |
| approved_automatic_rate_usd_per_lb | 0.01_BASE_PER_2000_SHORTFALL_ONLY_IF_APPLICABLE_CONTRACT_PROVEN |
| automatic_financial_assessment | CONTRACT_AND_NATIVE_ACCOUNTING_AUTHORIZATION_REQUIRED_D16_NOT_AUTOMATIC_BY_CALCULATION |
| blocking_decisions | D16 |
| base_rate_usd_per_lb_per_2000_shortfall | 0.01 |
| rate_interpolation_per_500_lbs | 0.0025 |
| partial_500_lbs | CONTINUOUS_LINEAR_PRORATION_NOT_COMPLETED_TIER_FLOOR |
| effective_rate_precision | DECIMAL_KEEP_ALL_INTERMEDIATE_PRECISION |
| final_amount_rounding | USD_CENTS_ROUND_HALF_UP_AT_END |
| preserve_explicit_zero_base_rate | True |
| proration_policy_id | BR-UND-002 |

| Obligation | Commercial source | Shared calculator | Native owner | Independent effect | Authority | Status |
|---|---|---|---|---|---|---|
| BUYER_LIABILITY | Accepted buyer contractual material net and supported SO/freight terms | SINGLE_SHARED_LIGHT_WEIGHT_CALCULATOR | Native Sales/Accounting with existing plasticos.claim when applicable | Separate buyer-side liability or account.move adjustment; no automatic supplier recovery | D16+BR-UND-003 | PENDING_TERMS_RUNTIME_TEST |
| SUPPLIER_RECOVERY | Accepted supplier contractual material net and supported supplier PO terms | SINGLE_SHARED_LIGHT_WEIGHT_CALCULATOR | Native Purchase/Claims/Accounting with existing authorized credit path | Independently established supplier recovery; no automatic mirror of buyer liability | D16+BR-UND-003 | PENDING_TERMS_RUNTIME_TEST |

Proposed ORM method `_compute_light_weight_deduction_total` and `light_weight_deduction_total` successor field are NOT present in the pinned source; `light_weight_deduction_weight` remains a computed pure output, not approval to create an Odoo field.

## 5. Complete exact field registry, grouped by existing owner/function

The registry catalogs **147 real declared/wrapper-claimed fields** relevant to this campaign. The labelled technical identity, source file, type, write permission and downstream use must be checked against the **installed** registry and composed views on the actual execution revision. "(default label)" means the source declaration did not explicitly set a business label; this pack does not invent one. Field source provenance statuses are not hosted Odoo validation.

### IDENTITY (9 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.name | plasticos_transaction | fields.Char | (technical: name) | plasticos_transaction/models/transaction.py | Exact internal transaction reference, no sender-only matching | READ_MATCH_ONLY | Document association and idempotency | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.supplier_id | plasticos_transaction | fields.Many2one(res.partner) | Supplier | plasticos_transaction/models/transaction.py | Transaction supplier, distinct from email sender; facilities require validation | READ_AUTHORITY | Supplier evidence and RWN | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.buyer_id | plasticos_transaction | fields.Many2one(res.partner) | Buyer | plasticos_transaction/models/transaction.py | Buyer/receiver, never supplier by default | READ_AUTHORITY | Buyer evidence and AR | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.carrier_id | plasticos_transaction | fields.Many2one(res.partner) | Carrier | plasticos_transaction/models/transaction.py | Transaction carrier corroboration; load.carrier_id must agree | READ_AUTHORITY | Carrier CST obligation and liability | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.sale_order_id | plasticos_transaction | fields.Many2one(sale.order) | (default label) | plasticos_transaction/models/transaction.py | Native sale.order relation | READ_RELATION | Invoice-line reconciliation | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.purchase_order_ids | plasticos_transaction | fields.Many2many(purchase.order) | (default label) | plasticos_transaction/models/transaction.py | All related native purchase orders | READ_RELATION | Supplier payable evidence | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.delivery_order_id | plasticos_transaction | fields.Many2one(stock.picking) | Delivery Order | plasticos_transaction/models/transaction.py | Existing stock picking; not arbitrary carrier delivery document | READ_RELATION | DO identity | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.do_number | plasticos_transaction | fields.Char related | DO Number | plasticos_transaction/models/transaction.py | Stored related to delivery_order_id.name | READ_ONLY | Matching references | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.load_id | plasticos_logistics | fields.Many2one(plasticos.load) | Load | plasticos_logistics/models/transaction_inherit.py | Single linked load, not a new multi-load transaction model | READ_RELATION | Source/load scoping | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### SUPPLIER (1 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.supplier_weight | plasticos_transaction | fields.Float | Supplier Weight (lbs) | plasticos_transaction/models/transaction.py | Validated supplier packaging-excluded material net; default supplier settlement basis | WRITE_ONLY_FROM_VERIFIED_SUPPLIER_SOURCE_NO_BLIND_OVERWRITE | Supplier RWN and purchase/approved deductions | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### BUYER (1 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.buyer_weight | plasticos_transaction | fields.Float | Buyer Weight (lbs) | plasticos_transaction/models/transaction.py | Validated net received quantity from required buyer Receiving Report | WRITE_ONLY_FROM_CURRENT_ACCEPTED_BUYER_RECEIVING_REPORT | Customer Invoice through native Sales/Accounting | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### CST (1 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.scale_weight | plasticos_transaction | fields.Float | Scale Weight (lbs) | plasticos_transaction/models/transaction.py | Validated certified reference material-net value after packaging treatment; not a third accepted commercial billing weight and not a direct settlement substitute | WRITE_FROM_VERIFIED_CST_ONLY_WHEN_SOURCE_AND_MATERIAL_NET_SUPPORTED;REFERENCE_ONLY_NO_AUTOMATIC_SETTLEMENT | Display preference and independent pairwise reconciliation with supplier/buyer only; human review on direct >5% commercial spread | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### LEGACY (9 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.gross_weight | plasticos_transaction | fields.Float computed | Gross Weight (lbs) | plasticos_transaction/models/transaction.py | Obsolete winner mislabeled gross; CST physical gross remains in document evidence | RETIRE_PENDING_CONSUMER_MIGRATION_NO_RAW_CST_WRITE | Old compute and material view | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.final_weight | plasticos_transaction | fields.Float computed | Final Net Weight (lbs) | plasticos_transaction/models/transaction.py | Obsolete selected generic weight, not an acceptable billable or underweight calculation weight | RETIRE_PENDING_CONSUMER_MIGRATION_NO_NEW_UNIVERSAL_WEIGHT | Deductions, commission SQL view and forms | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.weight_source | plasticos_transaction | fields.Selection computed | Weight Source | plasticos_transaction/models/transaction.py | Obsolete selected gross/scale/buyer/supplier winner; independent source-of-display label is presentation only | RETIRE_PENDING_CONSUMER_MIGRATION_NO_FINANCIAL_AUTHORITY | Commission sales dashboard etc | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.expected_weight | plasticos_transaction | fields.Float | Expected Weight (lbs) | plasticos_transaction/models/transaction.py | Plan/expectation, not supplier invoice or buyer received actual | NO_WRITE_FROM_SOURCE_NET_AS_SUBSTITUTE | Planning/variance | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.actual_weight | plasticos_transaction | fields.Float | Actual Weight (lbs) | plasticos_transaction/models/transaction.py | Separate existing actual_weight; not proven buyer_weight alias | DO_NOT_AUTO_OVERWRITE_WITH_REPORT | Legacy expected/actual variance | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.weight_variance_percent | plasticos_transaction | fields.Float computed | Weight Variance % | plasticos_transaction/models/transaction.py | Expected vs actual variance, distinct from supplier/buyer discrepancy | COMPUTED_NO_DIRECT_WRITE | Planning variance | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.quantity | plasticos_transaction | fields.Float | Quantity | plasticos_transaction/models/transaction.py | Transaction aggregate quantity not automatically source-specific invoice line quantity | DO_NOT_USE_AS_BUYER_WEIGHT_ALIAS | Dashboard, transaction summary | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.uom_id | plasticos_transaction | fields.Many2one(uom.uom) | Unit of Measure | plasticos_transaction/models/transaction.py | Unit on existing aggregate, validate native conversion | NATIVE_UOM_VALIDATION | Transaction display/summary | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.unit_price | plasticos_transaction | fields.Float | Unit Price | plasticos_transaction/models/transaction.py | Not automatically customer SO unit price or supplier PO unit price | READ_DISPLAY_UNLESS_CONTRACT_APPROVED | Pricing display | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### DISCREPANCY (2 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.weight_discrepancy_pct | plasticos_transaction | fields.Float computed | Weight Discrepancy % | plasticos_transaction/models/transaction.py | Existing abs(sw-bw)/max(sw,bw), percentage; denominator acceptance remains D13 | COMPUTED_SIGNAL_ONLY | RWN >5 threshold candidate; not standalone authority | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.weight_discrepancy_flagged | plasticos_transaction | fields.Boolean computed | Discrepancy Flagged | plasticos_transaction/models/transaction.py | Existing threshold strictly >0.05; flags review | COMPUTED_SIGNAL_NEVER_AUTO_SUBSTITUTION | Seller settlement review | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### PACKAGING (5 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.unit_count | plasticos_transaction | fields.Integer | Unit Count | plasticos_transaction/models/transaction.py | Aggregate count on transaction; insufficient for supplier/buyer mixed counts | VERIFIED_HOMOGENEOUS_ONLY | total_tare existing compute | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.unit_type | plasticos_transaction | fields.Selection | Unit Type | plasticos_transaction/models/transaction.py | Single package kind keys bale/gaylord/pallet/box/super_sack; cannot represent mix | VERIFIED_HOMOGENEOUS_ONLY | tare_per_unit compute | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.tare_per_unit_override | plasticos_transaction | fields.Float | Tare Override (lbs) | plasticos_transaction/models/transaction.py | Manual existing override for homogeneous combined package, not CST tare | APPROVED_OVERRIDES_ONLY | tare_per_unit compute | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.tare_per_unit | plasticos_transaction | fields.Float computed inverse | Tare per Unit (lbs) | plasticos_transaction/models/transaction.py | Existing 40 gaylord/40 pallet; box default zero is NOT approved material policy | COMPUTED_VALIDATED_PACKAGE_ONLY | total_tare compute | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.total_tare | plasticos_transaction | fields.Float computed | Total Tare (lbs) | plasticos_transaction/models/transaction.py | Current unit_count*tare_per_unit, not CST tare and not universally applicable to both party weights | COMPUTED_NEVER_DOUBLE_DEDUCT | Legacy final_weight; packaging calculation only if source coverage matches | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### SUPPLIER_TERMS (5 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.minimum_net_weight | plasticos_transaction | fields.Float | Minimum Net Weight (lbs) | plasticos_transaction/models/transaction.py | Existing contract minimum parameter; operator accepted 40000 lb for an applicable 53-foot trailer, not generic for all loads | VALIDATE_CONTRACT_AND_APPLICABILITY_D16 | Per-contract underweight calculation; no automatic party assignment | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.light_weight_deduction_rate | plasticos_transaction | fields.Float | Deduction Rate ($/lb) | plasticos_transaction/models/transaction.py | Existing Odoo rate field default 0.01 observed in source. Business meaning proposed: per-lb base rate for each 2000 lb of SHORTFALL; effective rate=base * (shortfall/2000), continuously prorated on partial 500 lb, actual material net * effective rate; D17 arithmetic RESOLVED; D16 contract and posting remain OPEN. Explicit rate zero respected. | EXISTING_RATE_FIELD_NOT_A_CURRENT_DYNAMIC_EFFECTIVE_RATE;D16_CONTRACT_APPLICABILITY_GATES_FINANCIAL_ACTION;EXPLICIT_ZERO_RESPECTED | Obligation-scoped threshold calculation | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.light_weight_deduction | plasticos_transaction | fields.Float computed | Light Weight Deduction ($) | plasticos_transaction/models/transaction.py | Legacy computed amount, obsolete final_weight and shortfall-times-rate inputs. Proposed controlled rename to light_weight_deduction_total and compute method _compute_light_weight_deduction_total; pure calculator is obligation-scoped and prorates effective rate on accepted material net. | MIGRATE_EXPLICITLY_OLD_FIELD_TO_light_weight_deduction_total_NO_NEW_PARALLEL_FIELD | Legacy-only until accepted per-obligation calculation and native financial claim/posting results, not economic effect authority | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.dead_freight_chargeback | plasticos_transaction | fields.Boolean computed | Dead Freight Chargeback | plasticos_transaction/models/transaction.py | Obsolete Boolean comparing deduction to supplier purchase cost; no independent accepted dead-freight financial meaning | RETIRE_PENDING_CONSUMER_MIGRATION_NO_REPLACEMENT_BOOLEAN | Legacy code only; retire after consumer census, never apply as underweight penalty or liability | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.lightweight_penalties | plasticos_transaction | fields.Float | Lightweight Penalties | plasticos_transaction/models/transaction.py | Existing supplier penalty recovery input; avoid duplicating deduction | ONE_ECONOMIC_EFFECT_ONLY | Margin/RWN | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### AR (1 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.customer_invoice_id | plasticos_transaction | fields.Many2one(account.move) | (default label) | plasticos_transaction/models/transaction.py | Existing customer invoice reference with move_type=out_invoice domain | RELATE_ONE_VERIFIED_CUSTOMER_INVOICE | Revenue and reconciliation | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### AP (1 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.vendor_bill_ids | plasticos_transaction | fields.Many2many(account.move) | (default label) | plasticos_transaction/models/transaction.py | Existing supplier vendor bills, move_type=in_invoice | RELATE_NATIVE_BILLS_NO_DUPLICATE_CREATE | Supplier purchase_cost_total | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### CARRIER_AP (2 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.freight_bill_ids | plasticos_transaction | fields.Many2many(account.move) | (default label) | plasticos_transaction/models/transaction.py | Existing carrier Vendor Bills, move_type=in_invoice | RELATE_NATIVE_BILLS_NO_DUPLICATE_CREATE | Carrier cost/penalty | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.freight_chargebacks | plasticos_transaction | fields.Float | Freight Chargebacks | plasticos_transaction/models/transaction.py | Current recoveries input, double-count hazard with native credit | ONE_ECONOMIC_EFFECT_ONLY | Margin | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### FINANCIAL (6 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.revenue_total | plasticos_transaction | fields.Float computed | Revenue Total | plasticos_transaction/models/transaction.py | Derived from native Customer Invoice and credit/debit notes | COMPUTED_FROM_ACCOUNT_MOVE | Margin, commissions | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.purchase_cost_total | plasticos_transaction | fields.Float computed | Purchase Cost | plasticos_transaction/models/transaction.py | Derived from native supplier Vendor Bills | COMPUTED_FROM_ACCOUNT_MOVE | Margin, light-weight deduction | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.freight_cost_total | plasticos_transaction | fields.Float computed | Freight Cost | plasticos_transaction/models/transaction.py | Derived from native carrier bills | COMPUTED_FROM_ACCOUNT_MOVE | Margin and carrier penalty | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.gross_margin | plasticos_transaction | fields.Float computed | Gross Margin | plasticos_transaction/models/transaction.py | Revenue minus actual costs plus authorized recoveries | COMPUTED_NO_EVIDENCE_DIRECT_WRITE | Commission | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.net_margin | plasticos_transaction | fields.Float computed | Net Margin | plasticos_transaction/models/transaction.py | Gross margin less commission | COMPUTED_NO_EVIDENCE_DIRECT_WRITE | Reporting | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.other_expenses | plasticos_transaction | fields.Float | Other Expenses | plasticos_transaction/models/transaction.py | Manual direct expenses, not derived from weight report | AUTHORIZED_ONLY | Margin | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### LIFECYCLE (2 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.transaction.state | plasticos_transaction | fields.Selection | Status (unlabeled) | plasticos_transaction/models/transaction.py | Transaction lifecycle; closed documents can still be missing CST | NATIVE_ACTION_TRANSITIONS_ONLY | Commercial status | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.compliance_status | plasticos_transaction | fields.Selection computed | (default label) | plasticos_transaction/models/transaction.py | Current all-document compliance aggregate; must not auto-post bills or block buyer AR due CST | NOT_FINANCIAL_POST_AUTHORITY | Legacy compliance | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### LOAD (20 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.load.name | plasticos_logistics | fields.Char | (default label) | plasticos_logistics/models/load.py | Load reference; distinguish multiple loads | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.company_id | plasticos_logistics | fields.Many2one(res.company) related | (default label) | plasticos_logistics/models/load.py | Company through sale order | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.carrier_id | plasticos_logistics | fields.Many2one(res.partner) | Carrier | plasticos_logistics/models/load.py | Carrier submitting CST must match approved load carrier | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.transaction_id | plasticos_logistics | fields.Many2one(plasticos.transaction) computed | Transaction | plasticos_logistics/models/load.py | Reverse linked transaction; not new many-to-many | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.pickup_partner_id | plasticos_logistics | fields.Many2one(res.partner) | Pickup Location | plasticos_logistics/models/load.py | Facility corroboration | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.delivery_partner_id | plasticos_logistics | fields.Many2one(res.partner) | Delivery Location | plasticos_logistics/models/load.py | Receiving facility corroboration | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.pickup_reference | plasticos_logistics | fields.Char | Pickup Reference/PO# | plasticos_logistics/models/load.py | Exact supplier pickup reference | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.delivery_reference | plasticos_logistics | fields.Char | Delivery Reference/PO# | plasticos_logistics/models/load.py | Exact buyer delivery reference | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.trailer_number | plasticos_logistics | fields.Char | Trailer Number | plasticos_logistics/models/load.py | Vehicle identifier; not weight or CST tare | VERIFY_SOURCE_AND_ROLE_BEFORE_WRITE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.seal_number | plasticos_logistics | fields.Char | Seal Number | plasticos_logistics/models/load.py | Seal identifier only after exact load match | VERIFY_SOURCE_AND_ROLE_BEFORE_WRITE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.pickup_datetime | plasticos_logistics | fields.Datetime | Pickup Date/Time | plasticos_logistics/models/load.py | Scheduled pickup not necessarily actual | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.delivery_datetime | plasticos_logistics | fields.Datetime | Delivery Date/Time | plasticos_logistics/models/load.py | Scheduled delivery not necessarily actual | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.delivered_at | plasticos_logistics | fields.Datetime | (default label) | plasticos_logistics/models/load.py | Actual event used in buyer/carrier SLA | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.dispatched_at | plasticos_logistics | fields.Datetime | (default label) | plasticos_logistics/models/load.py | Actual dispatch event | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.reference_weight | plasticos_logistics | fields.Float | Reference Weight (lbs) | plasticos_logistics/models/load.py | Planning reference not authoritative source net | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.quantity | plasticos_logistics | fields.Float | Quantity | plasticos_logistics/models/load.py | Cargo count, not automatically material net lb | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.quantity_uom | plasticos_logistics | fields.Char | Unit | plasticos_logistics/models/load.py | Existing load unit text, not automatic source net | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.double_blind | plasticos_logistics | fields.Boolean | Double Blind | plasticos_logistics/models/load.py | Supplier output must not disclose buyer identity | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.bol_pickup_attached | plasticos_logistics | fields.Boolean | (default label) | plasticos_logistics/models/load.py | Legacy BOL presence hint, not provenance | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.load.bol_delivery_attached | plasticos_logistics | fields.Boolean | (default label) | plasticos_logistics/models/load.py | Legacy BOL presence hint, not provenance | READ_REFERENCE_OR_LIFECYCLE | Document matching / freight / notices | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### EVIDENCE (32 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.document.attachment_id | plasticos_documents | fields.Many2one(ir.attachment) | (default label) | plasticos_documents/models/document.py | Original binary association shared over many transactions | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.tag_id | plasticos_documents | fields.Many2one(plasticos.document.tag) | (default label) | plasticos_documents/models/document.py | Document business taxonomy, CST distinct from SCALE | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.doc_category | plasticos_documents | fields.Selection | Document Category | plasticos_documents/models/document.py | Supplier/buyer/carrier/internal party responsibility; do not infer from tag | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.transaction_id | plasticos_documents | fields.Many2one(plasticos.transaction) | Transaction | plasticos_documents/models/document.py | One evidence association per cited transaction | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.load_id | plasticos_documents | fields.Many2one(plasticos.load) | Load | plasticos_documents/models/document.py | Exact load lineage | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.res_model | plasticos_documents | fields.Char | (default label) | plasticos_documents/models/document.py | Polymorphic model owner; permission check required | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.res_id | plasticos_documents | fields.Integer | (default label) | plasticos_documents/models/document.py | Polymorphic target record; permission check required | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.verified | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document.py | Verification status alone not certification proof | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.override | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document.py | Override is gated and auditable; not trust alone | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.active | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document.py | Current active evidence only for compliance | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.version | plasticos_documents | fields.Integer | Version | plasticos_documents/models/document.py | Legacy document revision | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.superseded_by | plasticos_documents | fields.Many2one(plasticos.document) | Superseded By | plasticos_documents/models/document.py | Revision lineage | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.is_current | plasticos_documents | fields.Boolean | Current Version | plasticos_documents/models/document.py | Do not count superseded evidence as current | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.expiry_date | plasticos_documents | fields.Date | Expiry Date | plasticos_documents/models/document.py | Document validity; if applicable | EVIDENCE_LINK_OR_VALIDATED_METADATA_ONLY | Document/requirement application | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.transaction_id | plasticos_documents_native | fields.Many2one(plasticos.transaction) | Transaction | plasticos_documents_native/models/document_native.py | Convenience pointer only when one transaction | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.load_id | plasticos_documents_native | fields.Many2one(plasticos.load) | Load | plasticos_documents_native/models/document_native.py | Convenience pointer only when one load | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.plasticos_doc_id | plasticos_documents_native | fields.Many2one(plasticos.document) | Plasticos Document | plasticos_documents_native/models/document_native.py | One legacy pointer cannot represent many cited TXs | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.doc_type | plasticos_documents_native | fields.Selection | Document Type | plasticos_documents_native/models/document_native.py | bol/invoice/scale_ticket/.../other; NO PACKING/RECEIVING/CST selection key | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.verified | plasticos_documents_native | fields.Boolean | Verified | plasticos_documents_native/models/document_native.py | Manual/native verified, not issuer certification | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.override | plasticos_documents_native | fields.Boolean | Override | plasticos_documents_native/models/document_native.py | Protected compliance exception action | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.intake_id | plasticos_documents_native | fields.Many2one(plasticos.intake) | Intake | plasticos_documents_native/models/document_native.py | Existing domain link, not weight destination | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.polymer_id | plasticos_documents_native | fields.Many2one(plasticos.polymer) | Polymer Type | plasticos_documents_native/models/document_native.py | Material metadata only, no weight authority | SOURCE_LINK_VERIFIED_NO_NEW_FIELD | Native ↔ legacy evidence linking | VERIFIED_AT_REPO_SOURCE_ONLY |
| documents.document.attachment_id | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Original file link; may require native Enterprise property verification | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.partner_id | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native contact on document, not a transaction-party proof | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.tag_ids | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native multi-tags, distinct from plasticos.document.tag_id | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.folder_id | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native folder, not duplicate role-specific physical copy | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.res_model | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native linkage model, one of multiple possible links | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.res_id | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native target record, not a multi-target relation | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| documents.document.name | Odoo Enterprise Documents | ENTERPRISE_NATIVE_FIELD_RUNTIME_CHECK | not certified in current database | plasticos_documents_native/models/document_native.py | Native document name, non-authoritative match hint | ENTERPRISE_REGISTRY_VERIFY | Single original and native metadata | INHERITED_BRIDGE_CLAIM_INSTALLED_REGISTRY_UNKNOWN |
| plasticos.document.tag.code | plasticos_documents | fields.Char | (default label) | plasticos_documents/models/document_tag.py | CST vs SCALE taxonomy code is distinct | READ_VERSIONED_SEED | CST/scale classification | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.tag.name | plasticos_documents | fields.Char | (default label) | plasticos_documents/models/document_tag.py | Approved tag label | READ_VERSIONED_SEED | CST/scale classification | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.tag.active | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document_tag.py | Inactive tag not valid evidence | READ_VERSIONED_SEED | CST/scale classification | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### OBLIGATION (18 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| plasticos.document.rule.tag_id | plasticos_documents | fields.Many2one(plasticos.document.tag) | (default label) | plasticos_documents/models/document_rule.py | Current scale rule references SCALE incorrectly for carrier obligation | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.required_for_invoice | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document_rule.py | Carrier CST must be false for buyer AR | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.required_for_close | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document_rule.py | Currently true for carrier scale; conflicts with nonblocking close | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.doc_category | plasticos_documents | fields.Selection | Document Category | plasticos_documents/models/document_rule.py | Party-specific rule scope | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.client_id | plasticos_documents | fields.Many2one(res.partner) | (default label) | plasticos_documents/models/document_rule.py | Client scoping must be respected | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.overdue_business_days | plasticos_documents | fields.Integer | Overdue After (Business Days) | plasticos_documents/models/document_rule.py | Reminder lead time; not autonomous penalty event deadline | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.rule.escalation_business_days | plasticos_documents | fields.Integer | Escalate After (Business Days) | plasticos_documents/models/document_rule.py | Escalation time; not automatic chargeback deadline | CONFIG_SEED_ONLY_AUTHORIZED | Missing document requirement | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.validation.matrix.doc_category | plasticos_documents | fields.Selection | Document Category | plasticos_documents/models/document_validation_matrix.py | Separate supplier, buyer and carrier requirement | CONFIG_SEED_ONLY_AUTHORIZED | Doc completeness matrix | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.validation.matrix.tag_id | plasticos_documents | fields.Many2one(plasticos.document.tag) | Required Document Tag | plasticos_documents/models/document_validation_matrix.py | CST tag for carrier vs SCALE for optional sources | CONFIG_SEED_ONLY_AUTHORIZED | Doc completeness matrix | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.validation.matrix.required_for_invoice | plasticos_documents | fields.Boolean | Required for Invoice | plasticos_documents/models/document_validation_matrix.py | Only buyer Receiving Report gates full invoice | CONFIG_SEED_ONLY_AUTHORIZED | Doc completeness matrix | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.validation.matrix.required_for_close | plasticos_documents | fields.Boolean | Required for Close | plasticos_documents/models/document_validation_matrix.py | Carrier CST should not block commercial close | CONFIG_SEED_ONLY_AUTHORIZED | Doc completeness matrix | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.document.validation.matrix.active | plasticos_documents | fields.Boolean | (default label) | plasticos_documents/models/document_validation_matrix.py | Active matrix requirement | CONFIG_SEED_ONLY_AUTHORIZED | Doc completeness matrix | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.missing_supplier_docs | plasticos_documents | fields.Boolean computed | Missing Supplier Docs | plasticos_documents/models/transaction_docs.py | Track supplier obligations independent of buyer AR | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.missing_buyer_docs | plasticos_documents | fields.Boolean computed | Missing Buyer Docs | plasticos_documents/models/transaction_docs.py | Buyer Receiving Report required), needs exact category | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.missing_carrier_docs | plasticos_documents | fields.Boolean computed | Missing Carrier Docs | plasticos_documents/models/transaction_docs.py | Carrier certified CST missing only after semantic check | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.missing_doc_status | plasticos_documents | fields.Selection | Document Status | plasticos_documents/models/transaction_docs.py | Document life independent of commercial life | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.scale_ticket_reminder_sent | plasticos_documents | fields.Boolean | Scale Ticket Reminder Sent | plasticos_documents/models/transaction_docs.py | Legacy reminder tracking; tag currently generic SCALE | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |
| plasticos.transaction.scale_ticket_escalated | plasticos_documents | fields.Boolean | Scale Ticket Escalated | plasticos_documents/models/transaction_docs.py | Legacy escalation tracker; no penalty by itself | COMPUTED_OR_CONTROLLED_EXISTING_STATUS | Missing-doc dashboard and reminder | VERIFIED_AT_REPO_SOURCE_ONLY |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### NATIVE_AR (11 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| sale.order.name | Odoo 19 Sales | fields.Char | Order Reference | odoo/odoo/addons/sale/models/sale_order.py | Exact SO identifier | RETRIEVE_FOR_MATCH | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.client_order_ref | Odoo 19 Sales | fields.Char | Customer Reference | odoo/odoo/addons/sale/models/sale_order.py | Existing external buyer PO reference | RETRIEVE_FOR_MATCH | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.partner_id | Odoo 19 Sales | fields.Many2one | Customer | odoo/odoo/addons/sale/models/sale_order.py | Actual buyer identity | VERIFY_ISSUER | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.company_id | Odoo 19 Sales | fields.Many2one | (default label) | odoo/odoo/addons/sale/models/sale_order.py | Company scoping for AR | VERIFY_COMPANY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.product_uom_qty | Odoo 19 Sales | fields.Float | Quantity | odoo/odoo/addons/sale/models/sale_order_line.py | Ordered quantity; NEVER replace with received net by default | READ_ORDER_TERMS | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.product_uom_id | Odoo 19 Sales | fields.Many2one | Unit | odoo/odoo/addons/sale/models/sale_order_line.py | Native sale line UoM | VERIFY_UOM | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.qty_delivered | Odoo 19 Sales | fields.Float computed | Delivery Quantity | odoo/odoo/addons/sale/models/sale_order_line.py | Native delivery basis; may be editable only under supported invoicing route | SELECT_SUPPORTED_NATIVE_FLOW | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.qty_to_invoice | Odoo 19 Sales | fields.Float computed | Quantity To Invoice | odoo/odoo/addons/sale/models/sale_order_line.py | Computed outcome, not source-target field | READ_DERIVED_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.qty_invoiced | Odoo 19 Sales | fields.Float computed | Invoiced Quantity | odoo/odoo/addons/sale/models/sale_order_line.py | Reconciliation, not direct ORM write | READ_DERIVED_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.price_unit | Odoo 19 Sales | fields.Float | Unit Price | odoo/odoo/addons/sale/models/sale_order_line.py | Agreed buyer sale price | READ_ORDER_TERMS | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| sale.order.line.invoice_lines | Odoo 19 Sales | fields.Many2many(account.move.line) | Invoice Lines | odoo/odoo/addons/sale/models/sale_order_line.py | Native invoice line links | VERIFY_LINEAGE | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### NATIVE_AP (10 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| purchase.order.name | Odoo 19 Purchase | fields.Char | Order Reference | odoo/odoo/addons/purchase/models/purchase_order.py | Exact PO identifier | RETRIEVE_FOR_MATCH | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.partner_ref | Odoo 19 Purchase | fields.Char | Vendor Reference | odoo/odoo/addons/purchase/models/purchase_order.py | Existing vendor-side order reference | RETRIEVE_FOR_MATCH | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.partner_id | Odoo 19 Purchase | fields.Many2one | Vendor | odoo/odoo/addons/purchase/models/purchase_order.py | Supplier identity | VERIFY_ISSUER | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.product_qty | Odoo 19 Purchase | fields.Float | Quantity | odoo/odoo/addons/purchase/models/purchase_order_line.py | Ordered vendor quantity; not automatically net payable quantity | READ_ORDER_TERMS | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.product_uom_id | Odoo 19 Purchase | fields.Many2one | Unit | odoo/odoo/addons/purchase/models/purchase_order_line.py | Native purchase line UoM | VERIFY_UOM | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.qty_received | Odoo 19 Purchase | fields.Float computed inverse | Received Qty | odoo/odoo/addons/purchase/models/purchase_order_line.py | Native purchase receipt status, not same as buyer_weight | SELECT_SUPPORTED_NATIVE_FLOW | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.qty_to_invoice | Odoo 19 Purchase | fields.Float computed | To Invoice Quantity | odoo/odoo/addons/purchase/models/purchase_order_line.py | Native billing computed, not direct write | READ_DERIVED_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.qty_invoiced | Odoo 19 Purchase | fields.Float computed | Billed Qty | odoo/odoo/addons/purchase/models/purchase_order_line.py | Native billed qty; not direct write | READ_DERIVED_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.price_unit | Odoo 19 Purchase | fields.Float | Unit Price | odoo/odoo/addons/purchase/models/purchase_order_line.py | Agreed supplier purchase unit price | READ_ORDER_TERMS | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| purchase.order.line.invoice_lines | Odoo 19 Purchase | fields.One2many(account.move.line) | Bill Lines | odoo/odoo/addons/purchase/models/purchase_order_line.py | Native invoice-line relation | VERIFY_LINEAGE | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

### NATIVE_ACCOUNTING (11 relevant fields)

| Exact technical field | Owner | Type | Inspected label | Source path/revision | Actual meaning | Write/access policy | Downstream consumer | Assurance |
|---|---|---|---|---|---|---|---|---|
| account.move.move_type | Odoo 19 Accounting | fields.Selection | (default label) | odoo/odoo/addons/account/models/account_move.py | out_invoice AR/in_invoice AP; also credit notes | NATIVE_TYPE_ENFORCEMENT | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.state | Odoo 19 Accounting | fields.Selection | Status | odoo/odoo/addons/account/models/account_move.py | draft/posted/cancel; posting separate authorization | NATIVE_POSTING_LIFECYCLE | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.partner_id | Odoo 19 Accounting | fields.Many2one | Partner | odoo/odoo/addons/account/models/account_move.py | Buyer for AR; supplier/carrier for AP | VERIFY_RECEIVER | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.company_id | Odoo 19 Accounting | fields.Many2one | Company | odoo/odoo/addons/account/models/account_move.py | Isolation and tax context | VERIFY_COMPANY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.currency_id | Odoo 19 Accounting | fields.Many2one | Currency | odoo/odoo/addons/account/models/account_move.py | Native currency precision/terms | VERIFY_CURRENCY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.invoice_origin | Odoo 19 Accounting | fields.Char | Origin | odoo/odoo/addons/account/models/account_move.py | Hint, not unique identity | CORROBORATE_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.invoice_line_ids | Odoo 19 Accounting | fields.One2many(account.move.line) | Invoice lines | odoo/odoo/addons/account/models/account_move.py | Actual material/quantity/price line set | VERIFY_NATIVE_LINES | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.amount_total | Odoo 19 Accounting | fields.Monetary computed | Total | odoo/odoo/addons/account/models/account_move.py | Native total, after taxes/discounts | NATIVE_COMPUTED_ONLY | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.line.quantity | Odoo 19 Accounting | fields.Float | Quantity | odoo/odoo/addons/account/models/account_move_line.py | Bill/invoice line native quantity in line UoM | WRITE_ONLY_BY_NATIVE_AUTHORIZED_INVOICE_FLOW | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.line.product_uom_id | Odoo 19 Accounting | fields.Many2one | Unit | odoo/odoo/addons/account/models/account_move_line.py | Line unit; pounds conversion only if coherent | VERIFY_NATIVE_UOM | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |
| account.move.line.price_unit | Odoo 19 Accounting | fields.Float | Unit Price | odoo/odoo/addons/account/models/account_move_line.py | Agreed buyer/supplier unit price, not OCR authority | READ_NATIVE_COMMERCIAL_TERMS | Native Sales/Purchase/Accounting | VERIFIED_PUBLIC_ODOO19_SOURCE_NOT_INSTALLED |

**Source epoch:** 4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e for custom source, separately pinned public native 19.0 blobs in `campaign.json.field_routing_contract.native_source_coordinates` for standard add-ons.

## 6. Commercial consumers and exact native quantity bridges

| Consumer | Standard commercial quantity | Allowed exceptional quantity | Price source | Native action and proper line model | Validation/authorization gates | Required tests |
|---|---|---|---|---|---|---|
| Supplier Received Weight Notice | plasticos.transaction.supplier_weight | NO AUTOMATIC SCALE SUBSTITUTION; >5% direct supplier/buyer difference -> mandatory human review, RWN held pending approved supplier commercial settlement correction (D13) | purchase.order.line.price_unit (agreed supplier PO) | Native report/mail.template; NOT account.move | Accepted supplier basis and native purchase terms; when direct commercial spread >5%, require documented human reviewer decision, not scale-weight winner; source scale remains reference; native send protections. Underweight amount uses BRS-007 BR-UND-002 continuous proration on actual material net and D16 separate contractual authority, never the CST display weight. Buyer report auto-send sequence pending D18; no blanket inferred required-report rule; direct >5 percent review once both sources available. | T162; T163; T164; T165; T166; T167; T181; T182; T183; T191; T192 |
| Buyer Customer Invoice | plasticos.transaction.buyer_weight | NONE; carrier CST is not buyer invoice quantity | sale.order.line.price_unit (agreed buyer SO) | Native sale.order.line.qty_delivered / qty_to_invoice / invoice_lines then account.move.line.quantity, move_type=out_invoice | Buyer Receiving Report and accepted buyer commercial material net. Buyer-imposed underweight liability is a separately authorized adjustment, not scale-weight substitute or automatic supplier recovery; no direct qty_to_invoice write | T144; T147; T148; T149; T150; T151; T178; T190; T191; T193 |
| Supplier Vendor Bill | plasticos.transaction.supplier_weight | No automatic scale substitute; human-approved commercial correction only when D13/D16 and supplier contract permit | purchase.order.line.price_unit | Native purchase.order.line.qty_received / qty_to_invoice / invoice_lines and account.move.line.quantity, move_type=in_invoice | Supplier PO/terms and vendor invoice; independently authorized supplier-side underweight recovery not inferred from buyer chargeback. Native bill matching and no double credit/recovery. Underweight amount uses BRS-007 BR-UND-002 continuous proration on actual material net and D16 separate contractual authority, never the CST display weight. | T166; T167; T169; T178; T188; T190; T194; T195 |
| Carrier Vendor Bill and missing CST chargeback | NO MATERIAL SETTLEMENT FIELD | N/A | Existing carrier freight terms | Native carrier bill/credit + existing plasticos.penalty.rule / plasticos.claim | Carrier CST missing-document $150 applies only after D01/D04/D05. This is distinct from BRS-007 material-net underweight, whose numeric formula is D17 RESOLVED and contractual application remains D16 OPEN. Never mirror buyer/supplier liability automatically. | T155; T157; T161; T171 |

**No direct writes to computed `sale.order.line.qty_to_invoice`, `purchase.order.line.qty_to_invoice`, or any `final_weight` / `weight_source` selected winner.** Actual installed native Sales delivered and Purchase received invoicing policies determine how `buyer_weight`/supplier payable quantity become valid `account.move.line.quantity`. Ordered native quantity is not overwritten as a substitute for delivery. Native posting and mailing are separately authorized, never proven by a document classification boolean.

## 7. Proposed unit/threshold/negative worked examples (NOT hosted tests)

### V01: CST certified physical chain with combined packaging

| Key | Value |
|---|---|
| CST_gross | 72000 |
| CST_tare | 32000 |
| packaging_tare | 800 |
| CST_net | 40000 |
| net_weight_billed | 39200 |
| candidate_field | plasticos.transaction.scale_weight |
| expected | No direct supplier/buyer write or automatic third billing basis; CST complete if certified and matched load. |

### V02: CST material-net source matches explicitly packaging-excluded source figure, preventing a second deduction

| Key | Value |
|---|---|
| CST_gross | 72800 |
| CST_tare | 32000 |
| packaging_tare | 800 |
| CST_net | 40800 |
| net_weight_billed | 40000 |
| candidate_field | plasticos.transaction.scale_weight |
| expected | CST net 40,800 before packaging; billable net 40,000 already agrees with material-net evidence. Do not subtract another 800 lb from that accepted result. |
| source_stated_material_net | 40000 |

### V03: supplier 100 Gaylords-on-pallet with source gross material included packaging

| Key | Value |
|---|---|
| gross | 40600 |
| count | 100 |
| unit_tare | 80 |
| packaging_tare | 8000 |
| material_net | 32600 |
| candidate_field | plasticos.transaction.supplier_weight |
| expected | Only if supplier source actually establishes gross includes those packages; preserve count and package type. |

### V04: buyer 10 Gaylords on 10 pallets from Receiving Report

| Key | Value |
|---|---|
| received_gross | 40000 |
| packaging_tare | 800 |
| buyer_net | 39200 |
| candidate_field | plasticos.transaction.buyer_weight |
| expected | Report basis supported; buyer quantity excludes packaging exactly once. |

### V05: normal supplier settlement

| Key | Value |
|---|---|
| supplier_weight | 40000 |
| buyer_weight | 39500 |
| discrepancy_under_current_code_pct | 1.25 |
| RWN_quantity | 40000 |
| buyer_invoice_quantity | 39500 |
| expected | Supplier and buyer commercial weights remain independent; certified scale if any is reference only. |

### V06: exact threshold negative witness (current code max denominator)

| Key | Value |
|---|---|
| supplier_weight | 40000 |
| buyer_weight | 38000 |
| discrepancy_under_current_code_pct | 5 |
| RWN_quantity | 40000 |
| expected | Exactly 5% does not trigger the mandatory threshold review, scale is only a reference regardless. |

### V07: Direct commercial spread >5% requires human review, not scale substitution

| Key | Value |
|---|---|
| supplier_weight | 40000 |
| buyer_weight | 37000 |
| discrepancy_under_current_code_pct | 7.5 |
| RWN_status | HOLD_HUMAN_RECONCILIATION_D13 |
| buyer_invoice_quantity | 37000 |
| expected | Supplier RWN must wait for human decision; scale_weight remains reference, buyer invoice proceeds independently. |

### V08: supplier weight absent, buyer report accepted

| Key | Value |
|---|---|
| buyer_weight | 39000 |
| RWN_status | HOLD_PENDING_D14 |
| buyer_invoice_quantity | 39000 |
| expected | Do not invent supplier_weight, invoice buyer normally. |

### V09: certified CST complete but packaging details absent

| Key | Value |
|---|---|
| CST_gross | 72000 |
| CST_tare | 32000 |
| CST_net | 40000 |
| CST_obligation | COMPLETE_IF_D03 |
| scale_weight_status | PENDING_PACKAGING_BASIS |
| expected | Missing packaging is not missing CST and cannot generate carrier $150 penalty. |

### V10: supplier optional scale not carrier CST

| Key | Value |
|---|---|
| supplier_scale_gross | 72000 |
| supplier_scale_tare | 32000 |
| supplier_scale_net | 40000 |
| carrier_CST_obligation | OUTSTANDING |
| expected | Generic supplier SCALE does not satisfy carrier CST. |

### V11: buyer optional scale not Receiving Report

| Key | Value |
|---|---|
| buyer_scale_net | 39500 |
| buyer_receiving_report | MISSING |
| buyer_full_invoice | HOLD |
| expected | Source optional scale cannot replace buyer report. |

### V12: duplicate BOL copies

| Key | Value |
|---|---|
| supplier_BOL | BOL123 |
| carrier_BOL | BOL123 |
| shipment_count | 1 |
| source_submission_count | 2 |
| expected | Retain separate delivery provenance without duplicate underlying shipment. |

### V13: 53-foot exact light-weight shortfall threshold 38000

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 38000 |
| shortfall_lbs | 2000 |
| qualifying_weight_lbs | 2000 |
| rate | 0.01 |
| total | 380.00 |
| expected | ACCEPTED continuously prorated LWD rate applied to actual material net, not shortfall; D17 arithmetic resolved, D16 financial attribution/accounting still required. |
| effective_rate_usd_per_lb | 0.01 |

### V14: 53-foot just above light-weight threshold 38001

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 38001 |
| shortfall_lbs | 1999 |
| qualifying_weight_lbs | 0 |
| rate | 0.01 |
| total | 0.00 |
| expected | ACCEPTED continuously prorated LWD rate applied to actual material net, not shortfall; D17 arithmetic resolved, D16 financial attribution/accounting still required. |
| effective_rate_usd_per_lb | 0 |

### V15: 53-foot 36000 shortfall 4000

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 36000 |
| shortfall_lbs | 4000 |
| qualifying_weight_lbs | 4000 |
| rate | 0.01 |
| total | 720.00 |
| expected | ACCEPTED continuously prorated LWD rate applied to actual material net, not shortfall; D17 arithmetic resolved, D16 financial attribution/accounting still required. |
| effective_rate_usd_per_lb | 0.02 |

### V16: 53-foot full minimum 40000

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 40000 |
| shortfall_lbs | 0 |
| qualifying_weight_lbs | 0 |
| rate | 0.01 |
| total | 0.00 |
| expected | ACCEPTED continuously prorated LWD rate applied to actual material net, not shortfall; D17 arithmetic resolved, D16 financial attribution/accounting still required. |
| effective_rate_usd_per_lb | 0 |

### V17: 53-foot exact 2000 shortfall at zero contractual rate

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 38000 |
| shortfall_lbs | 2000 |
| qualifying_weight_lbs | 2000 |
| rate | 0 |
| total | 0.00 |
| expected | ACCEPTED continuously prorated LWD rate applied to actual material net, not shortfall; D17 arithmetic resolved, D16 financial attribution/accounting still required. |
| effective_rate_usd_per_lb | 0 |

### V18: Supplier and buyer each within 4 percent CST but direct spread fails

| Key | Value |
|---|---|
| supplier_weight | 38400 |
| scale_weight | 40000 |
| buyer_weight | 41600 |
| supplier_to_scale_pct_of_scale | 4 |
| buyer_to_scale_pct_of_scale | 4 |
| direct_spread_lbs | 3200 |
| direct_spread_pct_max_denominator | 7.692307692307692307692307692 |
| status | REVIEW_REQUIRED |
| expected | Direct commercial spread over 5 percent; reference proximity cannot clear; no automatic RWN scale substitution. |

### V19: Buyer underweight charge is not automatic supplier recovery

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 38000 |
| rate | 0.01 |
| total | 380.00 |
| buyer_contract_applies | True |
| supplier_contract_proven | False |
| buyer_liability_status | ELIGIBLE_FOR_APPROVED_CLAIM_ONLY |
| supplier_recovery_status | NOT_AUTHORIZED |
| expected | At 38000 lb material net and accepted $0.01 base-per-2000 shortfall, pure LWD is $380; buyer liability requires its own contract and supplier recovery remains NOT_AUTHORIZED without independent supplier agreement. |
| shortfall_lbs | 2000 |
| qualifying_weight_lbs | 2000 |
| effective_rate_usd_per_lb | 0.01 |

### V20: CST reference not an accepted third billable weight

| Key | Value |
|---|---|
| supplier_weight | 40000 |
| buyer_weight | 38000 |
| scale_weight | 39500 |
| status | SCALE_REFERENCE_ONLY |
| expected | Supplier RWN normal supplier commercial weight absent threshold/human correction; buyer AR buyer commercial weight; certified scale remains reference and display choice only. |

### V21: 53-foot material net 37999 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37999 |
| shortfall_lbs | 2001 |
| qualifying_weight_lbs | 2001 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.010005 |
| total | 380.18 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V22: 53-foot material net 37751 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37751 |
| shortfall_lbs | 2249 |
| qualifying_weight_lbs | 2249 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.011245 |
| total | 424.51 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V23: 53-foot material net 37750 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37750 |
| shortfall_lbs | 2250 |
| qualifying_weight_lbs | 2250 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.01125 |
| total | 424.69 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V24: 53-foot material net 37501 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37501 |
| shortfall_lbs | 2499 |
| qualifying_weight_lbs | 2499 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.012495 |
| total | 468.57 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V25: 53-foot material net 37500 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37500 |
| shortfall_lbs | 2500 |
| qualifying_weight_lbs | 2500 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.0125 |
| total | 468.75 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V26: 53-foot material net 37000 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37000 |
| shortfall_lbs | 3000 |
| qualifying_weight_lbs | 3000 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.015 |
| total | 555.00 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V27: 53-foot material net 34000 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 34000 |
| shortfall_lbs | 6000 |
| qualifying_weight_lbs | 6000 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.03 |
| total | 1020.00 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V28: 53-foot material net 37749 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37749 |
| shortfall_lbs | 2251 |
| qualifying_weight_lbs | 2251 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.011255 |
| total | 424.86 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V29: 53-foot material net 37499 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 37499 |
| shortfall_lbs | 2501 |
| qualifying_weight_lbs | 2501 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.012505 |
| total | 468.92 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V30: 53-foot material net 20000 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 20000 |
| shortfall_lbs | 20000 |
| qualifying_weight_lbs | 20000 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.10 |
| total | 2000.00 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

### V31: 53-foot material net 10000 full continuous rate and amount

| Key | Value |
|---|---|
| minimum_material_net | 40000 |
| material_net | 10000 |
| shortfall_lbs | 30000 |
| qualifying_weight_lbs | 30000 |
| rate | 0.01 |
| effective_rate_usd_per_lb | 0.15 |
| total | 1500.00 |
| expected | Operator-approved 500-lb continuous pro rata rate including fractional increments, no completed-step floor or intermediate rounding; this example is arithmetic only, contractual monetary effect requires D16. |

**Numeric disclaimers:** the current discrepancy diagnostic formula uses `abs(supplier_weight - buyer_weight)/max(supplier_weight,buyer_weight)`; the operator has approved strictly >5%, not independently the denominator or D13 extras. Examples V05-V07 test the currently implemented denominator only as diagnostics; V13-V20 check operator-approved 53-foot shortfall and direct-spread human-review boundaries. The business denominator and human adjudication process remain D13/D16; D17 arithmetic is resolved; D16 applicable contract and financial effect remain unproven. All figures are synthetic, not live financial instructions. Packaging values must reflect per-source inclusion evidence, never assumed zero.

## 8. Inspected code-level gaps, exact remedial owner and allowed stop

| Gap | Observed limitation | Existing owner | Evidence class | Minimum bounded follow-up | Scoped blocker |
|---|---|---|---|---|---|
| FIELDGAP-01 | No verified dedicated ORM scalar/typed table for each party source gross/tare/packaging/net and per-line source proof. | plasticos_documents_native + existing Odoo Documents metadata first | PROVEN_REPRESENTATION_PRESSURE_NOT_AUTHORIZATION | S03/S05 inspect installed Enterprise metadata and existing source-linked evidence; D08 decide smallest representation only if required for replay/line-level arithmetic | Only unsupported automatic writeback, not document capture or other independent invoice actions. |
| FIELDGAP-02 | Existing transaction unit_type/unit_count/total_tare represents one aggregate; multiple packaging types/parties require separate source evidence. | plasticos_transaction | SUPPORTED_SINGLE_PACKAGE_ONLY | S05 prove homogeneous 80 lb override; hold mixed/unrepresentable D15, never copy supplier package numbers to buyer. | Only quantity that lacks verified packaging basis. |
| FIELDGAP-03 | Carrier scale seeded compliance rule tag_id points to generic SCALE not existing CST, and required_for_close=True. | plasticos_documents | OBSERVED_AT_PINNED_STAGING | S02/S08 align carrier rule/matrix to exact CST tag and nonblocking close, and test synthetic supplier SCALE cannot complete carrier obligation. | Carrier status/commercial close in affected implementation. |
| FIELDGAP-04 | document_sync.DOC_TYPE_TAG_MAP scale_ticket->SCALE, no role-aware CST routing; does not persist doc_category. | plasticos_documents_native | OBSERVED_AT_PINNED_STAGING | S01/S04 reuse existing native doc_type=scale_ticket, map verified carrier Certified Scale Ticket to existing CST tag and role association, preserve supplier/buyer SCALE; no new selection. | Automated carrier CST association/completeness until verified. |
| FIELDGAP-05 | Legacy compliance_service.is_compliant aggregates all active required rules regardless required_for_invoice or document role; account_move_inherit.action_post uses it for out_invoice. | plasticos_documents + plasticos_transaction | OBSERVED_AT_PINNED_STAGING | S02/S07 scope compliance to exact operation, verified buyer Receiving Report only for full buyer AR; prove missing carrier CST never blocks invoice or close. | Safe auto-posting of AR until runtime proof. |
| FIELDGAP-06 | final_weight computed source-priority and deduction uses final_weight; commission dashboard SQL/view consumes final_weight/weight_source. | plasticos_transaction + plasticos_commission | OBSERVED_AT_PINNED_STAGING | S01/S02/S05 bind all consumers, prohibit selected final weight as settlement; repair only affected surfaces, retaining safe compatibility. | Changed computed-weight behavior until consumer tests. |
| FIELDGAP-07 | Native quantity/invoicing flow not yet wired to buyer_weight or supplier settlement; transaction.quantity is not native invoice line. | plasticos_transaction + native Sales/Purchase/Accounting | OBSERVED_SOURCE_GAP_RUNTIME_NOT_RUN | S05/S07/S10 prove actual line-level UoM and delivered/received qty supported route to account.move.line.quantity and existing invoice linkage. | Automated invoice/bill until actual native route/authorization proven. |
| FIELDGAP-08 | D13 percentage denominator, source corroboration and human adjudication requirements not fully operator admitted. | BRS business owner | EXPLICIT_OPEN | Bind exact comparison denominator/rounding, CST corroboration quality and authorized human-reviewed commercial correction where strictly >5% direct supplier/buyer spread; no automatic scale substitution. | Only over-5% disputed supplier settlement human-adjudication action, never buyer invoice or source intake. |

## 9. Field-contract prohibited declarations

The following identifiers have **no accepted new transaction ORM field** and may occur only in authentic source text or negative examples:

- `plasticos.transaction.shipper_weight`
- `plasticos.transaction.received_weight`
- `plasticos.transaction.net_weight`
- `plasticos.transaction.net_weight_billed`
- `plasticos.transaction.cst_net_weight`
- `plasticos.transaction.final_billed_weight`

Unsupported native selection declarations: `documents.document.doc_type:cst`, `documents.document.doc_type:packing_list`, `documents.document.doc_type:receiving_report`.

## 10. Required implementation and proof sequence

1. Resolve installed `documents.document` and exact Odoo field registry, current `Staging`/feature revision, native AI/extraction capability and safe writable models.

2. Validate sender versus actual issuer, source document class, company, exact transaction/load/material line, unit and raw/gross/tare/packaging basis. Record source fact and current revision before any write.

3. Select one source lane and only its permitted existing scalar. No cross-lane auto-fallback, no missing→zero, no blanket newer→winner. Reconcile the native Documents↔legacy per-record link with CST versus SCALE tag.

4. Prove CST certification and gross/net obligation independently of packaging; do not let missing packaging turn into $150 penalty. Derive packaging-adjusted net only after applicable source facts are validated.

5. Normal supplier RWN uses supplier commercial net and correct PO price. A direct supplier/buyer discrepancy strictly >5% requires human reconciliation with CST as reference only; never automatic scale substitute. Buyer Customer Invoice remains on accepted buyer_weight and native Sales line flow. Independently applicable underweight obligations use the scoped BRS formula, but D17 historical arithmetic is resolved; financial posting remains dependent on D16 controlling contract and native financial authorization; native financial owners remain separate.

6. Retire obsolete `final_weight`, selected `gross_weight`, `weight_source` and `dead_freight_chargeback` only after verified consumer migration; use proposed `_compute_light_weight_deduction_total` for monetary output and separate calculation output `light_weight_deduction_weight` as NON-ORM until authorized.

7. Execute named `T130`–`T223` tests at the appropriate pure/ORM/hosted/CI layer; replay and concurrently invoke affected paths with one economic effect. Zero collected, skipped or missing mandatory runtime test = NOT RUN.

8. Resolve D08/D13/D14/D15/D16/D18 through operator authorization (D17 calculation is already resolved) when needed; preserve original historical plan and previous BRS rules unchanged as sources.

**Deferred:** `brs-logistics` and a semantic-kernel vocabulary framework. **Not authorized:** repository commit, PR, merge, deployment, Odoo DB mutation, send/post or new ORM fields from this ZIP.
