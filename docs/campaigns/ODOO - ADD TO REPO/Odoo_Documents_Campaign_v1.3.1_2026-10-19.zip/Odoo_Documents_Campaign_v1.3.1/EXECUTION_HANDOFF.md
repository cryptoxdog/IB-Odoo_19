# Coherent-Slice Execution Handoff

## 1. Use one slice, not this entire pack as an implementation prompt

Select exactly one slice from ROADMAP.md, first read proposed ADR-025 and `docs/business-rules/README.md` with its exact SHA from `campaign.json#/business_rules_binding`, supply upstream receipts and BRS clause IDs, and bind its exact source revision, allowed mutation paths, grant and acceptance set. The BRS is authoritative for Documents business meaning; no agent changes its accepted rules to match code. Keep all remaining campaign work outside that slice. Parallel agents may inspect or prepare disjoint work, but one writer owns each shared source surface and disposable database.

Do not rewrite source_inputs/document_transaction_match_3a3f9d7d.plan.md. It is the user's protected starting plan. Do not restart its completed ADR tasks from an earlier narrative; inspect actual local state. Do not delegate unseen Make commands or native Odoo hooks as proven execution surfaces.

## 2. First activation: S01 with the minimal current-intent overlay

**Mission:** finish the existing document-to-transaction match plan on its actual local branch and record its exact result. Reuse existing models/fields and shared-attachment evidence. Do not implement the entire campaign now.

**Read first:** P01 for preserved original tasks, operator-approved ADR-025 + `brs-documents@1.3.1` for actual business meaning, current local ADR-022/023 and its conflicts, exact diff/full heads, Staging and PR 265 metadata, repo/native field law, S01 scope/tests and policy deltas POL02-POL21. ADR-025 is only a proposed repo file until separately admitted.

**Preserve:** original plan task identities; no-new-schema restriction; existing transaction/load/cardinality; distinct supplier/buyer/scale weights; current PR 265 owner of native install flags; all proved already-completed work.

**Narrow safety ceiling:** no evidence destruction on citation correction, no ambiguous/unauthorized cross-company filing, no financial side effect from unvalidated text. The original inclusive-at-5%/universal final_weight ideas are not current authority. **Supplier RWN normally uses `supplier_weight`, strictly >5% direct supplier/buyer discrepancy requires human reconciliation with `scale_weight` as REFERENCE ONLY (D13); no automatic scale substitution, and Customer Invoice uses `buyer_weight`. Carrier CST means Certified Scale Ticket.** The two separate equations are `CST gross − CST tare = CST net` and `CST net − applicable packaging tare = net weight billed`. Do not subtract packaging twice when the source already excludes it; uncertified supplier/buyer scale evidence is not a carrier CST. Missing supplier quantity holds only RWN under D14; absent supplier PL/carrier scale documentary compliance is not a blanket action blocker. Preserve existing source fields and dependent consumers until safely changed. Do not silently declare unverified scale eligibility final.

**Do not absorb:** full AI provider integration, all document classifications, party reminder rebuild, RWN generation, native Customer Invoice pipeline, $150 chargeback, AP overhaul or dashboard redesign. Those have named slices and tests.

**Required exit:** exact files/head, actual task disposition, original focused tests plus necessary interface evidence, no claimed end-to-end mail/OCR proof from pure functions, independent revision-bound audit of actual diff where available, and a small successor finding handoff. No automatic merge or deployment.

## 3. Activation record for any later slice

Each actual handoff must contain the following information, using the current established specialist contract when one governs execution. This pack does not replace GAR, coding, PR audit or remediation tool contracts.

| Field | Required meaning |
|---|---|
| Slice and outcome | Exact Sxx ID, bounded user-facing result and exclusions. |
| Source basis | Actual local/remote head/base, source evidence and retained upstream receipts. |
| Authorization | Read/mutate repos and paths; whether commit, publication, merge, runtime data write, send/post or deployment is granted. Missing grant means stop at that boundary. |
| Predecessor proof | Prerequisite slice result, affected source/config hashes, expired/invalidated receipts. |
| Work owner | Highest authoritative model/module and one shared-surface writer. |
| Decisions | Only Dxx relevant to the intended effects; D13 (human review for direct supplier/buyer >5%, denominator and decision evidence), D14 (missing supplier payable quantity), D15 (packaging) hold only their affected operations. |
| CST arithmetic and evidence | BR-CST-001/002: carrier Certified Scale Ticket requires verified certification and matched load; CST gross minus CST tare is CST net; CST net minus packaging tare is net weight billed. Never treat raw CST net as billable net or as universal Final Weight. |
| Normative business law | Exact `brs-documents` SHA, applicable BR-* IDs, version and operator-approved status; ADR-025 charter proposed repository placement. |
| Field identity | Actual installed `plasticos.transaction.supplier_weight`, `buyer_weight`, `scale_weight`, legacy computed fields and native `account.move`, `plasticos.load.seal_number` / `trailer_number`; no fabricated aliases. |
| Test contract | Exact acceptance IDs, current verified test invocation, isolated database/provider/mail setup and evidence limits. |
| Closure | Per-task/finding fixed/already satisfied/invalid/blocked; no suppressed regressions. |

Commands are verified against the target when executing. Manifest versions are read from the actual merged baseline, not copied blindly from the old plan. Reconcile the open native bridge version collision after the owning PR lands. Use this Odoo repository's existing publication plumbing, not an assumed organization-wide ceremony.

## 4. State and receipt handling

Campaign task `PLANNED` means no execution by this compilation, not a statement that no local work exists. A coding agent may import observed local completion only with exact evidence. Keep claimed, source-present, tested, runtime-integrated, deployed and operating states separate.

A closed slice receipt identifies code/config/provider/fixture versions, exact permitted action, output artifacts, observed tests, critical source/fact/action lineage and all blocked decisions. Reuse it while inputs and affected contract remain unchanged. A later source change invalidates only affected claims, not all past work by default. A regression reopens the originating affected closure under an explicit revision, not the whole campaign.

Retain original test results and do not rerun a long extraction/import test solely because a second narration stage wants a green badge. Run a replay when it proves idempotency or recovery, not as ritual. Actual repo gates remain binding once verified. Add a bounded BRS/field-name conformance check to the existing CI owner in S02/S12, with known-bad alias, RWN direction, uncertified-as-CST, missing packaging deduction, double deduction and strict-5% witnesses; **do not create an unrelated second CI workflow**. Repository CI installation and required-check enforcement remain NOT_RUN until authorized and observed.

## 5. Shared-path and environment collision rules

Common hot spots are transaction.py, account_move_inherit.py, document_native.py, document_sync.py, compliance_service.py, transaction_docs.py, scale-ticket rules and the shared mail templates. The roadmap lists them explicitly. Logical lanes may design/test in parallel with distinct fixture databases, but implementation on a shared file is serialized or integrated through one designated owner. No agent silently rebases another agent's accepted work.

A disposable database is explicitly identified/allowlisted and confirmed not Production. Email/SMS and accounting write tests are intercepted/isolated. Never start a new shared production-like database just because a test command failed. Verify the existing test environment owner and actual setup. A missing Enterprise dependency or provider key is an honest integration blocker, not an excuse to claim a mock as native proof.

## 6. Rollout and recovery

First observe extraction and proposed mappings against a small approved representative corpus. Then authorize bounded fact application to the correct existing records. Then authorize eligible notices, invoices and carrier effects separately. Widen only after the exact acceptance scope is proved. Do not impose a universal manual check on routine valid cases as a substitute for reliable controls.

Maintain a practical stop path through existing native settings/actions and service permissions. Stopping application must not stop original receipt or lose queued evidence. Preserve pending work and supported retries. If an external send/post outcome is ambiguous, reconcile native record/queue/provider evidence rather than retrying blindly. Correct posted records through native financial mechanisms; never delete financial history to make a replay clean.

## 7. Campaign-level done

The **inbound buyer Receiving Report** drives `buyer_weight`/load facts and native Customer Invoice. The **outbound supplier RWN** independently confirms selected supplier settlement weight (normally `supplier_weight`; human review when direct supplier/buyer spread >5%; scale_weight is reference only), agreed purchase price and approved deductions. Missing supplier PL or carrier scale document compliance does not block normal commercial output; missing supplier payable quantity holds only RWN. All party requirements remain truthful; missing certified CST gross/net creates one eligible $150 carrier effect under the bound rule and does not hold commercial close. All supported ordinary classes have an automated outcome or a specific justified exception. Source/privacy/accounting/replay controls work across actual native interfaces. Measured operation, not a fabricated percentage, demonstrates the benefit.

Do not call this campaign done merely because S01, a template or general CI passed. Conversely, do not reopen a sufficient slice for optional cleanup. The campaign is a roadmap for coherent deliveries, not a single giant PR.

**v1.2.1 gate:** read `validation/DRIFT_REVIEW.md` once for the successor delta. Preserve inherited source inputs and exact field labels. Unknown packaging is a billing-calculation exception, not missing certified CST. Close any consumer changed by the selected slice in that slice; do not defer its regression to a later slice.


## Field-routing execution boundary (v1.2.1)

Before implementing a Documents measurement or monetary deduction, read the `brs-documents` index, **`BRS-003@1.0.1` for the five physical stages**, **`BRS-007@1.0.1` for obligation-scoped eligibility/liability**, and `FIELD_ROUTING_AND_CONFORMANCE.md`. Prove the actual technical target exists on the selected pinned Odoo 19 installed model and that its declared string/type/selection applies. Required routed destinations: accepted supplier material net → `plasticos.transaction.supplier_weight`; accepted buyer Receiving Report material net → `plasticos.transaction.buyer_weight`; validated certified source scale material net reference only → `plasticos.transaction.scale_weight`. No cross-party fallback. Carrier CST physical gross/CST tare/CST net are source evidence. **CST gross − CST tare = CST net; CST net − packaging tare = net weight billed.** Carrier certification obligation is independent of packaging availability; missing packaging alone does not trigger a carrier penalty.

Do not add `shipper_weight`, `received_weight`, `net_weight_billed`, an invented carrier measurement field or `documents.document.doc_type='cst'`; use existing taxonomy/role, or return D08 if actual native evidence model is insufficient. Quote relevant native `sale.order.line`, `purchase.order.line`, and `account.move.line` fields from the installed registry, then show actual AR/AP effect in Odoo test DB. No invented CLI or publication ceremony. Preserve the original S01 source plan in `source_inputs/`; resolve its weight contradictions with BRS at the affected implementation seam and close changed consumers. Each handoff must explicitly list a source-group boundary, touched existing fields/owners, positive/adverse tests and forbidden cross-source writes.

## v1.2.1 bounded technical handoff: light-weight deduction total

The approved *business* calculation is deterministic and **obligation-scoped**, with output `(shortfall_lbs, qualifying_shortfall_lbs, effective_rate_usd_per_lb, total_usd)`. When the controlling 53-foot contract establishes 40,000 lb minimum material net: below 2,000 lb shortfall there is no deduction; starting at 2,000 lb inclusive, effective rate = `0.01*(shortfall_lbs/2000)` USD/lb, including continuous partial 500 lb proration; monetary total = accepted actual material net * effective rate, USD cents half-up at the end. Physical weight comes only from BRS-003 and obligation policy only from BRS-007 BR-UND-002. D17 monetary arithmetic is RESOLVED, but D16 contractual attribution/financial posting authorization remains OPEN. The existing `_compute_light_weight_deduction` is obsolete, reads deprecated `final_weight`, and lacks threshold; it is NOT implemented. Proposed Odoo successor `_compute_light_weight_deduction_total()` and `light_weight_deduction_total` are pending controlled migration, not installed fields. `light_weight_deduction_weight` is pure calculated output, not a new ORM column. `dead_freight_chargeback` Boolean is deprecated, pending consumer closure.

Accounting responsibility is **not** computed from the preferred screen CST or solely from trailer weight. Buyer liability and supplier recovery each require independent contract, source material-net quantity, counterparties and native credit/claim/accounting evidence; no automatic mirroring. Keep the separate carrier missing-CST $150 documentation chargeback distinct. Tests `T181`–`T200` are specified, all NOT_RUN on Odoo. Approval of this design **does not** grant schema migration, posting, CI/PR publication or Odoo.sh deployment.

**D17 resolved; D16 action-specific hold:** The formula and numerical boundary fixtures are accepted. Never block computing a pure Decimal test outcome for the old D17 conflict. Conversely, never create an automatic invoice adjustment, supplier recovery, credit or financial posting without independently established contractual responsibility and native permissions (D16). Source capture, buyer invoice qualification and CST compliance are independent.

## v1.3.1 indexed BRS authority and corrected monetary formula

The current BRS authority in this **proposal pack** is **`brs-documents@1.3.1`**, a non-normative index at `docs/business-rules/README.md`/`index.json`, resolving **seven numbered, independently owned files BRS-001..BRS-007**. The seven files own all 46 stable `BR-*` IDs exactly once. Agents must inspect each owning `BRS-NNN@1.0.0` at its indexed SHA and rule IDs; unnumbered predecessor BRS files are historical only. ADR-025 has been updated to make this numbering/index/CI discipline explicit, pending actual repository admission.

The operator-resolved **BRS-007 BR-UND-002** LWD formula: for an applicable 53-foot 40,000 lb material net minimum, shortfall below 2,000 lb yields no charge; at or above 2,000 lb, effective $/lb rate equals `0.01 * (shortfall_lbs / 2000)`, continuously prorated for partial 500 lb increments (no stepped rounding), and amount equals **actual material net** multiplied by effective rate, with final USD cents half-up. Example 37,750 lb net -> 2,250 lb short -> $0.01125/lb -> $424.69; 36,000 lb net -> $0.02/lb -> $720.00. D17 is resolved for arithmetic; D16 remains for contract applicability, independently attributed buyer/supplier liability, and actual financial effects. Target Odoo runtime/CI are NOT_RUN.

The implementation should reuse verified current Odoo fields. Proposed `light_weight_deduction_total`, method `_compute_light_weight_deduction_total()`, obsolete `final_weight` and `dead_freight_chargeback` retirement are **pending migration**, not present or deleted in the live registry.

## v1.3.1 fidelity and register-before-code requirement

Read `validation/CHAT_POLICY_AUDIT.md` first, then `REGISTRATION_MANIFEST.json` and `REPOSITORY_REGISTRATION_RUNBOOK.md`. Do not treat narrative or source observations as admitted Odoo law. The five-stage glossary and raw document measurements are BRS-003 owned. **Buyer Receiving Report is a hard gate for full Customer Invoice only; RWN pre-buyer-report sending remains D18.** All RWN drafts remain unsent without an authorized path; do not manufacture a required document relation or auto-send. Execute the indexed BRS checker in the repository's EXISTING CI `static-checks` before claiming enforcement, followed by hosted Odoo tests on disposable database.
