# Acceptance and Test Evidence Contract

**Version:** 1.3.1 | **BRS:** brs-documents@1.3.1 | **Status:** package specification, not executed Odoo software.

**Business authority:** 7 numbered BRS-001..007 (rule-owner index `docs/business-rules/index.json` and `docs/business-rules/README.md`); ADR-025 is the proposed authority charter. Source-declared Odoo identities stay unchanged. **CST gross - CST tare = CST net; CST net - applicable packaging tare = net weight billed.** Supplier RWN normally uses `supplier_weight`; Customer Invoice uses `buyer_weight`. Strictly >5% direct supplier/buyer spread requires human review; scale is reference ONLY, never automatic RWN replacement. Missing packaging alone is not missing CST.

## Test execution discipline

All 223 cases are specifications with execution_status NOT_RUN and no runtime receipt. A package check is not an Odoo test. Each activated case needs a real named test, exact code/config/BRS/source-fixture revision, a disposable Enterprise-equivalent database where required, and intercepted outbound effects. No absent dependency, skipped required case or zero collection is a PASS.

## Cross-interface proof layers

Pure arithmetic/matching tests prove only those functions; ORM tests prove field/action effects; real native mail/AI/accounting tests prove their invoked interfaces; a joined case proves the named workflow, not production operation. Reuse valid same-head evidence and avoid redundant full suites.

## Cases

### T001. Original inputs unchanged

**Requirements:** R01

**Owner slices:** S00

**Document classes:** None

**BRS rules:** None

**Given:** Supplied plan and prior ZIP with known SHA-256

**When:** Build campaign

**Expected:** Embedded files byte-identical; changes exist only in policy delta and successor artifacts.

**Required proof:** artifact

**Execution:** NOT_RUN

**Receipt:** None.

### T002. Reported ADR completion is not runtime proof

**Requirements:** R01; R27

**Owner slices:** S00; S01

**Document classes:** None

**BRS rules:** BR-FLD-003

**Given:** P01 reports local commits; remote ref unresolved

**When:** Open slice

**Expected:** Locate local full SHA/ADR or retain UNKNOWN; no duplicate ADR generation.

**Required proof:** source

**Execution:** NOT_RUN

**Receipt:** None.

### T003. Single exact TX reference

**Requirements:** R05

**Owner slices:** S01

**Document classes:** C07

**BRS rules:** BR-DOC-002; BR-EVD-001

**Given:** Known sender, one exact TX token

**When:** Match/file

**Expected:** One correct current evidence row sharing original attachment.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T004. Ten references to ten loads

**Requirements:** R05; R06

**Owner slices:** S01; S04

**Document classes:** C01; C12

**BRS rules:** BR-DOC-002; BR-EVD-001

**Given:** One logical invoice references ten existing TXs, sender eligible for each

**When:** File and replay

**Expected:** Ten associations, one original; no duplicated bill and no invented transaction/load cardinality.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T005. No references remains reviewable

**Requirements:** R03; R05; R21

**Owner slices:** S04

**Document classes:** C26

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-003

**Given:** Document with no usable reference

**When:** Process

**Expected:** Retain source, one reasoned review item, no business/financial writes.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T006. Token boundary and hyphen

**Requirements:** R05

**Owner slices:** S01

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001

**Given:** Similar TX identifiers, embedded suffixes, short tokens

**When:** Match

**Expected:** No partial/short collision; complete stored hyphenated identifier matched as specified.

**Required proof:** pure

**Execution:** NOT_RUN

**Receipt:** None.

### T007. Trailer or seal alone cannot select TX

**Requirements:** R05; R11

**Owner slices:** S04

**Document classes:** C13

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-FLD-003

**Given:** Repeated trailer/seal but no strong business reference

**When:** Match

**Expected:** No authoritative association from vehicle alone.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T008. Reference disagreement does not vote

**Requirements:** R05

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001

**Given:** TX points to A, PO points to B, majority supports A

**When:** Match

**Expected:** Specific ambiguity; no majority-of-hits authority or wrong-party update.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T009. Wrong company and same document number

**Requirements:** R05; R22

**Owner slices:** S02; S04

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-004

**Given:** Two companies with same order/ref

**When:** Match/apply as company A user

**Expected:** Cannot associate/read/write company B document, load or move.

**Required proof:** security

**Execution:** NOT_RUN

**Receipt:** None.

### T010. Parent company and child facility

**Requirements:** R05; R22

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-002; BR-EVD-004

**Given:** Authorized child contact under supplier with two facilities

**When:** Match

**Expected:** Correct facility evidence required; commercial parent alone cannot choose neighboring load.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T011. Multiple unrelated attachments in one email

**Requirements:** R03; R05

**Owner slices:** S03; S04

**Document classes:** C01; C17

**BRS rules:** BR-DOC-002; BR-EVD-001

**Given:** Attachment A cites TX-A; B cites TX-B; mail body cites both

**When:** Process

**Expected:** Each logical part links only its own valid TX; body union never copies all links.

**Required proof:** native mail+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T012. Collated PDF logical boundaries

**Requirements:** R03; R04; R06

**Owner slices:** S03; S04

**Document classes:** C01; C17

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-002

**Given:** One PDF contains two invoices and one Receiving Report

**When:** Extract/segment

**Expected:** Preserve original; distinct parts and provenance; no merged totals or assumed native auto-split.

**Required proof:** provider+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T013. Multi-load total not allocated

**Requirements:** R06; R12

**Owner slices:** S01; S05

**Document classes:** C01; C18

**BRS rules:** BR-CAR-001; BR-DOC-002; BR-EVD-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Ten references and only one lump weight/amount

**When:** Apply

**Expected:** No tenfold copying or equal division; affected weight/allocation stays unresolved.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T014. Closed/cancelled records evidence boundary

**Requirements:** R05; R29

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-004

**Given:** Late evidence for closed TX and cancelled TX reference

**When:** Process

**Expected:** Safe evidence handling per policy; no auto financial rewrite or state guard bypass; cancelled not falsely active.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T015. Repeated same message and altered filename

**Requirements:** R03; R07

**Owner slices:** S03; S04

**Document classes:** None

**BRS rules:** BR-EVD-001; BR-EVD-004

**Given:** Same original delivered twice, renamed

**When:** Replay

**Expected:** No duplicate logical filing, business writes, bills, notices or open activities.

**Required proof:** mail+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T016. Concurrent same source event

**Requirements:** R07

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-EVD-004

**Given:** Two workers process same source/part/TX

**When:** Race and commit

**Expected:** One applicable business effect and association; no unique-key check-then-create gap.

**Required proof:** concurrency

**Execution:** NOT_RUN

**Receipt:** None.

### T017. Mid-sync failure

**Requirements:** R07

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-EVD-004

**Given:** Create evidence row then inject error before native link

**When:** Retry

**Expected:** Savepoint/atomic recovery leaves no duplicate row and no lost original.

**Required proof:** fault injection

**Execution:** NOT_RUN

**Receipt:** None.

### T018. Reference correction preserves history

**Requirements:** R07; R29

**Owner slices:** S02; S04

**Document classes:** None

**BRS rules:** BR-EVD-004

**Given:** Corrected source drops one prior citation

**When:** Reclassify

**Expected:** Previous association retained as historical/superseded; compliance/current display corrected without deletion.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T019. Currentness and expiry

**Requirements:** R07; R19

**Owner slices:** S02; S08

**Document classes:** None

**BRS rules:** BR-EVD-003; BR-EVD-004

**Given:** Verified old/superseded/expired document and current invalid revision

**When:** Evaluate requirement

**Expected:** No stale evidence satisfies current requirement; default active_test behavior separately checked.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T020. Mirror direct and polymorphic identity

**Requirements:** R06; R07

**Owner slices:** S04

**Document classes:** None

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-EVD-004

**Given:** Source linked to one then multiple transactions

**When:** Sync/query

**Expected:** Smart buttons, compliance and missing-doc checks agree; native single pointers not used as false never-synced signal.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T021. Alias upload and body-only coverage

**Requirements:** R03

**Owner slices:** S03

**Document classes:** C26

**BRS rules:** BR-EVD-001

**Given:** Real configured native alias plus UI upload and body-only email

**When:** Ingest

**Expected:** All arrive with source/received time; actual hook/action invocation proved, not inferred.

**Required proof:** native mail

**Execution:** NOT_RUN

**Receipt:** None.

### T022. Async extraction completes after mail hook

**Requirements:** R03; R04

**Owner slices:** S03; S04

**Document classes:** None

**BRS rules:** BR-EVD-001; BR-EVD-002

**Given:** Mail hook sees unread file, provider finishes later

**When:** Complete extraction

**Expected:** Existing native completion/retry path resumes once; no permanent unlinked loss.

**Required proof:** native AI+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T023. Spreadsheet and structured input

**Requirements:** R04

**Owner slices:** S03

**Document classes:** None

**BRS rules:** BR-EVD-002

**Given:** Supported XLSX/XML/CSV evidence with explicit units and per-row refs

**When:** Extract safely

**Expected:** Actual cell/row references retained; formula/macros not executed; unsupported format exception explicit.

**Required proof:** provider/parser

**Execution:** NOT_RUN

**Receipt:** None.

### T024. Scanned image and multipage report

**Requirements:** R04

**Owner slices:** S03

**Document classes:** C17

**BRS rules:** BR-EVD-002

**Given:** Legible scan/photo of accepted report

**When:** Extract

**Expected:** Correct facts compared to fixture truth and locations as supported; no invented bounding boxes.

**Required proof:** native AI

**Execution:** NOT_RUN

**Receipt:** None.

### T025. No OCR credit/provider outage

**Requirements:** R03; R04

**Owner slices:** S03

**Document classes:** None

**BRS rules:** BR-EVD-001; BR-EVD-002

**Given:** Provider unavailable or quota exhausted

**When:** Process/retry

**Expected:** Original retained, bounded retry and actionable reason; no fake zero/complete.

**Required proof:** fault injection

**Execution:** NOT_RUN

**Receipt:** None.

### T026. Prompt injection in attachment

**Requirements:** R04; R22

**Owner slices:** S03

**Document classes:** C27

**BRS rules:** BR-EVD-002; BR-EVD-004

**Given:** Document tells agent to change bank details, send files or execute code

**When:** Extract

**Expected:** Treat as data; no tool/recipient/permission expansion or unapproved external fetch.

**Required proof:** security

**Execution:** NOT_RUN

**Receipt:** None.

### T027. Malformed/oversized/password attachment

**Requirements:** R03; R22

**Owner slices:** S03

**Document classes:** None

**BRS rules:** BR-EVD-001; BR-EVD-002; BR-EVD-004

**Given:** Corrupt file, embedded executable, decompression bomb or locked PDF

**When:** Ingest

**Expected:** Safe retention/quarantine, bounded parser, no silent loss or executable run.

**Required proof:** security

**Execution:** NOT_RUN

**Receipt:** None.

### T028. Source sender versus scale issuer

**Requirements:** R05; R12

**Owner slices:** S04; S05

**Document classes:** C08; C09

**BRS rules:** BR-CAR-001; BR-CST-001; BR-DOC-002; BR-EVD-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Carrier forwards valid third-party ticket; stranger sends unverified scale claim

**When:** Validate

**Expected:** Carrier transport not automatic distrust or authority; issuer/source checked; stranger not independent by definition. CST status additionally requires verified certification and carrier-submission provenance (BR-CST-001).

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T029. Buyer Receiving Report facts and independent output readiness

**Requirements:** R08; R10; R11

**Owner slices:** S05

**Document classes:** C17; C13

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-FLD-002; BR-FLD-003; BR-REC-001; BR-REC-002; BR-WGT-001

**Given:** Buyer Receiving Report identifies TX/load, accepted net/unit and seal

**When:** Apply

**Expected:** Existing buyer_weight and correct load seal updated with source evidence; Receiving Report acceptance true, but supplier RWN requires independent supplier settlement basis/terms.

**Required proof:** native AI+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T030. Buyer Receiving Report absent

**Requirements:** R08

**Owner slices:** S05; S06; S07

**Document classes:** C17; C31; C32

**BRS rules:** BR-DOC-001; BR-REC-001

**Given:** All supplier/carrier docs present but no accepted buyer Receiving Report

**When:** Evaluate/send/post

**Expected:** Full Customer Invoice is blocked for missing mandatory buyer Receiving Report; supplier RWN auto-send remains separately held by unresolved D18, not by a falsely approved universal buyer-report document prerequisite. Supported RWN draft may exist.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T031. Numeric buyer weight without report

**Requirements:** R08

**Owner slices:** S05

**Document classes:** C17

**BRS rules:** BR-DOC-001; BR-REC-001

**Given:** buyer_weight populated manually/imported; report not linked/validated

**When:** Evaluate

**Expected:** No inference of report receipt or final automatic eligibility from scalar alone.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T032. Supplier weight missing does not block Customer Invoice but holds supplier RWN

**Requirements:** R09; R10; R37

**Owner slices:** S05; S06; S07

**Document classes:** C05; C17; C31; C32

**BRS rules:** BR-CAR-002; BR-DOC-001; BR-FLD-002; BR-REC-002; BR-SET-004; BR-WGT-001

**Given:** Valid buyer Receiving Report; no supplier weight

**When:** Process

**Expected:** Customer Invoice remains eligible using buyer_weight; supplier_weight stays Unknown; supplier RWN is held absent D14-approved settlement fallback. No source weight copied or zero invented.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T033. Supplier packing list absent nonblocking

**Requirements:** R09

**Owner slices:** S05; S08

**Document classes:** C04

**BRS rules:** BR-DOC-001; BR-REC-002; BR-SET-004

**Given:** Accepted buyer Receiving Report and valid supplier_weight from another approved supplier-side source; no supplier PL

**When:** Evaluate

**Expected:** RWN on supported supplier_weight/terms and Customer Invoice on buyer_weight remain eligible. PL absence stays tracked where applicable and nonblocking; neither optional scale status nor missing PL permits invented packaging tare.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T034. All carrier scale evidence missing nonblocking

**Requirements:** R13

**Owner slices:** S05; S07; S08

**Document classes:** C08; C17; C32

**BRS rules:** BR-CAR-001; BR-CAR-002

**Given:** Valid buyer Receiving Report, valid supplier_weight with <=5% supplier/buyer discrepancy and zero carrier scale documents

**When:** Process

**Expected:** Customer Invoice proceeds; ordinary supplier RWN proceeds from valid supplier_weight/terms, while carrier gross/net requirement remains outstanding and $150 lane pending bound due rule.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T035. Only net or only gross not complete

**Requirements:** R12; R19

**Owner slices:** S08

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-EVD-003; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Carrier uncertified/net-only/gross-only tickets and ambiguous gross/CST tare measurement

**When:** Evaluate

**Expected:** Captured/incomplete CST; no obligation completion from SCALE tag or uncertified source; AR unaffected.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T036. Complete gross and net in one ticket

**Requirements:** R12

**Owner slices:** S05; S08

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Certified carrier CST with gross, CST tare and CST net tied to same load/unit

**When:** Evaluate

**Expected:** Valid certified CST satisfies carrier gross/net component obligation; packaging-adjusted net billed is a separate validated derived quantity; no two-document requirement.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T037. Light/heavy pair compatible derivation

**Requirements:** R12

**Owner slices:** S05; S08

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Certified carrier CST same load/vehicle: heavy/gross 76000 lb, CST tare (source light reading) 36000 lb, source packaging tare 800 lb

**When:** Extract

**Expected:** CST net=40000 lb, net weight billed=39200 lb if packaging not previously excluded; capture calculated intermediate values; fulfill only verified certified source and D03 requirements.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T038. Light/heavy pair mismatch

**Requirements:** R12

**Owner slices:** S05

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Carrier ticket readings differ by load/vehicle, certification fails, or units cannot be reconciled

**When:** Pair

**Expected:** No valid certified CST completion or derived net weight billed; retain source and create a targeted processing/issuer exception.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T039. Stated net not double-tared

**Requirements:** R12; R33

**Owner slices:** S05

**Document classes:** C17

**BRS rules:** BR-CAR-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Supplier PL or buyer Receiving Report explicitly states material net=40000 lb AFTER packaging tare of 400 lb for 10 pallets; all quantities refer to that same source side.

**When:** Apply

**Expected:** The applicable supplier_weight or buyer_weight remains 40000, not 39600. Preserve the declared packaging-excluded evidence. The word net without this explicit meaning would not pass the same oracle.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T040. Gross minus tare mismatch

**Requirements:** R12

**Owner slices:** S05

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Carrier CST gross=76000, CST tare=36000, but stated CST net=39000 lb, and packaging counts are reported

**When:** Validate

**Expected:** Gross-CST tare must equal CST net=40000, not 39000; retain contradictory source, do not produce valid billable material net or mark certified requirement complete.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T041. Explicit kg and metric tonnes

**Requirements:** R12

**Owner slices:** S03; S05

**Document classes:** None

**BRS rules:** BR-CAR-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Report mass explicitly kg or metric tonnes

**When:** Normalize

**Expected:** Use native UoM with verified factor/rounding, preserve original; ambiguous tons not guessed.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T042. Negative or zero received weight

**Requirements:** R10; R12

**Owner slices:** S05

**Document classes:** None

**BRS rules:** BR-CAR-001; BR-FLD-002; BR-REC-002; BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Negative measurement or explicit zero vs missing value

**When:** Apply

**Expected:** Reject negative; zero not treated as missing nor automatically billable normal receipt; specific exception when needed.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T043. Revised buyer Receiving Report

**Requirements:** R10; R29

**Owner slices:** S05; S06; S07

**Document classes:** C19

**BRS rules:** BR-EVD-004; BR-FLD-002; BR-REC-002; BR-WGT-001

**Given:** Accepted revision changes received net after notice/invoice

**When:** Process

**Expected:** Preserve previous buyer facts and outputs. Revalidate the Customer Invoice and supplier RWN independently. A material buyer change requires an RWN correction only if its selected settlement quantity, terms/deductions or approved reported content changes; otherwise no duplicate notice. Native posted-invoice correction remains separately authorized.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T044. Supplier/scale conflict and five-percent boundary

**Requirements:** R10

**Owner slices:** S05

**Document classes:** None

**BRS rules:** BR-FLD-002; BR-REC-002; BR-WGT-001

**Given:** Distinct sources differ at exactly 5 percent and above

**When:** Reconcile

**Expected:** Exactly 5% does not permit the exceptional RWN source switch; strictly greater than 5% requires valid scale evidence and resolved D13. D02 controls price/deduction/AP realization, not the scale-eligibility decision. Preserve both source fields.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T045. No complete report per partial load

**Requirements:** R08; R12

**Owner slices:** S05; S07

**Document classes:** C17

**BRS rules:** BR-CAR-001; BR-DOC-001; BR-REC-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Report covers part of a shipment or lacks per-material allocation

**When:** Evaluate

**Expected:** No fabricate full receiving status or copied mass across lines; supported partial invoice policy or targeted exception.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T046. Seal leading zero and change chronology

**Requirements:** R11

**Owner slices:** S05

**Document classes:** C13

**BRS rules:** BR-EVD-002; BR-FLD-003

**Given:** Seal 001234 then corrected report 001235

**When:** Apply

**Expected:** Preserve exact string/source/history and conflict/replacement authority; no integer coercion.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T047. Container is not trailer

**Requirements:** R02; R11

**Owner slices:** S05

**Document classes:** C13

**BRS rules:** BR-EVD-002; BR-FLD-001; BR-FLD-003

**Given:** Document has a container/chassis number, no verified target scalar

**When:** Apply

**Expected:** Keep evidence; expose representation gap; do not write into trailer_number or invent field.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T048. Actual versus scheduled dates

**Requirements:** R11

**Owner slices:** S05

**Document classes:** C14

**BRS rules:** BR-EVD-002; BR-FLD-003

**Given:** Different scheduled pickup and actual pickup in evidence

**When:** Apply

**Expected:** Correct native event fields/actions, timezone explicit, both meanings preserved.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T049. RWN contents and receiver

**Requirements:** R16; R32

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Accepted buyer Receiving Report for discrepancy assessment, normal qualified supplier_weight, approved supplier purchase price, validated deductions and supplier contact

**When:** Render/queue

**Expected:** RWN includes supplier settlement weight and unit (not buyer_weight by default), supplier purchase price, approved light-weight/other chargebacks, reconciled total and correct supplier recipient; TX/PO/load/date/material and revision visible.

**Required proof:** mail/report

**Execution:** NOT_RUN

**Receipt:** None.

### T050. Double-blind notice

**Requirements:** R16; R22

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-EVD-002; BR-EVD-004; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Buyer Receiving Report includes buyer name/address and resale price

**When:** Render/send RWN

**Expected:** No protected buyer identity, resale price, margin or unredacted report attachment disclosed.

**Required proof:** security+mail

**Execution:** NOT_RUN

**Receipt:** None.

### T051. RWN no supplier quantity is an exception only for notice

**Requirements:** R09; R16; R32; R37

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-CAR-002; BR-DOC-001; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Buyer Receiving Report valid; supplier_weight absent; no approved D14 supplier payable fallback

**When:** Render

**Expected:** Do not send a quantity-free or buyer_weight-substituted supplier RWN; hold and explain payable basis. Customer invoice still eligible using buyer_weight.

**Required proof:** mail/report

**Execution:** NOT_RUN

**Receipt:** None.

### T052. RWN duplicate/retry/correction

**Requirements:** R07; R16; R29

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-EVD-004; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Identical accepted buyer Receiving Report AND selected supplier settlement weight/price/deductions replay; later material approved correction

**When:** Queue

**Expected:** One RWN per immutable supplier settlement revision (quantity, price, deductions and relevant buyer-report input); corrected notice separately identified and old retained; unknown send outcome not blindly retried.

**Required proof:** mail fault injection

**Execution:** NOT_RUN

**Receipt:** None.

### T053. Supplier notice failure does not block AR

**Requirements:** R17

**Owner slices:** S06; S07

**Document classes:** C31; C32

**BRS rules:** BR-REC-002; BR-REC-003

**Given:** Supplier RWN failed transport OR supplier payable basis unresolved; valid buyer Receiving Report and accepted buyer sales/accounting terms

**When:** Run both lanes

**Expected:** Supplier RWN exception visible; Customer Invoice creation, posting and sending remain independently eligible.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T054. Customer Invoice actual quantity and terms

**Requirements:** R10; R17

**Owner slices:** S07

**Document classes:** C32

**BRS rules:** BR-FLD-002; BR-REC-002; BR-REC-003; BR-WGT-001

**Given:** Accepted net 40000 lb and confirmed sales line 0.20 USD/lb, applicable tax policy

**When:** Create draft

**Expected:** Material amount 8000 USD before applicable taxes/authorized charges; correct buyer/company/UoM and native source line.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T055. Buyer document cannot change agreed price

**Requirements:** R17; R28

**Owner slices:** S07

**Document classes:** C17; C32

**BRS rules:** BR-REC-002; BR-REC-003; BR-SET-005

**Given:** Receiving report states a different unit price

**When:** Create/reconcile

**Expected:** Use accepted SO terms or hold mismatch; no unapproved repricing.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T056. Compliance flip does not post drafts

**Requirements:** R23

**Owner slices:** S02

**Document classes:** None

**BRS rules:** BR-EVD-002

**Given:** TX with unrelated/unvalidated AR/AP drafts; last doc verified

**When:** Recompute

**Expected:** No automatic posting solely from compliance; authorized eligibility required separately.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T057. Native Always auto-post respects gate

**Requirements:** R23

**Owner slices:** S02; S07; S10

**Document classes:** C01

**BRS rules:** BR-EVD-002

**Given:** Native vendor auto-post enabled with missing business prerequisite

**When:** Digitize/post

**Expected:** Cannot bypass same deterministic business controls; unsafe action held without losing document.

**Required proof:** native accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T058. No duplicate invoice or double send

**Requirements:** R07; R17

**Owner slices:** S07

**Document classes:** C32

**BRS rules:** BR-EVD-004; BR-REC-002; BR-REC-003

**Given:** Repeated report, mail and concurrent worker

**When:** Create/post/send

**Expected:** One appropriate native invoice/credit and one queue identity; no duplicate posting.

**Required proof:** concurrency+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T059. Posted AR correction

**Requirements:** R17; R29

**Owner slices:** S07

**Document classes:** C19; C32

**BRS rules:** BR-EVD-004; BR-REC-002; BR-REC-003

**Given:** Posted/sent invoice and changed accepted receiving net

**When:** Correct

**Expected:** Native correction with linkage/audit; no modifying posted original or second unrelated invoice.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T060. Consolidated invoice identity

**Requirements:** R06; R18

**Owner slices:** S10

**Document classes:** C01; C12

**BRS rules:** BR-DOC-002; BR-EVD-001; BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** One carrier invoice covers ten TXs; current bill exclusivity

**When:** Process

**Expected:** Never ten duplicate Vendor Bills; use proven current native allocation or named representation exception.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T061. Per-party receipt versus valid completeness

**Requirements:** R19; R21

**Owner slices:** S08

**Document classes:** None

**BRS rules:** BR-EVD-003

**Given:** Unreadable report, valid BOL and complete scale ticket

**When:** Display/evaluate

**Expected:** Separate received/validated/complete/gate status and party; not one green verified checkbox.

**Required proof:** ORM/UI

**Execution:** NOT_RUN

**Receipt:** None.

### T062. Correct clock anchors and calendar

**Requirements:** R20

**Owner slices:** S08

**Document classes:** None

**BRS rules:** BR-EVD-003

**Given:** Pickup/delivery dates and approved calendar/timezone

**When:** Advance frozen clock

**Expected:** Party obligations start from correct event; no transaction-create aging or unexplained historical default.

**Required proof:** clock/ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T063. Reminder channel/dedupe/stop

**Requirements:** R20

**Owner slices:** S08

**Document classes:** C17; C08

**BRS rules:** BR-EVD-003

**Given:** Approved email/SMS policy, missing buyer Receiving Report

**When:** Run cron twice then receive report

**Expected:** Correct recipient/refs/channel, no duplicate attempt; report reminder stops; other carrier obligations persist.

**Required proof:** mail/SMS+clock

**Execution:** NOT_RUN

**Receipt:** None.

### T064. Manager escalation and queue ownership

**Requirements:** R20; R21

**Owner slices:** S08

**Document classes:** None

**BRS rules:** BR-EVD-003

**Given:** Supplier/carrier/buyer obligations reach approved escalation

**When:** Run

**Expected:** Existing activities to correct manager, specific reason/source; no cron-user assignment or duplicate internal mail.

**Required proof:** ORM/UI

**Execution:** NOT_RUN

**Receipt:** None.

### T065. Pagination beyond first batch

**Requirements:** R03; R20

**Owner slices:** S08

**Document classes:** None

**BRS rules:** BR-EVD-001; BR-EVD-003

**Given:** More outstanding TXs than default cron limit

**When:** Run successive pages

**Expected:** All eligible obligations visited without starvation, duplicate notices or repeated completed work.

**Required proof:** ORM/performance

**Execution:** NOT_RUN

**Receipt:** None.

### T066. Rule scopes invoice versus close

**Requirements:** R19; R30

**Owner slices:** S08

**Document classes:** None

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-EVD-003

**Given:** Buyer Receiving Report missing vs carrier scale missing; client-specific extra rule

**When:** Evaluate each operation

**Expected:** Only proper blocker affects operation; carrier scale absence never becomes an AR or normal commercial-close gate.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T067. Penalty deadline unknown

**Requirements:** R14

**Owner slices:** S09

**Document classes:** C08; C33

**BRS rules:** BR-CAR-003

**Given:** Missing carrier gross/net but D01 not resolved

**When:** Run

**Expected:** No autonomous posted penalty; pending requirement/case visible; RWN/AR continue.

**Required proof:** accounting/clock

**Execution:** NOT_RUN

**Receipt:** None.

### T068. Penalty complete evidence before deadline

**Requirements:** R12; R14

**Owner slices:** S09

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CAR-003; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Valid accepted gross/net received on time

**When:** Evaluate after due

**Expected:** Zero chargeback; no race penalty based on late processing.

**Required proof:** clock/ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T069. One missing-evidence load produces 150

**Requirements:** R14; R15

**Owner slices:** S09

**Document classes:** C08; C33

**BRS rules:** BR-CAR-003; BR-SET-005

**Given:** Bound eligible rule, applicable carrier, required evidence absent beyond approved due

**When:** Assess and realize approved accounting route

**Expected:** One USD 150 carrier claim/effect for load; never charged to supplier/buyer.

**Required proof:** accounting/clock

**Execution:** NOT_RUN

**Receipt:** None.

### T070. Both gross and net missing is not 300

**Requirements:** R14; R15

**Owner slices:** S09

**Document classes:** C08

**BRS rules:** BR-CAR-003; BR-SET-005

**Given:** Same load lacks both measurements, D04 confirms one per-load event

**When:** Evaluate repeatedly

**Expected:** One USD 150 total, not 300 and not 150 per day.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T071. Gross-only/net-only conditional penalty

**Requirements:** R12; R14

**Owner slices:** S09

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CAR-003; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** One required measurement missing after bound due

**When:** Evaluate

**Expected:** Incomplete obligation produces one penalty under D03/D04; native SCALE tag alone does not waive it.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T072. Parser outage is not carrier noncompliance

**Requirements:** R03; R14

**Owner slices:** S09

**Document classes:** C08

**BRS rules:** BR-CAR-003; BR-EVD-001

**Given:** Ticket received by due date but parser failed or processing delayed

**When:** Evaluate

**Expected:** Processing exception first; no automatic penalty for established receipt with unresolved content.

**Required proof:** fault injection

**Execution:** NOT_RUN

**Receipt:** None.

### T073. Economic effect once

**Requirements:** R15

**Owner slices:** S09

**Document classes:** C12; C33

**BRS rules:** BR-CAR-003; BR-SET-005

**Given:** Carrier freight bill 1200 USD, approved vendor credit 150, related claim

**When:** Post and compute margin/commission

**Expected:** Net freight cost 1050; vendor balance reduced 150; transaction improvement exactly 150, not 300; claim not bank settlement.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T074. Penalty race/crash/replay

**Requirements:** R15

**Owner slices:** S09

**Document classes:** C33

**BRS rules:** BR-CAR-003; BR-SET-005

**Given:** Two jobs and injected crash after claim/create or credit/post

**When:** Retry

**Expected:** No duplicate claim/account.move/outbound; recovery inspects existing native result.

**Required proof:** concurrency+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T075. Carrier bill absent or already paid

**Requirements:** R15; R18

**Owner slices:** S09

**Document classes:** C12

**BRS rules:** BR-CAR-003; BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** Eligible missing docs; no bill yet, or already paid bill

**When:** Realize

**Expected:** Pending/approved alternative according to D05; no fabricated vendor document/payment or silent cash movement.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T076. Late evidence and reversal

**Requirements:** R15; R29

**Owner slices:** S09

**Document classes:** C08; C33

**BRS rules:** BR-CAR-003; BR-EVD-004; BR-SET-005

**Given:** Scale evidence arrives after assessment/post

**When:** Apply bound late-evidence policy

**Expected:** Receipt checklist corrected; no automatic deletion/refund without bound policy; reversal native, original retained.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T077. USD and company separation

**Requirements:** R14; R22

**Owner slices:** S09

**Document classes:** C33

**BRS rules:** BR-CAR-003; BR-EVD-002; BR-EVD-004

**Given:** Different carrier invoice currency or company

**When:** Assess

**Expected:** USD intent preserved; no rate invention or cross-company offset; specific currency policy needed.

**Required proof:** accounting+security

**Execution:** NOT_RUN

**Receipt:** None.

### T078. Penalty notice content

**Requirements:** R14; R16

**Owner slices:** S09

**Document classes:** C33

**BRS rules:** BR-CAR-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Approved assessed event and carrier recipient

**When:** Render/send

**Expected:** Correct carrier/TX/load/missing gross/net/due/150/dispute info; not a Customer Invoice charge.

**Required proof:** mail/report

**Execution:** NOT_RUN

**Receipt:** None.

### T079. AP invoice digitization and PO match

**Requirements:** R18

**Owner slices:** S10

**Document classes:** C01

**BRS rules:** BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** Routine supplier invoice exactly matches accepted PO terms

**When:** Digitize/reconcile

**Expected:** Correct native vendor/date/ref/lines/UoM/tax/company and linked draft; eligible automatic posting, no transcription.

**Required proof:** native AI+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T080. Freight invoice and accessorial mismatch

**Requirements:** R18

**Owner slices:** S10

**Document classes:** C12

**BRS rules:** BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** Carrier bill includes unapproved accessorial

**When:** Reconcile

**Expected:** Base known amounts retained, disputed extra exception; no silent all-bill posting/deduction.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T081. Supplier/AP weight terms remain scoped

**Requirements:** R09; R18

**Owner slices:** S10

**Document classes:** C01; C17

**BRS rules:** BR-DOC-001; BR-REC-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001

**Given:** Accepted buyer_weight=39000 and supplier_weight=40000; buyer Sales terms are valid; the supplier purchase price or deduction authority for the RWN and Vendor Bill is unresolved.

**When:** Process

**Expected:** Customer Invoice can proceed using buyer_weight. Only the affected supplier RWN financial content and Vendor Bill await D02; do not send an invented supplier amount or copy buyer_weight into supplier_weight.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T082. Credit/chargeback accounting direction

**Requirements:** R15; R18

**Owner slices:** S09; S10

**Document classes:** C02; C12

**BRS rules:** BR-CAR-003; BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** Supplier credit or carrier credit refers to existing bill

**When:** Apply

**Expected:** Correct native type/sign/tax/original relation and one effect; chatter-only applied flag insufficient.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T083. Incoming buyer note not new AR

**Requirements:** R17; R28

**Owner slices:** S07; S10

**Document classes:** C22

**BRS rules:** BR-REC-002; BR-REC-003; BR-SET-005

**Given:** Buyer debit note or document called invoice

**When:** Classify/process

**Expected:** Evidence of adjustment/claim, never duplicate new sale; resolve with native original invoice.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T084. Remittance is not bank settlement

**Requirements:** R18; R28

**Owner slices:** S10; S11

**Document classes:** C21

**BRS rules:** BR-REC-003; BR-SET-003; BR-SET-005; BR-WGT-001

**Given:** Buyer sends remittance advice

**When:** Process

**Expected:** Link references and proposed reconciliation; do not mark paid or commission paid from advice alone.

**Required proof:** accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T085. Quality/damage/photo duplicate claims

**Requirements:** R24; R28

**Owner slices:** S11

**Document classes:** C15; C20

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-REC-003; BR-SET-005

**Given:** Repeated quality claim photos/report

**When:** Process

**Expected:** One correctly scoped existing claim/evidence set; no automatic accepted liability or invented recovery.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T086. Certificate scope/expiry/material facts

**Requirements:** R24; R28

**Owner slices:** S11

**Document classes:** C23; C24

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-REC-003; BR-SET-005

**Given:** COA plus expiring certificate for one facility/lot

**When:** Extract/apply

**Expected:** Only correct material/facility scope, expiry tracked, no global taxonomy overwrite.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T087. Contract terms require commercial authority

**Requirements:** R24; R28

**Owner slices:** S11

**Document classes:** C25

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-REC-003; BR-SET-005

**Given:** Unsigned/inconsistent recurring price sheet arrives

**When:** Process

**Expected:** File/compare and route approval; no repricing existing TX or financial amendment.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T088. Protected onboarding/bank changes

**Requirements:** R22; R24; R28

**Owner slices:** S11

**Document classes:** C27

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-EVD-004; BR-REC-003; BR-SET-005

**Given:** Known vendor email requests new bank details

**When:** Process

**Expected:** Document retained and routed to protected owner; no automatic bank update even with high extraction confidence.

**Required proof:** security

**Execution:** NOT_RUN

**Receipt:** None.

### T089. Order confirmation/readiness facts

**Requirements:** R24; R28

**Owner slices:** S11

**Document classes:** C03; C11; C16

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-REC-003; BR-SET-005

**Given:** Supplier confirmation, buyer PO, carrier acknowledgment

**When:** Process

**Expected:** Correct existing order/event fact, no unapproved new commercial commitment or wrong-party reference.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T090. Outbound order/dispatch reference and privacy

**Requirements:** R16; R20; R27

**Owner slices:** S08; S11

**Document classes:** C28; C29; C30

**BRS rules:** BR-EVD-003; BR-FLD-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Existing PO/SO/DO actions render

**When:** Inspect complete native output

**Expected:** TX and correct recipient reference included, double-blind versions preserved, terms not invented.

**Required proof:** mail/report

**Execution:** NOT_RUN

**Receipt:** None.

### T091. Generic correspondence and unsupported evidence

**Requirements:** R03; R24

**Owner slices:** S11

**Document classes:** C26; C06

**BRS rules:** BR-DOC-001; BR-EVD-001; BR-EVD-002

**Given:** Email with unknown class or supporting photo

**When:** Process

**Expected:** Captured and filed when match safe; specific unsupported reason; no forced generic manual check on all valid docs.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T092. Verification/override direct RPC guard

**Requirements:** R22; R23

**Owner slices:** S02

**Document classes:** None

**BRS rules:** BR-EVD-002; BR-EVD-004

**Given:** User lacking permission calls write/verify/override

**When:** Attempt

**Expected:** Denied server-side; cannot unblock invoice by editing tag/rule/verified Boolean.

**Required proof:** security

**Execution:** NOT_RUN

**Receipt:** None.

### T093. Financial document retention after parent deletion

**Requirements:** R07; R22

**Owner slices:** S02

**Document classes:** None

**BRS rules:** BR-EVD-002; BR-EVD-004

**Given:** Attempt delete load/TX with original evidence and posted move

**When:** Delete

**Expected:** Protected native lifecycle preserves evidence/financial record or refuses deletion, never cascade loss.

**Required proof:** security+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T094. Feature disable and fail recovery

**Requirements:** R25

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-EVD-002

**Given:** Live-like queue with pending extraction/sends, feature disabled

**When:** Resume safely

**Expected:** Originals retained, no force-send rollback duplicate, pending work visible and bounded replay possible.

**Required proof:** operational

**Execution:** NOT_RUN

**Receipt:** None.

### T095. Representative corpus and true touch rate

**Requirements:** R24; R26

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-EVD-003

**Given:** Approved corpus labeled by class and actual exception conditions

**When:** Measure

**Expected:** Counts and manual minutes derive from observed outcomes; no invented percentage or broad proof from mocks.

**Required proof:** operational

**Execution:** NOT_RUN

**Receipt:** None.

### T096. No false dependency in execution graph

**Requirements:** R09; R13; R17; R27

**Owner slices:** S00; S12

**Document classes:** None

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-DOC-001; BR-FLD-003; BR-REC-002; BR-REC-003; BR-SET-004

**Given:** Full roadmap

**When:** Evaluate prerequisites

**Expected:** S07 not gated by S06 delivery, S09 penalty, S10 AP or nonblocking supplier evidence.

**Required proof:** artifact

**Execution:** NOT_RUN

**Receipt:** None.

### T097. Whole golden path without optional supplier PL/scales or mandatory carrier scales

**Requirements:** R08; R09; R10; R11; R13; R14; R16; R17; R19; R37

**Owner slices:** S12

**Document classes:** C17; C31; C32; C08; C33

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-DOC-001; BR-EVD-002; BR-EVD-003; BR-FLD-002; BR-FLD-003; BR-REC-001; BR-REC-002; BR-REC-003; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-001

**Given:** Valid buyer Receiving Report and independently accepted supplier_weight with <=5% discrepancy; missing supplier PL, optional supplier/buyer scales and required carrier gross/net; approved supplier price/deductions and bound carrier penalty terms

**When:** Process end to end and advance due clock

**Expected:** Correct buyer_weight/load facts; supplier RWN reports supplier_weight, approved price/deductions; native Customer Invoice uses buyer_weight; carrier gross/net remain outstanding and one eligible USD 150 carrier effect occurs only when due; no routine transcription.

**Required proof:** full native integration

**Execution:** NOT_RUN

**Receipt:** None.

### T098. Versioned deployed proof

**Requirements:** R25; R27

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-EVD-002; BR-FLD-003

**Given:** Passed scoped tests on exact checkout, module and runtime versions

**When:** Prepare rollout

**Expected:** Separate code/test/config/host/operating evidence; merge/deploy/send/post requires actual grant.

**Required proof:** operational

**Execution:** NOT_RUN

**Receipt:** None.

### T099. Graceful all-required closure

**Requirements:** R19; R30

**Owner slices:** S08; S12

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CAR-002; BR-EVD-003

**Given:** Customer Invoice issued; carrier CST absent; any assessed penalty has its approved financial disposition.

**When:** Evaluate close/checklist

**Expected:** Normal commercial close is not blocked solely by missing CST. Keep document absence and collection visible; do not reassess an already realized penalty or invent financial recovery. No Customer Invoice rollback.

**Required proof:** ORM/UI

**Execution:** NOT_RUN

**Receipt:** None.

### T100. Delivery proof is not a Receiving Report

**Requirements:** R08; R24

**Owner slices:** S05; S11

**Document classes:** C10

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-REC-001

**Given:** Signed POD confirms delivery but no received net quantity or receiving-report essentials

**When:** Process

**Expected:** File/apply actual delivery facts without fabricating buyer Receiving Report; hold full buyer Customer Invoice. For supplier RWN distinguish correct supplier quantity and D18 unresolved premature auto-send, no fabricated universal receiving gate.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T101. Buyer settlement ticket report equivalence

**Requirements:** R08; R10

**Owner slices:** S05

**Document classes:** C18

**BRS rules:** BR-DOC-001; BR-FLD-002; BR-REC-001; BR-REC-002; BR-WGT-001

**Given:** Buyer scale ticket without report essentials and separate complete accepted settlement report

**When:** Evaluate

**Expected:** Incomplete ticket does not bypass report requirement; complete accepted equivalent may satisfy it under D07.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T102. Exactly 5% does not switch supplier RWN

**Requirements:** R32

**Owner slices:** S05; S06

**Document classes:** C31

**BRS rules:** BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Supplier 40000 lb and buyer 38000 lb (difference 5% under current max denominator); optional eligible scale 38200

**When:** Evaluate standard RWN quantity

**Expected:** Use supplier_weight at EXACT 5%; do not substitute scale_weight. Formula denominator remains D13 pending explicit acceptance.

**Required proof:** business+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T103. Strictly over 5% with scale reference requires human RWN review

**Requirements:** R32; R37

**Owner slices:** S05; S06

**Document classes:** C09; C31

**BRS rules:** BR-CAR-002; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005; BR-WGT-010

**Given:** Supplier accepted material net 40000, buyer accepted material net 37600, certified CST material net reference 37800; direct spread over five percent under current diagnostic denominator

**When:** Attempt automated supplier RWN and independently eligible buyer Customer Invoice

**Expected:** Do not select 37800 or any alternative supplier payable weight automatically. Hold disputed supplier RWN until authorized human decision, preserve supplier 40000 and buyer 37600 and scale reference 37800, while buyer invoice may use accepted 37600.

**Required proof:** native mail+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T104. Over 5% disputed supplier RWN held for human review, with or without scale

**Requirements:** R32

**Owner slices:** S05; S06

**Document classes:** C09; C31

**BRS rules:** BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Direct supplier versus buyer material-net spread over 5%, independently of available/valid scale reference; no human reconciliation decision yet

**When:** Attempt RWN and Customer Invoice

**Expected:** Hold supplier RWN settlement on human review pending D13; never invent scale/buyer substitute or change accepted source fields; Customer Invoice independently eligible.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T105. Supplier quantity absent holds RWN but not Customer Invoice

**Requirements:** R32; R37

**Owner slices:** S05; S06; S07

**Document classes:** C17; C31; C32

**BRS rules:** BR-CAR-002; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Accepted buyer Receiving Report, no supplier_weight and no approved D14 fallback

**When:** Evaluate both supplier and buyer output lanes

**Expected:** No supplier RWN sent with missing or zero substituted supplier quantity; valid Customer Invoice can proceed on buyer_weight; missing PL itself not a blocker.

**Required proof:** integration

**Execution:** NOT_RUN

**Receipt:** None.

### T106. RWN includes purchase price and approved deductions

**Requirements:** R32

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Accepted ordinary supplier_weight, native purchase price/terms, approved light-weight deduction and separate authorized chargeback

**When:** Generate supplier settlement notice

**Expected:** Notice states supplier selected quantity, unit, purchase price, each approved signed deduction/chargeback and correct settlement total; no buyer sale price, no double economic effect.

**Required proof:** native report/accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T107. Normal supplier notice with no PL or optional scales

**Requirements:** R32; R37

**Owner slices:** S06; S07

**Document classes:** C04; C05; C18; C31

**BRS rules:** BR-CAR-002; BR-REC-002; BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005

**Given:** Accepted buyer Receiving Report and supported supplier_weight from authoritative completed supplier evidence, not an unverified placeholder PO quantity; <=5% under the bound comparison, no PL, and no optional supplier/buyer scales or required carrier CST.

**When:** Evaluate notice and Customer Invoice

**Expected:** RWN uses supported supplier_weight plus approved purchase price/deductions; Customer Invoice uses buyer_weight. PL absence is tracked/nonblocking, optional supplier/buyer scales remain optional, and mandatory carrier CST remains outstanding without blocking either otherwise eligible action.

**Required proof:** native integration

**Execution:** NOT_RUN

**Receipt:** None.

### T108. Gaylord and pallet packaging tare in source evidence

**Requirements:** R33

**Owner slices:** S05

**Document classes:** C04; C17

**BRS rules:** BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** 10 Gaylords each on a pallet; both sides explicitly describe source gross before packaging

**When:** Derive packaging tare for eligible source

**Expected:** 40 lb per Gaylord plus 40 lb per pallet = 800 lb total, not 400 or 1600; no second deduction after already-net interpretation.

**Required proof:** ORM+pure

**Execution:** NOT_RUN

**Receipt:** None.

### T109. Packaging already net cannot be re-tared

**Requirements:** R33

**Owner slices:** S05

**Document classes:** C04; C17

**BRS rules:** BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Supplier PL or buyer Receiving Report says stated net already excludes packaging tare; ten Gaylords on pallets

**When:** Apply quantity and show packaging evidence

**Expected:** Preserve stated net exactly; do not subtract an additional 800 lb or confuse packaging tare with CST tare.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T110. Box and mixed packing do not invent tare

**Requirements:** R33

**Owner slices:** S05; S11

**Document classes:** C04; C17

**BRS rules:** BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Source contains boxes without an approved tare or mixed Gaylord/pallet counts beyond one unit_type

**When:** Extract without silently writing false value

**Expected:** Unknown source-specific tare remains reviewable, no assumed box 0-lb policy and no invented field/selection; supported homogeneous portion can remain safe.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T111. Received Weight Notice is outbound, Receiving Report inbound

**Requirements:** R34

**Owner slices:** S03; S06

**Document classes:** C17; C31

**BRS rules:** BR-CAR-001; BR-DOC-001; BR-DOC-002; BR-REC-001

**Given:** Buyer sends Receiving Report and supplier RWN is generated later

**When:** Classify/route

**Expected:** Buyer document maps RECEIVING/buyer_weight; RWN is outbound supplier settlement report and is not an inbound buyer document, alias or doc_type enum.

**Required proof:** document integration

**Execution:** NOT_RUN

**Receipt:** None.

### T112. Duplicate supplier and carrier BOL copies

**Requirements:** R34

**Owner slices:** S04; S11

**Document classes:** C07

**BRS rules:** BR-CAR-001; BR-DOC-001; BR-DOC-002; BR-REC-001

**Given:** Supplier and trucker each send same BOL under different email identifiers

**When:** Ingest, classify and link

**Expected:** One underlying BOL business document/attachment identity as supported, with both delivery-source histories; no doubled load/invoice or lost provenance.

**Required proof:** mail+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T113. Supplier scale evidence optional including nearby scale

**Requirements:** R34

**Owner slices:** S05; S08

**Document classes:** C05; C09

**BRS rules:** BR-CAR-001; BR-DOC-001; BR-DOC-002; BR-REC-001

**Given:** Supplier has no own scale OR provides MRF/nearby facility ticket

**When:** Evaluate supplier document completeness and scale source trust

**Expected:** No supplier scale mandatory obligation. Preserve supplied evidence with actual issuer; separate supplier declaration and D13 scale eligibility decision.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T114. Buyer scale ticket optional not a Receiving Report

**Requirements:** R34

**Owner slices:** S05; S08

**Document classes:** C17; C18

**BRS rules:** BR-CAR-001; BR-DOC-001; BR-DOC-002; BR-REC-001

**Given:** Buyer scale ticket net exists but required Receiving Report absent

**When:** Evaluate full billing evidence

**Expected:** No full Customer Invoice; optional ticket saved as measurement, Receiving Report remains outstanding until D07-approved equivalence.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T115. Carrier scale gross and net mandatory per load

**Requirements:** R34

**Owner slices:** S08; S09

**Document classes:** C08

**BRS rules:** BR-CAR-001; BR-CST-001; BR-CST-002; BR-DOC-001; BR-DOC-002; BR-REC-001

**Given:** Certified carrier CST with CST gross/CST net/CST tare versus uncertified generic carrier scale and optional supplier/buyer scale evidence

**When:** Evaluate obligation by responsible source, load and components

**Expected:** Only valid certified carrier CST can satisfy required carrier gross and net; optional or uncertified ticket cannot; net billed subtracts packaging once, USD 150 carrier penalty remains D01/D03/D04/D05 and buyer AR nonblocking.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T116. No invented weight aliases in implementation

**Requirements:** R35

**Owner slices:** S01; S02; S12

**Document classes:** None

**BRS rules:** BR-FLD-001; BR-FLD-002; BR-FLD-003

**Given:** Changed XML/Python/ORM destination contains shipper_weight or received_weight or introduces new global net_weight

**When:** Run bounded contract and actual CI guards

**Expected:** Fail required check on unapproved technical identity; accept authentic incoming prose and approved Received Weight Notice document title.

**Required proof:** CI+static

**Execution:** NOT_RUN

**Receipt:** None.

### T117. Legacy computed weight is not source settlement truth

**Requirements:** R35

**Owner slices:** S01; S05

**Document classes:** C31

**BRS rules:** BR-FLD-001; BR-FLD-002; BR-FLD-003

**Given:** Supplier 40000, buyer 39500 and scale 39750; current computed final_weight/gross_weight still exist

**When:** Evaluate invoice/RWN and dashboard impacts

**Expected:** No settlement quantity picked from scale > buyer > supplier winner algorithm; no raw CST gross written to computed gross_weight; affected dashboard/deduction consumers explicitly addressed.

**Required proof:** ORM+dashboard

**Execution:** NOT_RUN

**Receipt:** None.

### T118. BRS and ADR-025 presence and revision binding

**Requirements:** R31; R35; R36

**Owner slices:** S00; S02; S12

**Document classes:** None

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-FLD-001; BR-FLD-002; BR-FLD-003

**Given:** Exact BRS markdown and ADR-025 inside package; work handoff cites accepted rule IDs and digest

**When:** Validate package contract

**Expected:** Stable IDs exist in BRS and campaign graph, digest matches; original plan byte-identical; brs-logistics remains deferred; only proposed repo admission claimed.

**Required proof:** artifact

**Execution:** NOT_RUN

**Receipt:** None.

### T119. Field model/type/label registry compatibility

**Requirements:** R31; R35; R36

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-FLD-001; BR-FLD-002; BR-FLD-003

**Given:** Verified exact installed Odoo/PlasticOS fields, composed views, selection keys and owner refs

**When:** Validate active policy-to-ORM mapping

**Expected:** Fields resolve with correct owner and labels; no invented doc_type RECEIVING value; source-only validation not promoted to Enterprise runtime PASS.

**Required proof:** Odoo registry

**Execution:** NOT_RUN

**Receipt:** None.

### T120. Actual CI negative naming and BRS witnesses

**Requirements:** R31; R36

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-DOC-001; BR-EVD-002; BR-FLD-001; BR-FLD-003

**Given:** Intentional wrong field alias, wrong RWN direction, swapped supplier/Customer Invoice quantities, exact5 scale substitution and unsupported value; new >5% scale auto-substitution and masked direct commercial 4%/4% spread and underweight threshold errors

**When:** Run existing repository required CI and disposable Odoo fixtures

**Expected:** Every injected bad case fails for its correct reason; valid counterpart passes; CI path actually blocks, not advisory.

**Required proof:** CI+negative controls

**Execution:** NOT_RUN

**Receipt:** None.

### T121. No silent modification of accepted BRS by implementer

**Requirements:** R36

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-EVD-002; BR-FLD-001

**Given:** Agent changes approved BRS to fit incorrect code without operator approval and marks runtime tests green

**When:** Evaluate governance enforcement

**Expected:** Reject unauthorized business-rule modification or report bounded nonmechanical approval gap; no false machine proof of human identity.

**Required proof:** policy+change review

**Execution:** NOT_RUN

**Receipt:** None.

### T122. Only certified carrier CST satisfies carrier documentation obligation

**Requirements:** R12; R38

**Owner slices:** S03; S04; S08; S09

**Document classes:** C05; C08; C18

**BRS rules:** BR-CST-001; BR-CAR-001; BR-CAR-002; BR-DOC-001

**Given:** Carrier sends a valid certified load-matched scale ticket; separate supplier and buyer send generic scale tickets with gross/net but no certification evidence; a carrier sends an uncertified SCALE-tagged ticket.

**When:** Classify and verify each source and evaluate the carrier CST obligation

**Expected:** Only the certified carrier CST can complete carrier CST obligation. Supplier/buyer scale tickets remain optional and not auto-certified. Uncertified carrier ticket is retained/incomplete; it cannot stop buyer invoicing or ordinary RWN and penalty only follows approved D01/D03/D04/D05. No new doc_type enum is introduced.

**Required proof:** Odoo Documents+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T123. CST gross to net billed requires TWO different tares

**Requirements:** R12; R33; R39

**Owner slices:** S05; S06; S08

**Document classes:** C08; C31

**BRS rules:** BR-CST-001; BR-CST-002; BR-WGT-003; BR-SET-003; BR-FLD-001

**Given:** One verified carrier CST: gross 72000 lb, CST tare 32000 lb, CST net 40000 lb; ten Gaylords on ten pallets, packaging tare 800 lb; customer Receiving Report has independent buyer_weight.

**When:** Extract source, validate per-load arithmetic and calculate source-specific candidate quantity

**Expected:** CST net=40000 lb from 72000-32000; net weight billed=39200 lb from 40000-800. All original/intermediate values and certification preserved. Validated packaging-adjusted CST material net 39200 remains reference for human reconciliation under D13, never automatic payable settlement. No override of buyer_weight/supplier_weight nor write to gross_weight/final_weight; no invented net_weight_billed technical field.

**Required proof:** pure+Odoo ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T124. Reject false certified status and packaging double deduction

**Requirements:** R38; R39

**Owner slices:** S05; S08; S09

**Document classes:** C08

**BRS rules:** BR-CST-001; BR-CST-002; BR-EVD-003

**Given:** (a) Carrier ticket bears existing CST tag but lacks verified certification; (b) certified CST documents CST gross=72000, CST tare=32000 and CST net=40000, plus a separate net weight billed=39200 explicitly after 800 packaging tare; (c) certified CST gross/net is valid but packaging data is unavailable.

**When:** Evaluate certified obligation and calculate eligible billable material net

**Expected:** (a) Certification requirement remains incomplete. (b) Preserve CST net=40000 and net weight billed=39200; never call 39200 the CST net before packaging or subtract 800 twice. (c) Certified-document receipt may be complete; only billed-net calculation is unresolved, no $150 solely for missing packaging, and independently valid Customer Invoice remains eligible.

**Required proof:** pure+Odoo ORM negative

**Execution:** NOT_RUN

**Receipt:** None.

### T125. CST measurement vocabulary is consistent across active artifacts

**Requirements:** R35; R36; R39

**Owner slices:** S02; S05; S12

**Document classes:** C08; C31

**BRS rules:** BR-FLD-001; BR-FLD-003; BR-CST-001; BR-CST-002

**Given:** The BRS, policies, prompts, formulas, reports and rendered campaign views describe a carrier CST; immutable historic sources retain authentic wording.

**When:** Apply naming/field checks to active content and run a known-bad alias witness.

**Expected:** Active measurement names are CST gross, CST tare, CST net, packaging tare and net weight billed. Preserve source wording only as evidence and actual Odoo labels/technical names unchanged. No invented CST quantity field.

**Required proof:** artifact+CI

**Execution:** NOT_RUN

**Receipt:** None.

### T126. Packaging unknown does not mean carrier CST missing

**Requirements:** R12; R13; R14; R39

**Owner slices:** S05; S08; S09

**Document classes:** C08; C31

**BRS rules:** BR-CST-002; BR-CAR-001; BR-CAR-002; BR-CAR-003; BR-WGT-004

**Given:** Carrier supplied a certified, load-matched CST with CST gross=72000, CST tare=32000, CST net=40000 by the approved deadline. Source-side packaging remains unknown; buyer_weight and buyer terms are independently supported.

**When:** Evaluate CST compliance, the carrier penalty, CST-based supplier selection and Customer Invoice separately.

**Expected:** Carrier CST obligation is complete and no $150 arises solely from packaging unknownness. Do not treat unknown packaging as zero. Hold only a supplier scale-based billed-net calculation that needs it; normal supported supplier_weight and Customer Invoice are unaffected.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T127. Source-specific packaging cannot be borrowed between parties

**Requirements:** R10; R12; R33; R39

**Owner slices:** S05; S11

**Document classes:** C04; C08; C17

**BRS rules:** BR-WGT-001; BR-WGT-002; BR-WGT-003; BR-WGT-004

**Given:** Supplier PL: 40800 lb including 10 Gaylords on 10 pallets. Buyer Receiving Report: 39720 lb including 9 Gaylords on 9 pallets. Both explicitly include packaging.

**When:** Normalize each source using its own package counts and approved 40/40 values.

**Expected:** supplier_weight=40000 and buyer_weight=39000; retain packaging evidence 800 and 720 respectively. Never use one party count as the other party fact, double deduct, or overwrite one shared packaging scalar as though it represents both. An unrepresentable case stays a scoped D15 exception.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T128. A bare net label is not a packaging deduction receipt

**Requirements:** R12; R33; R39

**Owner slices:** S05

**Document classes:** C04; C08; C17

**BRS rules:** BR-CST-002; BR-WGT-002; BR-WGT-004

**Given:** A document says net 40000 lb and lists packaging but does not say whether that packaging is included; another explicitly labels CST net derived from CST gross and CST tare.

**When:** Classify numeric meaning before billing normalization.

**Expected:** Do not assume the first amount is packaging-excluded or subtract by guess; preserve it as an unresolved source candidate. For the explicit CST chain, retain CST net separately and derive net weight billed once from supported packaging. No generic net-to-final_weight mapping.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T129. Changed summary cannot conceal a changed business rule

**Requirements:** R31; R35; R36

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-FLD-001; BR-FLD-003; BR-EVD-002

**Given:** An altered campaign swaps RWN and Customer Invoice quantity fields or renames an existing field/label in a mapping while retaining valid IDs and hashes of unrelated files.

**When:** Run the strengthened package checks and the later required repository tests.

**Expected:** Reject data/derived-view mismatch and wrong exact field/model/label or policy value. Artifact checks stay artifact-only; actual repository checks require their own execution receipt.

**Required proof:** artifact+CI

**Execution:** NOT_RUN

**Receipt:** None.

### T130. Supplier/buyer/carrier source numbers do not leak

**Requirements:** R40

**Owner slices:** S04; S05

**Document classes:** C04; C17; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** One source per role with identical-looking net values and exact party/issuer/load evidence

**When:** Classify and validate each source independently

**Expected:** Supplier source can update only supplier_weight, mandatory buyer report only buyer_weight, and eligible CST material net only scale_weight; other fields remain unchanged.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T131. A generic scale document is not certified carrier CST

**Requirements:** R40

**Owner slices:** S04; S08

**Document classes:** C05; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Generic SCALE tag on supplier or buyer scale document, neither certified by issuer nor carrier submission

**When:** Run classifier and carrier requirement evaluation

**Expected:** Source stays supplier/buyer category, never satisfies carrier CST requirement, never changes scale_weight as independent certified carrier result.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T132. Mail sender cannot elect weight lane

**Requirements:** R40

**Owner slices:** S04

**Document classes:** C04; C17; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Forwarded mail from carrier with embedded supplier PL and buyer Receiving Report, each distinct issuer

**When:** Classify each logical document part

**Expected:** Actual issuer and document class govern each part, sender alone never shifts SUPPLIER/BUYER/CST data to a different target field.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T133. Three weights legitimately differ

**Requirements:** R40

**Owner slices:** S05

**Document classes:** C04; C17; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Supplier material net 40,000 lb, buyer accepted net 39,500 lb, CST net billed 39,200 lb from one load

**When:** Apply validated accepted source facts

**Expected:** supplier_weight=40000; buyer_weight=39500; scale_weight=39200 only if approved eligibility; none is final_weight or a forced matching commercial value.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T134. Untrusted issuer blocks writing

**Requirements:** R40

**Owner slices:** S04; S05

**Document classes:** C17; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Scale-looking PDF from uncorroborated unrelated sender has a valid TX token

**When:** Extract and match without trusted issuer proof

**Expected:** Preserve file and candidate measurements; never write supplier_weight, buyer_weight or scale_weight and never mark carrier CST complete.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T135. Document versus load identity conflict blocks wrong field

**Requirements:** R40

**Owner slices:** S04; S05

**Document classes:** C08; C17

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** A buyer Receiving Report cites TX-A but printed load/reference corroborates a different TX-B

**When:** Validate candidate against exact transaction and load

**Expected:** Hold only ambiguous association, write no buyer_weight for either TX, preserve original and specific conflicting identifiers.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T136. Already accepted source requires controlled correction

**Requirements:** R40

**Owner slices:** S05

**Document classes:** C04; C17; C08

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Current verified buyer report with accepted buyer_weight and different later email with same filename

**When:** Reprocess same filename or new revision

**Expected:** Never overwrite accepted buyer_weight merely from arrival order; require source revision precedence and approved correction with previous value retained.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T137. Missing, zero, unit and partial lines remain distinct

**Requirements:** R40

**Owner slices:** S03; S05

**Document classes:** C04; C17

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** One unknown weight, one explicit 0 rejected load, incompatible unit and multi-load total with no per-load breakdown

**When:** Extract candidate quantities

**Expected:** No missing value becomes 0, no guessed pounds, no equal apportionment; only independently validated per-load values write to their owner fields.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T138. Supplier stated packaging-excluded net

**Requirements:** R41

**Owner slices:** S05

**Document classes:** C04

**BRS rules:** BR-WGT-005

**Given:** Supplier PL explicitly says 40,000 lb net of packaging with Gaylord count 10

**When:** Apply supplier material net

**Expected:** supplier_weight=40000 and no subtraction of 400 lb again; source package facts preserved as separate evidence.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T139. Supplier gross requires supported packaging

**Requirements:** R41

**Owner slices:** S05

**Document classes:** C04

**BRS rules:** BR-WGT-005

**Given:** Supplier gross material including ten Gaylords-on-pallets = 40,800 lb with source-evidenced combined 800 lb packaging

**When:** Compute packaging-excluded supplier material net

**Expected:** supplier_weight=40000, package tare 800, with independent source fact refs; never treat 40,800 as already net.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T140. Supplier PL optional for commercial gate

**Requirements:** R41

**Owner slices:** S05; S06

**Document classes:** C04; C31; C32

**BRS rules:** BR-WGT-005

**Given:** Accepted independent supplier net, valid buyer Receiving Report and no PL

**When:** Prepare supplier RWN and buyer AR

**Expected:** PL missing never by itself blocks either commercial output; only affected collection requirement remains open.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T141. Mixed supplier packaging preserves unrepresentable fact

**Requirements:** R41

**Owner slices:** S05

**Document classes:** C04

**BRS rules:** BR-WGT-005

**Given:** Supplier PL mixes Gaylords with and without pallets, and mixed boxes without an admitted box tare

**When:** Normalize pack lines

**Expected:** Keep each package line and known rates, do not apply one total_tare scalar or set box tare zero; hold only unsupported part pending D15.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T142. Supplier scale optional and never carrier CST

**Requirements:** R41

**Owner slices:** S04; S08

**Document classes:** C05; C08

**BRS rules:** BR-WGT-005

**Given:** Supplier-arranged offsite scale ticket arrives, generic SCALE tag, no carrier ticket

**When:** Classify and check missing documents

**Expected:** Optional supplier evidence may support validated supplier_weight, carrier CST remains missing and tracked, buyer AR independent.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T143. Per-unit weight totals are per-load

**Requirements:** R41

**Owner slices:** S05

**Document classes:** C04

**BRS rules:** BR-WGT-005

**Given:** Two distinct products and loads with per-unit weights and package counts but no combined allocation for third load

**When:** Aggregate evidence by line/load

**Expected:** Only line-matched totals become supplier_weight for correct records; never copy combined total into another transaction.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T144. Buyer report required despite optional buyer ticket

**Requirements:** R42

**Owner slices:** S05; S07

**Document classes:** C17; C18; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Buyer scale ticket says 38,000 lb; buyer Receiving Report absent

**When:** Evaluate full invoice readiness

**Expected:** buyer_weight is not accepted from optional scale ticket alone and final full-load Customer Invoice remains held, while source is retained.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T145. Buyer reported net after packaging

**Requirements:** R42

**Owner slices:** S05

**Document classes:** C17

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Accepted Receiving Report states 39,500 lb already excluding packaging

**When:** Validate and write current buyer report value

**Expected:** buyer_weight=39500 with no additional package deduction, leaving supplier_weight and scale_weight untouched.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T146. Buyer report gross plus packaging yields buyer net

**Requirements:** R42

**Owner slices:** S05

**Document classes:** C17

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Buyer reported 40,300 lb gross containing ten Gaylords and ten pallets (800 lb packaging)

**When:** Validate load and package roles

**Expected:** buyer_weight=39500, independent of supplier PL and carrier CST values.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T147. Buyer revised report after posted invoice

**Requirements:** R42

**Owner slices:** S05; S07

**Document classes:** C17; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Customer Invoice already posted for accepted buyer_weight; corrected Receiving Report changes accepted quantity

**When:** Apply correction workflow

**Expected:** Retain original report/invoice; do not overwrite posted invoice line directly; require authorized native credit/debit/corrected action.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T148. Native delivered quantity policy and UoM

**Requirements:** R42

**Owner slices:** S07

**Document classes:** C17; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Accepted buyer_weight in lb, SO line UoM and invoice-policy configuration verified

**When:** Prepare invoice using supported native route

**Expected:** Sale order line qty_delivered/qty_to_invoice semantics respected, account.move.line.quantity corresponds to converted accepted buyer net, never blind write computed qty_to_invoice.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T149. Ordered quantity remains intact

**Requirements:** R42

**Owner slices:** S07

**Document classes:** C17; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** SO ordered quantity differs from accepted buyer delivered weight

**When:** Create Customer Invoice from accepted receiving evidence

**Expected:** sale.order.line.product_uom_qty unchanged, native invoicing policy respected, invoice quantity reflects eligible received net only.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T150. Source discrepancy does not globally hold buyer invoice

**Requirements:** R42

**Owner slices:** S06; S07

**Document classes:** C17; C31; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Accepted buyer report and SO price; supplier settlement >5% disputed, missing CST

**When:** Post/send eligible buyer Customer Invoice

**Expected:** Correct buyer invoice proceeds, supplier RWN disputed only; missing carrier CST remains separate obligation.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T151. Partial buyer report line allocation

**Requirements:** R42

**Owner slices:** S05; S07

**Document classes:** C17; C32

**BRS rules:** BR-WGT-006; BR-REC-004

**Given:** Buyer report has valid quantity for only one of three load/material rows

**When:** Process partial report

**Expected:** Only supported lines/loads are eligible under approved native policy; others remain pending; do not divide total or invoice unreported loads.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T152. Carrier CST two-stage arithmetic

**Requirements:** R43

**Owner slices:** S05

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** CST gross 72,000, CST tare 32,000, valid 10 Gaylords on 10 pallets

**When:** Calculate physical and packaging stages

**Expected:** CST net=40000; packaging tare=800; net weight billed=39200; only eligible material net candidate can feed scale_weight, never gross_weight/final_weight.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T153. Carrier CST net evidence distinct from net billed

**Requirements:** R43

**Owner slices:** S05; S08

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Certified CST has gross=72000 tare=32000 and stated net=40000; packaging not known

**When:** Check carrier CST obligation and billable-net possibility

**Expected:** Certified gross/net ticket can satisfy CST obligation; C_NET_BILLED and scale_weight remain unknown pending packaging unless explicitly excluded by source; no $150 penalty for missing packaging.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T154. CST missing certification or unmatched scales

**Requirements:** R43

**Owner slices:** S04; S08

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Generic SCALE document or mismatched gross/tare vehicle/time, without valid certification

**When:** Check required CST evidence

**Expected:** Do not satisfy certified carrier CST; do not compute billable material net or set scale_weight; preserve both invalid/partial readings with reason.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T155. Legacy carrier rule must target existing CST tag

**Requirements:** R43

**Owner slices:** S02; S08

**Document classes:** C08; C05

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Current scale_ticket_rule.xml references tag_scale_ticket (SCALE), required_for_close True

**When:** Install selected correction in disposable Odoo

**Expected:** Carrier obligation uses existing CST tag and required_for_close False, buyer AR/close not blocked; suppliers SCALE docs never satisfy it.

**Required proof:** source+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T156. Native doc_type scale_ticket is role-aware

**Requirements:** R43

**Owner slices:** S04

**Document classes:** C08; C05; C18

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Native selection doc_type=scale_ticket with carrier, supplier and buyer sources

**When:** Synchronize native-to-legacy with exact issuer role

**Expected:** Verified carrier certified documents map to existing CST; supplier/buyer tickets map to SCALE, no doc_type=cst/receiving_report/packing_list.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T157. Missing packaging is not carrier CST missing

**Requirements:** R43

**Owner slices:** S08; S09

**Document classes:** C08; C33

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Valid certified CST gross and net received on time, package count unavailable

**When:** Evaluate carrier doc collection and chargeback

**Expected:** Carrier CST requirement complete without penalty; only net weight billed/scale_weight calculation needing packaging remains pending D15.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T158. Already packaging-excluded certified source

**Requirements:** R43

**Owner slices:** S05

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** CST gross/tare validated and source explicitly provides material net already excluding 800 lb packaging

**When:** Interpret source net basis

**Expected:** Accept one packaging-adjusted 39200 lb result only; do not subtract 800 again; preserve raw CST net=40000 separately.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T159. CST gross and tare cannot be written to legacy computed fields

**Requirements:** R43

**Owner slices:** S05

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** Carrier CST 72000 gross and 32000 tare with eligible net calculation

**When:** Route source facts to transaction fields

**Expected:** No direct raw values written to gross_weight, total_tare, final_weight, actual_weight or buyer_weight; only authorized net candidate may use scale_weight.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T160. Same-load CST and multi-load PDF

**Requirements:** R43

**Owner slices:** S04; S05

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** One CST PDF contains independently identified load A and load B readings plus a combined summary

**When:** Bind observations by page/load

**Expected:** Compute each supported per-load CST net separately, no copying combined number; independent legacy rows share original attachment.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T161. CST scale ticket tag not certification proof

**Requirements:** R43

**Owner slices:** S04; S08

**Document classes:** C08

**BRS rules:** BR-WGT-007; BR-CAR-004

**Given:** A native/legacy CST-tagged file with no verifiable issuer certification

**When:** Evaluate carrier required document completeness

**Expected:** Tags alone never establish certification or valid gross/net; requirement remains incomplete with specific review reason.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T162. Supplier RWN below/equal strict 5%

**Requirements:** R44

**Owner slices:** S06

**Document classes:** C04; C17; C31

**BRS rules:** BR-SET-006

**Given:** Buyer report accepted and supplier_weight differs exactly 5% under approved denominator

**When:** Select RWN quantity

**Expected:** RWN keeps accepted supplier_weight and supplier PO unit price/authorized deductions at exactly 5% under admitted denominator; certified CST is reference-only and does not override.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T163. Unreviewed >5% direct discrepancy always holds supplier RWN

**Requirements:** R44

**Owner slices:** S06

**Document classes:** C04; C17; C31; C08

**BRS rules:** BR-SET-006

**Given:** Difference above 5%, certified CST material net computed and all other D13 predicates unresolved

**When:** Prepare RWN

**Expected:** Hold the disputed supplier RWN until a documented human decision, even with valid source CST evidence; scale_weight remains independent reference and buyer invoice may proceed.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T164. Qualified certified CST reference cannot authorize supplier RWN without human decision

**Requirements:** R44

**Owner slices:** S06

**Document classes:** C08; C17; C31

**BRS rules:** BR-SET-006; BR-WGT-010

**Given:** Supplier material net 40000, buyer material net 37600, certified CST reference 37800, detailed ticket qualification accepted; no recorded human settlement decision

**When:** Prepare supplier RWN/AP from existing records without a human-approved correction

**Expected:** Supplier RWN remains held; scale_weight 37800 is reference and cannot override supplier_weight 40000 or buyer_weight 37600 merely because certified. After separately authorized human correction, only approved commercial settlement terms may be used with exact decision provenance, never automatic scale substitution.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T165. Unknown supplier weight does not become buyer weight

**Requirements:** R44

**Owner slices:** S06; S07

**Document classes:** C17; C31; C32

**BRS rules:** BR-SET-006

**Given:** Buyer Receiving Report accepted but supplier_weight absent and D14 unapproved

**When:** Prepare independent actions

**Expected:** Hold supplier RWN only for unresolved quantity; create eligible Customer Invoice from buyer_weight and native sale line.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T166. Supplier RWN financial contents remain supplier-side

**Requirements:** R44

**Owner slices:** S06

**Document classes:** C31

**BRS rules:** BR-SET-006

**Given:** Valid supplier settlement basis, supplier PO price and approved light-weight/other chargeback

**When:** Render/send supplier RWN

**Expected:** Shows supplier quantity, agreed supplier price, signed deductions, net due and exact revision; no buyer identity/SO price or raw buyer Receiving Report.

**Required proof:** ORM+mail

**Execution:** NOT_RUN

**Receipt:** None.

### T167. Supplier vendor bill not duplicated by RWN

**Requirements:** R44

**Owner slices:** S06; S10

**Document classes:** C31; C01

**BRS rules:** BR-SET-006

**Given:** Existing supplier Vendor Bill and RWN for same transaction with approved payable basis

**When:** Run RWN generation and native bill matching

**Expected:** RWN is communication only; exactly one economic supplier Vendor Bill through native Odoo, no fake payment or duplicate AP postings.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T168. Legacy selected weight cannot become financial authority

**Requirements:** R45

**Owner slices:** S01; S02

**Document classes:** None

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** scale_weight=39000 buyer_weight=39500 supplier_weight=40000 with existing final_weight consumers

**When:** Apply weight semantics compatibility update

**Expected:** No source winner is used for supplier RWN or buyer AR; legacy fields remain source-compatible or are explicitly migrated with tests.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T169. Light-weight deduction uses approved supplier-side source

**Requirements:** R45

**Owner slices:** S06; S10

**Document classes:** C31

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Minimum net contractual 40000; buyer only 39500; supplier 40000; legacy final_weight may prefer buyer/scale

**When:** Calculate supplier light-weight deduction

**Expected:** No deduction from buyer or arbitrary final_weight; only approved supplier settlement basis and contract minimum/rate determine result.

**Required proof:** ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T170. Commission dashboard follows corrected weight meaning

**Requirements:** R45

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Legacy commission SQL view reads final_weight and weight_source

**When:** Validate dashboard after transaction weight change

**Expected:** No displayed Net Wt sourced from retired universal winner without explicit documented compatibility/consumer migration; preserve existing commission amounts.

**Required proof:** ORM+SQL

**Execution:** NOT_RUN

**Receipt:** None.

### T171. Compliance does not auto-post unrelated native bills

**Requirements:** R45

**Owner slices:** S02; S07

**Document classes:** C08; C32

**BRS rules:** BR-FLD-004; BR-WGT-008

**Given:** Accepted buyer report but missing CST and unrelated draft supplier bills

**When:** Post authorized customer invoice after document intake

**Expected:** Only authorized customer action posts; missing CST does not block AR; compliance flip does not auto-post unrelated Vendor Bills.

**Required proof:** ORM+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T172. Original and normalized weight evidence survives replay

**Requirements:** R46

**Owner slices:** S03; S05

**Document classes:** C04; C08; C17

**BRS rules:** BR-EVD-005; BR-EVD-006

**Given:** One document of each source role, raw quantities/units/basis and per-line revision

**When:** Extract, accept, replay, then re-extract with changed AI model

**Expected:** Source+current+prior accepted values and fact identities persist; zero writes on identical replay, correction only through authorized revision.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T173. No hidden JSON or new field by convenience

**Requirements:** R46

**Owner slices:** S03; S05

**Document classes:** C08

**BRS rules:** BR-EVD-005; BR-EVD-006

**Given:** A producer cannot persist per-line CST tare and packaging facts in inspected existing fields

**When:** Choose persistence for typed source evidence

**Expected:** D08 explicitly blocks unsupported source fact application until approved minimal native/representation seam proven; no new column/model created by agent.

**Required proof:** design+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T174. Supplier and carrier BOL copies preserve provenance

**Requirements:** R46

**Owner slices:** S04

**Document classes:** C07

**BRS rules:** BR-EVD-005; BR-EVD-006

**Given:** Same BOL submitted by supplier and carrier using different messages

**When:** Classify and link source deliveries

**Expected:** One underlying BOL interpretation, distinct source receipts and no duplicate transactional BOL/bill or deleted historical message.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T175. Corrected source affects only correct load/line

**Requirements:** R46

**Owner slices:** S04; S05

**Document classes:** C08; C17

**BRS rules:** BR-EVD-005; BR-EVD-006

**Given:** Multi-load accepted buyer report updated only for load B and matching CST corrected for load A

**When:** Process targeted corrections

**Expected:** Old/new evidence and affected load/line linked; no changes to unrelated transaction weights, invoice or penalty records.

**Required proof:** ORM+replay

**Execution:** NOT_RUN

**Receipt:** None.

### T176. No financial output from ambiguous data

**Requirements:** R46

**Owner slices:** S05; S06; S07

**Document classes:** C08; C17

**BRS rules:** BR-EVD-005; BR-EVD-006

**Given:** Conflicting PDF source line references, partly readable figures and an unknown unit

**When:** Run deterministic action gates

**Expected:** Uncertain candidate facts retained with explicit owner; no guessed weight, RWN or invoice amount, independently valid other load continues.

**Required proof:** ORM+security

**Execution:** NOT_RUN

**Receipt:** None.

### T177. Installed Odoo field registry matches BRS contract

**Requirements:** R47

**Owner slices:** S00; S02

**Document classes:** None

**BRS rules:** BR-FLD-004; BR-REC-004

**Given:** Disposable Enterprise Odoo 19 registry with required custom add-ons loaded

**When:** Inspect ir.model.fields and composed views at exact code SHA

**Expected:** Real technical names/types/selection values/field owners match verified expected fields; unsupported doc_type and invented alias fields fail. Skipped inspection is not PASS.

**Required proof:** hosted Odoo

**Execution:** NOT_RUN

**Receipt:** None.

### T178. Native AR/AP invoicing integration proof

**Requirements:** R47

**Owner slices:** S07; S10

**Document classes:** C32; C01

**BRS rules:** BR-FLD-004; BR-REC-004

**Given:** Odoo 19 Sales/Purchase/Accounting installed at selected SHA and realistic standard application modes

**When:** Run buyer and supplier flow through native order/invoice actions

**Expected:** Computed delivered/to-invoice fields remain native and actual move lines reflect accepted source weights with no duplicate bill or unauthorized post.

**Required proof:** hosted Odoo+accounting

**Execution:** NOT_RUN

**Receipt:** None.

### T179. CI field/role/drift negative witnesses fail

**Requirements:** R47

**Owner slices:** S02

**Document classes:** None

**BRS rules:** BR-FLD-004; BR-REC-004

**Given:** Repo CI field validator and semantic checks on exact BRS revision with known-bad fixtures

**When:** Run checker with renamed buyer_weight, invented shipper_weight, wrong CST tag, customer invoice scale basis

**Expected:** All altered witnesses fail a required check while a known-good real fixture passes, with exact-head receipt and non-skipped Odoo tests.

**Required proof:** CI+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T180. Machine contract graph and derived views consistent

**Requirements:** R47

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-FLD-004; BR-REC-004

**Given:** Source-bound field flow registry, route rules, financial consumers and acceptance links

**When:** Validate archive and all derived views/checksum lineage

**Expected:** No unowned field, wrong source role, false-approval, coverage gap or stale BRS binding; artifact structural PASS never claims live/Odoo PASS.

**Required proof:** artifact+CI

**Execution:** NOT_RUN

**Receipt:** None.

### T181. Five weight measurement vocabulary definitions

**Requirements:** R48

**Owner slices:** S05; S12

**Document classes:** None

**BRS rules:** BR-VOC-001; BR-WGT-002

**Given:** Document actual, loaded CST gross/tare, packaging counts and independently verified material-only report

**When:** Normalize all five stages in source and BRS-derived data without new ORM fields

**Expected:** Each stage has exactly the operator-accepted meaning; CST load net and material net not conflated; accepted commercial values are source-specific.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T182. CST reference display does not authorize settlement

**Requirements:** R48

**Owner slices:** S05; S12

**Document classes:** C31

**BRS rules:** BR-WGT-009; BR-WGT-001

**Given:** CST certified material net 39200, supplier accepted 40000, buyer accepted 39000

**When:** Render preferred summary and calculate outgoing RWN and buyer invoice

**Expected:** Screen chooses certified CST 39200 with source label, but RWN and invoice remain on their own approved commercial quantities absent human correction.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T183. Preferred summary fallback hierarchy

**Requirements:** R48

**Owner slices:** S05; S12

**Document classes:** None

**BRS rules:** BR-WGT-009; BR-FLD-002

**Given:** CST uncertified or unavailable, buyer and supplier accepted quantities vary by case

**When:** Render preferred material weight through decreasing evidence availability

**Expected:** Uncertified SCALE cannot occupy Certified display priority; select buyer then supplier then No accepted weight, without writing final_weight.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T184. Direct spread defeats two close-to-CST comparisons

**Requirements:** R49

**Owner slices:** S05; S06; S12

**Document classes:** C31

**BRS rules:** BR-WGT-010; BR-SET-002

**Given:** Supplier 38400, certified CST material net 40000, buyer 41600

**When:** Apply all three independent comparisons and threshold reconciliation

**Expected:** Each source is 4 percent from CST, but direct commercial spread 3200 lb exceeds 5 percent under both current max- and CST-based reference denominators; mandatory HUMAN_REVIEW, no human-reviewed scale reference payable.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T185. Exactly five percent is not greater

**Requirements:** R49

**Owner slices:** S05; S06

**Document classes:** C31

**BRS rules:** BR-WGT-010; BR-SET-002

**Given:** Supplier accepted 40000 and buyer accepted 38000, reference CST available

**When:** Evaluate mandatory threshold using approved denominator once D13 approved

**Expected:** With current max-based diagnostic exactly 5 percent does not trigger mandatory over-five review; denominator cannot be implicitly inferred as BRS authority.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T186. Above-five discrepancy holds supplier RWN only

**Requirements:** R49

**Owner slices:** S06; S12

**Document classes:** C31

**BRS rules:** BR-SET-003; BR-WGT-010

**Given:** Accepted supplier 40000, buyer 37000, scale 39500, current code diagnostic spread 7.5 percent

**When:** Attempt auto-send RWN and independently create buyer invoice

**Expected:** Supplier RWN disputed settlement is held until recorded human decision, no source weight rewritten; valid buyer invoice remains eligible on buyer_weight.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T187. Human reconciliation decision provenance

**Requirements:** R49

**Owner slices:** S06; S10

**Document classes:** C31

**BRS rules:** BR-SET-003; BR-WGT-010

**Given:** Disputed direct commercial spread exceeding 5 percent, valid scale reference and named reviewer

**When:** Authorize supplier settlement after reviewer accepts documentary correction

**Expected:** Approved supplier adjustment records actor, reason, applicable contract and source revision; scale measurement alone cannot directly authorize supplier AP or RWN.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T188. Underweight exact inclusive two-ton shortfall

**Requirements:** R50

**Owner slices:** S10; S12

**Document classes:** C01

**BRS rules:** BR-UND-001; BR-UND-002

**Given:** Applicable 53-foot contract minimum 40000 lb, accepted material net 38000 lb, base rate $0.01/lb per 2000 lb shortfall

**When:** Compute deterministic obligation-scoped LWD amount and test threshold boundary

**Expected:** Shortfall 2000 lb inclusive; effective rate $0.010000/lb charged on ACTUAL 38000 material-net pounds yields exactly $380.00, not $20 shortfall multiplication, not $200 from superseded historical examples. No automatic financial posting without D16 contract/approval.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T189. Underweight 38001 boundary

**Requirements:** R50

**Owner slices:** S10; S12

**Document classes:** C01

**BRS rules:** BR-UND-001; BR-UND-002

**Given:** Applicable 53-foot contract minimum 40000 lb, accepted material net 38001 lb, base rate 0.01

**When:** Evaluate the 1999 lb below-trigger boundary

**Expected:** Shortfall 1999 lb is below inclusive 2000 threshold; effective LWD rate $0/lb, qualifying amount $0.00 despite a nominal base rate, and no automatic financial adjustment. No rounding of threshold.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T190. Underweight 36000 full shortfall

**Requirements:** R50

**Owner slices:** S10; S12

**Document classes:** C01

**BRS rules:** BR-UND-001; BR-UND-002

**Given:** Applicable 53-foot contract minimum 40000 lb, accepted material net 36000 lb, base rate $0.01/lb per 2000 shortfall

**When:** Compute continuous proration and apply effective rate to actual material net

**Expected:** Shortfall 4000 lb = 2 short tons, effective rate $0.020000/lb, total = 36000 x 0.02 = $720.00; reject $40 shortfall formula, old $400/$760 examples and $720 automatic posting without applicable contract.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T191. Exactly full weight no deduction

**Requirements:** R50

**Owner slices:** S10

**Document classes:** C01

**BRS rules:** BR-UND-002; BR-UND-005

**Given:** Applicable 53-foot minimum 40000 lb, material net 40000 lb

**When:** Calculate shortfall and monetary result

**Expected:** Qualifying deduction weight zero and total $0; no Boolean inferred from supplier purchase cost.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T192. Contractual explicit zero rate honored

**Requirements:** R50

**Owner slices:** S10

**Document classes:** C01

**BRS rules:** BR-UND-002; BR-UND-004

**Given:** Applicable contract and verified minimum, material net 38000, base rate explicitly zero

**When:** Run monetary calculation with stored configured zero

**Expected:** A verified explicit zero base rate remains zero; shortfall is eligible physically but effective rate 0 and total 0.00; no 0.01 fallback via Python or, no posting without independently evidenced financial authorization.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T193. Unknown applicable contract or packaging does not fabricate penalty

**Requirements:** R50

**Owner slices:** S05; S09

**Document classes:** None

**BRS rules:** BR-UND-003; BR-UND-006; BR-VOC-001

**Given:** A below-minimum load with unverified contract or disputed packaging source and a non-53-foot trailer variant

**When:** Evaluate calculator eligibility and document completeness separately

**Expected:** No invented charge, cash/claim effect or zero packaging assumption if agreement, applicable trailer or accepted material-net input is missing. Calculation can be evaluated only against separately established actual contractual scope; independent carrier CST completeness still stands.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T194. Buyer underweight liability is not supplier recovery

**Requirements:** R51

**Owner slices:** S07; S10; S12

**Document classes:** C22

**BRS rules:** BR-UND-003; BR-UND-007

**Given:** Buyer underweight obligation separately documented and a contractual $380.00 LWD calculation for 38000 material net, supplier recovery agreement not evidenced

**When:** Compute once and pass to native accounting/claims owners

**Expected:** Buyer-side $380 amount may be recognized only under independently evidenced agreement and native accounting approval; supplier recovery remains unasserted. No automatic $380 vendor recovery or double-counted margin.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T195. Separate supplier recovery under independent approved contract

**Requirements:** R51

**Owner slices:** S06; S10

**Document classes:** C22

**BRS rules:** BR-UND-003; BR-UND-007

**Given:** Buyer liability and supplier recovery separately documented for $380.00 each under their own controlling agreements and an accepted 38000 material-net basis

**When:** Calculate once per contractual obligation and reconcile financial records

**Expected:** Buyer-side $380 and supplier-side $380 remain two distinct contract/evidence/accounting obligations, not an automatic offset or mirrored posting. The same pure formula may calculate both when terms coincide but does not establish either legal claim.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T196. CST $150 penalty remains independent

**Requirements:** R51

**Owner slices:** S09; S10

**Document classes:** C33

**BRS rules:** BR-UND-007; BR-CAR-003

**Given:** One late carrier CST and one accepted 53-foot underweight contractual obligation

**When:** Evaluate document penalty and contractual shortfall separately

**Expected:** Carrier missing-CST documentation penalty stays a separate $150 due-dependent claim; LWD amount is continuously prorated on material net, not a flat missing-CST $/lb charge. No duplicate recovery or auto-posting.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T197. Old field and method consumer-safe migration

**Requirements:** R52

**Owner slices:** S02; S05; S10; S12

**Document classes:** None

**BRS rules:** BR-UND-004; BR-UND-005; BR-FLD-002

**Given:** Legacy ORM final_weight/gross_weight/weight_source, deduction, Boolean, XML view and commission dashboard consumers exist

**When:** Migrate exact installed consumers and update tests on disposable Enterprise database

**Expected:** No final_weight or old Boolean settlement authority survives; new compute method _compute_light_weight_deduction_total available only after explicit proven Odoo migration; historical data and views still load.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T198. No invented ORM shortfall field

**Requirements:** R52

**Owner slices:** S05; S12

**Document classes:** None

**BRS rules:** BR-UND-004

**Given:** Accepted light_weight_deduction_weight calculation name but field absent in pinned source

**When:** Plan and execute only authorized computing seam

**Expected:** Shortfall pounds stay pure calculation output unless separate D08 proof/approval; no unsupported light_weight_deduction_weight Odoo field, no duplicate total field added by accident.

**Required proof:** unit+ORM+CI

**Execution:** NOT_RUN

**Receipt:** None.

### T199. Dead-freight Boolean logic rejected

**Requirements:** R52

**Owner slices:** S10; S12

**Document classes:** None

**BRS rules:** BR-UND-005

**Given:** Old deduced Boolean compares deduction total against purchase_cost_total

**When:** Check new business contract and code after bounded migration

**Expected:** No purchase cost comparison authorizes liability, dead_freight_chargeback remains retired; preserve any old stored history through audited migration without substituting a new Boolean.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T200. Scoped BRS ownership and unknowns preserved

**Requirements:** R52

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-004; BR-FLD-002

**Given:** Seven indexed numbered BRS concern files, 46 stable BR-* IDs, standalone index/traceability validator and installed field source declarations

**When:** Validate one rule owner each, references, source digests, field identities and BRS revisions

**Expected:** Exactly one normative numbered BRS owner per BR-* ID, ordered BRS-001..007 index and verifiable hashes, no duplicate BRS text or active old unnumbered authority, direct linked requirement/test references; legacy automatic scale substitution and floor-tier LWD assertions are rejected. Odoo runtime cases remain NOT_RUN.

**Required proof:** pure+ORM

**Execution:** NOT_RUN

**Receipt:** None.

### T201. BRS T201 conformance

**Requirements:** R53

**Owner slices:** S00

**Document classes:** None

**BRS rules:** BR-DOC-001; BR-UND-002

**Given:** Every rule has one numbered file and stable BR ID

**When:** Load index and every BRS file

**Expected:** Seven BRS-001..007 files are sequential, each owns disjoint explicit BR definitions, and all 46 existing rule IDs are preserved exactly once.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T202. BRS T202 conformance

**Requirements:** R53

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-EVD-002

**Given:** Active BRS file altered without index digest change

**When:** Run standalone package BRS check

**Expected:** Mutation is rejected; SHA/index/campaign references cannot silently disagree.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T203. BRS T203 conformance

**Requirements:** R53

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-EVD-002

**Given:** Rule transferred to a second BRS file or orphaned

**When:** Run owner-index integrity check

**Expected:** Duplicate/missing rule rejected; BRS numbering and registry disallow a second normative owner.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T204. BRS T204 conformance

**Requirements:** R53

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** Underweight business meaning changes but numeric fixtures/tests remain stale

**When:** Run BRS fixture arithmetic and cross-acceptance validator

**Expected:** Fixed shortfall-times-rate, completed 500-lb tiers, and early rounding are rejected without a new approved BRS revision.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T205. BRS T205 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-001; BR-UND-002

**Given:** 38001 lb material net, 40000 min, applicable 53ft contract

**When:** Compute LWD amount

**Expected:** Shortfall 1999 below inclusive threshold; total exactly $0.00, no positive LWD rate.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T206. BRS T206 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** 38000 lb material net and active contractual $0.01 base per 2000 lb short

**When:** Compute effective rate and LWD total

**Expected:** Exactly 2000 lb short triggers $0.010000/lb on 38000 lb, total $380.00.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T207. BRS T207 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** 37750 lb material net, 2250 lb short, partial 500 increment

**When:** Compute effective rate and final cents

**Expected:** Effective rate $0.011250/lb, total $424.69; old $0.0100/lb completed-tier output $377.50 must fail.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T208. BRS T208 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** 37501 lb material net, 2499 lb short

**When:** Compute fractional rate without early rounding

**Expected:** Effective rate $0.012495/lb, final monetary amount $468.57 (half-up only at end), not $375.01/other tier result.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T209. BRS T209 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** 37500 lb material net, 2500 lb short

**When:** Compute proration at full 500 increment

**Expected:** Effective rate $0.012500/lb and total $468.75; floor and continuous agree exactly at tier.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T210. BRS T210 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** 36000 lb material net, 4000 lb short = 2 short tons

**When:** Compute rate on entire actual material net

**Expected:** Effective rate $0.020000/lb times 36000 lb = $720.00; reject legacy shortfall x rate = $40 and historical $760.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T211. BRS T211 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-002; BR-UND-006

**Given:** Applicable obligation with explicit base rate 0 and material net 38000

**When:** Compute without using rate or 0.01 fallback

**Expected:** Effective rate 0 and monetary amount $0.00; must not substitute 0.01 or imply liability.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T212. BRS T212 conformance

**Requirements:** R54

**Owner slices:** S10

**Document classes:** None

**BRS rules:** BR-UND-003; BR-UND-006

**Given:** Missing contractual applicability despite known physical material net 36000

**When:** Evaluate underweight financial obligation

**Expected:** No automatic charge or zero-value waiver created; calculation diagnostics may run but liability and posting remain held pending contract.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T213. BRS T213 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** Original 2250 lb short witness

**When:** Run floor-500 known-bad rate mutation

**Expected:** A floor-to-completed-500 rate of .01 produces $377.50 and MUST be rejected against accepted $424.69.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T214. BRS T214 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** Rate is artificially rounded before final money to .01 or .0125

**When:** Run premature-rounding negative witness on 2250 short

**Expected:** Premature rate rounding yields a different amount and MUST be rejected; preserve fractional $/lb precision.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T215. BRS T215 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-002

**Given:** Actual 38000 material net and 2000 shortfall

**When:** Try shortfall-times-rate mutant

**Expected:** Mutant returns $20.00 instead of $380.00; reject the old formula.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T216. BRS T216 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-003; BR-UND-006

**Given:** Buyer has qualifying underweight charge and supplier terms remain unknown

**When:** Assess and attribute independently

**Expected:** Shared calculation does not auto-create supplier recovery or assign liability; buyer posting only via native independently proven contract.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T217. BRS T217 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-UND-003; BR-UND-007

**Given:** Two distinct verified buyer and supplier contractual obligations

**When:** Compute and apply financial effects

**Expected:** One pure calculator may be reused, but two native financial records need separate provenance; no duplicated margin or mirrored auto-claim.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T218. BRS T218 conformance

**Requirements:** R54

**Owner slices:** S12

**Document classes:** None

**BRS rules:** BR-FLD-002; BR-UND-004; BR-UND-005

**Given:** Legacy final_weight and dead_freight Boolean remain in installed ORM

**When:** Check bounded migration and projected BRS semantics

**Expected:** No obsolete universal billing quantity or old purchase-cost Boolean controls underweight; planned ORM name changes not claimed installed before migration.

**Required proof:** ISOLATED_DECIMAL_TEST_OR_BRS_CONTRACT_CI_DEPENDING_ON_CASE

**Execution:** NOT_RUN

**Receipt:** None.

### T219. Buyer report missing is not invented RWN policy

**Requirements:** R55

**Owner slices:** S05; S06; S12

**Document classes:** C17; C31; C32

**BRS rules:** BR-SET-004; BR-SET-006; BR-REC-001

**Given:** Supplier source material net and authorized PO price exist, but buyer Receiving Report has not arrived

**When:** Prepare supplier RWN draft and evaluate automatic sending eligibility

**Expected:** Draft retained with accepted supplier weight, purchase price and source provenance. Automatic send remains scoped HOLD D18; do not assert buyer Receiving Report is a universally mandatory RWN document. Customer Invoice remains blocked until buyer report.

**Required proof:** TARGET_ODOO_DISPOSABLE_RUNTIME_OR_CI_CONTRACT_AS_SPECIFIED

**Execution:** NOT_RUN

**Receipt:** None.

### T220. Document net cannot masquerade as material net

**Requirements:** R55

**Owner slices:** S05; S12

**Document classes:** C04; C17

**BRS rules:** BR-VOC-001; BR-WGT-002; BR-WGT-005; BR-WGT-006

**Given:** Supplier PL and buyer Receiving Report each contain number labeled net, but neither proves whether packaging is included

**When:** Extract observations and consider writing supplier_weight/buyer_weight

**Expected:** Record raw Document measurement with source and basis UNKNOWN; do not write material-net commercial quantity or subtract packaging automatically until independently proven. Qualified CST compliance remains independently evaluable.

**Required proof:** TARGET_ODOO_DISPOSABLE_RUNTIME_OR_CI_CONTRACT_AS_SPECIFIED

**Execution:** NOT_RUN

**Receipt:** None.

### T221. Evidence-stage vocabulary must not invent ORM fields

**Requirements:** R55

**Owner slices:** S02; S05; S12

**Document classes:** C04; C17

**BRS rules:** BR-FLD-001; BR-FLD-004; BR-VOC-001

**Given:** Source-fact concept names S_DOCUMENT_NET and B_DOCUMENT_NET exist alongside registered scalar supplier_weight and buyer_weight

**When:** Run BRS and field-routing conformance and inspect actual installed Odoo field registry

**Expected:** Source observations remain evidence-only and are not Odoo fields; accepted material net writes are separately authorized into existing exact technical fields. No new source-side gross/net columns or dotted supplier.weight fields.

**Required proof:** TARGET_ODOO_DISPOSABLE_RUNTIME_OR_CI_CONTRACT_AS_SPECIFIED

**Execution:** NOT_RUN

**Receipt:** None.

### T222. BRS admission index binds actual code and test owner

**Requirements:** R55

**Owner slices:** S02; S12

**Document classes:** None

**BRS rules:** BR-EVD-002; BR-FLD-002; BR-UND-002

**Given:** Seven numbered BRSs and ADR-025 are proposed to target Staging plus target CI Gate existing static-checks

**When:** Simulate registration in isolated checkout and inspect planned touched files

**Expected:** No duplicate BRS owner, missing docs link, stale BRS digest, missing static-checks invocation, fake test PASS, false Stage HEAD binding or duplicate CI workflow is accepted. Registered test IDs remain NOT_RUN until actual non-skipped Odoo receipts.

**Required proof:** TARGET_ODOO_DISPOSABLE_RUNTIME_OR_CI_CONTRACT_AS_SPECIFIED

**Execution:** NOT_RUN

**Receipt:** None.

### T223. RWN discrepancy discovered after later buyer report

**Requirements:** R55

**Owner slices:** S06; S12

**Document classes:** C17; C31

**BRS rules:** BR-SET-002; BR-SET-003; BR-SET-006; BR-EVD-004

**Given:** An individually authorized supplier RWN was sent before buyer Receiving Report under future D18 approval, then accepted buyer weight reveals >5 percent spread

**When:** Reconcile supplier/buyer sources and handle corrected RWN

**Expected:** Retain original sent notice and source facts; trigger documented human review under D13 and controlled correction, never silently overwrite supplier source or send a second notice. Buyer Invoice uses independently valid buyer report.

**Required proof:** TARGET_ODOO_DISPOSABLE_RUNTIME_OR_CI_CONTRACT_AS_SPECIFIED

**Execution:** NOT_RUN

**Receipt:** None.

## Requirement-to-acceptance trace

| Requirement | BRS IDs | Owner slices | Acceptance IDs |
|---|---|---|---|
| R01: Use the supplied plan as the opening slice; preserve original bytes and settled work; later work remains coherent bounded successors. |  | S00; S01 | T001; T002 |
| R02: Native Odoo/PlasticOS models remain authoritative; no parallel DMS/ERP; no new schema without explicit approved representation gap. | BR-FLD-001; BR-EVD-002 | S00; S02; S04 | T047 |
| R03: Capture all in-scope email attachments and body-only messages; preserve original message/source, prevent silent loss and unsafe duplicate routing. | BR-EVD-001 | S03 | T005; T011; T012; T015; T021; T022; T025; T027; T065; T072; T091 |
| R04: AI extracts typed source-bound facts from content, not just filename; deterministic validation alone authorizes writes. | BR-EVD-002 | S03; S04 | T012; T022; T023; T024; T025; T026 |
| R05: Each logical document and each cited transaction is independently matched; reference/sender/company conflicts are exceptions, not majority votes. | BR-DOC-002; BR-EVD-001 | S01; S04 | T003; T004; T005; T006; T007; T008; T009; T010; T011; T014; T028 |
| R06: One original can support several transaction evidence rows; no invented load cardinality or bill duplication. | BR-DOC-002; BR-EVD-001 | S01; S04; S10 | T004; T012; T013; T020; T060 |
| R07: Preserve corrected/superseded source history, per-field provenance, safe synchronization, retries and concurrent idempotency. | BR-EVD-004 | S02; S04 | T015; T016; T017; T018; T019; T020; T052; T058; T093 |
| R08: An accepted inbound buyer Receiving Report (not RWN or optional scale) is mandatory before FULL customer invoicing. Its accepted material net supports direct supplier/buyer discrepancy reconciliation when present; supplier RWN sequencing without it remains unresolved D18. | BR-DOC-001; BR-REC-001 | S05; S06; S07 | T029; T030; T031; T045; T097; T100; T101 |
| R09: Supplier Packing List (PL) remains tracked/collected where applicable but is nonblocking. Supplier and buyer Scale Tickets are optional. Missing supplier_weight does not block Customer Invoicing; it holds only the supplier RWN unless D14 supplies an approved alternative. | BR-SET-004; BR-REC-002; BR-DOC-001 | S05; S08 | T032; T033; T051; T081; T096; T097 |
| R10: Accepted buyer-received net populates existing buyer_weight and native Customer Invoice quantity; preserve supplier_weight/scale_weight independently and do not create a universal Final Weight authority. | BR-WGT-001; BR-REC-002; BR-FLD-002 | S05; S07; S10 | T029; T032; T042; T043; T044; T054; T097; T101; T127 |
| R11: Extract seal, trailer, shipping references, dates and relevant other facts into verified existing authoritative load/transaction fields. | BR-FLD-003; BR-EVD-002 | S05 | T007; T029; T046; T047; T048; T097 |
| R12: Preserve CST gross, CST tare and CST net as distinct from packaging tare and net weight billed. Use approved 40 lb Gaylord, 40 lb pallet and 80 lb combined packaging; deduct only packaging not already excluded. CST gross/net evidence remains required per load. | BR-CAR-001; BR-CST-001; BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004 | S03; S05; S08 | T013; T028; T035; T036; T037; T038; T039; T040; T041; T042; T045; T068; T071; T122; T123; T126; T127; T128 |
| R13: Carrier certified CST gross/net documentary requirement remains mandatory but nonblocking for buyer invoicing, routine RWN and close. >5% direct supplier/buyer discrepancy requires human review; scale evidence is only corroborating reference, never automatic supplier settlement. | BR-CAR-001; BR-CAR-002; BR-CST-001 | S05; S08 | T034; T096; T097; T126 |
| R14: Missing/incomplete carrier scale evidence produces a USD 150 carrier chargeback when the bound timing/applicability rule is met, never a supplier or buyer charge. | BR-CAR-003 | S09 | T067; T068; T069; T070; T071; T072; T077; T078; T097; T126 |
| R15: A carrier penalty has one economic effect, replay-safe accounting, disclosed disputes/corrections and no fictional cash settlement. | BR-CAR-003; BR-SET-005 | S09; S10 | T069; T070; T073; T074; T075; T076; T082 |
| R16: Send supplier Received Weight Notice containing accepted supplier settlement weight (normally supplier_weight), supplier purchase price and independently authorized deductions/penalties, with double-blind confidentiality. On strictly >5% direct commercial discrepancy HOLD disputed supplier notice for human-reviewed contract/evidence decision; scale_weight is reference only. | BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005 | S06 | T049; T050; T051; T052; T078; T090; T097 |
| R17: Create/reconcile/post/send a native Customer Invoice under commercial/accounting authority, idempotently; supplier notice transport failure is not an AR prerequisite. | BR-REC-002; BR-REC-003 | S07 | T053; T054; T055; T058; T059; T083; T096; T097 |
| R18: Use native AP for supplier/freight bills and credits on independently accepted supplier commercial material net and purchase/freight terms. A >5% direct supplier/buyer discrepancy requires recorded human reconciliation; no automatic scale_weight substitute. Validate price/tax/company/currency/claims and never double a liability/recovery. | BR-WGT-001; BR-SET-003; BR-SET-005 | S10 | T060; T075; T079; T080; T081; T082; T084 |
| R19: Track receipt, validation, completeness and action eligibility separately for each supplier, buyer and carrier obligation. | BR-EVD-003 | S04; S08 | T019; T035; T061; T066; T097; T099 |
| R20: Automate party-specific missing-document follow-up, daily email/SMS where authorized, correct manager activities and no duplicate internal escalation noise. | BR-EVD-003 | S08 | T062; T063; T064; T065; T090 |
| R21: Expose existing-model transaction/document review views with party checklists, source evidence, action reasons and assigned exception resolution. | BR-EVD-003 | S08 | T005; T061; T064 |
| R22: Enforce ACL/company/facility/source identity, prompt-injection resistance, protected verification and attachment privacy across all entry points. | BR-EVD-002; BR-EVD-004 | S02; S03; S04; S12 | T009; T010; T026; T027; T050; T077; T088; T092; T093 |
| R23: Document compliance recomputation never posts an unrelated/unauthorized draft; native auto-post must obey the same eligibility gate. | BR-EVD-002 | S02; S07; S10 | T056; T057; T092 |
| R24: All confirmed document classes have an automated action or specific justified exception; new/unknown forms stay captured and reviewable. | BR-DOC-001; BR-EVD-002 | S11; S12 | T085; T086; T087; T088; T089; T091; T095; T100 |
| R25: Scope tests to the slice but prove affected ORM/native interfaces, adverse cases, replay and financial outcomes in a disposable Enterprise-equivalent environment. | BR-EVD-002 | S01; S12 | T094; T098 |
| R26: Measure actual per-class straight-through performance and human touches; do not invent percentages or impose routine AI-only review. | BR-EVD-003 | S12 | T095 |
| R27: Respect existing PR 265 ownership, code revisions, module versions, publication path and separate implementation/merge/deploy/send authorization. | BR-FLD-003 | S00; S01; S12 | T002; T090; T096; T098 |
| R28: Contract/quality/remittance/onboarding evidence must not silently amend price, settlement, banking, obligations or mark money as paid. | BR-SET-005; BR-REC-003 | S10; S11 | T055; T083; T084; T085; T086; T087; T088; T089 |
| R29: Late documents and corrections retain original outputs, stop applicable reminders, and rerun only affected validation/actions. | BR-EVD-004 | S04; S05; S06; S07; S09 | T014; T018; T043; T052; T059; T076 |
| R30: Buyer Receiving Report gates full Customer Invoice; supplier PL and source-scale optionality are distinct from carrier gross/net documentation obligation; missing carrier scales do not block close and follow-up survives close. | BR-CAR-001; BR-CAR-002; BR-CST-001 | S08; S12 | T066; T099 |
| R31: ADR-025 and brs-documents are the approved bounded business-authority design; agent handoffs must bind exact BRS ID/revision and may not silently change accepted policy or invent the future brs-logistics. | BR-DOC-001; BR-FLD-003 | S00; S01; S12 | T118; T119; T120; T129 |
| R32: RWN normally uses supplier_weight and agreed supplier PO/deductions; when direct supplier/buyer material-net spread strictly >5%, HOLD supplier settlement for documented human review with scale_weight reference-only; missing approved supplier payable quantity holds RWN, not Customer Invoice. | BR-SET-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-005 | S05; S06; S10 | T049; T051; T102; T103; T104; T105; T106; T107 |
| R33: PL and Receiving Report packaging counts are handled with approved 40 lb Gaylord, 40 lb pallet and 80 lb combined packaging tare, with no second deduction from already-net weights or invented box tare. | BR-CST-002; BR-WGT-002; BR-WGT-003; BR-WGT-004 | S05; S11 | T039; T108; T109; T110; T123; T127; T128 |
| R34: Controlled document names/directions: buyer Receiving Report inbound mandatory; RWN outbound supplier; BOL duplicates supplier/carrier; supplier/buyer scales optional; carrier scales required. | BR-CAR-001; BR-CST-001; BR-DOC-001; BR-DOC-002; BR-REC-001 | S04; S05; S08; S11 | T111; T112; T113; T114; T115 |
| R35: Exact Odoo 19/PlasticOS technical fields/labels and native models govern: supplier_weight, buyer_weight, scale_weight, load seal/trailer; no shipper_weight/received_weight/net_weight synonyms and no final_weight settlement authority. | BR-CST-002; BR-FLD-001; BR-FLD-002; BR-FLD-003 | S01; S02; S05; S12 | T116; T117; T118; T119; T125; T129 |
| R36: Bind every affected slice to normative BRS clause IDs and checked tests; existing CI must reject semantic/naming drift and do real Odoo runtime proof, not merely accept structural JSON. | BR-FLD-001; BR-EVD-002 | S02; S12 | T118; T119; T120; T121; T125; T129 |
| R37: Supplier RWN and Customer Invoice remain independent. Missing supplier PL or carrier CST as a document-compliance obligation blocks neither; missing supplier payable weight or unresolved >5% direct commercial discrepancy holds disputed RWN only. Certified scale reference does not itself resolve settlement. | BR-SET-004; BR-CAR-002; BR-REC-002 | S05; S06; S07; S08 | T032; T051; T097; T103; T105; T107 |
| R38: Carrier document name CST means Certified Scale Ticket, mandatory certified source for carrier on each load; supplier and buyer scale tickets are optional and may not be certified. No invented doc_type value or alias. | BR-CST-001; BR-CST-002 | S03; S04; S08; S09 | T122; T124 |
| R39: For a carrier CST, CST gross minus CST tare equals CST net; CST net minus applicable packaging tare equals net weight billed. Retain every intermediate source value. Unknown packaging holds only the affected billed-net calculation, not otherwise valid CST document receipt. No invented field or automatic supplier_weight/buyer_weight/final_weight overwrite. | BR-CST-001; BR-CST-002 | S05; S06; S08 | T123; T124; T125; T126; T127; T128 |
| R40: Three independent source-specific weight lanes selected by authenticated role/document/load/line/basis without invented ORM fields or cross-party copying. | BR-FLD-004; BR-WGT-008 | S00; S03; S04; S05 | T130; T131; T132; T133; T134; T135; T136; T137 |
| R41: Supplier PL/BOL/optional supplier-scale gross/packaging/net can yield only validated supplier_weight, with no double packaging tare and no buyer/CST substitution. | BR-WGT-005 | S03; S04; S05; S06 | T138; T139; T140; T141; T142; T143 |
| R42: Buyer Receiving Report uniquely governs buyer_weight and native Customer Invoice line quantities; optional buyer scale alone cannot replace it. | BR-WGT-006; BR-REC-004 | S03; S04; S05; S07; S06 | T144; T145; T146; T147; T148; T149; T150; T151 |
| R43: Carrier Certified Scale Ticket uses exact CST gross, CST tare, CST net, packaging tare and net weight billed semantics and distinct required-CST versus optional SCALE taxonomy. | BR-WGT-007; BR-CAR-004 | S01; S02; S04; S05; S08; S09 | T152; T153; T154; T155; T156; T157; T158; T159; T160; T161 |
| R44: Supplier RWN and supplier Vendor Bill consume correct supplier material net or eligible strict-over-5% scale material net without changing existing source weights or bill/accounting authority. | BR-SET-006 | S05; S06; S10 | T162; T163; T164; T165; T166; T167 |
| R45: Existing legacy final_weight/gross_weight and source discrepancy computations, light-weight deductions, closing and commission dashboard consumers are closed before semantic change. | BR-FLD-004; BR-WGT-008 | S01; S02; S05; S06; S12 | T168; T169; T170; T171 |
| R46: Source-linked evidence retains typed raw/normalized values and accepted revisions with correct document cardinality and explicit no-field representation gap D08. | BR-EVD-005; BR-EVD-006 | S03; S04; S05; S12 | T172; T173; T174; T175; T176 |
| R47: Field-level tests verify real Odoo 19 registry/native Sales/Purchase/Accounting and that enforced CI rejects semantic/field name drift and skipped cases. | BR-FLD-004; BR-REC-004 | S00; S02; S07; S10; S12 | T177; T178; T179; T180 |
| R48: Canonical five measurement terms and two commercial/one reference quantity distinction; independently verified CST screen priority is display-only. | BR-VOC-001; BR-WGT-001; BR-WGT-009 | S05; S06; S07; S12 | T181; T182; T183 |
| R49: Direct supplier/buyer >5% spread triggers human reconciliation, even when each commercial weight is within 5% of CST; no automatic scale RWN/AP substitution. | BR-WGT-010; BR-SET-002; BR-SET-003 | S05; S06; S10; S12 | T184; T185; T186; T187 |
| R50: Obligation-specific 53-foot 40000-lb material-net minimum; shortfall >=2000 inclusive. Effective light-weight rate=contractual $0.01/lb base per 2000 lb shortfall, continuously prorated (partial 500 lb accepted) and charged on actual material-net pounds; final cents only. Calculator not itself contractual posting authorization. | BR-UND-001; BR-UND-002; BR-UND-006 | S05; S09; S10; S12 | T188; T189; T190; T191; T192; T193 |
| R51: Underweight buyer liabilities and supplier recoveries are independent contract-authorized native accounting applications of one shared calculation, never automatic mirror or doubled margin. | BR-UND-003; BR-UND-007 | S06; S07; S09; S10; S12 | T194; T195; T196 |
| R52: Retire old universal Final Weight and dead-freight Boolean; migrate old light_weight_deduction to proposed light_weight_deduction_total with method _compute_light_weight_deduction_total and operator-approved continuously prorated rate on material net. No new ORM field authorized. | BR-UND-004; BR-UND-005; BR-FLD-002 | S02; S05; S06; S10; S12 | T197; T198; T199; T200 |
| R53: Numbered concern-specific BRS-001..007 with a sole normative BR-* rule owner, stable identifiers, machine index with content digests, ADR-style human index and exact requirement/acceptance trace across campaign. Old unnumbered BRS paths are non-authoritative after proposed adoption. | BR-DOC-001; BR-EVD-002; BR-UND-002 | S00; S12 | T201; T202; T203; T204 |
| R54: Accepted 53-foot underweight pure calculator uses 2000 inclusive shortfall trigger, effective rate $0.01/lb per 2000 shortfall, continuous $0.0025/lb per 500 increment including partial increments, entire material-net multiplication, USD cents at final output, zero base preserved and no auto contractual posting. | BR-UND-001; BR-UND-002; BR-UND-003; BR-UND-006 | S05; S09; S10; S12 | T205; T206; T207; T208; T209; T210; T211; T212; T213; T214; T215; T216; T217; T218 |
| R55: No blanket buyer-Receiving-Report precondition is inferred for supplier RWN: buyer report gates full AR, RWN draft is supported when supplier evidence permits, auto-send before buyer report is scoped HOLD D18. Source-document net is evidence until physical material-net basis is proven; target BRS admission/CI registration cannot claim unrun Odoo tests. | BR-EVD-002; BR-EVD-004; BR-FLD-001; BR-FLD-002; BR-FLD-004; BR-REC-001; BR-SET-002; BR-SET-003; BR-SET-004; BR-SET-006; BR-UND-002; BR-VOC-001; BR-WGT-002; BR-WGT-005; BR-WGT-006 | S02; S05; S06; S12 | T219; T220; T221; T222; T223 |
