# Odoo Documents Automation Campaign
## v1.3.1 | 19 October 2026 | Working roadmap, not executed software

**Outcome:** Use AI and native Odoo to receive and read ordinary supplier, buyer and carrier documents, enter validated details on the correct transaction/load, maintain a truthful per-party document checklist, send a Received Weight Notice to the supplier, and create/post/send the Customer Invoice. Staff handle genuine exceptions, not routine transcription.

**Starting point:** The user's `document_transaction_match_3a3f9d7d.plan.md` is preserved unchanged in `source_inputs/`. It is the opening implementation slice, not a container into which this whole campaign is pasted.

**Current business authority:** `brs-documents@1.3.1` is a **non-normative routing family index**, not an extra normative BRS. Seven numbered BRS-001..007 each own a scoped concern, with all 46 stable `BR-*` rules exactly once. BRS-003 owns physical weight meaning; BRS-007 owns the underweight pure calculation and contract-scoped liability. The design remains proposed to the repo under operator-approved ADR-025. The user's latest business meaning supersedes incorrect v1 narrative, not the original preserved source plan. `brs-logistics` is deferred/not authored.

**Correct workflow:** **Receiving Report** is **inbound from buyer**, mandatory for full Customer Invoice and provides accepted `buyer_weight`. **Received Weight Notice (RWN)** is **outbound to supplier**, normally on `supplier_weight` and purchase price with approved light-weight/other deductions; `scale_weight` is a **reference only**. A direct supplier/buyer material-net discrepancy **strictly greater than 5%** requires **human review**; scale cannot automatically substitute for an accepted supplier RWN or buyer invoice quantity. Supplier PL is tracked where applicable and nonblocking; supplier/buyer Scale Tickets are optional and may be uncertified; **carrier CST (Certified Scale Ticket)** with gross and net is mandatory **per load** but documentary absence is nonblocking for buyer invoicing and ordinary notice/commercial close, with the carrier $150 penalty under approved due/terms. If supplier payable quantity is missing, the RWN holds while Customer Invoice remains eligible. Never create `shipper_weight`, `received_weight` or new universal `net_weight` technical fields; retire obsolete `final_weight`, its selected-source `gross_weight`/`weight_source`, and `dead_freight_chargeback` business meanings now; technical fields remain only until audited consumers and data migrations are safe.

**Weight stages:** Document measurement; Load net; Packaging tare; Material net; Accepted commercial weight. Exact accepted definitions belong to `BRS-003@1.0.1`. **CST calculation:** `CST gross − CST tare = CST net; CST net − packaging tare = net weight billed`. Certified carrier CST is distinct from optional supplier/buyer scales. Example: 72,000 − 32,000 = 40,000; minus 800 packaging = **39,200 lb billable material net**, never automatically `buyer_weight`/`supplier_weight`. [BR-CST-001,BR-CST-002]

**Scope:** Existing Documents automation campaign, aligned to document-specific BRS and proposed ADR-025; this delivery changes package artifacts only. No new Odoo model/module, no rule engine, no invented logistic rules. Native Odoo Documents/Accounting reused; the future `brs-logistics` is deliberately not created.

## Read in this order

| Artifact | Use |
|---|---|
| `docs/business-rules/README.md` | **Non-normative** navigation index of seven individually authoritative numbered BRS files, stable rule IDs and exact source owner references. **Read first.** |
| `docs/business-rules/BRS-003-weights-and-packaging.md` | **Canonical five-stage vocabulary, CST load-net vs material-net, source field routing, 4%/4% direct-spread review and display-only CST priority.** |
| `docs/business-rules/BRS-007-underweight-and-chargebacks.md` | **Canonical 53-ft 40,000 lb minimum, inclusive 2,000 lb trigger, accepted partial-500 continuous proration on material net, D17 RESOLVED, D16 independently contract-scoped liability and proposed method migration.** |
| `docs/adr/ADR-025-business-rules-specification-authority.md` | Complete proposed charter for what a BRS is, when agents must consume it, precedence, approval and native-first/no-drift boundaries. |
| `CAMPAIGN_SPEC.md` | Business/technical operating specification, **derived from BRS**; cannot supersede accepted BRS meaning. |
| `ROADMAP.md` | Thirteen bounded slices, source-bound BRS IDs and successor dependencies. S01 remains the untouched user plan; the effective supersession map controls conflicting historical prose. |
| `DOCUMENT_COVERAGE.md` | Thirty-three inbound/outbound document classes, extraction, authority, destinations, blockers, exceptions and tests; maps all eighteen original v4 dossier items. |
| `ACCEPTANCE.md` | BRS-traceable 218 positive/adverse/threshold cases, all NOT_RUN as Odoo runtime tests (artifact validation is separate). |
| `SOURCES_DECISIONS_AND_GAPS.md` | Source epoch, exact-input lineage, current policy deltas, seventeen bounded decisions (D17 resolved) and 29 open implementation findings and field ownership. |
| `EXECUTION_HANDOFF.md` | Per-slice activation protocol, file-write collision rules, practical S01 handoff, receipt/closure contract and rollout discipline. |
| `campaign.json` | Machine-readable roadmap, policies, 54 requirements, sources, field map, document coverage, findings, decisions and tests. It is a local campaign graph, not an admitted L9 semantic schema or an Odoo data model. |
| `source_inputs/` | All existing protected historical inputs, plus the attributed current U07 operator correction transcript. Historical inputs are not active successors. |
| `validation/` and the accompanying final validation receipt | Package-level checks and limitations. They do not prove Odoo runtime behavior. |

## Fastest useful outcome

Run the protected starting-plan lane and native-intake discovery without expanding them. A valid inbound buyer Receiving Report updates `buyer_weight` and load facts and unlocks customer invoicing. The supplier RWN is independently generated **from accepted supplier settlement quantity, purchase price and approved deductions**, normally `supplier_weight`, any >5% direct commercial dispute requiring human adjudication (scale is reference only). Missing supplier PL/carrier documentary compliance does not block routine actions, while missing supplier payable quantity holds only the RWN. Neither a full AP redesign nor a new dashboard is needed for the earliest useful operation.

Commercial output and document collection are separate lanes. Carrier scale collection and its $150 penalty continue independently, including after commercial close. Paying/assessing a penalty does not make a missing document magically received.

## Evidence and authorization

The predecessor recorded `Staging` at `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e` on 19 October 2026 and PR 265 as open at `fca79680b8a6ac7d9ef237662571d57f1327f2da`, owning native bridge installation/view work. These are inherited observations, not fresh checks in v1.2.1. The local `feat/inbound-document-linking` branch and claimed ADR commits were not independently resolved remotely. Read its actual local state before running S01. Installed Enterprise modules, AI services, aliases and production behavior remain UNKNOWN.

The operator approved the BRS/ADR-025 design and this packaging revision. Proposed ADR-025 and BRS are **not** live repository-admitted law until a separate code PR is authorized and accepted. The operator authorized this compilation. No repository, database, contact, accounting, email, PR, merge or deployment mutation is authorized by this ZIP. Implement each selected slice only under a bounded grant. Source-presence, test pass, installed configuration and operating outcome are separate states.

**Admission class:** compiled operator-review proposal. Explicit operator statements are requirements; proposed technical realizations and unresolved business subrules are not silently admitted law. The pack is sufficient to use as a roadmap, not to certify deployment.

## v1.3.1 delivery boundary

Use all applicable scoped BRS owners, active specification and selected slice, not the immutable historical files in `source_inputs/`, as current instructions. The five measurement terms are **CST gross**, **CST tare**, **CST net**, **packaging tare**, and **net weight billed**. Existing Odoo/PlasticOS field names and source-declared labels are unchanged.

See [drift review](validation/DRIFT_REVIEW.md) for every repaired package finding and [validation scope](validation/VALIDATION_SCOPE.md) for limits. No GitHub/Odoo/runtime action was performed; live-source freshness and actual CI enforcement are not claimed.


## Field-routing implementation companion (v1.3.1)

Start with the Documents BRS index and the two scoped BRS owners (business authority), then `FIELD_ROUTING_AND_CONFORMANCE.md` (all touched existing field identities and measurements), then `CAMPAIGN_SPEC.md` §18 for source-to-native financial handoff. `campaign.json.field_routing_contract` is the matching checked machine view. The addition does not overwrite the preserved original plan or authorize new fields. Use the test IDs `T130`–`T218` and 31 declared worked examples to prevent three-source weight conflation. The first useful buyer invoice remains independent of supplier RWN and missing CST obligations. `brs-logistics` is future work only.

## v1.3.1 indexed BRS authority and corrected monetary formula

The current BRS authority in this **proposal pack** is **`brs-documents@1.3.1`**, a non-normative index at `docs/business-rules/README.md`/`index.json`, resolving **seven numbered, independently owned files BRS-001..BRS-007**. The seven files own all 46 stable `BR-*` IDs exactly once. Agents must inspect each owning `BRS-NNN@1.0.0` at its indexed SHA and rule IDs; unnumbered predecessor BRS files are historical only. ADR-025 has been updated to make this numbering/index/CI discipline explicit, pending actual repository admission.

The operator-resolved **BRS-007 BR-UND-002** LWD formula: for an applicable 53-foot 40,000 lb material net minimum, shortfall below 2,000 lb yields no charge; at or above 2,000 lb, effective $/lb rate equals `0.01 * (shortfall_lbs / 2000)`, continuously prorated for partial 500 lb increments (no stepped rounding), and amount equals **actual material net** multiplied by effective rate, with final USD cents half-up. Example 37,750 lb net -> 2,250 lb short -> $0.01125/lb -> $424.69; 36,000 lb net -> $0.02/lb -> $720.00. D17 is resolved for arithmetic; D16 remains for contract applicability, independently attributed buyer/supplier liability, and actual financial effects. Target Odoo runtime/CI are NOT_RUN.

The implementation should reuse verified current Odoo fields. Proposed `light_weight_deduction_total`, method `_compute_light_weight_deduction_total()`, obsolete `final_weight` and `dead_freight_chargeback` retirement are **pending migration**, not present or deleted in the live registry.
