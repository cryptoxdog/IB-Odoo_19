# Verbatim operator decisions used for brs-documents, October 19, 2026

## Earlier clarification: weight semantics

The final weight concept seems off. I think it should be net weight. Net and gross

We pay supplier on supplier weight. Buyer in buyer weight. Sometimes they match. Sometimes not. Both are fine. So I don’t know what final even means. Let’s resolve this drift before moving on.

## Business document vocabulary and settlement correction

7-currently our workflow is that a Received Weight Notice document gets sent to the supplier confirming the supplier weight and price and any penalties and deductions if any like light weight deduction or other chargebacks. Usually it has the supplier weight. That only changes to scale weight if there’s a higher than 5% discrepancy between supplier weight and buyer weight.

Received Weight Notice is not the right vocabulary presently for 
something we get from the buyer documenting their received weight. 

Other relevant document vocabulary. 
PL - Packing List - from supplier
Contains unit weights and packaging count if any like Gaylord’s and boxes for which we apply a “packaging tare” of 40 lbs Per Gaylord and 40 lbs Per pallet (Gaylord on pallet = 80 lbs packaging tare)
BOL - Bill of lading. Comes from supplier and truckers send them too usually it’s just copies
Of the same document 
Supplier scale tickets - some have a scale and they provide their scale tickets like mrfs. Some have a scale nearby and insist truckers use it and hence provide them. Suppliers aren’t obligated to provide scale tickets. Truckers are!

Receiving Report - what we get from the buyer documenting received weight. Mirror of a PL it’ll have packaging tare. 
Buyer scale tickets if they have a scale and weight and provide it. Not mandatory. Receiving Report is a key document we can’t fully bill out a load without it.

How much of my business logic belongs in ADR’s and if not there then where?

## Acceptance of BRS architecture and campaign-pack instruction

I accept the proposal. The pack must include adr 25 so agents know what the BRS is. And the document specific rules we’ve converged on clarifying vocabulary and corresponding Odoo fields prohibiting drift like no introducing shipper weight if we have supplier weight already.  

Add this to the campaign zip and make sure the campaign zip is fully aligned with the established brs-documents

There will later be a brs logistics

## Transcription status

The above is verbatim from operator chat requests in this conversation; formatting/group headings added for navigation. Previously supplied operator instructions in `LATEST_OPERATOR_INSTRUCTION.txt` remain historically preserved. No unprovided business decision is represented as a quoted instruction.

## Latest clarification: carrier certified scale ticket (CST), 2026-10-19

The carrier’s scale tickets we call CST for certified scale tickets to distinguish them from supplier and buyer scales which may not be certified.  

Clarification. CST gross - tare = net - packaging tare = net weight billed 

Update the campaign zip and deliver it
