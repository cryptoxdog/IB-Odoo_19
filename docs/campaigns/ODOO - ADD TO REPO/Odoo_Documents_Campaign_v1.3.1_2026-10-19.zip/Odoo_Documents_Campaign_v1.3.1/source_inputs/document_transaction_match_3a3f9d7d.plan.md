---
name: Document transaction match
overview: Implement ADR-023 and ADR-022 on feat/inbound-document-linking using only fields that already exist. One inbound file is filed on every transaction it cites through plasticos.document. The supplier invoice uses supplier_weight and the buyer invoice uses buyer_weight. No new model, field, or selection value is added.
todos:
  - id: document-adr
    content: Write ADR-023 as the accepted inbound document linking policy and index it
    status: completed
  - id: weight-adr
    content: Write ADR-022 as the accepted transaction weight policy and index it
    status: completed
  - id: matcher
    content: Match references from the existing mail hook and file one plasticos.document per cited transaction
    status: pending
  - id: sync
    content: Make legacy sync idempotent on attachment and transaction so a multi-load file is not duplicated
    status: pending
  - id: weight
    content: Post supplier_weight, buyer_weight, and scale_weight from the filed document and sender
    status: pending
  - id: tests
    content: Cover the match and weight cases with the existing fields, and update tests that expect a selected weight
    status: pending
isProject: false
---

# Exact document-to-transaction match

Branch: `feat/inbound-document-linking`, from `Staging`. Accepted records, already committed in `b57ce21`:

- [docs/adr/ADR-023-inbound-document-linking.md](docs/adr/ADR-023-inbound-document-linking.md)
- [docs/adr/ADR-022-transaction-weight-policy.md](docs/adr/ADR-022-transaction-weight-policy.md)

The newest-transaction helper is already a no-op in `7a92cd9`. [plasticos_documents_native/__manifest__.py](plasticos_documents_native/__manifest__.py) is `19.0.1.2.5` on this branch. Do not write the ADRs again. Do not set `auto_install` or `application` here; those flags belong to pull request 265.

## No new fields or vocabulary

Repo law: [CLAUDE.md](CLAUDE.md) principle 7 and [docs/adr/ADR-021-erp-sql-crm-api-import.md](docs/adr/ADR-021-erp-sql-crm-api-import.md) decision 6. A new field needs a proven gap and explicit operator approval. This plan does not ask for that approval, so it adds no model, no field, and no selection value.

Use the names already on the models:

- Parties: `supplier_id`, `buyer_id`, `carrier_id`
- Document party: `doc_category` values `supplier`, `buyer`, `carrier`, `internal`
- Weights: `supplier_weight`, `buyer_weight`, `scale_weight`
- Discrepancy: `weight_discrepancy_flagged`, `weight_discrepancy_pct`
- Native document: `transaction_id`, `load_id`, `partner_id`, `doc_type`, `plasticos_doc_id`, `attachment_id`, `name`
- Legacy document: `transaction_id`, `load_id`, `res_model`, `res_id`, `attachment_id`, `doc_category`

`supplier_weight` is the supplier weight. Do not say shipper in code, comments, or new prose. Do not add `purchase_weight`, `shipper_invoice_revision`, `role`, `scale_leg`, `weight_lbs`, `unresolved_references`, or `plasticos.document.transaction.link`.

Already present, and not created here:

- `ai_documents` is an Enterprise module. It is not added to `depends`.
- `ai_to_sort` is an Enterprise field when that module is installed. This plan does not declare it and does not read it.
- `_match_document_transactions` is not added. The entry point is the existing `_message_post_after_hook` on the `documents.document` inherit.

A token that matches nothing is not stored. The mail message already holds the text, and the document stays unlinked.

## What is already true in the code

[plasticos_documents_native/models/document_native.py](plasticos_documents_native/models/document_native.py) extends `documents.document`. `_auto_link_partner` is unused and already writes nothing. `doc_type` includes `bol`, `invoice`, and `scale_ticket`. There is no packing-list value, and none is added.

`load_id` on `plasticos.transaction` comes from [plasticos_logistics/models/transaction_inherit.py](plasticos_logistics/models/transaction_inherit.py). `sale_order_id` is a Many2one. `purchase_order_ids` is a Many2many. `do_number` is the stored related name of `delivery_order_id`. States include `delivered`, `closed`, and `cancelled`. There is no `pending` state.

Load references on [plasticos_logistics/models/load.py](plasticos_logistics/models/load.py): `name`, `pickup_reference`, `delivery_reference`, `trailer_number`, `seal_number`.

`_compute_final_weight` still prefers scale, then buyer, then supplier. The form group `material` in [plasticos_transaction/views/transaction_views.xml](plasticos_transaction/views/transaction_views.xml) shows `final_weight`. [plasticos_commission/models/sales_dashboard.py](plasticos_commission/models/sales_dashboard.py) reads `final_weight` and `weight_source`. That dashboard is left unchanged, because selecting `supplier_weight` there would add fields on the dashboard model.

[plasticos_documents/models/document.py](plasticos_documents/models/document.py) allows many rows to share one `attachment_id`. [plasticos_documents/models/compliance_service.py](plasticos_documents/models/compliance_service.py) `get_missing_documents` finds a row by `res_model`, `res_id`, and `tag_id`. That is how one file becomes evidence on many transactions without a new model.

```mermaid
flowchart LR
  mail[Inbound mail] --> hook[Existing mail hook]
  hook --> match[Reference match]
  match -->|one or many| legacy[One existing plasticos.document per transaction]
  match -->|none| hold[Leave unlinked]
  legacy --> compliance[get_missing_documents]
  legacy --> weights[supplier_weight buyer_weight scale_weight]
```

## Match rule, ADR-023

Override `_message_post_after_hook` in [plasticos_documents_native/models/document_native.py](plasticos_documents_native/models/document_native.py). Call `super()` first. Do not edit the Enterprise file. Read the attachment filename, `documents.document.name`, and the subject and body already stored on `mail.message`. Strip HTML before matching. `email_from` resolves the sender. `partner_id` is that contact when Enterprise has already set it. It does not select a transaction.

The pure function takes the text, the sender partner id, and the candidate reference rows. It returns the transactions to file. No Odoo import in that function.

A stored reference matches only as its own token: casefold both sides, and require a boundary that is the start, the end, or a character that is not a letter or digit. A hyphen inside the stored value stays part of the token. Ignore stored values shorter than 4 characters. Eligible values:

- `plasticos.transaction.name`
- `plasticos.load.name`, through `plasticos.transaction.load_id`
- `plasticos.load.pickup_reference` and `delivery_reference`
- `plasticos.transaction.do_number`
- `sale.order.name` from `sale_order_id`
- `purchase.order.name` from each record in `purchase_order_ids`

`trailer_number` and `seal_number` confirm a transaction that already matched another reference. They never select one.

Search every transaction except `state` `cancelled`.

Keep a hit only when the sender is that transaction's `supplier_id`, `buyer_id`, or `carrier_id`. When the sender is not the same party on every hit, keep the party that accounts for the most hits and file no row for the others. When the counts tie, file nothing. Zero hits files nothing.

One kept transaction, or many, creates one existing `plasticos.document` per transaction. A ten-load invoice that cites ten references gets ten rows sharing the native `attachment_id`.

A `doc_type` `scale_ticket` whose sender is none of the three parties still files when every cited reference hits. `doc_category` stays empty. The exception does not apply to `doc_type` `invoice`. A `scale_ticket` whose sender is `carrier_id` files with `doc_category` `carrier`.

When exactly one transaction is filed, set the existing `transaction_id`, `load_id`, and `plasticos_doc_id` on the native document. When more than one is filed, leave all three empty.

## Sync

[plasticos_documents_native/models/document_sync.py](plasticos_documents_native/models/document_sync.py) creates one `plasticos.document` per cited transaction. Each row shares `attachment_id`, sets `transaction_id`, sets `load_id` from that transaction, and sets `res_model` `plasticos.transaction` with `res_id` of that transaction. `doc_category` is `supplier`, `buyer`, or `carrier` from the sender. Re-running finds the existing row by `attachment_id` and `transaction_id` and updates it. A dropped citation removes that legacy row.

`batch_sync_unlinked` must not create a second row for an attachment and transaction that already has one. `plasticos_doc_id` remains empty on a multi-transaction file, so the cron cannot treat an empty `plasticos_doc_id` as "never synced" when those legacy rows already exist.

A stated net is `doc_type` `bol`, or a packing list recognized from the filename or body while `doc_type` is `bol` or `other`. Do not add a selection value.

## Weight posting, ADR-022

Read the numbers from the document text at post time. Do not store a light reading, a heavy reading, or a parsed-pound field. A scale net is heavy minus light from that text. Do not subtract `total_tare`. A light number alone, or a heavy number alone, writes none of `supplier_weight`, `buyer_weight`, or `scale_weight`. The file still exists so a later document can be read with it.

Post a weight only when the text states it for that transaction's reference. A lump total with no per-reference weight writes nothing. Do not copy it and do not divide it.

- Supplier stated net writes `supplier_weight`. No scale pair is required.
- Supplier pair net writes `supplier_weight` only when `supplier_weight` is still empty.
- Buyer stated net writes `buyer_weight`. A buyer pair writes `buyer_weight` only when `buyer_weight` is still empty.
- A scale ticket from a sender who is not the supplier, buyer, or carrier writes `scale_weight` from a complete pair.
- A carrier scale ticket writes none of the three fields.

The supplier invoice is paid from `supplier_weight`. The buyer invoice uses `buyer_weight`.

Edge case, all true: the filed supplier documents contain no complete light-plus-heavy pair, `supplier_weight` differs from `buyer_weight` by 5% or more, and `scale_weight` is within 5% of `buyer_weight`. A buyer pair, when the filed buyer documents contain one, is also within 5% of `buyer_weight`. The difference is `abs(a - b) / max(a, b)`. Exactly 5% counts. The supplier-invoice calculation then uses `scale_weight`. `supplier_weight` stays unchanged. `weight_discrepancy_flagged` is the existing signal. Any other gap of 5% or more sets that same flag and does not replace `supplier_weight` or `buyer_weight`. Compare `supplier_weight` with `buyer_weight`, and compare `scale_weight` with each of them when it is present. Change the current strict greater-than.

Stop `_compute_final_weight` from preferring a source. Leave `final_weight`, `gross_weight`, and `weight_source` on the model. They are not settlement quantities. `_compute_light_weight_deduction` reads `supplier_weight`, and reads `scale_weight` when the edge case applies. That choice is local to the method. The form group `material` shows the existing fields `supplier_weight`, `buyer_weight`, `scale_weight`, and `weight_discrepancy_flagged`. The weight comment cites ADR-022.

Do not change [plasticos_commission/models/sales_dashboard.py](plasticos_commission/models/sales_dashboard.py). Its `final_weight` column stays until a separate approval adds no new business field and only changes that view.

## What stays

`_validate_bill_uniqueness` still refuses one `account.move` on two transactions. The PDF is filed on every cited transaction. The bill is not split.

[plasticos_documents/data/scale_ticket_rule.xml](plasticos_documents/data/scale_ticket_rule.xml) still requires one `SCALE` tag for close. A lone light ticket still files. It does not write a weight.

No new `partner_id` on `plasticos.transaction`. Packaging tare fields stay. They are not the light scale ticket. `ai_documents` is not added to `depends`.

## Tests and versions

Update the tests that encode the old priority: [tests/test_constraints_onchanges.py](tests/test_constraints_onchanges.py), [plasticos_transaction/tests/test_transaction_form_ui.py](plasticos_transaction/tests/test_transaction_form_ui.py), and [tests/test_transaction_profit_snapshot.py](tests/test_transaction_profit_snapshot.py).

New pure tests: one reference to one transaction; ten references to ten transactions; no reference stays unlinked; a short or partial token does not match; a hyphenated reference matches only in full; trailer number alone does not match; a tied sender party files nothing; a scale ticket with no supplier, buyer, or carrier sender files with `doc_category` empty; an invoice from a non-party does not file; a cancelled transaction does not match. Weight tests: light without heavy writes no weight field; heavy without light writes none; heavy minus light is the pair net; a BOL net writes `supplier_weight` with no scale ticket; a small difference leaves the supplier invoice on `supplier_weight` and the buyer invoice on `buyer_weight`; the edge case leaves `supplier_weight` unchanged, flags `weight_discrepancy_flagged`, and uses `scale_weight` for the supplier-invoice calculation; a scale net that disagrees with the buyer leaves the supplier invoice on `supplier_weight`; a lump total on a multi-load invoice writes no per-load weight.

Versions, then `ruff format` the manifests:

- `plasticos_documents_native` `19.0.1.2.5` to `19.0.1.2.6`
- `plasticos_transaction` `19.0.2.3.37` to `19.0.2.3.38`

`plasticos_documents` stays at `19.0.2.1.1`. `plasticos_commission` stays at `19.0.1.4.3`.

Pull request 265 also uses native version `19.0.1.2.5` for a different change. If that pull request merges first, reconcile this branch's version line before publication.
