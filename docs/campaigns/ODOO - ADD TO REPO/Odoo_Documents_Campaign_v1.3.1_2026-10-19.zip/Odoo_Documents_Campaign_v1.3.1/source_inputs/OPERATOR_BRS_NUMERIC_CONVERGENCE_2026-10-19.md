# Operator Policy Convergence: BRS Numbering and Light Weight Deduction

**Date:** 2026-10-19
**Evidence:** attributed transcription of explicit operator messages in this conversation; NOT an independently authenticated verbatim export. **Status:** CURRENT OPERATOR DECISION FOR THIS PROPOSED PACK; no GitHub admission or Odoo mutation.

- Scope: transform all active BRS files into ADR-style sequential `BRS-NNN-<concern>.md`, with one owner per concern, indexed numbering, stable rule IDs, and coding/testing CI traceability.
- Controlled vocabulary: Document measurement, Load net, Packaging tare, Material net, Accepted commercial weight (five definitions preserved verbatim by BR-VOC-001).
- A carrier CST provides reference weight; buyer/supplier quantities are distinct commercial material-net values. Review direct supplier/buyer material-net spread strictly >5% even if both are individually close to the CST; never automatically substitute a reference scale weight for a payable quantity.
- The 53-foot contractual minimum is 40,000 lb material net; trigger light-weight deduction at a shortfall of 2,000 lb inclusive.
- The operator corrected the earlier shortfall-times-rate / $200/$400 illustrations and instructed that the deduction is **an effective $/lb charge on the actual material net weight**. At 36,000 lb material net, 4,000 lb shortfall is 2 short tons and effective rate is $0.02/lb; correct total is $720.00.
- Rate: $0.01/lb per 2,000 lb of shortfall; equivalent $0.0025/lb per each 500 lb shortfall. The operator first proposed completed 500-lb steps, then explicitly revised that instruction in favor of continuous proration to avoid a staircase effect. Final decision: continuous interpolation for partial 500 lb increments, with no premature rounding of rate. Example: 2,250 lb short -> $0.01125/lb (not $0.01/lb); at 37,750 lb net, total is $424.69.
- `_compute_light_weight_deduction_total()` is the target method name; the calculation is obligation-scoped, not a global transaction settlement quantity. `light_weight_deduction_weight` is a pure calculation output (eligible shortfall), `light_weight_deduction_total` is a proposed successor to legacy ORM `light_weight_deduction` only through a controlled migration. Retire the old `dead_freight_chargeback` Boolean when dependent code and historical data are migrated.
- A supplier recovery and buyer liability require **independent** contractual decisions and separate native financial evidence. Missing/ambiguous contract or approval holds the particular financial action; business arithmetic is not itself posting authorization.

**Supersession:** This most recent operator rate decision supersedes the old `D17` arithmetical conflict, earlier `$200/$400` synthetic examples and the later floor-to-500 policy. Keep those earlier instructions immutable as historical lineage but not current business rules. `D16` contractual responsibility/financial realization remains an OPEN bounded decision.
