# Operator-approved Weight Vocabulary and Underweight Policy — October 19, 2026

This file is a direct transcription/curation of this conversation's operator decisions and constraints, not a repository artifact, accounting posting permission, or executed business process. Earlier source_inputs remain byte-identical.

## Operator-established terms (exact wording)

| Stage | Meaning |
|---|---|
| Document measurement | The quantity actually shown on the PL, Receiving Report or scale ticket |
| Load net | Gross less corresponding vehicle/CST tare |
| Packaging tare | Weight of applicable Gaylords, pallets, etc. |
| Material net | Load net less applicable packaging tare, or independently verified material-only net |
| Accepted commercial weight | The validated material net used for supplier or buyer settlement |

## Other accepted decisions

- Scale Weight is a reference weight, **not itself a billable weight**. It is compared with the two commercial weights for discrepancy analysis; **greater than 5% supplier-versus-buyer discrepancy is an edge case requiring human review**, not an automatic substitution by scale_weight.
- A supplier 4% below CST while a buyer is 4% above CST cannot be approved by two independent within-5% comparisons if the direct supplier-versus-buyer spread exceeds 5%. Review all three pairwise differences; the direct commercial spread remains mandatory.
- Preserve existing supplier_weight, buyer_weight, scale_weight. No new nested Odoo gross/tare/net fields unless an independently demonstrated representation gap receives separate approval.
- No universal final_weight. Display preferred certified CST weight (only with validated certification/packaging), otherwise accepted buyer_weight, otherwise accepted supplier_weight, otherwise no accepted weight. Display does not determine monetary obligations.
- 53-foot trailer example: minimum net material weight 40,000 lb. Deduction applies only when the shortfall is **at least** one ton (2,000 lb); if triggered, **all** shortfall pounds are multiplied by $0.01/lb. 36,000 -> $400, 38,000 -> $200, 38,001 -> $0.
- `light_weight_deduction_rate`, `light_weight_deduction_weight`, `light_weight_deduction_total` are preferred semantic identities; `_compute_light_weight_deduction_total` is the preferred Odoo monetary compute method name, not `_compute_weight_deduction`. These are approved naming goals, **not** statements that missing ORM fields/methods already exist.
- Underweight applies to an actual **contractual obligation**, which may be buyer-side (e.g. buyer handles freight and bills Scrap Management) or supplier-side. Each obligation uses the same deterministic calculation, while Purchase/Sales/Claims/Accounting apply liabilities or recoveries separately under authorized terms.
- `dead_freight_chargeback` Boolean, which existing code derives from the amount exceeding purchase cost, has no accepted separate business meaning. Retire that old computation and field through verified consumer-safe migration, not an ungoverned schema change.
- `light_weight_deduction_weight` is a calculation output initially, not authorization for a new ORM field. `light_weight_deduction_total` is a proposed replacement field identity for existing `light_weight_deduction`, pending explicit controlled ORM migration.
- The carrier's missing-CST **$150 documentation chargeback** is distinct from the $0.01/lb contractual light-weight deduction. Do not blend the two penalties.

## Still unresolved and NOT implicitly approved

- Final comparison percentage denominator/precision and the detailed human adjudication rules; a threshold strictly greater than 5% is accepted but denominator remains D13.
- Contract-specific assignment, effective dates, 53-foot minimum exceptions, and non-53-foot policies; missing applicable terms block only the affected monetary action.
- `light_weight_deduction_total` as a transaction-level field is only a summary when there are independently distinct obligations; separate financial postings must stay in existing native commercial/claim/accounting owners.
- The full dead freight concept is not admitted as a separate fee by these directions; the obsolete Boolean is to be retired.
