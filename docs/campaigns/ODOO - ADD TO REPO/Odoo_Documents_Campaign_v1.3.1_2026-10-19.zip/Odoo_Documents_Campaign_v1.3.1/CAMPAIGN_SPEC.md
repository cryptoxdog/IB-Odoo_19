# Documents Automation Campaign: Master Specification

**Campaign:** ODOO_DOCUMENT_AUTOMATION_CAMPAIGN v1.2.1  
**Target:** `cryptoxdog/IB-Odoo_19`, integration branch `Staging`  
**Evidence epoch:** `4ac9bfa59bb3b1c595f2105d3a23326c72f0fb1e`, inherited pinned source evidence; not re-resolved during this package-only revision  
**Status:** Proposed campaign design; repository/runtime execution not performed  
**Business authority:** `docs/business-rules/README.md` (`brs-documents@1.3.1`), with separately owned `BRS-003@1.0.1` and `BRS-007@1.0.1`, all governed by proposed ADR-025. **Source notation:** [U01], [U02], [U03], [U04], [BRS01], [A25], [P01], [Gxx], [Nxx] resolve in `SOURCES_DECISIONS_AND_GAPS.md`.

## 1. Objective and meaning of finished

A document is not finished merely because it is saved or tagged. A supported incoming source is finished when its original is retained, its logical business documents are identified, each document is associated with the right transaction/load/company, its supported facts are extracted and validated, all authorized facts are applied to existing owners, and every appropriate downstream action is either completed, durably pending with a reason, or a genuine assigned exception. [U01,P02]

The desired day-to-day experience is that a buyer Receiving Report arrives, the correct Buyer Weight and shipment details become visible on the transaction, the supplier receives a **settlement** Received Weight Notice (normally stating `supplier_weight`, supplier purchase price and approved deductions; >5% direct commercial discrepancy **held for human review**, `scale_weight` reference-only), while the buyer gets the correct native Odoo invoice from `buyer_weight`, and the staff can see exactly which supplier/buyer/carrier documents are still outstanding. The staff do not need to copy weights, seal numbers, dates or invoice lines merely because an AI extractor was involved.

"All documents" means the ordinary current brokerage inventory in `DOCUMENT_COVERAGE.md`. It does not authorize uncontrolled master-data creation, a universal parser for every possible file, unbounded autonomous actions, or unrelated historical import/ERP migration work. Every declared class needs a supported path or a specific justified exception. Unsupported document variants remain captured and reviewable; they do not disappear.

### 1.1 Completion has four independent dimensions

| Dimension | Meaning | What it does not prove |
|---|---|---|
| Receipt/evidence | Source received, preserved, classified and associated. | Content valid, counterparty trusted or business action authorized. |
| Fact application | Correct validated fields applied with traceability. | Invoice posted, message delivered or settlement paid. |
| Commercial output | Correct notice/invoice drafted, authorized, queued/sent/posted as applicable. | Every supporting document has arrived. |
| Document obligation | Each required document/evidence item received, incomplete, overdue, disputed or explicitly resolved. | Receipt can be fabricated by a penalty or an override. |

Do not create a single overloaded `complete` switch that erases these distinctions. These are required behaviors, not approval for new model fields or selection values. Reuse native records, existing fields, tags, activities and evidence views first. [G02,G03]

## 2. Operator-intent reconciliation and precedence

### 2.1 What remains fixed

The original plan is the protected opening slice. Reuse `plasticos.document`, `documents.document`, existing transaction/load references, `supplier_weight`, `buyer_weight`, `scale_weight`, existing document party categories and native Accounting. No new model, field or selection value is authorized for S01. Do not recreate already completed ADRs, claim they were inspected without evidence, or take over PR 265 installation changes. [P01]

The historical Dropbox intent remains useful: one inbox, content-led classification, TX and role-specific order references, one original, role-based document views, missing-document follow-up and manager activities rather than internal email noise. Its old `sm.transaction`, `x_*` fields, literal folder hierarchy and old dollar amounts are not current implementation authority. [H01,P02,G02]

### 2.2 Operator-approved Documents business meaning (`brs-documents`)

| Input/output | Business meaning and selected existing Odoo field | Blocking scope |
|---|---|---|
| Inbound **buyer Receiving Report** | Buyer documents net received, material/line and packaging tare/count; maps accepted quantity to `plasticos.transaction.buyer_weight`. This is **not** the RWN. | Mandatory to fully invoice a load. Also used to compare buyer/supplier weights for the supplier settlement notice. |
| Outbound **Received Weight Notice (RWN)** | Scrap Management confirms the supplier settlement quantity, agreed supplier **purchase** price and approved penalties, light-weight and other chargebacks. Normally `supplier_weight`; any **strictly >5% direct supplier/buyer commercial spread** held for **human reconciliation** rather than automatic scale substitution; CST remains reference only. | Requires buyer Receiving Report and a valid payable settlement quantity/terms. Missing quantity holds the **RWN only** (D14). PL or carrier scale *document compliance* is not a blanket block. |
| Outbound **Customer Invoice** | Native Customer Invoice quantity is accepted `buyer_weight`, with native sale price/tax/UoM/order-line policy. | Independent of supplier RWN quantity/send, supplier PL/weight, supplier/buyer optional scale tickets and missing carrier gross/net. |
| Supplier **PL / Packing List** | Supplier-provided packaging counts/unit weights and optional quantity evidence. | PL not a required document to send ordinary RWN or invoice buyer if each action's actual facts are otherwise established. |
| **BOL / Bill of Lading** | Supplier and carrier may send copies of the same shipment BOL. | One business shipment document with distinct submission provenance, not doubled load or bill. |
| Supplier / buyer scale tickets | Optional scale evidence, **not necessarily certified**; supplier may arrange a nearby scale even without owning one. | Not mandatory for either supplier or buyer; not the carrier CST. Scale measurements only corroborate a **human-reviewed** >5% direct commercial discrepancy; CST and supplier/buyer scales are not third payable weights. D13 owns the percentage denominator and review evidence. |
| **CST / Certified Scale Ticket** | Carrier owes **certified** gross and net truck-scale evidence **per load**, even after close. CST gross minus CST tare is CST net; minus packaging tare is net weight billed. | Required carrier document, but not a general Customer Invoice, ordinary RWN or close gate. Missing evidence incurs **$150 carrier chargeback** once policy timing/applicability is approved. |
| Packaging tare | 40 lb/Gaylord, 40 lb/pallet, 80 lb/Gaylord-on-pallet. **Deducted from CST net** to derive net weight billed. Reuse a separately evidenced packaging-excluded result rather than deducting it twice; do not redefine CST net. | No double subtraction; box/mixed-package semantics pending D15. |

`final_weight` has **no valid universal business meaning** and is retired at the business-contract level. Existing `gross_weight`, `final_weight` and `weight_source` computed fields and the `dead_freight_chargeback` Boolean require finite audited consumer/data migration before technical deletion; there is no approved new universal replacement. Exact fields and existing Odoo 19 labels are in `brs-documents` §2, not the operator's colloquial synonyms. [U02,BRS01,G11]

### 2.3 Policy supersession without rewriting Slice 01

The exact original plan in `source_inputs/` is historically preserved. The governing **effective** instructions come from the operator-accepted numbered BRS-001..007 concern files indexed by brs-documents@1.3.1 plus repo/native field law. Earlier claims that buyer-received quantity becomes RWN quantity, or that scale automatically replaces supplier weight after 5%, are **superseded**. The latest operator decision mandates **human review on direct commercial discrepancy >5%**, with independent CST scale evidence as reference. D13 still owns denominator/rounding and manual adjudication detail; no automatic scale settlement is accepted.

The first slice's matching/attachment/no-new-field tasks remain bounded. Its proposed ADR-022 semantics must be reconciled with BRS before any conflicting weight behavior is admitted; only the affected consumers require local interface/regression proof. Do not append the campaign to the original plan or duplicate PR #265 ownership.

### 2.4 Business-rule architecture, not a new rules engine

`docs/adr/ADR-025-business-rules-specification-authority.md` defines what a BRS is and how operator approval, ADR architectural placement, exact Odoo 19 technical declarations, agents and existing CI relate. `docs/business-rules/README.md` is the **normative Documents family index**, with owned supporting concern files for material weights and underweight/chargebacks. The three files own **46** stable `BR-*` rule identities without duplication; this master spec/roadmap/coverage/acceptance are derived execution plans, not independent commercial authority. `brs-logistics` is deferred, not admitted or created. Repository adoption of ADR-025/BRS requires a separately authorized PR, index, agent pointer and CI integration. The ZIP alone creates no repository law. [U02,A25,BRS01]

## 3. Architecture and code ownership

### 3.1 The single processing path

```text
Native inbound alias / approved upload / body-only email
  -> native message and original attachment/document
  -> logical-document segmentation + AI/text/OCR candidate extraction
  -> deterministic reference, issuer, party, company and facility validation
  -> existing document-to-transaction evidence associations
  -> owner-specific fact validation and ORM application
     -> accepted buyer receiving snapshot
        -> supplier Received Weight Notice queue
        -> native Customer Invoice draft / post / send queue
     -> supplier and carrier AP evidence / native bill workflow
     -> per-party document requirement evaluation
        -> missing-document reminders / manager activity
        -> independently eligible $150 carrier chargeback
```

Logical document processing stages are a specification, not a new orchestration service or parallel ERP. Extend existing Odoo lifecycle/action paths with the smallest necessary methods. The exact entry points must be verified against the installed Odoo 19 Enterprise code; P01's `_message_post_after_hook` claim is not a substitute for that inspection. Asynchronous extraction completion, user upload, revision and replay must reach the same business rules, not separate implementations. [P01,G13,G14,N01,N02]

### 3.2 Ownership table

| Concern | Highest current owner to reuse | Boundary |
|---|---|---|
| Original files, folders, tags, aliases, native digitization | Odoo Documents, `ir.attachment`, native mail/account features | Do not replace Enterprise source or duplicate original storage. |
| Odoo-to-PlasticOS document integration | `plasticos_documents_native` | Classification/link/event adapter; does not become settlement authority. |
| Required documents, evidence associations, lifecycle | `plasticos_documents` | Operation/party requirements and truthful receipt/completeness. |
| Transaction weight meaning and invoice relationships | `plasticos_transaction` | Distinct source weights; financial consumer closure. |
| Load references, seal/trailer, dates and freight facts | `plasticos_logistics` | Existing actions and company/facility boundaries. |
| Native AP/AR, credit/debit and posting lifecycle | `account.move`, existing sale/purchase bridges | No parallel accounting ledger or fake posted status. |
| Follow-up, existing messaging templates, documentation penalty configuration | `plasticos_automation` | Extend existing `documentation` rule, fixed calculation and native messaging. |
| Carrier/quality claim and resolution evidence | `plasticos_claims` | Claim is not a bank payment or automatically recognized recovery. |
| Effective cross-role and company access | Owning module ACLs plus `plasticos_security_base` where actually required | Scope-specific grant before changes; no broad permission redesign. |

The external-intelligence ADR governs buyer matching/partner enrichment through Gate. This campaign resolves references on existing transactions and reads documents; it does not resurrect retired matching/enrichment engines or introduce direct CEG/EIE calls. Native document extraction is the initial reuse candidate, subject to actual installed action/capability verification. [G04]

### 3.3 Native reuse constraints

Official Odoo 19 documentation describes folder aliases, AI folder prompts/actions, record linking and native bill digitization. It does not prove these are installed or configured in this database, nor that a native OCR action extracts scale gross/net/seals into PlasticOS fields. N01 and N02 differ on whether the AI app itself must be installed; inspect the actual Enterprise addon registry and action implementation rather than selecting a dependency from documentation wording. [N01,N02,N03]

Native account digitization is preferred for supplier/freight bills. Native Documents is the front door for varied formats and body-only mail. Choose one path for a given source so forwarding through both the Documents alias and a journal alias does not create two bills. A native "To Split" tag is a review aid, not evidence that automatic segmentation occurred. Accounting centralization and transaction views must reference the same document rather than fight over a second physical folder hierarchy. [N01,N02,N03]

## 4. Ingestion and source evidence

### 4.1 Inputs

Supported categories include text-based PDFs, scanned PDFs, ordinary images, machine-readable bill XML where supported, spreadsheets with explicit cells/rows, and substantive email bodies. The exact supported formats/provider limits are resolved in S03. Never execute spreadsheet macros, formulas as arbitrary code, embedded attachments, scripts or instructions embedded in a file. Formula values without a trustworthy cached result are unresolved, not calculated by an unsafe office runtime.

For every incoming message, preserve the original sender/recipient metadata available through native mail, provider/message ID, arrival time, subject/body, attachment boundaries and forwarded context. Original evidence should be retrievable even if classification fails. Existing native attachment checksums and message identifiers are reuse candidates; a renamed duplicate is not a new invoice simply because its filename differs.

Different parties may independently send the same bytes. Distinguish source-delivery evidence from logical business-document identity: avoid storing duplicate originals unnecessarily while not erasing who supplied evidence and when. Attachments in the same email do not automatically inherit every reference found in the envelope/body.

### 4.2 Failure behavior

Unsupported or damaged files stay in a native review/quarantine path with their source and reason. Password protection, unusable scans, missing extraction credits and transient service errors have distinct reasons. Retry is bounded and recoverable; repeated failures do not overwrite a field with zero, discard the source or generate a penalty against the carrier for an internal parser outage.

A delayed processing job uses observed document receipt time when assessing an external deadline, not its own eventual execution time. An ambiguous email delivery outcome is not proof the document never arrived. Obtain the minimum necessary runtime/provider configuration evidence in the disposable environment; do not sample private operational inboxes outside this mission without an appropriate read grant.

### 4.3 Content and segmentation

Extract content before relying on filename or subject. Native text/XML/cells can be used when reliable; OCR is necessary for image-only content. This retains the older content-first intent without charging or rerunning OCR on text already available.

A multi-page single report is not automatically multiple business documents. A single PDF containing multiple invoices, or an invoice and Receiving Report, may need logical segmentation. Each part keeps original identity, page/span boundaries as supplied, and a specific class. A multi-load document can be a single logical document with several per-load rows. Do not confuse segmentation with transaction allocation.

Preserve one original. A derived page extract or machine-readable extraction evidence is a derivative with its own purpose and linkage, not an independent competing source of truth. Native metadata/evidence attachments are the first persistence option. Any new schema requires the D08 representation check and explicit approval.

## 5. AI extraction contract and trust boundary

### 5.1 Candidate facts

For each logical document, obtain the following where actually evidenced:

| Fact group | Candidate information |
|---|---|
| Identity | Class, document number/date/revision, issuer, transporter/sender, addressee, company/counterparty/facility candidates. |
| Commercial references | TX, PO, SO, DO, BOL, invoice and load references, with their local text/page/row association. |
| Material | Description, polymer, form, grade, product/lot and accepted line mapping. |
| Quantity | Original numeric text, unit, stated gross/tare/net, heavy/light readings if present, package count, per-line/per-load quantity and total. |
| Transport | Container/trailer/chassis/seal, carrier/equipment, origin/destination, actual versus planned dates. |
| Finance | Invoice number, currency, quantity, unit price, line subtotal, tax, freight/accessorials, deduction, total and referenced original credit/invoice. |
| Qualification | Certificate/permit scope, issuer, effective/expiry dates, lot/facility and revision. |
| Evidence | Original source identity, logical part, page/cell/span when supported, provider/model/prompt/version and raw result/validation outcome. |

This table is a fact schema, not a list of fields to add to Odoo. Missing numbers remain absent, not `0.0`. Preserve exact identifier strings and original formatting where material. Distinguish explicitly stated, measured, calculated and inferred values. AI confidence can inform review but cannot authorize a business action.

### 5.2 Validation before mutation

The same deterministic boundary must protect all AI and manual-triggered processing paths. A candidate must have a supported destination and meaning, valid source identity and scope, unambiguous correct transaction/load, explicit unit/currency/date semantics, internal arithmetic consistent within an accepted precision rule, no conflicting stronger/current evidence, and a permitted lifecycle action. Then the owner applies the fact through existing ORM behavior.

A schema-valid extraction is not validated business evidence. An invoice with perfect OCR may be a duplicate, refer to the wrong company, charge an unapproved accessorial, or reflect a supplier's contested quantity. A buyer Receiving Report may be a partial or corrected report. Do not add a mandatory human confirmation solely because AI generated the candidate; do add a specific exception when these predicates fail.

### 5.3 AI action restrictions

A document may contain requests to change bank details, send emails, run code, contact websites or ignore restrictions. These are untrusted content. The extractor receives the source and a narrowly typed task; it cannot choose arbitrary write models/fields/actions/recipients. Only the reviewed deterministic mapping and current authorization layer can cause effects. Do not accept externally supplied amounts or destinations as control instructions.

Version extraction behavior so accepted results can be replayed without rerunning the provider unnecessarily. Re-extraction after provider/prompt change creates a new evaluated candidate and does not silently erase the previous accepted interpretation. Explicit source locations may be absent if the provider does not supply them; record that limitation instead of inventing coordinates.

## 6. Transaction matching, roles and cardinality

### 6.1 Candidate retrieval

Use the exact existing references listed in P01: transaction name, linked load name and pickup/delivery references, transaction DO number, native SO name and linked PO names. Keep token-boundary protection and preserve hyphenated identifiers. P01's four-character minimum is a starting rule, not authority to silently drop a legitimate shorter identifier; such a case becomes a recorded unsupported-reference exception until a bounded policy change.

Candidate retrieval must be indexed/bounded and scoped to authorized company/record access. Do not enumerate every historical transaction for every attachment unnecessarily. Equally, do not reject legitimate late evidence merely to accelerate search. Trailer and seal can corroborate a strong reference but cannot independently select a transaction because equipment and seals can be reused or mistyped.

### 6.2 Per-document and per-hit validation

Each association stands on its own evidence. A majority of matching tokens does not authorize dropping contradictory party references. Conflicting TX versus PO/SO/DO results, wrong company, wrong facility or multiple credible candidates route the affected logical document to review. No latest-open-deal or sender-domain-only decision is authoritative.

Resolve a legitimate contact to its commercial parent/facility through existing relations. The document issuer and the email sender are separate facts. A carrier can forward an independent scale's certificate; a stranger does not become an independent trustworthy scale merely because it is none of the transaction's three parties. Third-party evidence needs corroborated issuer/source/load identity and current permissions.

### 6.3 Shared source and many transactions

One attachment can support several `plasticos.document` rows on existing transactions. Preserve direct `transaction_id`/`load_id` and polymorphic `res_model/res_id` consistency. For a single transaction, native convenience links can be set. For many transactions, the native Many2one pointers cannot pretend to represent all links; leave them unset as the original plan specifies, and treat the evidence associations as the set of links. An empty native pointer must not cause the batch sync to recreate rows forever. [P01,G13]

`plasticos.transaction.load_id` remains singular with the existing uniqueness rule. A multi-load document refers to multiple existing transaction/load records. It does not authorize a new multi-load transaction model. One invoice PDF filed on ten transactions is not authority to create ten Vendor Bills or break bill-exclusivity constraints. If native bill-line allocation cannot express the case without violating an existing owner contract, hold that accounting allocation, not the original document intake. [G21,P01]

### 6.4 Corrections and replay

A correction to classification or citation must preserve the original interpretation as history, adjust current associations safely, and recompute both old and new affected records. The existing `is_current`, `superseded_by`, `active`, attachment and chatter mechanisms are candidate tools; prove their interactions rather than deleting evidence rows silently.

Idempotency must cover source/part/transaction association, accepted fact revision, claim, bill, invoice, outgoing notice and reminder independently. Filename-only identity is insufficient. Application-level search-before-create is not concurrency proof; inspect native uniqueness/locking/savepoint facilities and prove races. A data-model gap is escalated under D08, not hidden in an overloaded scalar.

## 7. Weight and logistics semantics

### 7.1 Separate supplier, buyer and scale quantities

`plasticos.transaction.supplier_weight` is supplier-declared net quantity, normally the supplier payable/RWN basis; `buyer_weight` is buyer-received net supported by mandatory inbound Receiving Report, and is the Customer Invoice quantity; `scale_weight` is a separate eligible scale-observed net source. All three are independent. Supplier and buyer weights may differ legitimately. Do not introduce `shipper_weight`, `received_weight`, `purchase_weight` or a universal `net_weight` field, copy buyer quantity into supplier quantity, or let source priority choose a generic winner. `final_weight` has no approved universal commercial meaning. [BR-FLD-001,BR-FLD-002,BR-WGT-001]

The buyer Receiving Report may state material/line received net, gross, packaging unit count and packaging tare. An optional buyer scale ticket does not by itself satisfy the mandatory report. A vendor or carrier scale document is not a buyer Receiving Report. [BR-DOC-001,BR-REC-001]

### 7.2 Supplier settlement selection, strict discrepancy threshold and independent buyer AR

The supplier **Received Weight Notice** normally states `supplier_weight` and the agreed supplier purchase price and deductions. Where the supplier/buyer discrepancy is **strictly greater than 5%**, the supplier RWN requires **recorded human reconciliation**, using scale_weight only as reference evidence; no scale substitution is automatic. Exactly 5% does not switch. The current formula uses `abs(supplier_weight-buyer_weight)/max(supplier_weight,buyer_weight)`, but the formula's status remains current-code/provisional until the operator resolves D13, including extra prior-plan predicates. Do not use `weight_discrepancy_flagged` or two separately close-to-CST comparisons to waive the direct commercial discrepancy or authorize a substituted RWN. [BR-SET-001,BR-SET-002,BR-SET-003]

A valid buyer Receiving Report does not fabricate supplier weight. Without accepted supplier payable quantity or an explicitly authorized D14 fallback, hold the **RWN** only and continue buyer invoicing using accepted `buyer_weight` and native sale terms. Supplier PL and supplier scale ticket are optional documents; their absence is not itself a notice blocker if payable quantity is independently known. Likewise, carrier scale documentary compliance is not a notice blocker, although the >5% exception can factually require valid scale measurement. [BR-SET-004,BR-REC-002,BR-CAR-002]

Supplier AP application/adjustments follow purchase terms, validated deductions and native Accounting. The RWN is not a payment or posted-bill receipt. D02 remains open only for approved financial mechanisms; it does not reopen the already accepted normal supplier settlement basis or buyer quantity authority. [BR-SET-005]

### 7.3 CST gross, CST tare, CST net, packaging tare, net weight billed

**CST means carrier Certified Scale Ticket.** This term differentiates the required carrier certified document from optional supplier/buyer scale tickets that may not be certified. Verify certificate/issuer and ticket-to-load identity. For a valid CST, the **operator-approved arithmetic** is:

```text
CST gross - CST tare = CST net
CST net - packaging tare = net weight billed
```

**Example:** 72,000 lb CST gross − 32,000 lb CST tare = 40,000 lb CST net; ten Gaylords on ten pallets = 800 lb packaging tare; **net weight billed = 39,200 lb**. Do not call the intermediate CST net 'net weight billed'. An explicitly packaging-excluded source value is retained as net weight billed and is not reduced again; it never redefines the intermediate CST net. A bare net label is insufficient to prove packaging exclusion. For authorized exceptional `scale_weight` use, the candidate is packaging-adjusted material net, not raw gross or CST net before packaging. Do not overwrite `supplier_weight`, `buyer_weight`, computed `gross_weight`, or `final_weight` with a new unapproved concept. [BR-CST-001,BR-CST-002]

Both **certified** carrier gross and net evidence are required per load. One qualified ticket can provide both observations, but a generic `SCALE`/`scale_ticket` classifier or an uncertified ticket does not fulfill the CST obligation. Heavy/light readings may derive an intermediate net, but the derived value must be labeled calculated and the evidence-completeness decision follows D03. Do not assume that two arbitrary scale readings form a valid pair: match load, vehicle/equipment, scale/source, time relationship, unit and revision.

The invariant is **CST gross minus corresponding CST tare equals CST net; CST net minus applicable packaging tare equals net weight billed**. Packaging tare is a separate business calculation: **40 lb per Gaylord, 40 lb per pallet, and 80 lb for a Gaylord on a pallet** when the stated source weight has not already had that packaging deducted. Ten Gaylords on ten pallets can total **800 lb** of packaging tare. A reported net of 40,000 lb that already excludes packaging stays 40,000 lb, never 39,200 lb from another deduction. Mixed packages/boxes need D15; one `unit_type` cannot silently represent arbitrary combinations. [BR-WGT-002,BR-WGT-003,BR-WGT-004]

Do not store CST gross into `plasticos.transaction.gross_weight`, which is currently a computed selected-source value, unless the authoritative model contract is deliberately and safely changed. Retain raw gross/net/scale pairing in source-linked extraction evidence and display it from the document view when no semantically correct scalar exists. This is not a license to add a new field or to claim raw values were applied to a field that does not exist. [G11]

### 7.4 Missing, zero, units and discrepancies

Unknown is not zero. A zero-weight rejected load is explicit exceptional evidence, not a missing value and not a routine positive invoice. Negative measurement, impossible arithmetic or missing unit creates a specific exception. Do not infer pounds from magnitude, dollars from a symbol in an unrelated currency context, or a timezone from server location.

Use native UoM conversion and currency/precision policies after verification. Keep original units and converted values linked. Ambiguous "tons" needs its actual meaning resolved. Rounding follows the relevant native quantity/currency precision, not arbitrary hidden tolerances.

The operator has accepted the **strictly greater-than-5%** supplier RWN exception threshold. Exactly 5% is not greater. The current max-denominator computation is a verifiable source implementation, not necessarily an independently approved commercial denominator; bind D13 denominator and human adjudication evidence before consequential disputed settlement. Compare buyer, supplier and scale evidence separately; missing comparison is not zero variance. The discrepancy flag is not an approved deduction. [BR-SET-002,BR-SET-003]

### 7.5 Per-load/material allocation and logistics detail

Only apply a quantity explicitly associated with that load/material/line, or a deterministic aggregation of individually evidenced components. A combined shipment total is never copied to every load or divided equally without source-supported allocation. Native sale/purchase invoice lines must preserve material/UoM associations.

For seal/trailer and other references, preserve leading zeros, exact text and revision. Corrected seals or dates are chronological facts, not last-arrival-wins overwrites. Compare actual versus scheduled events before writing; use existing state-transition methods and date owners, not unsafe context bypasses. Container and chassis values do not belong in `trailer_number`; retain evidence and resolve their destination as a representation gap. [G12]

### 7.6 Existing consumer closure

Before altering `final_weight`, `gross_weight`, `weight_source`, tare or deductions, census all relevant reads, stored computes, views, order/invoice preparation, transaction financial rollups and commission/dashboard consumers on the actual target revision. Preserve existing outputs or explicitly migrate their meaning. Do not leave a visible column claiming "Material Weight" while its compute has become blank or unrelated.

Do not solve this by expanding into a dashboard redesign or historical re-import. If a consumer is outside the currently selected slice, record the necessary minimal dependency and retain backward-compatible behavior until its bounded change is admitted. A model field's continued existence is not compatibility proof.

## 8. Business gates and document tracking

### 8.1 Operation-specific gates derived from BRS

| Condition | Capture/validated facts | Supplier RWN | Customer Invoice | Carrier scale follow-up |
|---|---|---|---|---|
| Buyer Receiving Report missing or invalid | Keep independent source facts; no false buyer Receiving Report acceptance | Hold final RWN (comparison/report prerequisite) | Hold **full-load** Customer Invoice | Independently continue |
| Valid buyer Receiving Report; accepted supplier_weight; difference ≤5% | Keep both source weights | Use supplier_weight + approved supplier price/deductions | Use buyer_weight + native sale terms | Independently continue |
| Valid buyer Receiving Report; supplier_weight unavailable | Apply independent buyer facts | Hold RWN quantity pending D14; do not copy buyer weight | Eligible | Independently continue |
| Valid buyer Receiving Report; discrepancy >5%; qualifying scale evidence and D13 resolved | Preserve all original source fields | Use eligible scale_weight; do not overwrite supplier_weight | Eligible on buyer_weight | Independently continue |
| Valid buyer Receiving Report; discrepancy >5%; scale missing/unqualified or D13 unresolved | Preserve evidence/exception | Hold **only disputed RWN selection** | Eligible on buyer_weight | Continue obligation/penalty if eligible |
| Supplier PL absent, but payable quantity otherwise supported | Keep missing PL state if applicable | PL absence alone nonblocking | PL absence nonblocking | Unchanged |
| Carrier gross/net absent or incomplete | Track required but nonblocking | Ordinary RWN documentary gate unaffected; exceptional scale fact may matter separately | Eligible; commercial close not blocked solely by scales | Required evidence remains due; $150 action only under approved rule |
| RWN transmission fails, but accepted Customer Invoice terms hold | Track outgoing exception | Retry/reconcile outcome safely | Independently eligible | Unchanged |

Eligibility never bypasses actual company, identity, price/UoM/tax, authorization, effective permissions or native posting/send rules. Distinguish documentary completeness from the facts required for an individual financial decision. [BR-SET-004,BR-REC-002,BR-CAR-002]

### 8.2 Checklist truth

**Two independent checks:** certified CST gross/net receipt is a carrier document obligation; source-specific packaging tare is an input to net weight billed. Missing packaging information alone cannot make an otherwise complete CST missing, cannot trigger its $150 chargeback, and cannot hold an independently valid Customer Invoice. Do not silently use zero packaging.

For each transaction/load and responsible party show expected document class/evidence, received source count, current valid source(s), missing/incomplete/conflicting reason, due date when bound, responsible owner and current follow-up/exception. Received and validated are not synonyms. The gross/net requirement needs component coverage, not just existence of a `SCALE` or `CST` tag. The verified existing PlasticOS `tag_cst` (`code CST`) is a reusable carrier label, **not** standalone proof of certification.

Existing `doc_category`, rule/matrix models, source associations, missing flags and native activities are starting surfaces. The current category missing flags must not be the only evidence when they cannot distinguish two sources using the same tag. Requirement evaluation should consider the correct party and operation. A supplier scale ticket does not accidentally satisfy an unrelated buyer receiving requirement.

Default Odoo `active_test` already excludes inactive records in ordinary searches; the earlier blanket inactive-document finding was too broad. Current/superseded/expired validity and explicit context overrides remain material test obligations. Preserve this correction rather than duplicating a false finding. [G09,G10]

### 8.3 Required-but-nonblocking scales after close

The carrier owes gross and net evidence on every load even if the buyer has been invoiced and the transaction is commercially closed. Keep collecting and assessing the bound penalty independently. Update the existing `required_for_close` use so it cannot covertly reintroduce a scale-document hold contrary to U01. Commercial close is not a statement that all documents arrived.

A penalty does not mark the ticket received. A resolved claim can explain the financial disposition of the missing obligation while the original checklist still records absence or an explicitly accepted exception. Never generate an empty scale record or set verified merely to make a dashboard green. Ensure closed-state cron domains do not abandon unresolved scale obligations.

## 9. Received Weight Notice: supplier settlement output

### 9.1 Outbound identity and readiness

**RWN is generated by Scrap Management for the SUPPLIER. It is never the buyer's incoming Receiving Report.** An accepted buyer Receiving Report is required to establish the buyer-side comparison, but does not alone provide supplier payable quantity. An ordinary qualifying notice uses `supplier_weight`; strict >5% uses eligible `scale_weight` only after D13 conditions. Unknown supplier quantity without D14-approved alternative holds the RWN and creates a targeted exception while buyer AR proceeds. No PL, optional supplier/buyer scale ticket or carrier scale **document-compliance** obligation is an automatic prerequisite. [BR-DOC-001,BR-SET-001..004]

Use native supported outbound identity based on transaction/load and accepted settlement inputs: chosen weight source and revision, buyer-report comparison revision, purchase price/terms and deduction revisions, purpose and recipient. Replaying an identical source must not resend or create a second notice; external mail delivery acknowledgement remains distinct from document generation.

### 9.2 Content and arithmetic

RWN includes supplier/our identity, supplier PO/TX/load reference, material, relevant dates, **selected supplier settlement net quantity and unit**, agreed supplier **purchase unit price**, gross payable amount, approved light-weight deduction and other applicable authorized chargebacks/penalties with sign and currency, **net amount due** when determinable, and revision/status on a correction. Do not apply source-proposed deductions without existing contractual/claim/accounting authority. If price, line allocation, tax/currency or deduction amount is unresolved, hold the affected final notice rather than send invented totals. An RWN is not a native posted Vendor Bill or evidence of funds disbursed. [BR-SET-001,BR-SET-005]

Supplier-declared weight and optional buyer comparison can appear if supported and permitted by the disclosure policy. Avoid repeating gross/net/packaging deductions on already-net quantities. Only approved corrections revise notices, with original content/recipients retained.

### 9.3 Double-blind and recipient controls

Do not disclose buyer identity, receiving facility/address, resale/SO price, gross margin or an unredacted buyer Receiving Report attachment by default. The buyer Receiving Report can supply the comparison quantity without transferring buyer identity. The notice uses a verified supplier contact from existing authorized commercial relations, not an arbitrary sender email copied from an attachment. Validate sending company, reply identity and the exact recipient; record the rendered content and all relevant financial figures.

### 9.4 Native action, idempotency and independent AR

First locate an existing valid report/template and use native `mail.template`/report/queue; no new RWN table or parallel document system. Queue only after committed accepted facts; keep prepared/queued/sent/failure/unknown states separate. Corrections to quantity, price, deductions or terms can produce a marked corrected notice with full lineage. Do not blindly retry unknown external send outcomes. Failed/held RWN does **not** block Customer Invoice creation/posting/sending, which uses `buyer_weight`. [BR-EVD-004,BR-REC-002]

## 10. Customer Invoice specification

### 10.1 Inputs and native ownership

The inbound buyer Receiving Report supplies accepted `buyer_weight` and delivery facts, independent from the outbound supplier RWN settlement selection. The accepted native SO/order lines supply product, agreed sale price, units, currency, taxes, account and commercial billing policy. Claims/deductions alter the invoice only when authorized by the proper business rule. Extracted text cannot unilaterally reprice the sale. [U01,G19,N03]

Create or reconcile an existing native draft, link it correctly to the transaction and native order lines, and post/send automatically when deterministic validations and actual authorization allow. Do not add universal human approval just because accounting or AI is involved. Do not let a document verification checkbox post every draft associated with the transaction.

### 10.2 Preconditions

Require a valid current report, unambiguous buyer/company/order-line identity, explicit compatible quantity/UoM, correct accepted price/tax/currency, eligible delivery/invoicing policy, no unresolved discrepancy that actually invalidates this buyer quantity/price/action, no duplicate move/action, and permitted posting/send lifecycle. No supplier packing/weight or carrier scale requirement is added to this gate.

If the report is partial, multi-product or multi-load, use actual native line allocation and existing transaction relation cardinality. If those cannot express the case safely, create a targeted allocation exception while preserving the source and other valid facts. One customer PO is not proof of delivered quantity, and a buyer document called "invoice" is not authority to create a second AR invoice.

### 10.3 Replay and corrections

Duplicate protection must cover source evidence, intended invoice, native post and outbound message separately. Matching by free-text `invoice_origin` alone is insufficient where company, multiple order references or explicit transaction relationships disagree. Resolve actual owner relations and test all supported paths. [G19]

A posted invoice is not silently overwritten when a corrected Receiving Report arrives. Use supported native credit/debit/correction behavior with exact original linkage and an approved adjustment. Cancellation/closed-period/closed-transaction guards must remain effective unless a specifically authorized minimal policy revision changes them. Neither invoice reconciliation nor a remittance notice means money has cleared.

## 11. Carrier gross/net requirement and $150 chargeback

### 11.1 Requirement and applicability

Each load requires **carrier-provided certified CST evidence** establishing CST gross and CST net for that load, with consistent CST tare arithmetic where evidenced. Validate the packaging-adjusted net weight billed separately. Missing packaging evidence alone does not invalidate otherwise complete certified CST receipt or create its $150 penalty. Supplier scale tickets and buyer scale tickets are optional and may be uncertified for their parties and do not automatically discharge the carrier document obligation. Track who submitted the carrier evidence, the actual issuer, load/vehicle/time references, the individual components and validity. Missing gross or missing net means incomplete evidence. One valid document can contain both; a meaningless file count, generic SCALE tag, or uncertified carrier source cannot satisfy this rule. The CST net (gross minus CST tare) is not automatically the net weight billed (CST net minus applicable packaging tare). [BR-CST-001,BR-CST-002]

The chargeback amount is $150. Do not use historical $300 CST amounts. Do not charge the supplier/buyer, copy the charge onto AR, or apply it once for gross and once for net. The proposed event unit is once per load/carrier; confirm in D04 before autonomous realization. [U01]

D01 binds the qualifying deadline: trigger event, time unit, timezone, grace, any notice prerequisite and effective scope. Old follow-up thresholds are not automatically the penalty deadline. D03 binds what counts as acceptable gross/net, especially derived net from a pair. D05 binds applicability to accepted carrier terms and native accounting treatment. No need to block RWN/AR while these penalty details are unresolved.

### 11.2 Decision table

| Evidence and policy | Required system behavior |
|---|---|
| Gross and net valid, received by deadline | Complete that requirement; stop scale reminders; no charge. |
| Evidence absent/incomplete, not yet due | Outstanding required evidence and reminders; no premature charge. |
| Due rule or event unit unresolved | Pending requirement/decision; no autonomous financial action. |
| Original received by deadline but extraction failed | Processing exception first; do not blame carrier from our parser failure. |
| Qualifying evidence incomplete after bound due rule | Assess one $150 carrier event under approved applicability; buyer flow remains unblocked. |
| Both components missing for same event | Still one $150 under the once-per-load rule, not $300 or daily recurrence. |
| Carrier bill not yet available | Pending chargeback/claim, not a fabricated bill or paid adjustment. |
| Carrier bill already paid / wrong currency / disputed applicability | Existing approved correction route or specific accounting exception; no silent cash deduction. |
| Late valid evidence after assessment/post | Update receipt; apply bound waiver/reversal rule only; retain financial and evidentiary history. |

### 11.3 Existing owners and actual financial effect

`plasticos.penalty.rule` already has `documentation`, `fixed`, `penalty_rate`, partner scoping and grace fields. At the pinned revision its calculation branch does not evaluate documentation. Extend the existing owner with this actual requirement, not another penalty engine. Do not turn a business-day deadline into a simple `grace_period_days` number if the field cannot represent its meaning. [G06]

`plasticos.claim` already has `freight_chargeback`, transaction/load linkage, currency, claimed/recovery amounts, assignee and lifecycle. Use it for the appropriate case/evidence/exception. A claim for 150 is not recovered cash. `plasticos.invoice.adjustment.action_apply_adjustment` currently marks applied and writes chatter, not an accounting journal entry; that is not acceptance evidence for the finished chargeback. [G08,G18]

For an eligible unpaid freight bill, an approved native vendor credit/adjustment is a reuse candidate. The accounting owner must confirm the sign, tax/account, vendor, company, original bill and legal/commercial document direction. Do not forge a supplier-issued credit, invent a journal, or charge a paid bank account. A different agreed carrier debit route remains an explicitly bounded decision.

### 11.4 Economic-once rule

A $1,200 freight bill and approved $150 carrier credit should yield $1,050 net freight cost and exactly $150 economic improvement, subject to applicable tax treatment. If the transaction already sums signed freight credits and also adds the claim `recovery_amount`, margin can increase twice. Test invoice totals, vendor balance, claim display, transaction cost/margin and commission together. Use one authoritative financial effect and derive displays from it; do not make claim state a parallel ledger. [G11,G18]

Duplicate cron execution, multiple missing components, repeated source delivery or a crash after posting must not create a second case, credit or outbound notice. Resolve existing effect identity before retry. Late ticket arrival may stop future reminders but never deletes the posted credit or silently refunds the carrier. Keep financial recognition separate from bank settlement.

## 12. Supplier/freight AP and the remaining document classes

Supplier and carrier bills use native invoice digitization and existing purchase/freight terms. Recognized vendor, reference, date, lines, price, tax/currency and totals become a draft/reconciliation candidate. The automatic posting gate checks correct party/company, duplicate reference/context, agreed quantities/prices and approved charges. OCR confidence alone does not pass these checks. [N03]

Supplier AP normally uses accepted `supplier_weight` for its purchase quantity. The selected supplier-side settlement/RWN basis may change **only after a recorded human decision** for a strict >5% direct discrepancy with supported contract and evidence; scale_weight remains an independent reference; never silently replace supplier quantity with `buyer_weight`. Missing supplier quantity holds the affected RWN/AP decision, **not the Customer Invoice**. Native auto-post must obey the actual purchase terms, deductions and approved authority.

Consolidated invoices stay one commercial invoice. Current bill exclusivity and single/multiple transaction relations must be proven sufficient before automatic allocation. Preserve evidence for all cited loads even when native accounting allocation needs a bounded decision. No second importer or new invoice-per-load duplication is permitted. [P01,G19,G21]

Other coverage includes order confirmations, packing/manifests, BOL/POD, transport identifiers, certificates/lab reports, quality/damage/rejection claims and photographs, contracts, correspondence, remittances and onboarding. Each class has fields, authority, destination, validation and exception in the matrix. Sensitive bank/tax/legal entity changes remain protected owner actions. A certificate does not redefine global material taxonomy. A claim does not establish liability by itself. Remittance is evidence, not cleared payment.

## 13. Follow-up, exception queue and operator workspace

Use native Documents and existing transaction views, not another dashboard system. The transaction should expose receipt-derived facts, relevant originals, source-specific weights, per-party document obligations, independent RWN/AR statuses, and unresolved review/penalty items. Review cards should show the exact reason, document/source location where available, candidate target/change, current value, why validation failed, responsible owner and next permitted action.

Preserve the historical intent of daily party-specific email/SMS collection where the actual channel, recipients, business calendar and policy are authorized. Retain the documented supplier pickup+1, carrier pickup+2 and buyer delivery+1 collection starts and 5/6/5-business-day escalation intent. Bind the actual calendar/recipients/provider and resolve any conflicting source through D09; do not silently replace collection policy or treat it as the carrier-penalty deadline. No missing SMS setup should block receiving/AR or make a required follow-up disappear; surface the channel limitation and use only an approved fallback. [H01,P02,D09]

A manager activity represents an exception or genuinely overdue requirement, not a routine AI touch. Assign the actual business owner, not whichever service user ran the cron. Dedupe open activities by affected record/requirement/reason and keep daily attempts distinct from duplicated unresolved tasks. Stop only the requirement that is satisfied, not all reminders because some document arrived.

Crons must cover the whole eligible backlog with bounded pagination and respect source time, event dates, calendar and state. Closed commercial records with missing scales remain eligible for collection/penalty follow-up. Use savepoints/transaction boundaries proportionally so one bad document does not lose unrelated accepted evidence or create partial duplicate effects.

## 14. Security, retention and safe execution

### 14.1 Access and confidentiality

Model ACLs are additive. A broad internal-user create/write/unlink grant is not restricted by adding another role-specific row. Audit actual grants plus record rules and native attachment permissions. Protect compliance-rule changes, verification and overrides at callable ORM entry points, not merely by hiding buttons. No document content can grant authority to modify those controls. [G15]

Bind company and legitimate target record across native document, legacy association, load, order and accounting move. Do not rely on a UI domain to enforce it. If the legacy polymorphic association lacks an adequate existing company/record-permission route, document the smallest representation gap rather than pretending a free-text `res_model/res_id` pair enforces isolation.

Double-blind supplier/buyer handling applies to outgoing documents and to searchable metadata, folder names, previews, shared links and exported evidence. Existing native attachment centralization can change linked-record access, so test effective permissions after synchronization and reclassification. No confidential source is exposed simply because the outgoing notice is allowed.

### 14.2 Retention and integrity

Retain the original file and accepted interpretations, rule/prompt/provider versions, actor, prior/new values, validated target and effects. Use existing source-linked attachments and native audit records where sufficient. Preserve missing provenance as an explicit limitation; do not fake page coordinates or extraction evidence.

Prevent destructive cascades from erasing financial/document history. Archive/supersede under existing semantics and preserve the original. Native trash/retention policies are runtime configuration to inspect, not indefinite retention proof. Recovery/restore actions are separately authorized; this campaign does not execute them.

### 14.3 Transactional effects

Fact application, evidence association and action intent must be recoverable coherently. Outgoing emails and posted journal entries have different irreversibility properties. Stage external sends through the native durable queue after committed business state. Reuse native posting lifecycles with immutable source/event references. A caught exception must not create a false success or consume the retry state while leaving an effect unknown.

An actual send with an unknown provider response requires outcome reconciliation rather than promising impossible universal exactly-once delivery. Within the application's durable identities, prove no duplicate business-action creation and no unconditional resends. A valid financial move may survive a worker failure; retry must inspect its identity/state before doing anything again.

## 15. Campaign sequence and concurrency

S00 binds inputs, policy delta and actual environment/branch state. S01 executes the protected user plan as a bounded opening result. S02 provides the necessary integrity/financial controls. S03 native intake/extraction discovery and preparation can proceed alongside S01/S02, but concurrent edits to shared native module files must be serialized. S04 joins actual extraction to safe matching/synchronization. S05 produces validated receiving facts. S06 and S07 independently consume them for supplier notice and Customer Invoice.

S08 develops truthful document requirements/follow-up from S04 without delaying S05. S09 realizes the $150 carrier rule after S08 and its bounded policy decisions. S10 AP and S11 remaining classes use the same foundation without gating the first useful receiving-to-AR outcome. S12 proves and rolls out the full declared scope. See the exact task/dependency graph in `ROADMAP.md` and `campaign.json`.

Do not turn logical independence into uncontrolled simultaneous writes. The same `transaction.py`, `document_sync.py`, compliance service, template file or test database has one active writer at a time. Separate scope branches, assign an owner for shared integration hunks and reuse accepted receipts when exact source/config/fixture identity stays valid. Parallel source inspection or fixture preparation can be safe even when implementation must serialize.

Every slice has its own outcome, owner paths, exclusions, acceptance and stop conditions. Completed bounded work stays closed unless new evidence demonstrates a contradiction requiring an explicitly authorized revision. Defer optional aesthetic refactors, folder redesigns, generic workflow engines and unrelated CI changes.

## 16. Evidence, acceptance and rollout

The 180 cases in `ACCEPTANCE.md` specify positive, adverse, replay, concurrency, source-trust, company, accounting, notification and correction behavior. They are NOT_RUN Odoo/runtime cases in this compilation. Source/machine-graph validation cannot promote them to PASS. Historical CI results at the same SHA are context, not proof that the new campaign exists.

Use a verified disposable production-equivalent Odoo 19 Enterprise environment with the necessary actual addons and fresh bounded fixtures. Capture exact code head, installed module versions, native provider/config version, test identity/command, database identity, fixtures and observed ORM/move/message outcomes. Block destructive or external send/post tests unless they are isolated and authorized. Intercept email/SMS in tests and use explicit providers/stubs only for what they actually prove.

The first full golden-path fixture deliberately lacks the supplier Packing List and optional supplier/buyer scales, and also lacks required carrier **certified CST** gross/net tickets, **but does include independently supported supplier_weight and an accepted buyer Receiving Report with ≤5% discrepancy**. The RWN must then confirm `supplier_weight` and supplier purchase price/approved deductions; the Customer Invoice must use `buyer_weight`; the carrier obligation persists and one $150 event may be realized only under approved due/applicability terms. A separate negative fixture lacks supplier_weight and must hold only the RWN while customer invoicing still proceeds. Replay must not duplicate any outcome.

Activation proceeds through read-only/shadow observation, bounded authorized fact application, then eligible notification/accounting actions and observed operation. These are deployment stages, not new platform components. Use existing native controls and exact configuration. Disable unsafe automation without losing original sources or native pending work; test recovery and corrections before widening volume.

Measure actual documents by class, accepted fact/application results, touchless completions, human minutes, exception reasons, missing-document age, duplicate effects, incorrect associations, send failures and penalty outcomes. Define denominators explicitly and do not invent an accuracy percentage or arbitrary review target. A single wrong financially material update is investigated even when most documents work.

## 17. Final closure and scope boundaries

Close each confirmed finding as fixed, already satisfied/invalid or explicitly blocked with owner and next evidence. The package accounts for 26 tracked findings; it does not declare them all fixed. Carrier timing unknown blocks only automatic carrier assessment; Unresolved supplier price/deduction terms hold only the affected RWN financial content and Vendor Bill, not independently valid buyer_weight or Customer Invoice. Missing actual native extraction capability is a genuine dependency for live automation and needs a bounded adapter decision, not invented installation claims.

This campaign excludes bank settlement/payment execution, broad historical import, rebuilding Gate/CEG/EIE, a parallel DMS/accounting engine, global taxonomy redesign and speculative third-party document platforms. A new field/model/service is admitted only for a proven current obligation that existing owners cannot represent correctly, with explicit scope and operator approval.

**Roadmap completion is not implementation completion.** This BRS-bound campaign pack is ready to guide coherent slices. ADR-025 and brs-documents are in the ZIP as proposed repository source additions, not accepted current Git files; brs-logistics is deferred. All consequential technical actions must use exact brs-documents IDs and native model fields. It does not authorize a commit, PR, merge, deployment, production data write, invoice post or message send. The next activation is the existing plan's exact-head S01 handoff under the small policy delta, not a new full-campaign coding prompt.


## 18. Exact three-lane field, source-fact and native commercial handoff

The companion `FIELD_ROUTING_AND_CONFORMANCE.md` is a generated, source-bound field ledger for **147** touched native/PlasticOS fields, party-scoped raw facts, eight document-routing cases and supplier RWN/customer invoice/vendor bill/penalty consumers. `campaign.json.field_routing_contract` is the machine-readable derivative of `brs-documents` §11 and the inspected Odoo model declarations. **It is not a new runtime schema, Odoo model, or a second business authority.** Business rules live only in `brs-documents`; this technical mapping can be revised only after exact current source and BRS meaning are reconciled.

### 18.1 Ingest, qualify, preserve, apply, consume

1. **Document intake:** native Odoo Documents owns attachment, native tags, folder, mail alias, and AI candidate extraction. Each original retains source message and attachment identity. Do not duplicate originals just because two parties sent copies. The source evidence must identify exact logical part and scope before any write.
2. **Identify issuer and business lane:** document role must be independently established against `plasticos.transaction.supplier_id`, `buyer_id`, `carrier_id`, `plasticos.load.carrier_id` and exact company/load. Sender/filename alone never chooses the owner. Compare issuer to allowed documents: PL/optional supplier scale, required buyer Receiving Report/optional buyer scale, or carrier-required certified CST.
3. **Parse per-source physical measurement and packaging:** source gross, paired source/CST tare, source/CST net, per-unit counts and packaging deductions are **source-linked facts**, not invented ORM fields. Parse raw amounts, original units and explicit basis, then normalize pounds using native Odoo UoM. Separate truck physical CST tare from material packaging tare; source optional scale tare has its own issuer.
4. **Validate arithmetic and scope:** same load/trailer/time/issuer, independent material/product lines, gross >= paired tare, net basis explicit and packaging already-included/excluded known. A valid stated net that already excludes packaging is not reduced a second time. Unknown package counts remain unknown. Do not equal-split a combined total across loads.
5. **Apply existing transaction scalar only with accepted evidence:** supplier material net → `supplier_weight`; buyer Receiving Report material net → `buyer_weight`; valid eligible source scale material net → `scale_weight` (not a global settlement winner). Other original readings stay linked as evidence with enough keys to replay/correct. If the installed metadata cannot represent a required fact or durable action identity, D08 blocks only that action.
6. **Generate commercial output through owning native flow:** RWN supplier settlement normal `supplier_weight` and agreed purchase price, or eligible exceptional `scale_weight` after strictly >5% plus D13; Customer Invoice uses `buyer_weight` linked via native Sales line invoiceability into `account.move.line.quantity`; supplier Vendor Bill via native purchase/bill matching. Do not directly write native computed qty-to-invoice fields. Missing supplier quantity or carrier CST does not independently block buyer invoice.
7. **Track obligations distinctly:** Buyer Receiving Report remains mandatory for full buyer billing; supplier PL and optional supplier/buyer scales do not become hard blockers; carrier CST gross/net is required per load but is independent of packaging readiness and commercial close. Missing valid CST can trigger one $150 carrier chargeback only when due/applicability rules are authorized.
8. **Prove correction and idempotence:** accepted revisions, replacements and invoice/note corrections must not duplicate documents, weights, RWN, invoices, claims, bill credits, or count recoveries twice. Existing `final_weight`/`gross_weight`/`weight_source`, deductions and dashboard consumers require specific backward-compatibility proof before semantic changes.

### 18.2 Agent contract before each slice

For the selected slice, load `brs-documents` exact version, **FIELD_ROUTING_AND_CONFORMANCE.md** relevant section, actual Odoo field declarations and tests; bind source, party, logical document, load/material, source basis, exact write target, authorized owner, and independent downstream consumer. Record open D08/D13/D15 instead of guessing. Deliver linked acceptance case IDs and evidence for actual runtime behavior; package-level validation cannot make a skipped/absent real Odoo test green. Avoid running unrelated full suites twice. This makes the pack comprehensive without appending dozens of requirements to the unchanged S01 starting-plan file.

## v1.2.1 accepted weights and underweight obligation policy

**Governing concerns:** `BRS-003@1.0.1` owns five definitions verbatim from the operator: **Document measurement** = the quantity shown on a PL, Receiving Report or scale ticket; **Load net** = gross less corresponding vehicle/CST tare; **Packaging tare** = packaging weight; **Material net** = load net less applicable packaging tare or independently verified material-only net; **Accepted commercial weight** = validated material net used for supplier or buyer settlement. Carrier CST arithmetic remains `CST gross − CST tare = CST net`; `CST net − applicable packaging tare = material net` (carrier legacy label “net weight billed”). Certified `scale_weight` is a reference only, though it is the preferred *display* weight ahead of buyer and supplier weights. All three pairwise comparisons are diagnostic, but the direct supplier/buyer material-net discrepancy determines the strictly >5% **mandatory human review**. Source denominator/rounding stays D13. [U06,BR-VOC-001,BR-WGT-010]

**Obligation-scoped underweight:** `BRS-007 BR-UND-002` is the sole formula owner. With a valid applicable 53-foot contractual 40,000 lb material-net minimum, shortfall below 2,000 lb produces no eligible charge. Starting at 2,000 lb inclusive, effective rate = `contractual_base_rate_per_2000_shortfall * (shortfall_lbs / 2000)` with default business base `$0.01/lb per 2000 lb` and continuous interpolation for partial 500 lb increments (no floor/ceil). Total = **actual accepted obligation-specific material net** times effective rate; retain precision and round only the final USD amount to cents half-up. E.g., 38,000 lb -> $380; 37,750 lb -> $424.69; 36,000 lb -> $720. D17 arithmetic resolved; D16 application/party liability/native posting remains open. Distinguish the carrier missing-certified-CST $150 document chargeback. [U07,BR-UND-001..007,D16,D17]

**Technical migration proposal, not current schema:** Keep existing `minimum_net_weight` and `light_weight_deduction_rate`. Propose `light_weight_deduction_total` as a replacement for the existing `light_weight_deduction` and the Odoo monetary computed method `_compute_light_weight_deduction_total()`, not `_compute_weight_deduction()`. Treat `light_weight_deduction_weight` as a pure calculation output unless separately approved as an ORM field through D08. Retire the obsolete `dead_freight_chargeback` Boolean and universal `final_weight` after enumerating real installed consumers. Current Odoo source performs the wrong zero-rate fallback and charges shortfalls below 2,000 lb; these are **not** implemented fixes in this pack. [G23,U06,BR-UND-004,BR-UND-005]

## v1.3.1 indexed BRS authority and corrected monetary formula

The current BRS authority in this **proposal pack** is **`brs-documents@1.3.1`**, a non-normative index at `docs/business-rules/README.md`/`index.json`, resolving **seven numbered, independently owned files BRS-001..BRS-007**. The seven files own all 46 stable `BR-*` IDs exactly once. Agents must inspect each owning `BRS-NNN@1.0.0` at its indexed SHA and rule IDs; unnumbered predecessor BRS files are historical only. ADR-025 has been updated to make this numbering/index/CI discipline explicit, pending actual repository admission.

The operator-resolved **BRS-007 BR-UND-002** LWD formula: for an applicable 53-foot 40,000 lb material net minimum, shortfall below 2,000 lb yields no charge; at or above 2,000 lb, effective $/lb rate equals `0.01 * (shortfall_lbs / 2000)`, continuously prorated for partial 500 lb increments (no stepped rounding), and amount equals **actual material net** multiplied by effective rate, with final USD cents half-up. Example 37,750 lb net -> 2,250 lb short -> $0.01125/lb -> $424.69; 36,000 lb net -> $0.02/lb -> $720.00. D17 is resolved for arithmetic; D16 remains for contract applicability, independently attributed buyer/supplier liability, and actual financial effects. Target Odoo runtime/CI are NOT_RUN.

The implementation should reuse verified current Odoo fields. Proposed `light_weight_deduction_total`, method `_compute_light_weight_deduction_total()`, obsolete `final_weight` and `dead_freight_chargeback` retirement are **pending migration**, not present or deleted in the live registry.
