# Cursor Campaign Contract: Historical ERP Document-Blob Reconnaissance

**Issued:** 2026-10-20  
**Execution agent:** Cursor (C), operating locally through Docker  
**Repository:** `https://github.com/cryptoxdog/IB-Odoo_19`  
**Base authority:** `origin/Staging` (case sensitive; bind to the actual checked-out SHA)  
**Campaign:** `erp-document-blob-recon`  
**Mode:** READ / EXPLORE / PROVE / REPORT. **No Odoo import, application implementation, production access, merge, or deployment.**  
**Requested repository destination:** `docs/reports/erp-document-blob-recon-2026-10-20/`

## 0. Operator intent and definition of success

The operator owns a local SQL Server `.bak` backup and wants no hand-run SQL, manual exports, or CSV transfers. PaperSolve has confirmed that historical document content is held as SQL BLOBs. Most valuable: **PDF and JPEG documents**, next **other images, Excel and Office files**; saved emails are lower-priority but **must still be discovered, counted, and given a disposition**. The long-term destination is **Odoo 19 / PlasticOS**, with each file attached to its true transaction or other correctly identified owner through the existing historical SQL import architecture.

**Your assignment is reconnaissance, not migration.** Work inside Docker on the operator's machine, retrieve the actual source facts, establish coverage and reversible relationships, and produce enough verified evidence to specify the next implementation campaign without guessing. Save a sanitized, actionable reconnaissance pack in the repository's `docs/reports` tree. Do not make the operator use SQL. Only interrupt for a genuinely blocking missing asset or consent, e.g. the separate document-database backup is unavailable.

A successful result answers, with measured counts and reproducible evidence:

1. Which SQL backup(s) exist locally and which restored databases do they actually contain? Does the **separate document database** exist, or is an additional `.bak` required?
2. Which source tables and columns contain files, file pointers, document metadata, pages, annotations or saved emails? What do `DocumentImage`, `WksDocument`, and other discovered tables actually store?
3. What is the **complete eligible-source census** by tenant/source database, `RefType`, file format, date, payload size, compression, duplicates, and broken records? Distinguish *SQL metadata census* from *content-inspected census*.
4. What do `DocID`, `ImageID`, `RefID`, `RefType`, and `DBName` mean, and which joins work? Specifically test `DocumentImage.DocID = WksDocument.DocumentID` and alternate reference-key hypotheses; **no inferred meanings without evidence**.
5. Exactly how many source documents link unambiguously to source `BuySellNo`, source PO/SO/invoice/bill/load or other entities, and then to the Odoo objects produced by the current deterministic importer? Count unresolved, ambiguous, source-missing and target-not-yet-imported separately.
6. Which established Odoo 19 model should own each file (`ir.attachment`, Enterprise `documents.document`, `plasticos.document` mirror, native sale/purchase/accounting objects), and are the required modules/fields installed and correctly wired in the Docker target?
7. What are the unavoidable implementation obligations, runtime cost/storage estimate, privacy boundaries, and precise acceptance gates for a **future** import PR?

## 1. Binding evidence and known leads (not conclusions)

Operator-supplied PaperSolve screenshot/email shows a separate SQL database with a `[dbo].[DocumentImage]` table and these visible fields: `ImageID`, `DBName`, `DocID`, `RefID`, `RefType`, `DocName`, `DocType`, `Blob_Image`, `Blob_Size`, `CreatedD`. Visible rows include `RefType` values `W`, `P`, `E`; some `DocName`/`DocType` values are NULL; `DBName` varies in case. The visible BLOB bytes begin with hexadecimal `1F8B08`, strongly indicating a GZIP wrapper **for those examples**, not necessarily every row. Preserve the source identifiers; do not assume what W/P/E mean. A single `DocID` may be a logical document and multiple `ImageID`s may be page/file variants, or not: prove cardinalities.

Existing repository evidence (review in the *current checkout*, since code may have moved):

- `plasticos_partner_import/erp/reader.py`: direct SQL Server reader and existing projection authority. The importer is `reader -> SourceIndex -> mapping/reconstruction -> ORM upsert`, **not** a CSV wizard.
- `plasticos_partner_import/erp/source_index.py`: source-native identity and transaction grouping.
- `plasticos_partner_import/erp/mapping_status.py`: `WksDocument` is currently unconsumed, explicitly because its document files are not carried by the existing export.
- `plasticos_partner_import/erp_extracted_data/06_extract_remaining.sql` and `05_extract_all.sql`: historical slim projection of `WksDocument.DocumentID`, `DocType`, `BuySellNo`, `RefFile`, etc.; large `Field*` text columns are omitted. Inspect their semantics, do not assume they are binary documents.
- `plasticos_partner_import/erp_extracted_data/meta/p0_columns.csv`: source column inventory including `WksDocument.Field01...Field46` as character fields.
- `plasticos_transaction/models/native_document_import.py`: transaction importer generates native SOs/POs/invoices/bills, preserves worksheet grouping and deterministic `ir.model.data` identifiers.
- `plasticos_documents/models/document.py`, `plasticos_documents/models/transaction_docs_bridge.py`: legacy document model and transaction Documents smart button.
- `plasticos_documents_native/models/document_native.py`, `document_sync.py`, and its `__manifest__.py`: Enterprise documents extension and native-to-legacy mirror. The inspected code's sync creates a mirror without explicitly setting its direct `transaction_id`; investigate the resulting smart-button visibility as a **target-readiness finding**, do not silently patch it. The auto-link-by-partner heuristic is unsuitable for historical identity mapping.
- `config/odoo_module_order.yaml`: Enterprise modules and `plasticos_documents_native` are declared for Docker parity. Declaration is **not proof of installation**.
- `scripts/test_env.sh`: protected disposable **Odoo/PostgreSQL** clone lifecycle. `docker-compose.yml` has Odoo/Postgres services, **not a source SQL Server restore service**. Do not confuse these.
- `docs/adr/ADR-021-erp-sql-crm-api-import.md`, `AGENTS.md`, `CLAUDE.md`: repository operational authority.

Existing counts from historical documentation are **not current proof**. The earlier slim `WksDocument` export and older SQL table estimates may disagree; measure the actual restored databases and explain snapshot differences rather than reusing stale numbers.

**Repo legal/naming boundary:** The historical software vendor's proprietary name must not be introduced into repository filenames, newly committed content, comments or tests. Use neutral `ERP`, `source`, `document store`, and runtime-bound SQL catalog aliases. Do not embed the screenshot or source-specific literal SQL database names in committed reports. Capture exact restored database names privately in the untracked evidence manifest if required for replay.

## 2. Authority, source safety, and mutation boundary

**Allowed:** Read the current checkout/commit, inspect Git status and in-flight importer PRs, inspect Docker locally, inspect `.bak` metadata, restore backup(s) into a **newly named isolated disposable SQL Server lab** (or safely use an already verified restored lab), query restored data read-only, sample/decompress files inside isolated containers, create ignored/private local evidence, and write sanitized reconnaissance reports under the specified `docs/reports` path. If required, run read-only discovery against a proven owned disposable Odoo test clone to verify installed model structures and identity coverage. These are not production transactions.

**Forbidden:** Mutate original `.bak`; attach to/restore over a business, unknown, production or ambiguous SQL database; reuse another agent's SQL or Odoo database without identity/ownership proof; run data imports or native ORM writes; alter `plasticos_*` code, manifests, mappings, migrations, Odoo data, CI, or settings; create new authoritative importer/router; deploy or merge; edit unrelated files; delete volumes/containers owned by someone else; publish raw blobs, passwords, personal data, full document titles, paths to private files, emails or screenshots to GitHub, CI logs or third-party services. Never execute Office macros, email attachments or untrusted embedded content. No OCR required.

**Key distinction:** Restoring a `.bak` necessarily writes a *disposable lab database*, which is allowed; source backups remain unchanged. All recon SQL against the restored business data must be read-only. Prefer a read-only principal and read-only connection when feasible. Isolate credentials and suppress database dumps in terminal logs.

**No second importer.** Reuse existing importer identities to *analyze* future attachment integration; do not build the attachment importer in this campaign. A temporary analysis script, running from a private ignored working folder/container, is permitted if it materially improves reproducibility. Keep it out of the product runtime and don't commit speculative pipeline code.

**Git scope:** Dedicated `docs/erp-document-blob-recon` branch from an up-to-date `origin/Staging`, or the operator's already approved non-conflicting branch. First record `git status`, branch, HEAD SHA, and active worktrees. Never reset/discard uncommitted work or pull in unrelated PR changes. This campaign's committed diff must be **report assets only** under `docs/reports/erp-document-blob-recon-2026-10-20/`. For GitHub persistence, use the repo's established Odoo report/PR publishing procedure into `Staging` only, without merging. Do not invent a make target, use org-wide `--SSOT` publication, arm auto-merge, or deploy. If publishing is blocked by policy or tooling, save in the worktree and report the exact blocker.

## 3. Phase A: Preflight, backup discovery, and lab binding

### A1. Discover without guessing local paths

- Verify the checkout is `cryptoxdog/IB-Odoo_19`; record exact `HEAD`, base SHA, timestamp, Git status, current branch. Read the current repository instructions and applicable Docker/read-only-data rules.
- Check Docker daemon/context and available local Docker storage/memory; inspect existing SQL Server lab container(s) and the source-repository Compose stack separately. Identify existing container identities, bound port, database inventory, and ownership. Do not assume a container named in prior chat still exists.
- Locate the operator's local `.bak` **without indiscriminate full-disk crawling or uploading private files**: inspect normal user backup/Downloads locations and the known local workspace, using bounded filename discovery. Record the resolved location privately, backup filename and byte count, but not the private absolute path in Git output. Avoid copying large backups into the Git worktree or Docker build context.
- Inspect `.bak` with supported SQL Server backup metadata (`HEADERONLY`, `FILELISTONLY` or equivalent) in an isolated container before attempting restore. **A SQL Server `.bak` normally backs up a single database, not every database on the server.** Do not assume the transaction backup includes the separate document store. Determine whether one or multiple `.bak`s are required.
- If a verified restored SQL lab already contains both the transaction data and the document database at compatible snapshots, prefer reuse *read-only* with ownership proof. Otherwise construct the smallest private isolated SQL Server lab using an image/version known to support the backup and safely restore to fresh names and volumes. Bind backup files read-only; restore database data/log files only to lab-owned paths; constrain network/ports (local host only if exposed); never overwrite existing database names. The existing Odoo Compose config is not a SQL Server restore spec. Validate candidate image/version/runtime storage capacity before running it.
- Use a **single** source SQL lab; no competing restore pipelines. Record SQL Server version, backup creation/finish timestamps, backup header metadata, database logical name aliases, and checksums/fingerprints where practical. Privately retain connection details, never in tracked files.

### A2. Backup availability gates

- Gate A-PASS: both required source databases available and queryable in the isolated lab, provenance recorded.
- Gate A-PARTIAL: business transaction database available, document store missing. Produce all schema/transaction-side work possible, explicitly mark blob census/content/joins **BLOCKED** and identify missing backup by its expected role; never report zero documents.
- Gate A-BLOCKED: no valid restored source database or unsafe restore conditions. Emit a bounded forensic failure record and ask the operator for only the missing backup/location or runtime resource. Do not fabricate fallback files.

## 4. Phase B: Discover all document-bearing SQL surfaces

Do not restrict investigation to one suspected table. Build an evidence-backed schema catalogue across the transaction and document databases:

1. Introspect DB schemas, names, PKs/FKs/indexes, column types, nullability, computed columns, row estimates, and any views/synonyms/procedures obviously related to documents, images, files, attachments, emails, forms, worksheets, PO/SO and deliveries. Distinguish verified table metadata from guesses.
2. Inspect `DocumentImage` fields and all real keys/uniqueness constraints. Inspect `WksDocument` (`DocumentID`, `BuySellNo`, `DocType`, `RefFile`, date, notes, `Field01...Field46`). Check whether the Field columns are printable form-template contents, URLs/paths, metadata, or actual encoded payloads. Query safely for metadata and bounded examples; never dump entire fields into logs.
3. Find any **other** binary/image/file storage, external filename tables, document indexes, fax/email archives, and orphaned references. Search across both database catalogs based on schema/column types and names. Enumerate SQL `varbinary(max)`, `image`, `FILESTREAM`, large `varchar/nvarchar`, and file pointers, but avoid falsely calling every such column a document.
4. Measure tenant/source `DBName` value variants (including mixed case and whitespace); establish the *authorized* source-domain predicate using transaction database identity and supporting evidence. Report excluded other-tenant counts without importing or exposing their content. Never combine unrelated tenants merely because keys overlap.
5. Inventory `RefType` values (including NULL/blank/unexpected), `DocName`, `DocType`, date span, `RefID`, `DocID`, `ImageID`, `Blob_Size`, actual `DATALENGTH(Blob_Image)`, NULL/zero-length blobs, missing registry references. Compare file/reference coverage to `WksDocument` and other discovered source doc tables.
6. Check source snapshots for timezone assumptions, duplicate rows, invalid IDs, broken backup/schema permissions, missing databases and external file dependencies. Treat repository's old counts as historical signals, not current truth.

Produce a source-surface matrix: `database_alias`, `object`, `role`, `row_count`, `binary/metadata/pointer`, `key(s)`, `parent_ref(s)`, `availability`, `confidence`, `evidence_query_id`.

## 5. Phase C: BLOB science and complete file-type census

**Priority:** PDFs and JPG/JPEG first; also account for PNG/TIFF/other raster images, Excel (`.xls`, `.xlsx`, `.xlsm`), Word/Office, saved email (`.eml`, `.msg`), archives, and unknown/corrupt formats. A PDF is a PDF even when its filename is NULL; identify by content, not by extension or source `DocType`.

- First get a full **SQL metadata-only** census of qualifying eligible rows, compression signatures, sizes, date distribution, and source-type distribution. No full-payload export is needed for this.
- Probe **deterministic stratified samples** across every `RefType`, every discovered source-doc class, years/date buckets, tiny/median/large payload sizes, NULL/blank metadata, and unusual content signatures. At minimum inspect several `W`, `P`, `E` examples if present, plus non-GZIP/NULL/large/collision cases. Record sampled source-native IDs privately and anonymized examples in report.
- Detect GZIP only when bytes actually match the header, then stream-decompress with input/output size caps, CRC/trailer validation, bounded nesting/recursion, and explicit exception codes. Do **not** call `gzip.decompress()` on unlimited input in one large memory allocation. Detect file type from **decoded** bytes (`%PDF`, JPEG `FFD8FF`, PNG, TIFF, ZIP/OOXML, OLE `.xls`/`.msg`, MIME EML, etc.) using safe local signature parsers. Distinguish: raw BLOB, compressed stream, decoded document, embedded wrapper, page image, and inaccessible/invalid content. No macros, external converters, or execution of content.
- Hash raw BLOB and decoded file separately (`SHA-256`), preserving source identity and repeatability. Compare `Blob_Size` to actual length; report whether it describes stored vs decoded size. Record memory-safe bytes read, decode failures, estimated storage requirements and unsupported formats.
- Determine whether `ImageID` means physical image/page, whether multiple rows under one `DocID` represent multiple pages, multiple files or duplicates, and whether a logical PDF can be reconstructed **without inventing page ordering**. Count exact-byte duplicates independently of logical document versions; never silently discard duplicates or email attachments.
- Aim to **content-inspect every eligible BLOB** in bounded, streaming, read-only passes to obtain authoritative full-media counts and hashes. No need to persist all raw files. Before full pass, measure total bytes and forecast disk, CPU and time. If unsafe or prohibitively expensive, complete the metadata census and representative content sample, mark full content coverage `NOT_DONE`, and report measured blockers/cost. **Sampled file types must never be presented as full-population counts.**
- Put any temporarily materialized sample PDFs/JPEGs/XLS in an ignored/private folder outside the Git report, with restrictive permissions, checksum manifest, and deliberate cleanup/retention note. Do not publish sensitive customer images or email content. Store only safe aggregate metrics and sanitized identities in the repo report.

Required format output: per media type `raw_rows`, `decoded_rows`, `unique_image_id`, `distinct_doc_id`, `total_raw_bytes`, `total_decoded_bytes`, `bad_rows`, `gzip_rows`, `coverage_fraction`, plus by-`RefType` cross-tab and date span. Uninspected is **unknown**, not `other`.

## 6. Phase D: Reconstruct source identities and linkage (the central proof)

Map relationships with **full-population read-only joins**, not visually sampled coincidence. Start with these *hypotheses*, discover other actual keys from schema:

- `DocumentImage.DocID` ⇄ `WksDocument.DocumentID`.
- `DocumentImage.RefID`, interpreted in the context of `RefType`, ⇄ candidate worksheet, document, PO, order, invoice, email or other source object PKs.
- `WksDocument.BuySellNo` ⇄ `BuySell.BuySellNo`, `WKSDetail.BuySellNo`, existing native document reconstruction and associated header tables.
- `WksDocument.RefFile` ⇄ actual stored filename/path or file metadata **only if observed**.
- Source order numbers and `BuySellNo` ⇄ existing importer `SourceIndex` → Odoo source-native XML IDs/ORM records (not name/fuzzy match).

For each `RefType` (including `W`, `P`, `E`), record the exact query and count of rows with **0 / 1 / >1 candidate** joins, match rate, conflicting candidates, and secondary evidence (e.g., dates/IDs/source keys). A one-sided numeric key collision is not enough to prove semantics. Where the two linkage paths disagree, keep the document unresolved and report both candidates; never pick one arbitrarily.

**Reconciliation denominators are mandatory:** Blob physical rows, distinct `ImageID`, distinct `DocID`, registry `DocumentID`, source `BuySellNo`, and Odoo transactions are *different units*. State which denominator each percentage uses. Preserve multi-image documents, multi-document transactions, single native order spanning several worksheets, and one worksheet generating sale/purchase/invoice/bill objects. Do not force artificial one-to-one relationships.

Give **every eligible source file/image** independent, non-overlapping classifications on **three axes**. A corrupt payload can still have a verified source link; do not lose that information by forcing one global status:

1. **Source link:** `source_link_verified` (unique and validated source entity/`BuySellNo`), `source_link_ambiguous` (competing valid entities/contradictory keys), `source_ref_unresolved` (referenced source target absent), `source_ref_missing` (no usable key), `nontransaction_document` (positively established non-transaction owner), or `source_link_not_examined` (document-store blocker).
2. **Payload:** `decoded_valid`, `recognized_unsupported`, `missing_payload`, `corrupt_payload`, or `payload_not_examined`. Track MIME/format separately; an unidentified but readable file is `recognized_unsupported` or `unknown_mime`, never silently `PDF`.
3. **Odoo target projection:** `existing_odoo_target`, `importer_would_create_target`, `target_not_currently_realized`, `native_owner_not_decided`, `target_collision`, or `target_not_examined`.

**Do not collapse source proof into target success.** Each axis must reconcile independently to its eligible-row denominator; count total and bytes in each cell, and account for duplicates/pages explicitly. Detect source IDs reused across database aliases and if the same `DocID` has multiple `ImageID`s.

Create a sanitized, machine-readable **linkage matrix** with one row per tested relationship/path (not a dump of private customer documents), including measured cardinalities and counterexamples. Retain the full source-key-level linkage and exception inventory **locally outside Git**, so the next campaign can reproduce or audit every disputed row.

## 7. Phase E: Verify the proposed Odoo destination (no writes)

Review the real checked-out code and, if available, introspect **only a proven owned disposable Odoo test clone** through `scripts/test_env.sh`, not an unverified business DB.

1. Verify exact source IDs, canonical importer source-index records, SO/PO grouping, invoice/vendor bill import identity, and transaction compile boundary. Identify joins to `plasticos.transaction`, `sale.order`, `purchase.order`, `account.move`, `plasticos.load` (only if real source evidence supports each route).
2. Verify the actual installed status of `documents`, `documents_account`, `plasticos_documents`, `plasticos_documents_native`; `auto_install=False` and a manifest dependency are not installation proof. If Enterprise assets are unavailable, record `NOT_PROVEN` rather than creating a CE substitute.
3. Inspect `ir.attachment` binary storage behavior; `documents.document` ownership and native record fields; `plasticos.document` sync; transaction Documents smart-button model/domain; other sale/purchase/accounting attachment access points; ACL, company, and compliance implications.
4. Verify or disprove the suspected `plasticos.document.transaction_id` mirror-link gap by tracing current code. Record whether a future document linked via `documents.document.transaction_id` would actually display under the transaction's smart button; state the minimal owning module to change **if needed**, but do not implement now.
5. The native documents module contains a partner-based heuristic that may attach documents to the newest transaction. **Never use that for historical backfill.** Future imports must match exact SQL source keys to existing canonical Odoo identities; if no unambiguous target exists, leave a reconciled exception.
6. Evaluate whether streaming attachment reads can extend the existing SQL reader/index/ORM importer without marshaling multi-GB byte blobs through the current text-row payload structures. This is an *interface finding*, not authorization to build a second importer.

Produce a target destination decision table: source document family → proposed native Odoo model → exact foreign-key owner → evidence → coverage → missing dependency → migration obligation. Keep `verified=False` for historical document proof until future verification; do not make source import equivalent to compliance verification.

## 8. Phase F: Reconciliation, costs and negative calibrations

**Quantitative invariants** (write exact numbers, no invented percentages):

- Every eligible document BLOB row is counted exactly once in the metadata census, with explicit exclusions by DB source and reason.
- For each classification axis, `seen = sum(all mutually exclusive statuses on that axis)`; no double-counting physical rows versus logical docs/pages. Keep the source-link, payload, and Odoo-target axes independent.
- `matched_unique + ambiguous + no_match = attempted_source_links` for each join path; keep NULL/missing keys visibly accounted for.
- Content inspected count = valid decoded + corrupt/unreadable + recognized-but-unsupported, with `not_examined` tracked independently. Unknown MIME cannot be promoted to success.
- Re-running a representative probe under identical source snapshots yields the **same counts, linkage decisions, content hashes, and exceptions** (no Odoo writes). Source `ImageID` identity and content hash disagreements are blocking findings.
- No cross-tenant linkage; no partner-name, filename, date-nearest, first-result, or fuzzy transaction matches.

**Adversarial/known-bad probes:** At least one row per discovered failure class if available: NULL `RefID`, NULL `DocID`, unknown `RefType`, duplicate `DocID` with multiple images, same reference pointing to multiple records, different DBName capitalization, orphan registry row, orphan image row, `DocType`/actual MIME mismatch, non-GZIP blob, truncated/corrupt GZIP, very large expansion ratio, invalid filename, mismatched existing Odoo target, one sale order spanning multiple worksheets. If natural source data lacks a case, exercise *a read-only simulated fixture* outside application state and say so. Show that the detection rejects or quarantines each, not that it silently routes it.

**Cost report:** full BLOB byte count (compressed and estimated/observed decoded); largest blob and p50/p95; per-format counts; sample throughput and projected full-scan time; Odoo attachment estimated storage; Docker disk and memory limits; whether GZIP decompress is CPU or I/O bound; exact blocker if the full pass cannot safely run. Do not claim duration estimates as measured completion times.

**Security:** Verify that generated tracked outputs contain no raw binary, body text, email addresses, private paths, plaintext secrets, document thumbnails, customer names, or banned vendor naming. Include `git diff --name-only`, output-byte sizes, and a simple sensitive-content scan result in manifest. Do not require uploading any private document to outside services.

## 9. Required deliverables: the recon pack

Create **exactly the smallest sufficient tracked pack** in:

`docs/reports/erp-document-blob-recon-2026-10-20/`

1. **`RECON_REPORT.md`**: Executive answer, evidence-backed schema/backup map, true source/format census, `RefType` semantics, row/doc/transaction linkage funnel, file reconstruction findings, target Odoo-readiness audit, quantitative exceptions, unresolved facts, backup completeness, performance/storage estimate, and a *bounded Phase 2 implementation specification* with acceptance criteria. Start with a concise `Bottom Line`, current status `PROVEN / PARTIAL / BLOCKED`, and a prioritized decision. Include exact SHA/date and proof command IDs, not sensitive command arguments.
2. **`recon_manifest.json`**: machine-readable provenance, report schema/version, commit SHA, Docker image digest/version, SQL backup SHA-256 and backup times (not private location), source database aliases/snapshots, query IDs/hashes, samples and full-census denominator metadata, coverage and integrity counters, feature/module presence with proof status, exception category counts, generated-output hashes, stable rerun evidence, status/blockers. No secrets or raw contents.
3. **`linkage_matrix.csv`**: compact, per tested join path / RefType / target-kind aggregate: source rows attempted, unique, none, multiple, conflict, join predicates/provenance ID, confidence and verdict. CSV is *evidence output only*, never an import surface.

Keep the detailed private evidence outside tracked Git, e.g. an existing ignored `.l9/runtime/...` directory after checking `.gitignore`: `source_id_inventory`, source-ID-level linkage exceptions, local sampled binary files, exact SQL query logs, content hashes and timings. List these private file *roles* and verification hashes in the report, but no raw private paths. If a private file is absent on a later machine, the pack must still communicate what to rerun and why.

Optional extra tracked files require a demonstrated information need that cannot be satisfied by these three (smallest sufficient artifact policy). Do not copy old reports, screenshots, the source `.bak`, BLOBs, huge extracted grids, or source DB-specific strings into Git.

### Required `RECON_REPORT.md` decision summary table

| Question | Status | Count / evidence | Remaining obligation |
|---|---|---|---|
| Transaction DB restored | PROVEN/PARTIAL/BLOCKED | source snapshot | ... |
| Document DB restored | PROVEN/PARTIAL/BLOCKED | backup fingerprint | ... |
| Document storage inventory complete | ... | table/surface census | ... |
| All eligible BLOB rows counted | ... | rows + bytes | ... |
| File MIME proven across complete population | ... | decoded/unknown | ... |
| RefType meanings independently established | ... | W/P/E/other by count | ... |
| Source linkage unambiguous | ... | rows/docs/percent and denominator | ... |
| Odoo identity destination available | ... | types/coverage | ... |
| Native Documents/PlasticOS bridge verified | ... | module and model proof | ... |
| Bulk import ready to design | YES/NO/BLOCKED | required gates | ... |

### Final operator-facing response from Cursor

Return concise bullets with: (1) discovered backup coverage; (2) complete physical/doc/media/linkage counts, clearly marking anything partial; (3) top blockers + verified root causes; (4) read-only Docker run evidence and report file paths; (5) committed branch/PR URL only if published under approved Odoo flow; and (6) the **next highest leverage move**. If document DB is missing, state the required backup precisely by role. Do not ask the operator to run SQL.

## 10. Gates, completion, and stop conditions

| Gate | Mandatory proof | Failure disposition |
|---|---|---|
| G0 source binding | checkout/base HEAD, `.bak` fingerprint and safe Docker identity | stop or PARTIAL, no guessed restore |
| G1 document-store availability | real doc DB and transaction DB, separately verified | BLOCKED for content/linkage if absent |
| G2 source schema | source object/PK/FK/column catalogue and eligible-scope predicate | UNKNOWN remains UNKNOWN |
| G3 complete census | exact per-source row/byte/type/NULL/duplicate totals | PARTIAL if truncated |
| G4 content inspection | file decode, MIME and checksum proof with measured coverage | samples never imply full-format census |
| G5 identity joins | both DocID and RefID hypotheses, all RefTypes, full 0/1/many reconciliation | ambiguous stays quarantined |
| G6 Odoo mapping feasibility | actual importer model/identity paths, module presence and smart-button proof | no invented fields or heuristics |
| G7 reproducibility | repeat probe yields same counts, hashes and join outcomes | differences investigated, not waved away |
| G8 clean publication | report-only diff, privacy and naming checks; Odoo branch/PR path | no merge/deploy/unsafe push |

**Completion rule:** Every question and finding must be marked `PROVEN`, `INVALID`, or `BLOCKED/PARTIAL` with evidence and next requirement. No silent omissions. A missing document backup is a valid, documented reconnaissance blocker, not permission to claim zero docs or extrapolate from screenshots. Success means the operator can authorize a separately scoped **SQL BLOB → Odoo attached-documents import** on facts instead of assumptions.

## 11. Non-goals and Phase 2 boundary

**Do not do now:** importing even one historical document into Odoo; changing Odoo models, import reader or manifests; enabling native Documents on an unapproved DB; performing production restores; OCR, text extraction or AI classification of customer documents; converting all images to PDF; deleting duplicates; reconstructing multi-page documents without proven order; emailing PaperSolve; replacing the source importer or adding a parallel copy pipeline; moving attachments into cloud storage; scheduling continuing scans.

**Future campaign** (spec only): Extend the existing deterministic direct-SQL importer with a bounded, streaming binary-attachment stage keyed by verified source-native image/document identities, exact-source transaction mapping, proper native Enterprise document and `ir.attachment` persistence, legacy document bridge/smart-button correctness, full-count reconciliation, permissions and storage limits, corruption isolation, and *identical replay with zero duplicates*. Only after recon verifies the exact source join, resource budget and installed target models can this implementation be authorized.

**Architecture constraint:** agents execute, skills teach, gates enforce, rules govern. Follow existing Odoo and Cursor tooling authorities; do not author competing instructions or invent a new importer architecture.
