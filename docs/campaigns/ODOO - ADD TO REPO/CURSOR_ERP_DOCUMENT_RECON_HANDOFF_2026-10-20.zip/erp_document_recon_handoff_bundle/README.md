# Historical ERP Document Reconnaissance: Cursor Handoff

Open `CURSOR_RECON_CONTRACT.md` in Cursor attached to `cryptoxdog/IB-Odoo_19` and give C the instruction below. The mission is exploratory and produces a **new report** in `docs/reports`, not an import.

> Execute `CURSOR_RECON_CONTRACT.md` as the governing read-only reconnaissance campaign on the current `origin/Staging`-based checkout. Use Docker and the operator's local SQL Server backup(s). Do all SQL and forensic work yourself. Produce and validate the exact report pack under `docs/reports/erp-document-blob-recon-2026-10-20/`; publish via the repository's existing Odoo reporting/PR flow, without merge or deployment. If the separate document database is missing, return a truthful partial report and identify the exact missing asset; do not substitute speculation. No production writes or importer code changes.

This bundle contains instructions only, no source backups, private documents or application modifications.
